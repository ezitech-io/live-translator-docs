"use strict";
(() => {
  // src-bex/mic-interceptor.ts
  var LOG = "[MicInterceptor]";
  var virtualMic = null;
  var storedRealStream = null;
  function base64ToUint8Array(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
  function int16ToFloat32(int16) {
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = (int16[i] ?? 0) / 32768;
    }
    return float32;
  }
  function storeRealStream(stream) {
    storedRealStream = stream;
  }
  function wrapStream(realStream) {
    storedRealStream = realStream;
    if (virtualMic) {
      connectRealMic(realStream);
      return virtualMic.destination.stream;
    }
    const audioCtx = new AudioContext();
    if (audioCtx.state === "suspended") {
      void audioCtx.resume();
    }
    const destination = audioCtx.createMediaStreamDestination();
    destination.channelCount = 1;
    destination.channelCountMode = "explicit";
    const micGain = audioCtx.createGain();
    micGain.channelCount = 1;
    micGain.channelCountMode = "explicit";
    micGain.gain.setValueAtTime(0, audioCtx.currentTime);
    micGain.connect(destination);
    virtualMic = {
      audioCtx,
      destination,
      micGain,
      micSource: null,
      realStream: null,
      nextPlayTime: 0,
      isInjecting: false,
      lastSourceNode: null,
      onInjectionDone: null,
      leftoverPcmByte: null
    };
    connectRealMic(realStream);
    return destination.stream;
  }
  function connectRealMic(realStream) {
    if (!virtualMic) return;
    if (virtualMic.micSource) {
      try {
        virtualMic.micSource.disconnect();
      } catch {
      }
    }
    virtualMic.realStream = realStream;
    virtualMic.micSource = virtualMic.audioCtx.createMediaStreamSource(realStream);
    virtualMic.micSource.connect(virtualMic.micGain);
  }
  function setMicGain(gain) {
    if (!virtualMic) return;
    if (virtualMic.audioCtx.state === "suspended") {
      void virtualMic.audioCtx.resume();
    }
    virtualMic.micGain.gain.setValueAtTime(gain, virtualMic.audioCtx.currentTime);
  }
  async function ensureAudioCtxRunning() {
    if (!virtualMic) return;
    if (virtualMic.audioCtx.state !== "running") {
      await virtualMic.audioCtx.resume();
    }
  }
  function getAudioCtxState() {
    return virtualMic?.audioCtx?.state ?? "no-context";
  }
  function activateVirtualMic() {
    if (!storedRealStream) return null;
    const virtualStream = wrapStream(storedRealStream);
    return virtualStream.getAudioTracks()[0] ?? null;
  }
  function deactivateVirtualMic() {
    if (!virtualMic) return;
    try {
      virtualMic.micSource?.disconnect();
    } catch {
    }
    try {
      virtualMic.micGain.disconnect();
    } catch {
    }
    try {
      void virtualMic.audioCtx.close();
    } catch {
    }
    virtualMic = null;
  }
  function getVirtualTrack() {
    return virtualMic?.destination.stream.getAudioTracks()[0] ?? null;
  }
  function getDestinationTrack() {
    const track = virtualMic?.destination.stream.getAudioTracks()[0];
    return track && track.readyState === "live" ? track : null;
  }
  function getStoredRealTrack() {
    return storedRealStream?.getAudioTracks()[0] ?? null;
  }
  function startInjection(onDone) {
    if (!virtualMic) return;
    virtualMic.isInjecting = true;
    virtualMic.lastSourceNode = null;
    virtualMic.onInjectionDone = onDone;
    virtualMic.leftoverPcmByte = null;
  }
  function injectAudioChunk(pcm16Base64, sampleRate) {
    if (!virtualMic) return;
    try {
      if (virtualMic.audioCtx.state === "suspended") {
        void virtualMic.audioCtx.resume();
      }
      const incomingBytes = base64ToUint8Array(pcm16Base64);
      let mergedBytes = incomingBytes;
      if (virtualMic.leftoverPcmByte !== null) {
        const prefixed = new Uint8Array(incomingBytes.length + 1);
        prefixed[0] = virtualMic.leftoverPcmByte;
        prefixed.set(incomingBytes, 1);
        mergedBytes = prefixed;
        virtualMic.leftoverPcmByte = null;
      }
      if ((mergedBytes.length & 1) === 1) {
        virtualMic.leftoverPcmByte = mergedBytes[mergedBytes.length - 1] ?? null;
        mergedBytes = mergedBytes.subarray(0, mergedBytes.length - 1);
      }
      if (mergedBytes.length === 0) return;
      const int16 = new Int16Array(
        mergedBytes.buffer,
        mergedBytes.byteOffset,
        mergedBytes.byteLength / 2
      );
      const float32 = int16ToFloat32(int16);
      const buffer = virtualMic.audioCtx.createBuffer(1, float32.length, sampleRate);
      buffer.getChannelData(0).set(float32);
      const source = virtualMic.audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(virtualMic.destination);
      source.addEventListener("ended", () => {
        try {
          source.disconnect();
        } catch {
        }
      }, { once: true });
      const now = virtualMic.audioCtx.currentTime;
      const startTime = Math.max(now, virtualMic.nextPlayTime);
      source.start(startTime);
      virtualMic.nextPlayTime = startTime + buffer.duration;
      virtualMic.lastSourceNode = source;
    } catch (err) {
      console.warn(LOG, "Failed to inject audio chunk:", err);
    }
  }
  function stopInjection() {
    if (!virtualMic) return;
    virtualMic.isInjecting = false;
    const lastNode = virtualMic.lastSourceNode;
    const capturedDone = virtualMic.onInjectionDone;
    virtualMic.onInjectionDone = null;
    if (!capturedDone) return;
    const remainingMs = Math.max(0, (virtualMic.nextPlayTime - virtualMic.audioCtx.currentTime) * 1e3);
    if (remainingMs <= 0 || !lastNode) {
      capturedDone();
      return;
    }
    let resolved = false;
    const resolve = () => {
      if (resolved) return;
      resolved = true;
      capturedDone();
    };
    lastNode.addEventListener("ended", resolve, { once: true });
    setTimeout(resolve, remainingMs + 500);
  }
  function isActive() {
    return virtualMic !== null;
  }
  function isVirtualStream(stream) {
    if (!virtualMic) return false;
    return stream === virtualMic.destination.stream;
  }
  function dispose() {
    if (virtualMic) {
      try {
        virtualMic.micSource?.disconnect();
      } catch {
      }
      try {
        virtualMic.micGain.disconnect();
      } catch {
      }
      try {
        void virtualMic.audioCtx.close();
      } catch {
      }
      virtualMic = null;
    }
    storedRealStream = null;
  }

  // src-bex/platform-strategy.ts
  var PLATFORM_WRAP_STRATEGY = {
    "web.whatsapp.com": "always",
    "zoom.us": "always",
    "teams.microsoft.com": "always",
    "teams.live.com": "always",
    "meet.google.com": "deferred"
  };
  function resolveWrapStrategy(hostname) {
    for (const [pattern, strategy] of Object.entries(PLATFORM_WRAP_STRATEGY)) {
      if (hostname.includes(pattern)) return strategy;
    }
    return "deferred";
  }
  function detectPlatform(hostname) {
    if (hostname.includes("meet.google.com")) return "meet";
    if (hostname.includes("zoom.us")) return "zoom";
    if (hostname.includes("teams.microsoft.com") || hostname.includes("teams.live.com")) return "teams";
    if (hostname.includes("web.whatsapp.com")) return "whatsapp";
    return "unknown";
  }

  // src-bex/mic-interceptor-inject.ts
  var LOG2 = "[MicInterceptor:MAIN]";
  var shouldWrap = false;
  var getUserMediaCallCount = 0;
  var alwaysWrapHandled = false;
  var wrapStrategy = resolveWrapStrategy(location.hostname);
  var alwaysWrap = wrapStrategy === "always";
  var ourStreams = /* @__PURE__ */ new WeakSet();
  var inIframe = window !== window.top;
  function broadcastMessage(msg, targetOrigin = "*") {
    window.postMessage(msg, targetOrigin);
    if (inIframe) {
      try {
        window.parent.postMessage(msg, targetOrigin);
      } catch {
      }
    }
  }
  console.info(LOG2, "Initialized", { platform: detectPlatform(location.hostname), wrapStrategy, inIframe });
  var originalGUM = Object.getOwnPropertyDescriptor(
    MediaDevices.prototype,
    "getUserMedia"
  ).value;
  async function patchedGetUserMedia(constraints) {
    const callId = ++getUserMediaCallCount;
    const stream = await originalGUM.call(this, constraints);
    if (constraints?.audio) {
      if (alwaysWrap) {
        const isFirstCall = !alwaysWrapHandled;
        try {
          interceptingCreateMSS = true;
          try {
            wrapStream(stream);
          } finally {
            interceptingCreateMSS = false;
          }
          if (isFirstCall) {
            alwaysWrapHandled = true;
            await ensureAudioCtxRunning();
          }
          const gain = shouldWrap ? 0 : 1;
          setMicGain(gain);
          const sourceTrack = getDestinationTrack();
          if (!sourceTrack) {
            console.warn(LOG2, `getUserMedia#${callId} destination track dead, falling back`);
            storeRealStream(stream);
            if (isFirstCall) alwaysWrapHandled = false;
            reportStatus();
            return stream;
          }
          const clonedTrack = sourceTrack.clone();
          const videoTracks = stream.getVideoTracks();
          const result = new MediaStream([clonedTrack, ...videoTracks]);
          ourStreams.add(result);
          reportStatus();
          return result;
        } catch (err) {
          console.warn(LOG2, `getUserMedia#${callId} wrap failed, returning original:`, err);
        }
      } else if (shouldWrap) {
        try {
          const wrapped = wrapStream(stream);
          ourStreams.add(wrapped);
          reportStatus();
          return wrapped;
        } catch (err) {
          console.warn(LOG2, "Failed to wrap stream, returning original:", err);
        }
      } else {
        storeRealStream(stream);
      }
      reportStatus();
    }
    return stream;
  }
  navigator.mediaDevices.getUserMedia = patchedGetUserMedia;
  MediaDevices.prototype.getUserMedia = patchedGetUserMedia;
  if ("getUserMedia" in navigator) {
    const origLegacy = navigator.getUserMedia;
    if (typeof origLegacy === "function") {
      ;
      navigator.getUserMedia = function(constraints, onSuccess, onError) {
        patchedGetUserMedia.call(navigator.mediaDevices, constraints).then(onSuccess, onError);
      };
    }
  }
  var interceptingCreateMSS = false;
  var originalCreateMSS = Object.getOwnPropertyDescriptor(
    AudioContext.prototype,
    "createMediaStreamSource"
  ).value;
  AudioContext.prototype.createMediaStreamSource = function(stream) {
    if (interceptingCreateMSS) {
      return originalCreateMSS.call(this, stream);
    }
    const audioTracks = stream.getAudioTracks();
    if (alwaysWrap && !alwaysWrapHandled && audioTracks.length > 0 && !ourStreams.has(stream) && !isVirtualStream(stream)) {
      interceptingCreateMSS = true;
      try {
        storeRealStream(stream);
        const virtualStream = wrapStream(stream);
        ourStreams.add(virtualStream);
        alwaysWrapHandled = true;
        setMicGain(shouldWrap ? 0 : 1);
        void ensureAudioCtxRunning();
        const sourceNode = originalCreateMSS.call(this, virtualStream);
        reportStatus();
        return sourceNode;
      } catch (err) {
        console.warn(LOG2, "createMSS: swap failed, passing through:", err);
        alwaysWrapHandled = false;
      } finally {
        interceptingCreateMSS = false;
      }
    }
    return originalCreateMSS.call(this, stream);
  };
  var audioSenders = /* @__PURE__ */ new Set();
  var trackedPCs = /* @__PURE__ */ new Set();
  if (typeof RTCPeerConnection !== "undefined") {
    const NativeRTCPeerConnection = window.RTCPeerConnection;
    window.RTCPeerConnection = new Proxy(NativeRTCPeerConnection, {
      construct(target, args, newTarget) {
        const pc = Reflect.construct(target, args, newTarget);
        trackedPCs.add(pc);
        pc.addEventListener("connectionstatechange", () => {
          if (pc.connectionState === "closed" || pc.connectionState === "failed") {
            trackedPCs.delete(pc);
          }
        });
        return pc;
      }
    });
    const addTrackDescriptor = Object.getOwnPropertyDescriptor(NativeRTCPeerConnection.prototype, "addTrack");
    const originalAddTrack = addTrackDescriptor?.value;
    if (originalAddTrack) {
      NativeRTCPeerConnection.prototype.addTrack = function(track, ...streams) {
        const sender = originalAddTrack.call(this, track, ...streams);
        if (track.kind === "audio") {
          audioSenders.add(sender);
          if (shouldWrap) {
            const virtualTrack = getVirtualTrack();
            if (virtualTrack) {
              void sender.replaceTrack(virtualTrack).catch(
                (err) => console.warn(LOG2, "Auto-replaceTrack on new sender failed:", err)
              );
            }
          }
        }
        return sender;
      };
    }
    const addTransceiverDescriptor = Object.getOwnPropertyDescriptor(NativeRTCPeerConnection.prototype, "addTransceiver");
    const originalAddTransceiver = addTransceiverDescriptor?.value;
    if (originalAddTransceiver) {
      NativeRTCPeerConnection.prototype.addTransceiver = function(trackOrKind, init) {
        const transceiver = originalAddTransceiver.call(this, trackOrKind, init);
        const isAudio = typeof trackOrKind === "string" ? trackOrKind === "audio" : trackOrKind.kind === "audio";
        if (isAudio) {
          audioSenders.add(transceiver.sender);
          if (shouldWrap) {
            const virtualTrack = getVirtualTrack();
            if (virtualTrack) {
              void transceiver.sender.replaceTrack(virtualTrack).catch(
                (err) => console.warn(LOG2, "Auto-replaceTrack on transceiver sender failed:", err)
              );
            }
          }
        }
        return transceiver;
      };
    }
  }
  if (typeof RTCRtpSender !== "undefined") {
    const replaceTrackDescriptor = Object.getOwnPropertyDescriptor(RTCRtpSender.prototype, "replaceTrack");
    const originalReplaceTrack = replaceTrackDescriptor?.value;
    if (originalReplaceTrack) {
      RTCRtpSender.prototype.replaceTrack = function(track) {
        if (shouldWrap && audioSenders.has(this)) {
          const virtualTrack = getVirtualTrack();
          if (virtualTrack && track !== null && track !== virtualTrack) {
            return originalReplaceTrack.call(this, virtualTrack);
          }
        }
        return originalReplaceTrack.call(this, track);
      };
    }
  }
  function discoverAudioSenders() {
    for (const pc of trackedPCs) {
      try {
        if (pc.connectionState === "closed" || pc.connectionState === "failed") {
          trackedPCs.delete(pc);
          continue;
        }
        if (typeof pc.getTransceivers === "function") {
          for (const transceiver of pc.getTransceivers()) {
            const sender = transceiver.sender;
            if (audioSenders.has(sender)) continue;
            const isAudio = sender.track?.kind === "audio" || transceiver.receiver?.track?.kind === "audio";
            if (isAudio) audioSenders.add(sender);
          }
        } else {
          for (const sender of pc.getSenders()) {
            if (sender.track?.kind === "audio" && !audioSenders.has(sender)) {
              audioSenders.add(sender);
            }
          }
        }
      } catch {
      }
    }
  }
  async function replaceTrackOnAllSenders(newTrack) {
    discoverAudioSenders();
    if (audioSenders.size === 0) return;
    const invalid = [];
    for (const sender of audioSenders) {
      try {
        await sender.replaceTrack(newTrack);
      } catch {
        invalid.push(sender);
      }
    }
    for (const s of invalid) audioSenders.delete(s);
  }
  function reportStatus() {
    broadcastMessage({
      source: "live-translator-mic-interceptor",
      type: "VIRTUAL_MIC_STATUS",
      payload: {
        supported: true,
        active: isActive(),
        wrapping: shouldWrap,
        alwaysWrap,
        alwaysWrapHandled,
        wrapStrategy,
        platform: detectPlatform(location.hostname),
        senders: audioSenders.size,
        peerConnections: trackedPCs.size,
        audioCtxState: getAudioCtxState(),
        inIframe
      }
    });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window && event.source !== window.parent) return;
    const data = event.data;
    if (data?.source !== "live-translator-panel-relay") return;
    switch (data.type) {
      case "ACTIVATE_VIRTUAL_MIC": {
        shouldWrap = true;
        if (alwaysWrap) {
          void ensureAudioCtxRunning().then(() => {
            setMicGain(0);
          });
        }
        const virtualTrack = activateVirtualMic();
        if (virtualTrack) {
          void replaceTrackOnAllSenders(virtualTrack);
        }
        broadcastMessage({
          source: "live-translator-mic-interceptor",
          type: "VIRTUAL_MIC_ACTIVATED",
          payload: { active: true, alwaysWrap, wrapStrategy }
        });
        reportStatus();
        break;
      }
      case "DEACTIVATE_VIRTUAL_MIC": {
        shouldWrap = false;
        if (alwaysWrap) {
          setMicGain(1);
        } else {
          const realTrack = getStoredRealTrack();
          if (realTrack) {
            void replaceTrackOnAllSenders(realTrack).then(() => deactivateVirtualMic());
          } else {
            deactivateVirtualMic();
          }
        }
        broadcastMessage({
          source: "live-translator-mic-interceptor",
          type: "VIRTUAL_MIC_DEACTIVATED",
          payload: { active: false }
        });
        reportStatus();
        break;
      }
      case "START_AUDIO_INJECTION":
        startInjection(() => {
          broadcastMessage({
            source: "live-translator-mic-interceptor",
            type: "AUDIO_INJECTION_DONE"
          });
        });
        break;
      case "INJECT_AUDIO_CHUNK":
        if (data.pcm16Base64 && data.sampleRate) {
          injectAudioChunk(data.pcm16Base64, data.sampleRate);
        }
        break;
      case "STOP_AUDIO_INJECTION":
        stopInjection();
        break;
      case "REQUEST_STATUS":
        reportStatus();
        break;
      case "DISPOSE":
        shouldWrap = false;
        if (alwaysWrap) {
          setMicGain(1);
        } else {
          dispose();
        }
        break;
    }
  });
  reportStatus();
})();
