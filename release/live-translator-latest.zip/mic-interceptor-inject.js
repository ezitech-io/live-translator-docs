"use strict";
(() => {
  // src-bex/mic-interceptor.ts
  var LOG = "[MicInterceptor]";
  var virtualMic = null;
  function base64ToInt16Array(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Int16Array(bytes.buffer);
  }
  function int16ToFloat32(int16) {
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = (int16[i] ?? 0) / 32768;
    }
    return float32;
  }
  function wrapStream(realStream) {
    if (virtualMic) {
      connectRealMic(realStream);
      return virtualMic.destination.stream;
    }
    const audioCtx = new AudioContext({ sampleRate: 24e3 });
    const destination = audioCtx.createMediaStreamDestination();
    const micGain = audioCtx.createGain();
    micGain.gain.setValueAtTime(1, audioCtx.currentTime);
    micGain.connect(destination);
    virtualMic = {
      audioCtx,
      destination,
      micGain,
      micSource: null,
      realStream: null,
      nextPlayTime: 0,
      isInjecting: false,
      lastSourceNode: null,
      onInjectionDone: null
    };
    connectRealMic(realStream);
    console.log(LOG, "Virtual mic created, wrapping real stream");
    return destination.stream;
  }
  function connectRealMic(realStream) {
    if (!virtualMic) return;
    if (virtualMic.micSource) {
      try {
        virtualMic.micSource.disconnect();
      } catch {
      }
    }
    virtualMic.realStream = realStream;
    virtualMic.micSource = virtualMic.audioCtx.createMediaStreamSource(realStream);
    virtualMic.micSource.connect(virtualMic.micGain);
    console.log(LOG, "Real mic connected through GainNode");
  }
  function muteRealMic() {
    if (!virtualMic) return;
    virtualMic.micGain.gain.setValueAtTime(0, virtualMic.audioCtx.currentTime);
    console.log(LOG, "Real mic muted");
  }
  function unmuteRealMic() {
    if (!virtualMic) return;
    virtualMic.micGain.gain.setValueAtTime(1, virtualMic.audioCtx.currentTime);
    console.log(LOG, "Real mic unmuted");
  }
  function startInjection(onDone) {
    if (!virtualMic) return;
    virtualMic.nextPlayTime = 0;
    virtualMic.isInjecting = true;
    virtualMic.lastSourceNode = null;
    virtualMic.onInjectionDone = onDone;
  }
  function injectAudioChunk(pcm16Base64, sampleRate) {
    if (!virtualMic) return;
    try {
      if (virtualMic.audioCtx.state === "suspended") {
        void virtualMic.audioCtx.resume();
      }
      const int16 = base64ToInt16Array(pcm16Base64);
      const float32 = int16ToFloat32(int16);
      const buffer = virtualMic.audioCtx.createBuffer(1, float32.length, sampleRate);
      buffer.getChannelData(0).set(float32);
      const source = virtualMic.audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(virtualMic.destination);
      const now = virtualMic.audioCtx.currentTime;
      const startTime = Math.max(now, virtualMic.nextPlayTime);
      source.start(startTime);
      virtualMic.nextPlayTime = startTime + buffer.duration;
      virtualMic.lastSourceNode = source;
    } catch (err) {
      console.warn(LOG, "Failed to inject audio chunk:", err);
    }
  }
  function stopInjection() {
    if (!virtualMic) return;
    virtualMic.isInjecting = false;
    const remainingMs = Math.max(0, (virtualMic.nextPlayTime - virtualMic.audioCtx.currentTime) * 1e3);
    if (remainingMs <= 0) {
      virtualMic.onInjectionDone?.();
      virtualMic.onInjectionDone = null;
    } else {
      setTimeout(() => {
        virtualMic?.onInjectionDone?.();
        if (virtualMic) virtualMic.onInjectionDone = null;
      }, remainingMs + 50);
    }
  }
  function isActive() {
    return virtualMic !== null;
  }
  function dispose() {
    if (!virtualMic) return;
    try {
      virtualMic.micSource?.disconnect();
    } catch {
    }
    try {
      virtualMic.micGain.disconnect();
    } catch {
    }
    try {
      void virtualMic.audioCtx.close();
    } catch {
    }
    virtualMic = null;
    console.log(LOG, "Virtual mic disposed");
  }

  // src-bex/mic-interceptor-inject.ts
  var LOG2 = "[MicInterceptor:MAIN]";
  var originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  navigator.mediaDevices.getUserMedia = async function(constraints) {
    const stream = await originalGetUserMedia(constraints);
    if (constraints?.audio) {
      try {
        const wrapped = wrapStream(stream);
        console.log(LOG2, "getUserMedia intercepted \u2014 returning virtual mic stream");
        reportStatus();
        return wrapped;
      } catch (err) {
        console.warn(LOG2, "Failed to wrap stream, returning original:", err);
      }
    }
    return stream;
  };
  console.log(LOG2, "getUserMedia patched");
  function detectPlatform() {
    const host = location.hostname;
    if (host.includes("meet.google.com")) return "meet";
    if (host.includes("zoom.us")) return "zoom";
    if (host.includes("teams.microsoft.com") || host.includes("teams.live.com")) return "teams";
    return "unknown";
  }
  function reportStatus() {
    window.postMessage({
      source: "live-translator-mic-interceptor",
      type: "VIRTUAL_MIC_STATUS",
      payload: {
        supported: true,
        active: isActive(),
        platform: detectPlatform()
      }
    }, "*");
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (data?.source !== "live-translator-panel-relay") return;
    switch (data.type) {
      case "MUTE_REAL_MIC":
        muteRealMic();
        break;
      case "UNMUTE_REAL_MIC":
        unmuteRealMic();
        break;
      case "START_AUDIO_INJECTION":
        startInjection(() => {
          window.postMessage({
            source: "live-translator-mic-interceptor",
            type: "AUDIO_INJECTION_DONE"
          }, "*");
        });
        break;
      case "INJECT_AUDIO_CHUNK":
        if (data.pcm16Base64 && data.sampleRate) {
          injectAudioChunk(data.pcm16Base64, data.sampleRate);
        }
        break;
      case "STOP_AUDIO_INJECTION":
        stopInjection();
        break;
      case "REQUEST_STATUS":
        reportStatus();
        break;
      case "DISPOSE":
        dispose();
        break;
    }
  });
  reportStatus();
})();
