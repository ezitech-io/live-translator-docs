import { H as markRaw, L as withDirectives, W as reactive, Z as unref, _ as defineComponent, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
//#region node_modules/quasar/src/utils/private.inject-obj-prop/inject-obj-prop.js
function injectProp(target, propName, get, set) {
	Object.defineProperty(target, propName, {
		get,
		set,
		enumerable: true
	});
	return target;
}
//#endregion
//#region node_modules/quasar/src/utils/private.create/create.js
function createComponent(raw) {
	return markRaw(defineComponent(raw));
}
function createDirective(raw) {
	return markRaw(raw);
}
var createReactivePlugin = (state, plugin) => {
	const reactiveState = reactive(state);
	for (const name in state) injectProp(plugin, name, () => reactiveState[name], (val) => {
		reactiveState[name] = val;
	});
	return plugin;
};
//#endregion
//#region node_modules/quasar/src/utils/event/event.js
var listenOpts = {
	hasPassive: false,
	passiveCapture: true,
	notPassiveCapture: true
};
try {
	const opts = Object.defineProperty({}, "passive", { get() {
		Object.assign(listenOpts, {
			hasPassive: true,
			passive: { passive: true },
			notPassive: { passive: false },
			passiveCapture: {
				passive: true,
				capture: true
			},
			notPassiveCapture: {
				passive: false,
				capture: true
			}
		});
	} });
	window.addEventListener("qtest", null, opts);
	window.removeEventListener("qtest", null, opts);
} catch (_) {}
function noop() {}
function leftClick(e) {
	return e.button === 0;
}
function position(e) {
	if (e.touches && e.touches[0]) e = e.touches[0];
	else if (e.changedTouches && e.changedTouches[0]) e = e.changedTouches[0];
	else if (e.targetTouches && e.targetTouches[0]) e = e.targetTouches[0];
	return {
		top: e.clientY,
		left: e.clientX
	};
}
function getEventPath(e) {
	if (e.path) return e.path;
	if (e.composedPath) return e.composedPath();
	const path = [];
	let el = e.target;
	while (el) {
		path.push(el);
		if (el.tagName === "HTML") {
			path.push(document);
			path.push(window);
			return path;
		}
		el = el.parentElement;
	}
}
function stop(e) {
	e.stopPropagation();
}
function prevent(e) {
	e.cancelable !== false && e.preventDefault();
}
function stopAndPrevent(e) {
	e.cancelable !== false && e.preventDefault();
	e.stopPropagation();
}
function preventDraggable(el, status) {
	if (el === void 0 || status === true && el.__dragPrevented === true) return;
	const fn = status === true ? (el) => {
		el.__dragPrevented = true;
		el.addEventListener("dragstart", prevent, listenOpts.notPassiveCapture);
	} : (el) => {
		delete el.__dragPrevented;
		el.removeEventListener("dragstart", prevent, listenOpts.notPassiveCapture);
	};
	el.querySelectorAll("a, img").forEach(fn);
}
function addEvt(ctx, targetName, events) {
	const name = `__q_${targetName}_evt`;
	ctx[name] = ctx[name] !== void 0 ? ctx[name].concat(events) : events;
	events.forEach((evt) => {
		evt[0].addEventListener(evt[1], ctx[evt[2]], listenOpts[evt[3]]);
	});
}
function cleanEvt(ctx, targetName) {
	const name = `__q_${targetName}_evt`;
	if (ctx[name] !== void 0) {
		ctx[name].forEach((evt) => {
			evt[0].removeEventListener(evt[1], ctx[evt[2]], listenOpts[evt[3]]);
		});
		ctx[name] = void 0;
	}
}
//#endregion
//#region node_modules/quasar/src/utils/private.render/render.js
function hSlot(slot, otherwise) {
	return slot !== void 0 ? slot() || otherwise : otherwise;
}
function hUniqueSlot(slot, otherwise) {
	if (slot !== void 0) {
		const vnode = slot();
		if (vnode !== void 0 && vnode !== null) return vnode.slice();
	}
	return otherwise;
}
/**
* Source definitely exists,
* so it's merged with the possible slot
*/
function hMergeSlot(slot, source) {
	return slot !== void 0 ? source.concat(slot()) : source;
}
/**
* Merge with possible slot,
* even if source might not exist
*/
function hMergeSlotSafely(slot, source) {
	if (slot === void 0) return source;
	return source !== void 0 ? source.concat(slot()) : slot();
}
function hDir(tag, data, children, key, condition, getDirsFn) {
	data.key = key + condition;
	const vnode = h(tag, data, children);
	return condition === true ? withDirectives(vnode, getDirsFn()) : vnode;
}
//#endregion
//#region node_modules/quasar/src/utils/dom/dom.js
function css(element, css) {
	const style = element.style;
	for (const prop in css) style[prop] = css[prop];
}
function getElement(el) {
	if (el === void 0 || el === null) return;
	if (typeof el === "string") try {
		return document.querySelector(el) || void 0;
	} catch (err) {
		return;
	}
	const target = unref(el);
	if (target) return target.$el || target;
}
function childHasFocus(el, focusedEl) {
	if (el === void 0 || el === null || el.contains(focusedEl) === true) return true;
	for (let next = el.nextElementSibling; next !== null; next = next.nextElementSibling) if (next.contains(focusedEl)) return true;
	return false;
}
//#endregion
export { injectProp as C, createReactivePlugin as S, preventDraggable as _, hMergeSlot as a, createComponent as b, hUniqueSlot as c, getEventPath as d, leftClick as f, prevent as g, position as h, hDir as i, addEvt as l, noop as m, css as n, hMergeSlotSafely as o, listenOpts as p, getElement as r, hSlot as s, childHasFocus as t, cleanEvt as u, stop as v, createDirective as x, stopAndPrevent as y };
