const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BexLayout-lZsJkOj5.js","./_plugin-vue_export-helper-Xbx7mXmu.js","./dom-ClQ5j7De.js","./vue.runtime.esm-bundler-dwk6Qeub.js","./QResizeObserver-y6jkY3kf.js","./Platform-DVLU8Kjq.js","./BexLayout-BEVozLSk.css","./TranslatorPage-Crkpck8y.js","./vue-i18n.runtime-0_E2riTW.js","./use-quasar-DhYvgUB3.js","./vm-BBDykFtW.js","./position-engine-B68WAgD4.js","./QPage-BSDss9Gk.js","./QTooltip-Bi3BldQd.js","./useSubtitleSync-DENG9ngW.js","./settings-store-shjF23n8.js","./TranslatorPage-CjsOQfGD.css","./AssistantPage-B1_zPi0t.js","./AssistantPage-Cz3TGlkW.css","./SubtitlePage-Bsx5aCVk.js","./SubtitlePage-Dem5ltU6.css","./SettingsPage-DvL3mpg3.js","./SettingsPage-C6nberD1.css","./ErrorNotFound-BeelMfgp.js","./i18n-CNFYrHnB.js"])))=>i.map(i=>d[i]);
import { B as isReactive, F as watch, G as ref, H as markRaw, J as toRaw, K as shallowReactive, L as withDirectives, M as provide, P as resolveComponent, R as effectScope, S as nextTick, T as onBeforeUnmount, U as onScopeDispose, V as isRef, W as reactive, X as toRefs, Y as toRef, Z as unref, _ as defineComponent, b as hasInjectionContext, f as createBlock, i as createApp, j as openBlock, n as Transition, q as shallowRef, r as TransitionGroup, u as computed, v as getCurrentInstance, x as inject, y as h, z as getCurrentScope } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { C as injectProp, S as createReactivePlugin, a as hMergeSlot, b as createComponent, g as prevent, h as position, l as addEvt, m as noop$2, n as css, o as hMergeSlotSafely, p as listenOpts, u as cleanEvt, v as stop, x as createDirective, y as stopAndPrevent } from "./dom-ClQ5j7De.js";
import { n as client, r as isRuntimeSsrPreHydration, t as Platform } from "./Platform-DVLU8Kjq.js";
import { a as useSizeDefaults, c as isKeyCode, i as QIcon_default, l as onKeyDownComposition, n as vmHasRouter, o as useSizeProps, s as use_size_default } from "./vm-BBDykFtW.js";
//#region node_modules/@quasar/app-vite/exports/bex/private/bex-bridge.js
var portNameRE = /^background$|^app$|^content@/;
var { runtime } = chrome;
/**
* @param {number} max
* @returns {number}
*/
function getRandomId(max) {
	return Math.floor(Math.random() * max);
}
/**
* @typedef Message
* @property {string} from
* @property {string} to
* @property {string} event
* @property {any} payload
*/
var BexBridge = class {
	/** @type {string} */
	portName = null;
	/** @type {boolean} */
	isConnected = false;
	/** @type {{ type: 'on' | 'once', callback: (message: Message) => void }[]} */
	listeners = {};
	/** @type {{ [portName: string]: chrome.runtime.Port }} */
	portMap = {};
	/** @type {string[]} */
	portList = [];
	/** @type {{ [id: string]: { portName: string, resolve: (payload: any) => void, reject: (err: any) => void } }} */
	messageMap = {};
	/** @type {{ [id: string]: { portName: string, number: number, messageType: string, messageProps: any, payload: any[] } }} */
	chunkMap = {};
	/** @type {'background' | 'content' | 'app'} */
	#type;
	/** @type {boolean} */
	#debug = false;
	/** @type {string} */
	#banner;
	/**
	* @param {{ type: 'background' | 'content' | 'app', name?: string, debug?: boolean }} options
	*/
	constructor({ type, name = "", debug }) {
		this.portName = type;
		this.#type = type;
		if (type === "content")
 /**
		* There can be multiple instances of the same content script
		* but for different tabs, so we need to differentiate them.
		*
		* Generating an easy to handle id for the content script.
		*/
		this.portName = `${type}@${name}-${getRandomId(1e4)}`;
		this.#banner = `[QBex|${this.portName}]`;
		this.#debug = debug === true;
		if (type !== "background") {
			this.on("@quasar:ports", ({ payload }) => {
				this.portList = payload.portList;
				if (payload.removed !== void 0) this.#cleanupPort(payload.removed);
			});
			return;
		}
		/**
		* Else we're the background script
		*/
		this.isConnected = true;
		const onPacket = this.#onPacket.bind(this);
		runtime.onConnect.addListener((port) => {
			if (portNameRE.test(port.name) === false) return;
			if (this.portMap[port.name] !== void 0) {
				this.warn(`Connection with "${port.name}" already exists. Disconnecting the previous one and connecting the new one.`);
				this.portMap[port.name].disconnect();
				this.#cleanupPort(port.name);
			}
			this.portMap[port.name] = port;
			port.onMessage.addListener(onPacket);
			port.onDisconnect.addListener(() => {
				port.onMessage.removeListener(onPacket);
				this.#cleanupPort(port.name);
				this.log(`Closed connection with ${port.name}.`);
				this.#onPortChange({ removed: port.name });
			});
			this.log(`Opened connection with ${port.name}.`);
			this.#onPortChange({ added: port.name });
		});
	}
	/**
	* @returns {Promise<void>}
	*/
	connectToBackground() {
		if (this.#type === "background") return Promise.reject("The background script itself does not need to connect");
		if (this.isConnected === true) return Promise.reject("The bridge is already connected");
		const portToBackground = runtime.connect({ name: this.portName });
		return new Promise((resolve, reject) => {
			const onPacket = (packet) => {
				if (this.isConnected === false) {
					/**
					* We rely on the fact that upon connection is established
					* the background script will send a @quasar:ports event
					*/
					this.isConnected = true;
					this.log("Connected to the background script.");
					this.portMap = { background: portToBackground };
					resolve();
				}
				this.#onPacket(packet);
			};
			const onDisconnect = () => {
				if (runtime.lastError?.message?.indexOf("Could not establish connection") !== -1) {
					this.isConnected = false;
					portToBackground.onMessage.removeListener(onPacket);
					portToBackground.onMessage.removeListener(onDisconnect);
					reject("Could not connect to the background script.");
					return;
				}
				this.isConnected = false;
				for (const id in this.messageMap) this.messageMap[id].reject("Connection was closed");
				this.portMap = {};
				this.portList = [];
				this.messageMap = {};
				this.chunkMap = {};
				this.log("Closed connection with the background script.");
			};
			portToBackground.onMessage.addListener(onPacket);
			portToBackground.onDisconnect.addListener(onDisconnect);
		});
	}
	/**
	* @returns {Promise<void>}
	*/
	disconnectFromBackground() {
		if (this.#type === "background") return Promise.reject("Background script does not need to disconnect");
		if (this.isConnected === false) return Promise.reject("Tried to disconnect from the background script but the port was not connected");
		this.portMap.background.disconnect();
		delete this.portMap.background;
		this.isConnected = false;
		return Promise.resolve();
	}
	/**
	* @param {string} event
	* @param {(message: Message) => void} callback
	*/
	on(event, callback) {
		if (!event) {
			this.warn("Tried add listener but no event specified.");
			return;
		}
		if (typeof callback !== "function") {
			this.warn("Tried add listener but no valid callback function specified.");
			return;
		}
		(this.listeners[event] || (this.listeners[event] = [])).push({
			type: "on",
			callback
		});
		this.log(`Added a listener for event: "${event}".`);
	}
	/**
	* @param {string} event
	* @param {(message: Message) => void} callback
	*/
	once(event, callback) {
		if (!event) {
			this.warn("Tried add listener but no event specified.");
			return;
		}
		if (typeof callback !== "function") {
			this.warn("Tried add listener but no valid callback function specified.");
			return;
		}
		(this.listeners[event] || (this.listeners[event] = [])).push({
			type: "once",
			callback
		});
		this.log(`Added a one-time listener for event: "${event}".`);
	}
	/**
	* @param {string} event
	* @param {(message: Message) => void} callback
	*/
	off(event, callback) {
		if (!event) {
			this.warn("Tried to remove listeners but no event specified.");
			return;
		}
		const list = this.listeners[event];
		if (list === void 0) {
			this.warn(`Tried to remove listener for "${event}" event but there is no such listener attached.`);
			return;
		}
		if (callback === void 0) {
			if (event.startsWith("@quasar:")) this.listeners[event] = [list[0]];
			else delete this.listeners[event];
			this.log(`Stopped listening for "${event}".`);
			return;
		}
		if (typeof callback !== "function") {
			this.warn("Tried to remove listener but the callback specified is not a function.");
			return;
		}
		const liveEvents = list.filter((entry) => entry.callback !== callback);
		if (liveEvents.length !== 0) {
			this.listeners[event] = liveEvents;
			this.log(`Removed a listener for: "${event}".`);
		} else {
			delete this.listeners[event];
			this.log(`Stopped listening for: "${event}".`);
		}
	}
	/**
	* @param {{ event: string, to: string, payload: any } | undefined} param
	* @returns {Promise<any>} response payload
	*/
	async send({ event, to, payload } = {}) {
		if (this.isConnected === false) throw new Error("Tried to send message but the bridge is not connected. Please connect it first.");
		if (!event) throw new Error("Tried to send message with no \"event\" prop specified");
		if (!to) throw new Error("Tried to send message with no \"to\" prop specified");
		if (this.portList.includes(to) === false) throw new Error(this.#type === "background" ? `Tried to send message to "${to}" but there is no such port registered` : `Tried to send message to "${to}" but the port to background is not available to send through`);
		const id = getRandomId(1e6);
		await this.#sendMessage({
			id,
			to,
			payload,
			messageType: "event-send",
			messageProps: { event }
		});
		if (this.portList.includes(to) === false) throw new Error(`Connection to "${to}" was closed while waiting for a response`);
		return new Promise((resolve, reject) => {
			this.messageMap[id] = {
				portName: to,
				resolve: (responsePayload) => {
					delete this.messageMap[id];
					resolve(responsePayload);
				},
				reject: (err) => {
					delete this.messageMap[id];
					reject(err);
				}
			};
		});
	}
	/**
	* @param {boolean} value
	*/
	setDebug(value) {
		this.#debug = value === true;
	}
	log(...args) {
		if (this.#debug !== true || args.length === 0) return;
		const lastArg = args[args.length - 1];
		if (lastArg !== void 0 && Object(lastArg) === lastArg) {
			const log = `${this.#banner} ${args.slice(0, -1).join(" ")} (click to expand)`;
			console.groupCollapsed(log);
			console.dir(lastArg);
			console.groupEnd(log);
		} else console.log(this.#banner, ...args);
	}
	warn(...args) {
		if (args.length === 0) return;
		const lastArg = args[args.length - 1];
		if (lastArg !== void 0 && Object(lastArg) === lastArg) {
			console.warn(this.#banner, ...args.slice(0, -1));
			const group = "The above warning details (click to expand)";
			console.groupCollapsed(group);
			console.dir(lastArg);
			console.groupEnd(group);
		} else console.warn(this.#banner, ...args);
	}
	/**
	* Should be used only by the background script
	* @param {{ added?: string } | { removed?: string }} reason
	*/
	#onPortChange(reason) {
		this.portList = Object.keys(this.portMap);
		const list = ["background", ...this.portList];
		for (const portName of this.portList) this.send({
			event: "@quasar:ports",
			to: portName,
			payload: {
				portList: list.filter((name) => name !== portName),
				...reason
			}
		}).catch((err) => {
			this.warn(`Failed to inform "${portName}" about the port list.`, err);
		});
	}
	/**
	* @param {Message} message
	*/
	async #triggerMessageEvent(message) {
		const list = this.listeners[message.event];
		if (list === void 0) return;
		const plural = list.length > 1 ? "s" : "";
		this.log(`Triggering ${list.length} listener${plural} for event: "${message.event}".`, {
			message,
			listeners: list
		});
		let responsePayload;
		for (const { type, callback } of list.slice(0)) {
			if (type === "once") this.off(message.event, callback);
			try {
				if (responsePayload === void 0) {
					const value = callback(message);
					responsePayload = value instanceof Promise ? await value : value;
				} else callback(message);
			} catch (err) {
				this.warn(`Error while triggering listener${plural} for event: "${message.event}".`, {
					error: err,
					message,
					listener: {
						type,
						callback
					}
				});
				return Promise.reject(err);
			}
		}
		return responsePayload;
	}
	/**
	* @param {string} portName
	*/
	#cleanupPort(portName) {
		for (const id in this.chunkMap) if (this.chunkMap[id].portName === portName) delete this.chunkMap[id];
		for (const id in this.messageMap) {
			const packet = this.messageMap[id];
			if (packet.portName === portName) packet.reject("Connection was closed");
		}
		delete this.portMap[portName];
	}
	#onPacket(packet) {
		/**
		* if it's not a packet sent by this bridge
		* then ignore it
		*/
		if (Object(packet) !== packet || packet.id === void 0 || packet.from === void 0 || packet.to === void 0 || packet.type === void 0) {
			this.log("Received a message that does not appear to be emitted by a Quasar bridge or is malformed.", packet);
			return;
		}
		this.log(`Received message of type "${packet.type}" from "${packet.from}".`, packet);
		/**
		* if the packet is not addressed to this bridge
		* then forward it to the target
		*/
		if (packet.to !== this.portName) {
			this.#sendPacket(packet).catch((err) => {
				this.warn(`Failed to forward message of type "${packet.type}" from "${packet.from}" to "${packet.to}".`, err);
				this.#sendMessage({
					id: packet.id,
					to: packet.from,
					messageType: "event-response",
					messageProps: {
						error: {
							message: err.message,
							stack: err.stack || "no stack available"
						},
						quiet: true
					}
				});
			});
			return;
		}
		if (packet.type === "full") {
			this.#onMessage({
				id: packet.id,
				from: packet.from,
				to: packet.to,
				payload: packet.payload,
				type: packet.messageType,
				props: packet.messageProps
			});
			return;
		}
		if (packet.type === "chunk") {
			const chunk = this.chunkMap[packet.id];
			if (chunk === void 0) {
				if (packet.chunkIndex !== void 0) {
					this.warn("Received an unregistered chunk.", packet);
					return;
				}
				this.chunkMap[packet.id] = {
					portName: packet.from,
					number: packet.chunksNumber,
					messageType: packet.messageType,
					messageProps: packet.messageProps,
					payload: []
				};
				return;
			}
			if (packet.chunkIndex !== chunk.payload.length) {
				this.warn("Received an out of order chunk.", packet);
				delete this.chunkMap[packet.id];
				return;
			}
			chunk.payload.push(packet.payload);
			if (packet.chunkIndex === chunk.number - 1) {
				delete this.chunkMap[packet.id];
				this.#onMessage({
					id: packet.id,
					from: packet.from,
					to: packet.to,
					payload: chunk.payload,
					type: chunk.messageType,
					props: chunk.messageProps
				});
			}
			return;
		}
		if (packet.type === "chunk-abort") {
			delete this.chunkMap[packet.id];
			return;
		}
		this.warn(`Received an unknown message type: "${packet.type}".`);
	}
	#sendPacket(packet) {
		this.log(packet.from === this.portName ? `Sending message of type "${packet.type}" to "${packet.to}".` : `Forwarding message of type "${packet.type}" from "${packet.from}" to "${packet.to}".`, packet);
		const port = this.#type === "background" ? this.portMap[packet.to] : this.portMap.background;
		if (this.portList.includes(packet.to) === false) return Promise.reject(`Tried to send message of type "${packet.type}" to "${packet.to}" but there is no such port registered`);
		if (port === void 0) return Promise.reject(this.#type === "background" ? `Tried to send message of type "${packet.type}" to "${packet.to}" but the port is not available` : `Tried to send message of type "${packet.type}" to "${packet.to}" but the port to background is not available to forward through`);
		try {
			port.postMessage(packet);
		} catch (err) {
			this.warn(`Failed to send message to "${packet.to}".`, err);
			return Promise.reject(err);
		}
		return Promise.resolve();
	}
	/**
	* @param {{ id?: number, to: string, payload: any, messageType: "event-send" | "event-response", messageProps: any }} param
	*/
	#sendMessage({ id = getRandomId(1e6), to, payload, messageType, messageProps }) {
		if (Array.isArray(payload) === false) return this.#sendPacket({
			id,
			from: this.portName,
			to,
			type: "full",
			payload,
			messageType,
			messageProps
		});
		let promise = this.#sendPacket({
			id,
			from: this.portName,
			to,
			type: "chunk",
			chunksNumber: payload.length,
			messageType,
			messageProps
		});
		for (let i = 0; i < payload.length; i++) promise = promise.then(() => this.#sendPacket({
			id,
			from: this.portName,
			to,
			type: "chunk",
			payload: payload[i],
			chunkIndex: i
		}));
		return promise.catch((err) => {
			this.#sendPacket({
				id,
				from: this.portName,
				to,
				type: "chunk-abort"
			}).catch((err) => {
				this.warn(`Failed to send a chunk-abort message to "${to}".`, err);
			});
			return Promise.reject(err);
		});
	}
	#onMessage(message) {
		if (message.type === "event-response") {
			const target = this.messageMap[message.id];
			if (target === void 0) {
				if (message.props.quiet !== true) this.warn(`Received a response for an unknown message id: "${message.id}".`, message);
				return;
			}
			if (message.props.error !== void 0) target.reject(message.props.error);
			else target.resolve(message.payload);
			return;
		}
		if (message.type === "event-send") {
			this.#triggerMessageEvent({
				from: message.from,
				to: message.to,
				event: message.props.event,
				payload: message.payload
			}).then((returnPayload) => {
				this.#sendMessage({
					id: message.id,
					to: message.from,
					payload: returnPayload,
					messageType: "event-response",
					messageProps: {}
				});
			}).catch((err) => {
				this.#sendMessage({
					id: message.id,
					to: message.from,
					messageType: "event-response",
					messageProps: { error: {
						message: err.message,
						stack: err.stack || "no stack available"
					} }
				});
			});
			return;
		}
		this.warn(`Received a message with unknown type: "${message.type}".`, message);
	}
};
//#endregion
//#region .quasar/prod-bex-chrome/bex-app.js
var bridge = window.QBexBridge = new BexBridge({ type: "app" });
var bex = {
	bridge,
	promise: bridge.connectToBackground().catch(() => {})
};
//#endregion
//#region node_modules/quasar/src/utils/debounce/debounce.js
function debounce_default(fn, wait = 250, immediate) {
	let timer = null;
	function debounced() {
		const args = arguments;
		const later = () => {
			timer = null;
			if (immediate !== true) fn.apply(this, args);
		};
		if (timer !== null) clearTimeout(timer);
		else if (immediate === true) fn.apply(this, args);
		timer = setTimeout(later, wait);
	}
	debounced.cancel = () => {
		timer !== null && clearTimeout(timer);
	};
	return debounced;
}
//#endregion
//#region node_modules/quasar/src/plugins/screen/Screen.js
var SIZE_LIST = [
	"sm",
	"md",
	"lg",
	"xl"
];
var { passive } = listenOpts;
var Screen_default = createReactivePlugin({
	width: 0,
	height: 0,
	name: "xs",
	sizes: {
		sm: 600,
		md: 1024,
		lg: 1440,
		xl: 1920
	},
	lt: {
		sm: true,
		md: true,
		lg: true,
		xl: true
	},
	gt: {
		xs: false,
		sm: false,
		md: false,
		lg: false
	},
	xs: true,
	sm: false,
	md: false,
	lg: false,
	xl: false
}, {
	setSizes: noop$2,
	setDebounce: noop$2,
	install({ $q, onSSRHydrated }) {
		$q.screen = this;
		if (this.__installed === true) {
			if ($q.config.screen !== void 0) if ($q.config.screen.bodyClasses === false) document.body.classList.remove(`screen--${this.name}`);
			else this.__update(true);
			return;
		}
		const { visualViewport } = window;
		const target = visualViewport || window;
		const scrollingElement = document.scrollingElement || document.documentElement;
		const getSize = visualViewport === void 0 || client.is.mobile === true ? () => [Math.max(window.innerWidth, scrollingElement.clientWidth), Math.max(window.innerHeight, scrollingElement.clientHeight)] : () => [visualViewport.width * visualViewport.scale + window.innerWidth - scrollingElement.clientWidth, visualViewport.height * visualViewport.scale + window.innerHeight - scrollingElement.clientHeight];
		const classes = $q.config.screen?.bodyClasses === true;
		this.__update = (force) => {
			const [w, h] = getSize();
			if (h !== this.height) this.height = h;
			if (w !== this.width) this.width = w;
			else if (force !== true) return;
			let s = this.sizes;
			this.gt.xs = w >= s.sm;
			this.gt.sm = w >= s.md;
			this.gt.md = w >= s.lg;
			this.gt.lg = w >= s.xl;
			this.lt.sm = w < s.sm;
			this.lt.md = w < s.md;
			this.lt.lg = w < s.lg;
			this.lt.xl = w < s.xl;
			this.xs = this.lt.sm;
			this.sm = this.gt.xs === true && this.lt.md === true;
			this.md = this.gt.sm === true && this.lt.lg === true;
			this.lg = this.gt.md === true && this.lt.xl === true;
			this.xl = this.gt.lg;
			s = this.xs === true && "xs" || this.sm === true && "sm" || this.md === true && "md" || this.lg === true && "lg" || "xl";
			if (s !== this.name) {
				if (classes === true) {
					document.body.classList.remove(`screen--${this.name}`);
					document.body.classList.add(`screen--${s}`);
				}
				this.name = s;
			}
		};
		let updateEvt, updateSizes = {}, updateDebounce = 16;
		this.setSizes = (sizes) => {
			SIZE_LIST.forEach((name) => {
				if (sizes[name] !== void 0) updateSizes[name] = sizes[name];
			});
		};
		this.setDebounce = (deb) => {
			updateDebounce = deb;
		};
		const start = () => {
			const style = getComputedStyle(document.body);
			if (style.getPropertyValue("--q-size-sm")) SIZE_LIST.forEach((name) => {
				this.sizes[name] = parseInt(style.getPropertyValue(`--q-size-${name}`), 10);
			});
			this.setSizes = (sizes) => {
				SIZE_LIST.forEach((name) => {
					if (sizes[name]) this.sizes[name] = sizes[name];
				});
				this.__update(true);
			};
			this.setDebounce = (delay) => {
				updateEvt !== void 0 && target.removeEventListener("resize", updateEvt, passive);
				updateEvt = delay > 0 ? debounce_default(this.__update, delay) : this.__update;
				target.addEventListener("resize", updateEvt, passive);
			};
			this.setDebounce(updateDebounce);
			if (Object.keys(updateSizes).length !== 0) {
				this.setSizes(updateSizes);
				updateSizes = void 0;
			} else this.__update();
			classes === true && this.name === "xs" && document.body.classList.add("screen--xs");
		};
		if (isRuntimeSsrPreHydration.value === true) onSSRHydrated.push(start);
		else start();
	}
});
//#endregion
//#region node_modules/quasar/src/plugins/dark/Dark.js
var Plugin$3 = createReactivePlugin({
	isActive: false,
	mode: false
}, {
	__media: void 0,
	set(val) {
		Plugin$3.mode = val;
		if (val === "auto") {
			if (Plugin$3.__media === void 0) {
				Plugin$3.__media = window.matchMedia("(prefers-color-scheme: dark)");
				Plugin$3.__updateMedia = () => {
					Plugin$3.set("auto");
				};
				Plugin$3.__media.addListener(Plugin$3.__updateMedia);
			}
			val = Plugin$3.__media.matches;
		} else if (Plugin$3.__media !== void 0) {
			Plugin$3.__media.removeListener(Plugin$3.__updateMedia);
			Plugin$3.__media = void 0;
		}
		Plugin$3.isActive = val === true;
		document.body.classList.remove(`body--${val === true ? "light" : "dark"}`);
		document.body.classList.add(`body--${val === true ? "dark" : "light"}`);
	},
	toggle() {
		Plugin$3.set(Plugin$3.isActive === false);
	},
	install({ $q, ssrContext }) {
		const dark = $q.config.dark;
		$q.dark = this;
		if (this.__installed !== true) this.set(dark !== void 0 ? dark : false);
	}
});
//#endregion
//#region node_modules/quasar/src/utils/css-var/set-css-var.js
function setCssVar(propName, value, element = document.body) {
	if (typeof propName !== "string") throw new TypeError("Expected a string as propName");
	if (typeof value !== "string") throw new TypeError("Expected a string as value");
	if (!(element instanceof Element)) throw new TypeError("Expected a DOM element");
	element.style.setProperty(`--q-${propName}`, value);
}
//#endregion
//#region node_modules/quasar/src/plugins/private.body/Body.js
function getMobilePlatform(is) {
	if (is.ios === true) return "ios";
	if (is.android === true) return "android";
}
function getBodyClasses({ is, has, within }, cfg) {
	const cls = [is.desktop === true ? "desktop" : "mobile", `${has.touch === false ? "no-" : ""}touch`];
	if (is.mobile === true) {
		const mobile = getMobilePlatform(is);
		mobile !== void 0 && cls.push("platform-" + mobile);
	}
	if (is.nativeMobile === true) {
		const type = is.nativeMobileWrapper;
		cls.push(type);
		cls.push("native-mobile");
		if (is.ios === true && (cfg[type] === void 0 || cfg[type].iosStatusBarPadding !== false)) cls.push("q-ios-padding");
	} else if (is.electron === true) cls.push("electron");
	else if (is.bex === true) cls.push("bex");
	within.iframe === true && cls.push("within-iframe");
	return cls;
}
function applyClientSsrCorrections() {
	const { is } = client;
	const classes = document.body.className;
	const classList = new Set(classes.replace(/ {2}/g, " ").split(" "));
	if (is.nativeMobile !== true && is.electron !== true && is.bex !== true) {
		if (is.desktop === true) {
			classList.delete("mobile");
			classList.delete("platform-ios");
			classList.delete("platform-android");
			classList.add("desktop");
		} else if (is.mobile === true) {
			classList.delete("desktop");
			classList.add("mobile");
			classList.delete("platform-ios");
			classList.delete("platform-android");
			const mobile = getMobilePlatform(is);
			if (mobile !== void 0) classList.add(`platform-${mobile}`);
		}
	}
	if (client.has.touch === true) {
		classList.delete("no-touch");
		classList.add("touch");
	}
	if (client.within.iframe === true) classList.add("within-iframe");
	const newCls = Array.from(classList).join(" ");
	if (classes !== newCls) document.body.className = newCls;
}
function setColors(brand) {
	for (const color in brand) setCssVar(color, brand[color]);
}
var Body_default = { install(opts) {
	if (this.__installed === true) return;
	if (isRuntimeSsrPreHydration.value === true) applyClientSsrCorrections();
	else {
		const { $q } = opts;
		$q.config.brand !== void 0 && setColors($q.config.brand);
		const cls = getBodyClasses(client, $q.config);
		document.body.classList.add.apply(document.body.classList, cls);
	}
	if (client.is.ios === true) document.body.addEventListener("touchstart", noop$2);
	window.addEventListener("keydown", onKeyDownComposition, true);
} };
//#endregion
//#region node_modules/quasar/src/plugins/private.history/History.js
var getTrue = () => true;
function filterInvalidPath(path) {
	return typeof path === "string" && path !== "" && path !== "/" && path !== "#/";
}
function normalizeExitPath(path) {
	path.startsWith("#") === true && (path = path.substring(1));
	path.startsWith("/") === false && (path = "/" + path);
	path.endsWith("/") === true && (path = path.substring(0, path.length - 1));
	return "#" + path;
}
function getShouldExitFn(cfg) {
	if (cfg.backButtonExit === false) return () => false;
	if (cfg.backButtonExit === "*") return getTrue;
	const exitPaths = ["#/"];
	Array.isArray(cfg.backButtonExit) === true && exitPaths.push(...cfg.backButtonExit.filter(filterInvalidPath).map(normalizeExitPath));
	return () => exitPaths.includes(window.location.hash);
}
var History_default = {
	__history: [],
	add: noop$2,
	remove: noop$2,
	install({ $q }) {
		if (this.__installed === true) return;
		const { cordova, capacitor } = client.is;
		if (cordova !== true && capacitor !== true) return;
		const qConf = $q.config[cordova === true ? "cordova" : "capacitor"];
		if (qConf?.backButton === false) return;
		if (capacitor === true && (window.Capacitor === void 0 || window.Capacitor.Plugins.App === void 0)) return;
		this.add = (entry) => {
			if (entry.condition === void 0) entry.condition = getTrue;
			this.__history.push(entry);
		};
		this.remove = (entry) => {
			const index = this.__history.indexOf(entry);
			if (index >= 0) this.__history.splice(index, 1);
		};
		const shouldExit = getShouldExitFn(Object.assign({ backButtonExit: true }, qConf));
		const backHandler = () => {
			if (this.__history.length) {
				const entry = this.__history[this.__history.length - 1];
				if (entry.condition() === true) {
					this.__history.pop();
					entry.handler();
				}
			} else if (shouldExit() === true) navigator.app.exitApp();
			else window.history.back();
		};
		if (cordova === true) document.addEventListener("deviceready", () => {
			document.addEventListener("backbutton", backHandler, false);
		});
		else window.Capacitor.Plugins.App.addListener("backButton", backHandler);
	}
};
//#endregion
//#region node_modules/quasar/lang/en-US.js
var en_US_default = {
	isoName: "en-US",
	nativeName: "English (US)",
	label: {
		clear: "Clear",
		ok: "OK",
		cancel: "Cancel",
		close: "Close",
		set: "Set",
		select: "Select",
		reset: "Reset",
		remove: "Remove",
		update: "Update",
		create: "Create",
		search: "Search",
		filter: "Filter",
		refresh: "Refresh",
		expand: (label) => label ? `Expand "${label}"` : "Expand",
		collapse: (label) => label ? `Collapse "${label}"` : "Collapse"
	},
	date: {
		days: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
		daysShort: "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
		months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
		monthsShort: "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
		firstDayOfWeek: 0,
		format24h: false,
		pluralDay: "days",
		prevMonth: "Previous month",
		nextMonth: "Next month",
		prevYear: "Previous year",
		nextYear: "Next year",
		today: "Today",
		prevRangeYears: (range) => `Previous ${range} years`,
		nextRangeYears: (range) => `Next ${range} years`
	},
	table: {
		noData: "No data available",
		noResults: "No matching records found",
		loading: "Loading...",
		selectedRecords: (rows) => rows === 1 ? "1 record selected." : (rows === 0 ? "No" : rows) + " records selected.",
		recordsPerPage: "Records per page:",
		allRows: "All",
		pagination: (start, end, total) => start + "-" + end + " of " + total,
		columns: "Columns"
	},
	pagination: {
		first: "First page",
		prev: "Previous page",
		next: "Next page",
		last: "Last page"
	},
	editor: {
		url: "URL",
		bold: "Bold",
		italic: "Italic",
		strikethrough: "Strikethrough",
		underline: "Underline",
		unorderedList: "Unordered List",
		orderedList: "Ordered List",
		subscript: "Subscript",
		superscript: "Superscript",
		hyperlink: "Hyperlink",
		toggleFullscreen: "Toggle Fullscreen",
		quote: "Quote",
		left: "Left align",
		center: "Center align",
		right: "Right align",
		justify: "Justify align",
		print: "Print",
		outdent: "Decrease indentation",
		indent: "Increase indentation",
		removeFormat: "Remove formatting",
		formatting: "Formatting",
		fontSize: "Font Size",
		align: "Align",
		hr: "Insert Horizontal Rule",
		undo: "Undo",
		redo: "Redo",
		heading1: "Heading 1",
		heading2: "Heading 2",
		heading3: "Heading 3",
		heading4: "Heading 4",
		heading5: "Heading 5",
		heading6: "Heading 6",
		paragraph: "Paragraph",
		code: "Code",
		size1: "Very small",
		size2: "A bit small",
		size3: "Normal",
		size4: "Medium-large",
		size5: "Big",
		size6: "Very big",
		size7: "Maximum",
		defaultFont: "Default Font",
		viewSource: "View Source"
	},
	tree: {
		noNodes: "No nodes available",
		noResults: "No matching nodes found"
	}
};
//#endregion
//#region node_modules/quasar/src/plugins/lang/Lang.js
function getLocale() {
	const val = Array.isArray(navigator.languages) === true && navigator.languages.length !== 0 ? navigator.languages[0] : navigator.language;
	if (typeof val === "string") return val.split(/[-_]/).map((v, i) => i === 0 ? v.toLowerCase() : i > 1 || v.length < 4 ? v.toUpperCase() : v[0].toUpperCase() + v.slice(1).toLowerCase()).join("-");
}
var Plugin$2 = createReactivePlugin({ __qLang: {} }, {
	getLocale,
	set(langObject = en_US_default, ssrContext) {
		const lang = {
			...langObject,
			rtl: langObject.rtl === true,
			getLocale
		};
		lang.set = Plugin$2.set;
		if (Plugin$2.__langConfig === void 0 || Plugin$2.__langConfig.noHtmlAttrs !== true) {
			const el = document.documentElement;
			el.setAttribute("dir", lang.rtl === true ? "rtl" : "ltr");
			el.setAttribute("lang", lang.isoName);
		}
		Object.assign(Plugin$2.__qLang, lang);
	},
	install({ $q, lang, ssrContext }) {
		$q.lang = Plugin$2.__qLang;
		Plugin$2.__langConfig = $q.config.lang;
		if (this.__installed === true) lang !== void 0 && this.set(lang);
		else {
			this.props = new Proxy(this.__qLang, {
				get() {
					return Reflect.get(...arguments);
				},
				ownKeys(target) {
					return Reflect.ownKeys(target).filter((key) => key !== "set" && key !== "getLocale");
				}
			});
			this.set(lang || en_US_default);
		}
	}
});
//#endregion
//#region node_modules/quasar/icon-set/material-icons.js
var material_icons_default = {
	name: "material-icons",
	type: {
		positive: "check_circle",
		negative: "warning",
		info: "info",
		warning: "priority_high"
	},
	arrow: {
		up: "arrow_upward",
		right: "arrow_forward",
		down: "arrow_downward",
		left: "arrow_back",
		dropdown: "arrow_drop_down"
	},
	chevron: {
		left: "chevron_left",
		right: "chevron_right"
	},
	colorPicker: {
		spectrum: "gradient",
		tune: "tune",
		palette: "style"
	},
	pullToRefresh: { icon: "refresh" },
	carousel: {
		left: "chevron_left",
		right: "chevron_right",
		up: "keyboard_arrow_up",
		down: "keyboard_arrow_down",
		navigationIcon: "lens"
	},
	chip: {
		remove: "cancel",
		selected: "check"
	},
	datetime: {
		arrowLeft: "chevron_left",
		arrowRight: "chevron_right",
		now: "access_time",
		today: "today"
	},
	editor: {
		bold: "format_bold",
		italic: "format_italic",
		strikethrough: "strikethrough_s",
		underline: "format_underlined",
		unorderedList: "format_list_bulleted",
		orderedList: "format_list_numbered",
		subscript: "vertical_align_bottom",
		superscript: "vertical_align_top",
		hyperlink: "link",
		toggleFullscreen: "fullscreen",
		quote: "format_quote",
		left: "format_align_left",
		center: "format_align_center",
		right: "format_align_right",
		justify: "format_align_justify",
		print: "print",
		outdent: "format_indent_decrease",
		indent: "format_indent_increase",
		removeFormat: "format_clear",
		formatting: "text_format",
		fontSize: "format_size",
		align: "format_align_left",
		hr: "remove",
		undo: "undo",
		redo: "redo",
		heading: "format_size",
		code: "code",
		size: "format_size",
		font: "font_download",
		viewSource: "code"
	},
	expansionItem: {
		icon: "keyboard_arrow_down",
		denseIcon: "arrow_drop_down"
	},
	fab: {
		icon: "add",
		activeIcon: "close"
	},
	field: {
		clear: "cancel",
		error: "error"
	},
	pagination: {
		first: "first_page",
		prev: "keyboard_arrow_left",
		next: "keyboard_arrow_right",
		last: "last_page"
	},
	rating: { icon: "grade" },
	stepper: {
		done: "check",
		active: "edit",
		error: "warning"
	},
	tabs: {
		left: "chevron_left",
		right: "chevron_right",
		up: "keyboard_arrow_up",
		down: "keyboard_arrow_down"
	},
	table: {
		arrowUp: "arrow_upward",
		warning: "warning",
		firstPage: "first_page",
		prevPage: "chevron_left",
		nextPage: "chevron_right",
		lastPage: "last_page"
	},
	tree: { icon: "play_arrow" },
	uploader: {
		done: "done",
		clear: "clear",
		add: "add_box",
		upload: "cloud_upload",
		removeQueue: "clear_all",
		removeUploaded: "done_all"
	}
};
//#endregion
//#region node_modules/quasar/src/plugins/icon-set/IconSet.js
var Plugin$1 = createReactivePlugin({
	iconMapFn: null,
	__qIconSet: {}
}, {
	set(setObject, ssrContext) {
		const def = { ...setObject };
		def.set = Plugin$1.set;
		Object.assign(Plugin$1.__qIconSet, def);
	},
	install({ $q, iconSet, ssrContext }) {
		if ($q.config.iconMapFn !== void 0) this.iconMapFn = $q.config.iconMapFn;
		$q.iconSet = this.__qIconSet;
		injectProp($q, "iconMapFn", () => this.iconMapFn, (val) => {
			this.iconMapFn = val;
		});
		if (this.__installed === true) iconSet !== void 0 && this.set(iconSet);
		else {
			this.props = new Proxy(this.__qIconSet, {
				get() {
					return Reflect.get(...arguments);
				},
				ownKeys(target) {
					return Reflect.ownKeys(target).filter((key) => key !== "set");
				}
			});
			this.set(iconSet || material_icons_default);
		}
	}
});
//#endregion
//#region node_modules/quasar/src/utils/private.symbols/symbols.js
var layoutKey = "_q_l_";
var pageContainerKey = "_q_pc_";
var fabKey = "_q_f_";
var formKey = "_q_fo_";
function emptyRenderFn() {}
//#endregion
//#region node_modules/quasar/src/utils/private.config/instance-config.js
var globalConfig = {};
var globalConfigIsFrozen = false;
function freezeGlobalConfig() {
	globalConfigIsFrozen = true;
}
//#endregion
//#region node_modules/quasar/src/utils/is/is.js
function isDeepEqual(a, b) {
	if (a === b) return true;
	if (a !== null && b !== null && typeof a === "object" && typeof b === "object") {
		if (a.constructor !== b.constructor) return false;
		let length, i;
		if (a.constructor === Array) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (isDeepEqual(a[i], b[i]) !== true) return false;
			return true;
		}
		if (a.constructor === Map) {
			if (a.size !== b.size) return false;
			let iter = a.entries();
			i = iter.next();
			while (i.done !== true) {
				if (b.has(i.value[0]) !== true) return false;
				i = iter.next();
			}
			iter = a.entries();
			i = iter.next();
			while (i.done !== true) {
				if (isDeepEqual(i.value[1], b.get(i.value[0])) !== true) return false;
				i = iter.next();
			}
			return true;
		}
		if (a.constructor === Set) {
			if (a.size !== b.size) return false;
			const iter = a.entries();
			i = iter.next();
			while (i.done !== true) {
				if (b.has(i.value[0]) !== true) return false;
				i = iter.next();
			}
			return true;
		}
		if (a.buffer != null && a.buffer.constructor === ArrayBuffer) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (a[i] !== b[i]) return false;
			return true;
		}
		if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
		if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
		if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
		const keys = Object.keys(a).filter((key) => a[key] !== void 0);
		length = keys.length;
		if (length !== Object.keys(b).filter((key) => b[key] !== void 0).length) return false;
		for (i = length; i-- !== 0;) {
			const key = keys[i];
			if (isDeepEqual(a[key], b[key]) !== true) return false;
		}
		return true;
	}
	return a !== a && b !== b;
}
function isObject(v) {
	return v !== null && typeof v === "object" && Array.isArray(v) !== true;
}
function isDate(v) {
	return Object.prototype.toString.call(v) === "[object Date]";
}
function isRegexp(v) {
	return Object.prototype.toString.call(v) === "[object RegExp]";
}
function isNumber(v) {
	return typeof v === "number" && isFinite(v);
}
//#endregion
//#region node_modules/quasar/src/install-quasar.js
/**
* If the list below changes, make sure
* to also edit /ui/testing/specs/generators/generator.plugin.js
* on the "autoInstalledPlugins" array
*/
var autoInstalledPlugins = [
	Platform,
	Body_default,
	Plugin$3,
	Screen_default,
	History_default,
	Plugin$2,
	Plugin$1
];
function createChildApp(appCfg, parentApp) {
	const app = createApp(appCfg);
	app.config.globalProperties = parentApp.config.globalProperties;
	const { reload, ...appContext } = parentApp._context;
	Object.assign(app._context, appContext);
	return app;
}
function installPlugins(pluginOpts, pluginList) {
	pluginList.forEach((Plugin) => {
		Plugin.install(pluginOpts);
		Plugin.__installed = true;
	});
}
function prepareApp(app, uiOpts, pluginOpts) {
	app.config.globalProperties.$q = pluginOpts.$q;
	app.provide("_q_", pluginOpts.$q);
	installPlugins(pluginOpts, autoInstalledPlugins);
	uiOpts.components !== void 0 && Object.values(uiOpts.components).forEach((c) => {
		if (isObject(c) === true && c.name !== void 0) app.component(c.name, c);
	});
	uiOpts.directives !== void 0 && Object.values(uiOpts.directives).forEach((d) => {
		if (isObject(d) === true && d.name !== void 0) app.directive(d.name, d);
	});
	uiOpts.plugins !== void 0 && installPlugins(pluginOpts, Object.values(uiOpts.plugins).filter((p) => typeof p.install === "function" && autoInstalledPlugins.includes(p) === false));
	if (isRuntimeSsrPreHydration.value === true) pluginOpts.$q.onSSRHydrated = () => {
		pluginOpts.onSSRHydrated.forEach((fn) => {
			fn();
		});
		pluginOpts.$q.onSSRHydrated = () => {};
	};
}
var install_quasar_default = function(parentApp, opts = {}) {
	const $q = { version: "2.18.7" };
	if (globalConfigIsFrozen === false) {
		if (opts.config !== void 0) Object.assign(globalConfig, opts.config);
		$q.config = { ...globalConfig };
		freezeGlobalConfig();
	} else $q.config = opts.config || {};
	prepareApp(parentApp, opts, {
		parentApp,
		$q,
		lang: opts.lang,
		iconSet: opts.iconSet,
		onSSRHydrated: []
	});
};
//#endregion
//#region node_modules/quasar/src/vue-plugin.js
var vue_plugin_default = {
	name: "Quasar",
	version: "2.18.7",
	install: install_quasar_default,
	lang: Plugin$2,
	iconSet: Plugin$1
};
//#endregion
//#region src/App.vue
var App_default = /* @__PURE__ */ defineComponent({
	__name: "App",
	setup(__props) {
		return (_ctx, _cache) => {
			const _component_router_view = resolveComponent("router-view");
			return openBlock(), createBlock(_component_router_view);
		};
	}
});
//#endregion
//#region node_modules/@quasar/app-vite/exports/wrappers/wrappers.js
var wrapper = (callback) => callback;
var defineBoot = wrapper;
var defineRouter = wrapper;
var defineStore$1 = wrapper;
//#endregion
//#region node_modules/pinia/dist/pinia.mjs
/*!
* pinia v3.0.4
* (c) 2025 Eduardo San Martin Morote
* @license MIT
*/
var IS_CLIENT = typeof window !== "undefined";
/**
* setActivePinia must be called to handle SSR at the top of functions like
* `fetch`, `setup`, `serverPrefetch` and others
*/
var activePinia;
/**
* Sets or unsets the active pinia. Used in SSR and internally when calling
* actions and getters
*
* @param pinia - Pinia instance
*/
var setActivePinia = (pinia) => activePinia = pinia;
var piniaSymbol = Symbol();
function isPlainObject(o) {
	return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
}
/**
* Possible types for SubscriptionCallback
*/
var MutationType;
(function(MutationType) {
	/**
	* Direct mutation of the state:
	*
	* - `store.name = 'new name'`
	* - `store.$state.name = 'new name'`
	* - `store.list.push('new item')`
	*/
	MutationType["direct"] = "direct";
	/**
	* Mutated the state with `$patch` and an object
	*
	* - `store.$patch({ name: 'newName' })`
	*/
	MutationType["patchObject"] = "patch object";
	/**
	* Mutated the state with `$patch` and a function
	*
	* - `store.$patch(state => state.name = 'newName')`
	*/
	MutationType["patchFunction"] = "patch function";
})(MutationType || (MutationType = {}));
var _global = typeof window === "object" && window.window === window ? window : typeof self === "object" && self.self === self ? self : typeof global === "object" && global.global === global ? global : typeof globalThis === "object" ? globalThis : { HTMLElement: null };
function bom(blob, { autoBom = false } = {}) {
	if (autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(blob.type)) return new Blob([String.fromCharCode(65279), blob], { type: blob.type });
	return blob;
}
function download(url, name, opts) {
	const xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.responseType = "blob";
	xhr.onload = function() {
		saveAs(xhr.response, name, opts);
	};
	xhr.onerror = function() {
		console.error("could not download file");
	};
	xhr.send();
}
function corsEnabled(url) {
	const xhr = new XMLHttpRequest();
	xhr.open("HEAD", url, false);
	try {
		xhr.send();
	} catch (e) {}
	return xhr.status >= 200 && xhr.status <= 299;
}
function click(node) {
	try {
		node.dispatchEvent(new MouseEvent("click"));
	} catch (e) {
		const evt = new MouseEvent("click", {
			bubbles: true,
			cancelable: true,
			view: window,
			detail: 0,
			screenX: 80,
			screenY: 20,
			clientX: 80,
			clientY: 20,
			ctrlKey: false,
			altKey: false,
			shiftKey: false,
			metaKey: false,
			button: 0,
			relatedTarget: null
		});
		node.dispatchEvent(evt);
	}
}
var _navigator = typeof navigator === "object" ? navigator : { userAgent: "" };
var isMacOSWebView = /Macintosh/.test(_navigator.userAgent) && /AppleWebKit/.test(_navigator.userAgent) && !/Safari/.test(_navigator.userAgent);
var saveAs = !IS_CLIENT ? () => {} : typeof HTMLAnchorElement !== "undefined" && "download" in HTMLAnchorElement.prototype && !isMacOSWebView ? downloadSaveAs : "msSaveOrOpenBlob" in _navigator ? msSaveAs : fileSaverSaveAs;
function downloadSaveAs(blob, name = "download", opts) {
	const a = document.createElement("a");
	a.download = name;
	a.rel = "noopener";
	if (typeof blob === "string") {
		a.href = blob;
		if (a.origin !== location.origin) if (corsEnabled(a.href)) download(blob, name, opts);
		else {
			a.target = "_blank";
			click(a);
		}
		else click(a);
	} else {
		a.href = URL.createObjectURL(blob);
		setTimeout(function() {
			URL.revokeObjectURL(a.href);
		}, 4e4);
		setTimeout(function() {
			click(a);
		}, 0);
	}
}
function msSaveAs(blob, name = "download", opts) {
	if (typeof blob === "string") if (corsEnabled(blob)) download(blob, name, opts);
	else {
		const a = document.createElement("a");
		a.href = blob;
		a.target = "_blank";
		setTimeout(function() {
			click(a);
		});
	}
	else navigator.msSaveOrOpenBlob(bom(blob, opts), name);
}
function fileSaverSaveAs(blob, name, opts, popup) {
	popup = popup || open("", "_blank");
	if (popup) popup.document.title = popup.document.body.innerText = "downloading...";
	if (typeof blob === "string") return download(blob, name, opts);
	const force = blob.type === "application/octet-stream";
	const isSafari = /constructor/i.test(String(_global.HTMLElement)) || "safari" in _global;
	const isChromeIOS = /CriOS\/[\d]+/.test(navigator.userAgent);
	if ((isChromeIOS || force && isSafari || isMacOSWebView) && typeof FileReader !== "undefined") {
		const reader = new FileReader();
		reader.onloadend = function() {
			let url = reader.result;
			if (typeof url !== "string") {
				popup = null;
				throw new Error("Wrong reader.result type");
			}
			url = isChromeIOS ? url : url.replace(/^data:[^;]*;/, "data:attachment/file;");
			if (popup) popup.location.href = url;
			else location.assign(url);
			popup = null;
		};
		reader.readAsDataURL(blob);
	} else {
		const url = URL.createObjectURL(blob);
		if (popup) popup.location.assign(url);
		else location.href = url;
		popup = null;
		setTimeout(function() {
			URL.revokeObjectURL(url);
		}, 4e4);
	}
}
var { assign: assign$1 } = Object;
/**
* Creates a Pinia instance to be used by the application
*/
function createPinia() {
	const scope = effectScope(true);
	const state = scope.run(() => ref({}));
	let _p = [];
	let toBeInstalled = [];
	const pinia = markRaw({
		install(app) {
			setActivePinia(pinia);
			pinia._a = app;
			app.provide(piniaSymbol, pinia);
			app.config.globalProperties.$pinia = pinia;
			toBeInstalled.forEach((plugin) => _p.push(plugin));
			toBeInstalled = [];
		},
		use(plugin) {
			if (!this._a) toBeInstalled.push(plugin);
			else _p.push(plugin);
			return this;
		},
		_p,
		_a: null,
		_e: scope,
		_s: /* @__PURE__ */ new Map(),
		state
	});
	return pinia;
}
var noop$1 = () => {};
function addSubscription(subscriptions, callback, detached, onCleanup = noop$1) {
	subscriptions.add(callback);
	const removeSubscription = () => {
		subscriptions.delete(callback) && onCleanup();
	};
	if (!detached && getCurrentScope()) onScopeDispose(removeSubscription);
	return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
	subscriptions.forEach((callback) => {
		callback(...args);
	});
}
var fallbackRunWithContext = (fn) => fn();
/**
* Marks a function as an action for `$onAction`
* @internal
*/
var ACTION_MARKER = Symbol();
/**
* Action name symbol. Allows to add a name to an action after defining it
* @internal
*/
var ACTION_NAME = Symbol();
function mergeReactiveObjects(target, patchToApply) {
	if (target instanceof Map && patchToApply instanceof Map) patchToApply.forEach((value, key) => target.set(key, value));
	else if (target instanceof Set && patchToApply instanceof Set) patchToApply.forEach(target.add, target);
	for (const key in patchToApply) {
		if (!patchToApply.hasOwnProperty(key)) continue;
		const subPatch = patchToApply[key];
		const targetValue = target[key];
		if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef(subPatch) && !isReactive(subPatch)) target[key] = mergeReactiveObjects(targetValue, subPatch);
		else target[key] = subPatch;
	}
	return target;
}
var skipHydrateSymbol = Symbol();
/**
* Returns whether a value should be hydrated
*
* @param obj - target variable
* @returns true if `obj` should be hydrated
*/
function shouldHydrate(obj) {
	return !isPlainObject(obj) || !Object.prototype.hasOwnProperty.call(obj, skipHydrateSymbol);
}
var { assign: assign$2 } = Object;
function isComputed(o) {
	return !!(isRef(o) && o.effect);
}
function createOptionsStore(id, options, pinia, hot) {
	const { state, actions, getters } = options;
	const initialState = pinia.state.value[id];
	let store;
	function setup() {
		if (!initialState && true)
 /* istanbul ignore if */
		pinia.state.value[id] = state ? state() : {};
		return assign$2(toRefs(pinia.state.value[id]), actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
			computedGetters[name] = markRaw(computed(() => {
				setActivePinia(pinia);
				const store = pinia._s.get(id);
				return getters[name].call(store, store);
			}));
			return computedGetters;
		}, {}));
	}
	store = createSetupStore(id, setup, options, pinia, hot, true);
	return store;
}
function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
	let scope;
	const optionsForPlugin = assign$2({ actions: {} }, options);
	const $subscribeOptions = { deep: true };
	let isListening;
	let isSyncListening;
	let subscriptions = /* @__PURE__ */ new Set();
	let actionSubscriptions = /* @__PURE__ */ new Set();
	let debuggerEvents;
	const initialState = pinia.state.value[$id];
	if (!isOptionsStore && !initialState && true)
 /* istanbul ignore if */
	pinia.state.value[$id] = {};
	ref({});
	let activeListener;
	function $patch(partialStateOrMutator) {
		let subscriptionMutation;
		isListening = isSyncListening = false;
		if (typeof partialStateOrMutator === "function") {
			partialStateOrMutator(pinia.state.value[$id]);
			subscriptionMutation = {
				type: MutationType.patchFunction,
				storeId: $id,
				events: debuggerEvents
			};
		} else {
			mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
			subscriptionMutation = {
				type: MutationType.patchObject,
				payload: partialStateOrMutator,
				storeId: $id,
				events: debuggerEvents
			};
		}
		const myListenerId = activeListener = Symbol();
		nextTick().then(() => {
			if (activeListener === myListenerId) isListening = true;
		});
		isSyncListening = true;
		triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
	}
	const $reset = isOptionsStore ? function $reset() {
		const { state } = options;
		const newState = state ? state() : {};
		this.$patch(($state) => {
			assign$2($state, newState);
		});
	} : noop$1;
	function $dispose() {
		scope.stop();
		subscriptions.clear();
		actionSubscriptions.clear();
		pinia._s.delete($id);
	}
	/**
	* Helper that wraps function so it can be tracked with $onAction
	* @param fn - action to wrap
	* @param name - name of the action
	*/
	const action = (fn, name = "") => {
		if (ACTION_MARKER in fn) {
			fn[ACTION_NAME] = name;
			return fn;
		}
		const wrappedAction = function() {
			setActivePinia(pinia);
			const args = Array.from(arguments);
			const afterCallbackSet = /* @__PURE__ */ new Set();
			const onErrorCallbackSet = /* @__PURE__ */ new Set();
			function after(callback) {
				afterCallbackSet.add(callback);
			}
			function onError(callback) {
				onErrorCallbackSet.add(callback);
			}
			triggerSubscriptions(actionSubscriptions, {
				args,
				name: wrappedAction[ACTION_NAME],
				store,
				after,
				onError
			});
			let ret;
			try {
				ret = fn.apply(this && this.$id === $id ? this : store, args);
			} catch (error) {
				triggerSubscriptions(onErrorCallbackSet, error);
				throw error;
			}
			if (ret instanceof Promise) return ret.then((value) => {
				triggerSubscriptions(afterCallbackSet, value);
				return value;
			}).catch((error) => {
				triggerSubscriptions(onErrorCallbackSet, error);
				return Promise.reject(error);
			});
			triggerSubscriptions(afterCallbackSet, ret);
			return ret;
		};
		wrappedAction[ACTION_MARKER] = true;
		wrappedAction[ACTION_NAME] = name;
		return wrappedAction;
	};
	const store = reactive({
		_p: pinia,
		$id,
		$onAction: addSubscription.bind(null, actionSubscriptions),
		$patch,
		$reset,
		$subscribe(callback, options = {}) {
			const removeSubscription = addSubscription(subscriptions, callback, options.detached, () => stopWatcher());
			const stopWatcher = scope.run(() => watch(() => pinia.state.value[$id], (state) => {
				if (options.flush === "sync" ? isSyncListening : isListening) callback({
					storeId: $id,
					type: MutationType.direct,
					events: debuggerEvents
				}, state);
			}, assign$2({}, $subscribeOptions, options)));
			return removeSubscription;
		},
		$dispose
	});
	pinia._s.set($id, store);
	const setupStore = (pinia._a && pinia._a.runWithContext || fallbackRunWithContext)(() => pinia._e.run(() => (scope = effectScope()).run(() => setup({ action }))));
	for (const key in setupStore) {
		const prop = setupStore[key];
		if (isRef(prop) && !isComputed(prop) || isReactive(prop)) {
			if (!isOptionsStore) {
				if (initialState && shouldHydrate(prop)) if (isRef(prop)) prop.value = initialState[key];
				else mergeReactiveObjects(prop, initialState[key]);
				pinia.state.value[$id][key] = prop;
			}
		} else if (typeof prop === "function") {
			setupStore[key] = action(prop, key);
			optionsForPlugin.actions[key] = prop;
		}
	}
	/* istanbul ignore if */
	assign$2(store, setupStore);
	assign$2(toRaw(store), setupStore);
	Object.defineProperty(store, "$state", {
		get: () => pinia.state.value[$id],
		set: (state) => {
			$patch(($state) => {
				assign$2($state, state);
			});
		}
	});
	pinia._p.forEach((extender) => {
		assign$2(store, scope.run(() => extender({
			store,
			app: pinia._a,
			pinia,
			options: optionsForPlugin
		})));
	});
	if (initialState && isOptionsStore && options.hydrate) options.hydrate(store.$state, initialState);
	isListening = true;
	isSyncListening = true;
	return store;
}
/*! #__NO_SIDE_EFFECTS__ */
function defineStore(id, setup, setupOptions) {
	let options;
	const isSetupStore = typeof setup === "function";
	options = isSetupStore ? setupOptions : setup;
	function useStore(pinia, hot) {
		const hasContext = hasInjectionContext();
		pinia = pinia || (hasContext ? inject(piniaSymbol, null) : null);
		if (pinia) setActivePinia(pinia);
		pinia = activePinia;
		if (!pinia._s.has(id)) if (isSetupStore) createSetupStore(id, setup, options, pinia);
		else createOptionsStore(id, options, pinia);
		return pinia._s.get(id);
	}
	useStore.$id = id;
	return useStore;
}
/**
* Creates an object of references with all the state, getters, and plugin-added
* state properties of the store. Similar to `toRefs()` but specifically
* designed for Pinia stores so methods and non reactive properties are
* completely ignored.
*
* @param store - store to extract the refs from
*/
function storeToRefs(store) {
	const rawStore = toRaw(store);
	const refs = {};
	for (const key in rawStore) {
		const value = rawStore[key];
		if (value.effect) refs[key] = computed({
			get: () => store[key],
			set(value) {
				store[key] = value;
			}
		});
		else if (isRef(value) || isReactive(value)) refs[key] = toRef(store, key);
	}
	return refs;
}
//#endregion
//#region src/stores/index.ts
var stores_default = defineStore$1(() => {
	return createPinia();
});
//#endregion
//#region node_modules/vue-router/dist/useApi-j1E6pMaV.js
/*!
* vue-router v5.0.3
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
var isBrowser = typeof document !== "undefined";
/**
* Allows differentiating lazy components from functional components and vue-class-component
* @internal
*
* @param component
*/
function isRouteComponent(component) {
	return typeof component === "object" || "displayName" in component || "props" in component || "__vccOpts" in component;
}
function isESModule(obj) {
	return obj.__esModule || obj[Symbol.toStringTag] === "Module" || obj.default && isRouteComponent(obj.default);
}
var assign = Object.assign;
function applyToParams(fn, params) {
	const newParams = {};
	for (const key in params) {
		const value = params[key];
		newParams[key] = isArray(value) ? value.map(fn) : fn(value);
	}
	return newParams;
}
var noop = () => {};
/**
* Typesafe alternative to Array.isArray
* https://github.com/microsoft/TypeScript/pull/48228
*
* @internal
*/
var isArray = Array.isArray;
function mergeOptions(defaults, partialOptions) {
	const options = {};
	for (const key in defaults) options[key] = key in partialOptions ? partialOptions[key] : defaults[key];
	return options;
}
/**
* Flags so we can combine them when checking for multiple errors. This is the internal version of
* {@link NavigationFailureType}.
*
* @internal
*/
var ErrorTypes = /* @__PURE__ */ function(ErrorTypes) {
	ErrorTypes[ErrorTypes["MATCHER_NOT_FOUND"] = 1] = "MATCHER_NOT_FOUND";
	ErrorTypes[ErrorTypes["NAVIGATION_GUARD_REDIRECT"] = 2] = "NAVIGATION_GUARD_REDIRECT";
	ErrorTypes[ErrorTypes["NAVIGATION_ABORTED"] = 4] = "NAVIGATION_ABORTED";
	ErrorTypes[ErrorTypes["NAVIGATION_CANCELLED"] = 8] = "NAVIGATION_CANCELLED";
	ErrorTypes[ErrorTypes["NAVIGATION_DUPLICATED"] = 16] = "NAVIGATION_DUPLICATED";
	return ErrorTypes;
}({});
var NavigationFailureSymbol = Symbol("");
ErrorTypes.MATCHER_NOT_FOUND, ErrorTypes.NAVIGATION_GUARD_REDIRECT, ErrorTypes.NAVIGATION_ABORTED, ErrorTypes.NAVIGATION_CANCELLED, ErrorTypes.NAVIGATION_DUPLICATED;
/**
* Creates a typed NavigationFailure object.
* @internal
* @param type - NavigationFailureType
* @param params - { from, to }
*/
function createRouterError(type, params) {
	return assign(/* @__PURE__ */ new Error(), {
		type,
		[NavigationFailureSymbol]: true
	}, params);
}
function isNavigationFailure(error, type) {
	return error instanceof Error && NavigationFailureSymbol in error && (type == null || !!(error.type & type));
}
/**
* RouteRecord being rendered by the closest ancestor Router View. Used for
* `onBeforeRouteUpdate` and `onBeforeRouteLeave`. rvlm stands for Router View
* Location Matched
*
* @internal
*/
var matchedRouteKey = Symbol("");
/**
* Allows overriding the router view depth to control which component in
* `matched` is rendered. rvd stands for Router View Depth
*
* @internal
*/
var viewDepthKey = Symbol("");
/**
* Allows overriding the router instance returned by `useRouter` in tests. r
* stands for router
*
* @internal
*/
var routerKey = Symbol("");
/**
* Allows overriding the current route returned by `useRoute` in tests. rl
* stands for route location
*
* @internal
*/
var routeLocationKey = Symbol("");
/**
* Allows overriding the current route used by router-view. Internally this is
* used when the `route` prop is passed.
*
* @internal
*/
var routerViewLocationKey = Symbol("");
/**
* Returns the current route location. Equivalent to using `$route` inside
* templates.
*/
function useRoute(_name) {
	return inject(routeLocationKey);
}
//#endregion
//#region node_modules/vue-router/dist/devtools-CVsCuYdF.js
/*!
* vue-router v5.0.3
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
/**
* Encoding Rules (␣ = Space)
* - Path: ␣ " < > # ? { }
* - Query: ␣ " < > # & =
* - Hash: ␣ " < > `
*
* On top of that, the RFC3986 (https://tools.ietf.org/html/rfc3986#section-2.2)
* defines some extra characters to be encoded. Most browsers do not encode them
* in encodeURI https://github.com/whatwg/url/issues/369, so it may be safer to
* also encode `!'()*`. Leaving un-encoded only ASCII alphanumeric(`a-zA-Z0-9`)
* plus `-._~`. This extra safety should be applied to query by patching the
* string returned by encodeURIComponent encodeURI also encodes `[\]^`. `\`
* should be encoded to avoid ambiguity. Browsers (IE, FF, C) transform a `\`
* into a `/` if directly typed in. The _backtick_ (`````) should also be
* encoded everywhere because some browsers like FF encode it when directly
* written while others don't. Safari and IE don't encode ``"<>{}``` in hash.
*/
var HASH_RE = /#/g;
var AMPERSAND_RE = /&/g;
var SLASH_RE = /\//g;
var EQUAL_RE = /=/g;
var IM_RE = /\?/g;
var PLUS_RE = /\+/g;
/**
* NOTE: It's not clear to me if we should encode the + symbol in queries, it
* seems to be less flexible than not doing so and I can't find out the legacy
* systems requiring this for regular requests like text/html. In the standard,
* the encoding of the plus character is only mentioned for
* application/x-www-form-urlencoded
* (https://url.spec.whatwg.org/#urlencoded-parsing) and most browsers seems lo
* leave the plus character as is in queries. To be more flexible, we allow the
* plus character on the query, but it can also be manually encoded by the user.
*
* Resources:
* - https://url.spec.whatwg.org/#urlencoded-parsing
* - https://stackoverflow.com/questions/1634271/url-encoding-the-space-character-or-20
*/
var ENC_BRACKET_OPEN_RE = /%5B/g;
var ENC_BRACKET_CLOSE_RE = /%5D/g;
var ENC_CARET_RE = /%5E/g;
var ENC_BACKTICK_RE = /%60/g;
var ENC_CURLY_OPEN_RE = /%7B/g;
var ENC_PIPE_RE = /%7C/g;
var ENC_CURLY_CLOSE_RE = /%7D/g;
var ENC_SPACE_RE = /%20/g;
/**
* Encode characters that need to be encoded on the path, search and hash
* sections of the URL.
*
* @internal
* @param text - string to encode
* @returns encoded string
*/
function commonEncode(text) {
	return text == null ? "" : encodeURI("" + text).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]");
}
/**
* Encode characters that need to be encoded on the hash section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeHash(text) {
	return commonEncode(text).replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Encode characters that need to be encoded query values on the query
* section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeQueryValue(text) {
	return commonEncode(text).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Like `encodeQueryValue` but also encodes the `=` character.
*
* @param text - string to encode
*/
function encodeQueryKey(text) {
	return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
/**
* Encode characters that need to be encoded on the path section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodePath(text) {
	return commonEncode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F");
}
/**
* Encode characters that need to be encoded on the path section of the URL as a
* param. This function encodes everything {@link encodePath} does plus the
* slash (`/`) character. If `text` is `null` or `undefined`, returns an empty
* string instead.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeParam(text) {
	return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode$1(text) {
	if (text == null) return null;
	try {
		return decodeURIComponent("" + text);
	} catch (err) {}
	return "" + text;
}
var TRAILING_SLASH_RE = /\/$/;
var removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, "");
/**
* Transforms a URI into a normalized history location
*
* @param parseQuery
* @param location - URI to normalize
* @param currentLocation - current absolute location. Allows resolving relative
* paths. Must start with `/`. Defaults to `/`
* @returns a normalized history location
*/
function parseURL(parseQuery, location, currentLocation = "/") {
	let path, query = {}, searchString = "", hash = "";
	const hashPos = location.indexOf("#");
	let searchPos = location.indexOf("?");
	searchPos = hashPos >= 0 && searchPos > hashPos ? -1 : searchPos;
	if (searchPos >= 0) {
		path = location.slice(0, searchPos);
		searchString = location.slice(searchPos, hashPos > 0 ? hashPos : location.length);
		query = parseQuery(searchString.slice(1));
	}
	if (hashPos >= 0) {
		path = path || location.slice(0, hashPos);
		hash = location.slice(hashPos, location.length);
	}
	path = resolveRelativePath(path != null ? path : location, currentLocation);
	return {
		fullPath: path + searchString + hash,
		path,
		query,
		hash: decode$1(hash)
	};
}
/**
* Stringifies a URL object
*
* @param stringifyQuery
* @param location
*/
function stringifyURL(stringifyQuery, location) {
	const query = location.query ? stringifyQuery(location.query) : "";
	return location.path + (query && "?") + query + (location.hash || "");
}
/**
* Strips off the base from the beginning of a location.pathname in a non-case-sensitive way.
*
* @param pathname - location.pathname
* @param base - base to strip off
*/
function stripBase(pathname, base) {
	if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase())) return pathname;
	return pathname.slice(base.length) || "/";
}
/**
* Checks if two RouteLocation are equal. This means that both locations are
* pointing towards the same {@link RouteRecord} and that all `params`, `query`
* parameters and `hash` are the same
*
* @param stringifyQuery - A function that takes a query object of type LocationQueryRaw and returns a string representation of it.
* @param a - first {@link RouteLocation}
* @param b - second {@link RouteLocation}
*/
function isSameRouteLocation(stringifyQuery, a, b) {
	const aLastIndex = a.matched.length - 1;
	const bLastIndex = b.matched.length - 1;
	return aLastIndex > -1 && aLastIndex === bLastIndex && isSameRouteRecord$1(a.matched[aLastIndex], b.matched[bLastIndex]) && isSameRouteLocationParams$1(a.params, b.params) && stringifyQuery(a.query) === stringifyQuery(b.query) && a.hash === b.hash;
}
/**
* Check if two `RouteRecords` are equal. Takes into account aliases: they are
* considered equal to the `RouteRecord` they are aliasing.
*
* @param a - first {@link RouteRecord}
* @param b - second {@link RouteRecord}
*/
function isSameRouteRecord$1(a, b) {
	return (a.aliasOf || a) === (b.aliasOf || b);
}
function isSameRouteLocationParams$1(a, b) {
	if (Object.keys(a).length !== Object.keys(b).length) return false;
	for (var key in a) if (!isSameRouteLocationParamsValue$1(a[key], b[key])) return false;
	return true;
}
function isSameRouteLocationParamsValue$1(a, b) {
	return isArray(a) ? isEquivalentArray$1(a, b) : isArray(b) ? isEquivalentArray$1(b, a) : (a && a.valueOf()) === (b && b.valueOf());
}
/**
* Check if two arrays are the same or if an array with one single entry is the
* same as another primitive value. Used to check query and parameters
*
* @param a - array of values
* @param b - array of values or a single value
*/
function isEquivalentArray$1(a, b) {
	return isArray(b) ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
}
/**
* Resolves a relative path that starts with `.`.
*
* @param to - path location we are resolving
* @param from - currentLocation.path, should start with `/`
*/
function resolveRelativePath(to, from) {
	if (to.startsWith("/")) return to;
	if (!to) return from;
	const fromSegments = from.split("/");
	const toSegments = to.split("/");
	const lastToSegment = toSegments[toSegments.length - 1];
	if (lastToSegment === ".." || lastToSegment === ".") toSegments.push("");
	let position = fromSegments.length - 1;
	let toPosition;
	let segment;
	for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
		segment = toSegments[toPosition];
		if (segment === ".") continue;
		if (segment === "..") {
			if (position > 1) position--;
		} else break;
	}
	return fromSegments.slice(0, position).join("/") + "/" + toSegments.slice(toPosition).join("/");
}
/**
* Initial route location where the router is. Can be used in navigation guards
* to differentiate the initial navigation.
*
* @example
* ```js
* import { START_LOCATION } from 'vue-router'
*
* router.beforeEach((to, from) => {
*   if (from === START_LOCATION) {
*     // initial navigation
*   }
* })
* ```
*/
var START_LOCATION_NORMALIZED = {
	path: "/",
	name: void 0,
	params: {},
	query: {},
	hash: "",
	fullPath: "/",
	matched: [],
	meta: {},
	redirectedFrom: void 0
};
var NavigationType = /* @__PURE__ */ function(NavigationType) {
	NavigationType["pop"] = "pop";
	NavigationType["push"] = "push";
	return NavigationType;
}({});
var NavigationDirection = /* @__PURE__ */ function(NavigationDirection) {
	NavigationDirection["back"] = "back";
	NavigationDirection["forward"] = "forward";
	NavigationDirection["unknown"] = "";
	return NavigationDirection;
}({});
/**
* Normalizes a base by removing any trailing slash and reading the base tag if
* present.
*
* @param base - base to normalize
*/
function normalizeBase(base) {
	if (!base) if (isBrowser) {
		const baseEl = document.querySelector("base");
		base = baseEl && baseEl.getAttribute("href") || "/";
		base = base.replace(/^\w+:\/\/[^\/]+/, "");
	} else base = "/";
	if (base[0] !== "/" && base[0] !== "#") base = "/" + base;
	return removeTrailingSlash(base);
}
var BEFORE_HASH_RE = /^[^#]+#/;
function createHref(base, location) {
	return base.replace(BEFORE_HASH_RE, "#") + location;
}
function getElementPosition(el, offset) {
	const docRect = document.documentElement.getBoundingClientRect();
	const elRect = el.getBoundingClientRect();
	return {
		behavior: offset.behavior,
		left: elRect.left - docRect.left - (offset.left || 0),
		top: elRect.top - docRect.top - (offset.top || 0)
	};
}
var computeScrollPosition = () => ({
	left: window.scrollX,
	top: window.scrollY
});
function scrollToPosition(position) {
	let scrollToOptions;
	if ("el" in position) {
		const positionEl = position.el;
		const isIdSelector = typeof positionEl === "string" && positionEl.startsWith("#");
		const el = typeof positionEl === "string" ? isIdSelector ? document.getElementById(positionEl.slice(1)) : document.querySelector(positionEl) : positionEl;
		if (!el) return;
		scrollToOptions = getElementPosition(el, position);
	} else scrollToOptions = position;
	if ("scrollBehavior" in document.documentElement.style) window.scrollTo(scrollToOptions);
	else window.scrollTo(scrollToOptions.left != null ? scrollToOptions.left : window.scrollX, scrollToOptions.top != null ? scrollToOptions.top : window.scrollY);
}
function getScrollKey(path, delta) {
	return (history.state ? history.state.position - delta : -1) + path;
}
var scrollPositions = /* @__PURE__ */ new Map();
function saveScrollPosition(key, scrollPosition) {
	scrollPositions.set(key, scrollPosition);
}
function getSavedScrollPosition(key) {
	const scroll = scrollPositions.get(key);
	scrollPositions.delete(key);
	return scroll;
}
/**
* ScrollBehavior instance used by the router to compute and restore the scroll
* position when navigating.
*/
function isRouteLocation(route) {
	return typeof route === "string" || route && typeof route === "object";
}
function isRouteName(name) {
	return typeof name === "string" || typeof name === "symbol";
}
/**
* Transforms a queryString into a {@link LocationQuery} object. Accept both, a
* version with the leading `?` and without Should work as URLSearchParams

* @internal
*
* @param search - search string to parse
* @returns a query object
*/
function parseQuery(search) {
	const query = {};
	if (search === "" || search === "?") return query;
	const searchParams = (search[0] === "?" ? search.slice(1) : search).split("&");
	for (let i = 0; i < searchParams.length; ++i) {
		const searchParam = searchParams[i].replace(PLUS_RE, " ");
		const eqPos = searchParam.indexOf("=");
		const key = decode$1(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
		const value = eqPos < 0 ? null : decode$1(searchParam.slice(eqPos + 1));
		if (key in query) {
			let currentValue = query[key];
			if (!isArray(currentValue)) currentValue = query[key] = [currentValue];
			currentValue.push(value);
		} else query[key] = value;
	}
	return query;
}
/**
* Stringifies a {@link LocationQueryRaw} object. Like `URLSearchParams`, it
* doesn't prepend a `?`
*
* @internal
*
* @param query - query object to stringify
* @returns string version of the query without the leading `?`
*/
function stringifyQuery(query) {
	let search = "";
	for (let key in query) {
		const value = query[key];
		key = encodeQueryKey(key);
		if (value == null) {
			if (value !== void 0) search += (search.length ? "&" : "") + key;
			continue;
		}
		(isArray(value) ? value.map((v) => v && encodeQueryValue(v)) : [value && encodeQueryValue(value)]).forEach((value) => {
			if (value !== void 0) {
				search += (search.length ? "&" : "") + key;
				if (value != null) search += "=" + value;
			}
		});
	}
	return search;
}
/**
* Transforms a {@link LocationQueryRaw} into a {@link LocationQuery} by casting
* numbers into strings, removing keys with an undefined value and replacing
* undefined with null in arrays
*
* @param query - query object to normalize
* @returns a normalized query object
*/
function normalizeQuery(query) {
	const normalizedQuery = {};
	for (const key in query) {
		const value = query[key];
		if (value !== void 0) normalizedQuery[key] = isArray(value) ? value.map((v) => v == null ? null : "" + v) : value == null ? value : "" + value;
	}
	return normalizedQuery;
}
/**
* Create a list of callbacks that can be reset. Used to create before and after navigation guards list
*/
function useCallbacks() {
	let handlers = [];
	function add(handler) {
		handlers.push(handler);
		return () => {
			const i = handlers.indexOf(handler);
			if (i > -1) handlers.splice(i, 1);
		};
	}
	function reset() {
		handlers = [];
	}
	return {
		add,
		list: () => handlers.slice(),
		reset
	};
}
function guardToPromiseFn(guard, to, from, record, name, runWithContext = (fn) => fn()) {
	const enterCallbackArray = record && (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
	return () => new Promise((resolve, reject) => {
		const next = (valid) => {
			if (valid === false) reject(createRouterError(ErrorTypes.NAVIGATION_ABORTED, {
				from,
				to
			}));
			else if (valid instanceof Error) reject(valid);
			else if (isRouteLocation(valid)) reject(createRouterError(ErrorTypes.NAVIGATION_GUARD_REDIRECT, {
				from: to,
				to: valid
			}));
			else {
				if (enterCallbackArray && record.enterCallbacks[name] === enterCallbackArray && typeof valid === "function") enterCallbackArray.push(valid);
				resolve();
			}
		};
		const guardReturn = runWithContext(() => guard.call(record && record.instances[name], to, from, next));
		let guardCall = Promise.resolve(guardReturn);
		if (guard.length < 3) guardCall = guardCall.then(next);
		guardCall.catch((err) => reject(err));
	});
}
function extractComponentsGuards(matched, guardType, to, from, runWithContext = (fn) => fn()) {
	const guards = [];
	for (const record of matched) for (const name in record.components) {
		let rawComponent = record.components[name];
		if (guardType !== "beforeRouteEnter" && !record.instances[name]) continue;
		if (isRouteComponent(rawComponent)) {
			const guard = (rawComponent.__vccOpts || rawComponent)[guardType];
			guard && guards.push(guardToPromiseFn(guard, to, from, record, name, runWithContext));
		} else {
			let componentPromise = rawComponent();
			guards.push(() => componentPromise.then((resolved) => {
				if (!resolved) throw new Error(`Couldn't resolve component "${name}" at "${record.path}"`);
				const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
				record.mods[name] = resolved;
				record.components[name] = resolvedComponent;
				const guard = (resolvedComponent.__vccOpts || resolvedComponent)[guardType];
				return guard && guardToPromiseFn(guard, to, from, record, name, runWithContext)();
			}));
		}
	}
	return guards;
}
/**
* Split the leaving, updating, and entering records.
* @internal
*
* @param  to - Location we are navigating to
* @param from - Location we are navigating from
*/
function extractChangingRecords(to, from) {
	const leavingRecords = [];
	const updatingRecords = [];
	const enteringRecords = [];
	const len = Math.max(from.matched.length, to.matched.length);
	for (let i = 0; i < len; i++) {
		const recordFrom = from.matched[i];
		if (recordFrom) if (to.matched.find((record) => isSameRouteRecord$1(record, recordFrom))) updatingRecords.push(recordFrom);
		else leavingRecords.push(recordFrom);
		const recordTo = to.matched[i];
		if (recordTo) {
			if (!from.matched.find((record) => isSameRouteRecord$1(record, recordTo))) enteringRecords.push(recordTo);
		}
	}
	return [
		leavingRecords,
		updatingRecords,
		enteringRecords
	];
}
//#endregion
//#region node_modules/vue-router/dist/vue-router.js
/*!
* vue-router v5.0.3
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
var createBaseLocation = () => location.protocol + "//" + location.host;
/**
* Creates a normalized history location from a window.location object
* @param base - The base path
* @param location - The window.location object
*/
function createCurrentLocation(base, location) {
	const { pathname, search, hash } = location;
	const hashPos = base.indexOf("#");
	if (hashPos > -1) {
		let slicePos = hash.includes(base.slice(hashPos)) ? base.slice(hashPos).length : 1;
		let pathFromHash = hash.slice(slicePos);
		if (pathFromHash[0] !== "/") pathFromHash = "/" + pathFromHash;
		return stripBase(pathFromHash, "");
	}
	return stripBase(pathname, base) + search + hash;
}
function useHistoryListeners(base, historyState, currentLocation, replace) {
	let listeners = [];
	let teardowns = [];
	let pauseState = null;
	const popStateHandler = ({ state }) => {
		const to = createCurrentLocation(base, location);
		const from = currentLocation.value;
		const fromState = historyState.value;
		let delta = 0;
		if (state) {
			currentLocation.value = to;
			historyState.value = state;
			if (pauseState && pauseState === from) {
				pauseState = null;
				return;
			}
			delta = fromState ? state.position - fromState.position : 0;
		} else replace(to);
		listeners.forEach((listener) => {
			listener(currentLocation.value, from, {
				delta,
				type: NavigationType.pop,
				direction: delta ? delta > 0 ? NavigationDirection.forward : NavigationDirection.back : NavigationDirection.unknown
			});
		});
	};
	function pauseListeners() {
		pauseState = currentLocation.value;
	}
	function listen(callback) {
		listeners.push(callback);
		const teardown = () => {
			const index = listeners.indexOf(callback);
			if (index > -1) listeners.splice(index, 1);
		};
		teardowns.push(teardown);
		return teardown;
	}
	function beforeUnloadListener() {
		if (document.visibilityState === "hidden") {
			const { history } = window;
			if (!history.state) return;
			history.replaceState(assign({}, history.state, { scroll: computeScrollPosition() }), "");
		}
	}
	function destroy() {
		for (const teardown of teardowns) teardown();
		teardowns = [];
		window.removeEventListener("popstate", popStateHandler);
		window.removeEventListener("pagehide", beforeUnloadListener);
		document.removeEventListener("visibilitychange", beforeUnloadListener);
	}
	window.addEventListener("popstate", popStateHandler);
	window.addEventListener("pagehide", beforeUnloadListener);
	document.addEventListener("visibilitychange", beforeUnloadListener);
	return {
		pauseListeners,
		listen,
		destroy
	};
}
/**
* Creates a state object
*/
function buildState(back, current, forward, replaced = false, computeScroll = false) {
	return {
		back,
		current,
		forward,
		replaced,
		position: window.history.length,
		scroll: computeScroll ? computeScrollPosition() : null
	};
}
function useHistoryStateNavigation(base) {
	const { history, location } = window;
	const currentLocation = { value: createCurrentLocation(base, location) };
	const historyState = { value: history.state };
	if (!historyState.value) changeLocation(currentLocation.value, {
		back: null,
		current: currentLocation.value,
		forward: null,
		position: history.length - 1,
		replaced: true,
		scroll: null
	}, true);
	function changeLocation(to, state, replace) {
		/**
		* if a base tag is provided, and we are on a normal domain, we have to
		* respect the provided `base` attribute because pushState() will use it and
		* potentially erase anything before the `#` like at
		* https://github.com/vuejs/router/issues/685 where a base of
		* `/folder/#` but a base of `/` would erase the `/folder/` section. If
		* there is no host, the `<base>` tag makes no sense and if there isn't a
		* base tag we can just use everything after the `#`.
		*/
		const hashIndex = base.indexOf("#");
		const url = hashIndex > -1 ? (location.host && document.querySelector("base") ? base : base.slice(hashIndex)) + to : createBaseLocation() + base + to;
		try {
			history[replace ? "replaceState" : "pushState"](state, "", url);
			historyState.value = state;
		} catch (err) {
			console.error(err);
			location[replace ? "replace" : "assign"](url);
		}
	}
	function replace(to, data) {
		changeLocation(to, assign({}, history.state, buildState(historyState.value.back, to, historyState.value.forward, true), data, { position: historyState.value.position }), true);
		currentLocation.value = to;
	}
	function push(to, data) {
		const currentState = assign({}, historyState.value, history.state, {
			forward: to,
			scroll: computeScrollPosition()
		});
		changeLocation(currentState.current, currentState, true);
		changeLocation(to, assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data), false);
		currentLocation.value = to;
	}
	return {
		location: currentLocation,
		state: historyState,
		push,
		replace
	};
}
/**
* Creates an HTML5 history. Most common history for single page applications.
*
* @param base -
*/
function createWebHistory(base) {
	base = normalizeBase(base);
	const historyNavigation = useHistoryStateNavigation(base);
	const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
	function go(delta, triggerListeners = true) {
		if (!triggerListeners) historyListeners.pauseListeners();
		history.go(delta);
	}
	const routerHistory = assign({
		location: "",
		base,
		go,
		createHref: createHref.bind(null, base)
	}, historyNavigation, historyListeners);
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => historyNavigation.location.value
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => historyNavigation.state.value
	});
	return routerHistory;
}
/**
* Creates a hash history. Useful for web applications with no host (e.g. `file://`) or when configuring a server to
* handle any URL is not possible.
*
* @param base - optional base to provide. Defaults to `location.pathname + location.search` If there is a `<base>` tag
* in the `head`, its value will be ignored in favor of this parameter **but note it affects all the history.pushState()
* calls**, meaning that if you use a `<base>` tag, it's `href` value **has to match this parameter** (ignoring anything
* after the `#`).
*
* @example
* ```js
* // at https://example.com/folder
* createWebHashHistory() // gives a url of `https://example.com/folder#`
* createWebHashHistory('/folder/') // gives a url of `https://example.com/folder/#`
* // if the `#` is provided in the base, it won't be added by `createWebHashHistory`
* createWebHashHistory('/folder/#/app/') // gives a url of `https://example.com/folder/#/app/`
* // you should avoid doing this because it changes the original url and breaks copying urls
* createWebHashHistory('/other-folder/') // gives a url of `https://example.com/other-folder/#`
*
* // at file:///usr/etc/folder/index.html
* // for locations with no `host`, the base is ignored
* createWebHashHistory('/iAmIgnored') // gives a url of `file:///usr/etc/folder/index.html#`
* ```
*/
function createWebHashHistory(base) {
	base = location.host ? base || location.pathname + location.search : "";
	if (!base.includes("#")) base += "#";
	return createWebHistory(base);
}
var TokenType = /* @__PURE__ */ function(TokenType) {
	TokenType[TokenType["Static"] = 0] = "Static";
	TokenType[TokenType["Param"] = 1] = "Param";
	TokenType[TokenType["Group"] = 2] = "Group";
	return TokenType;
}({});
var TokenizerState = /* @__PURE__ */ function(TokenizerState) {
	TokenizerState[TokenizerState["Static"] = 0] = "Static";
	TokenizerState[TokenizerState["Param"] = 1] = "Param";
	TokenizerState[TokenizerState["ParamRegExp"] = 2] = "ParamRegExp";
	TokenizerState[TokenizerState["ParamRegExpEnd"] = 3] = "ParamRegExpEnd";
	TokenizerState[TokenizerState["EscapeNext"] = 4] = "EscapeNext";
	return TokenizerState;
}(TokenizerState || {});
var ROOT_TOKEN = {
	type: TokenType.Static,
	value: ""
};
var VALID_PARAM_RE = /[a-zA-Z0-9_]/;
function tokenizePath(path) {
	if (!path) return [[]];
	if (path === "/") return [[ROOT_TOKEN]];
	if (!path.startsWith("/")) throw new Error(`Invalid path "${path}"`);
	function crash(message) {
		throw new Error(`ERR (${state})/"${buffer}": ${message}`);
	}
	let state = TokenizerState.Static;
	let previousState = state;
	const tokens = [];
	let segment;
	function finalizeSegment() {
		if (segment) tokens.push(segment);
		segment = [];
	}
	let i = 0;
	let char;
	let buffer = "";
	let customRe = "";
	function consumeBuffer() {
		if (!buffer) return;
		if (state === TokenizerState.Static) segment.push({
			type: TokenType.Static,
			value: buffer
		});
		else if (state === TokenizerState.Param || state === TokenizerState.ParamRegExp || state === TokenizerState.ParamRegExpEnd) {
			if (segment.length > 1 && (char === "*" || char === "+")) crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
			segment.push({
				type: TokenType.Param,
				value: buffer,
				regexp: customRe,
				repeatable: char === "*" || char === "+",
				optional: char === "*" || char === "?"
			});
		} else crash("Invalid state to consume buffer");
		buffer = "";
	}
	function addCharToBuffer() {
		buffer += char;
	}
	while (i < path.length) {
		char = path[i++];
		if (char === "\\" && state !== TokenizerState.ParamRegExp) {
			previousState = state;
			state = TokenizerState.EscapeNext;
			continue;
		}
		switch (state) {
			case TokenizerState.Static:
				if (char === "/") {
					if (buffer) consumeBuffer();
					finalizeSegment();
				} else if (char === ":") {
					consumeBuffer();
					state = TokenizerState.Param;
				} else addCharToBuffer();
				break;
			case TokenizerState.EscapeNext:
				addCharToBuffer();
				state = previousState;
				break;
			case TokenizerState.Param:
				if (char === "(") state = TokenizerState.ParamRegExp;
				else if (VALID_PARAM_RE.test(char)) addCharToBuffer();
				else {
					consumeBuffer();
					state = TokenizerState.Static;
					if (char !== "*" && char !== "?" && char !== "+") i--;
				}
				break;
			case TokenizerState.ParamRegExp:
				if (char === ")") if (customRe[customRe.length - 1] == "\\") customRe = customRe.slice(0, -1) + char;
				else state = TokenizerState.ParamRegExpEnd;
				else customRe += char;
				break;
			case TokenizerState.ParamRegExpEnd:
				consumeBuffer();
				state = TokenizerState.Static;
				if (char !== "*" && char !== "?" && char !== "+") i--;
				customRe = "";
				break;
			default:
				crash("Unknown state");
				break;
		}
	}
	if (state === TokenizerState.ParamRegExp) crash(`Unfinished custom RegExp for param "${buffer}"`);
	consumeBuffer();
	finalizeSegment();
	return tokens;
}
var BASE_PARAM_PATTERN = "[^/]+?";
var BASE_PATH_PARSER_OPTIONS = {
	sensitive: false,
	strict: false,
	start: true,
	end: true
};
var PathScore = /* @__PURE__ */ function(PathScore) {
	PathScore[PathScore["_multiplier"] = 10] = "_multiplier";
	PathScore[PathScore["Root"] = 90] = "Root";
	PathScore[PathScore["Segment"] = 40] = "Segment";
	PathScore[PathScore["SubSegment"] = 30] = "SubSegment";
	PathScore[PathScore["Static"] = 40] = "Static";
	PathScore[PathScore["Dynamic"] = 20] = "Dynamic";
	PathScore[PathScore["BonusCustomRegExp"] = 10] = "BonusCustomRegExp";
	PathScore[PathScore["BonusWildcard"] = -50] = "BonusWildcard";
	PathScore[PathScore["BonusRepeatable"] = -20] = "BonusRepeatable";
	PathScore[PathScore["BonusOptional"] = -8] = "BonusOptional";
	PathScore[PathScore["BonusStrict"] = .7000000000000001] = "BonusStrict";
	PathScore[PathScore["BonusCaseSensitive"] = .25] = "BonusCaseSensitive";
	return PathScore;
}(PathScore || {});
var REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
/**
* Creates a path parser from an array of Segments (a segment is an array of Tokens)
*
* @param segments - array of segments returned by tokenizePath
* @param extraOptions - optional options for the regexp
* @returns a PathParser
*/
function tokensToParser(segments, extraOptions) {
	const options = assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
	const score = [];
	let pattern = options.start ? "^" : "";
	const keys = [];
	for (const segment of segments) {
		const segmentScores = segment.length ? [] : [PathScore.Root];
		if (options.strict && !segment.length) pattern += "/";
		for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
			const token = segment[tokenIndex];
			let subSegmentScore = PathScore.Segment + (options.sensitive ? PathScore.BonusCaseSensitive : 0);
			if (token.type === TokenType.Static) {
				if (!tokenIndex) pattern += "/";
				pattern += token.value.replace(REGEX_CHARS_RE, "\\$&");
				subSegmentScore += PathScore.Static;
			} else if (token.type === TokenType.Param) {
				const { value, repeatable, optional, regexp } = token;
				keys.push({
					name: value,
					repeatable,
					optional
				});
				const re = regexp ? regexp : BASE_PARAM_PATTERN;
				if (re !== BASE_PARAM_PATTERN) {
					subSegmentScore += PathScore.BonusCustomRegExp;
					try {
						new RegExp(`(${re})`);
					} catch (err) {
						throw new Error(`Invalid custom RegExp for param "${value}" (${re}): ` + err.message);
					}
				}
				let subPattern = repeatable ? `((?:${re})(?:/(?:${re}))*)` : `(${re})`;
				if (!tokenIndex) subPattern = optional && segment.length < 2 ? `(?:/${subPattern})` : "/" + subPattern;
				if (optional) subPattern += "?";
				pattern += subPattern;
				subSegmentScore += PathScore.Dynamic;
				if (optional) subSegmentScore += PathScore.BonusOptional;
				if (repeatable) subSegmentScore += PathScore.BonusRepeatable;
				if (re === ".*") subSegmentScore += PathScore.BonusWildcard;
			}
			segmentScores.push(subSegmentScore);
		}
		score.push(segmentScores);
	}
	if (options.strict && options.end) {
		const i = score.length - 1;
		score[i][score[i].length - 1] += PathScore.BonusStrict;
	}
	if (!options.strict) pattern += "/?";
	if (options.end) pattern += "$";
	else if (options.strict && !pattern.endsWith("/")) pattern += "(?:/|$)";
	const re = new RegExp(pattern, options.sensitive ? "" : "i");
	function parse(path) {
		const match = path.match(re);
		const params = {};
		if (!match) return null;
		for (let i = 1; i < match.length; i++) {
			const value = match[i] || "";
			const key = keys[i - 1];
			params[key.name] = value && key.repeatable ? value.split("/") : value;
		}
		return params;
	}
	function stringify(params) {
		let path = "";
		let avoidDuplicatedSlash = false;
		for (const segment of segments) {
			if (!avoidDuplicatedSlash || !path.endsWith("/")) path += "/";
			avoidDuplicatedSlash = false;
			for (const token of segment) if (token.type === TokenType.Static) path += token.value;
			else if (token.type === TokenType.Param) {
				const { value, repeatable, optional } = token;
				const param = value in params ? params[value] : "";
				if (isArray(param) && !repeatable) throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
				const text = isArray(param) ? param.join("/") : param;
				if (!text) if (optional) {
					if (segment.length < 2) if (path.endsWith("/")) path = path.slice(0, -1);
					else avoidDuplicatedSlash = true;
				} else throw new Error(`Missing required param "${value}"`);
				path += text;
			}
		}
		return path || "/";
	}
	return {
		re,
		score,
		keys,
		parse,
		stringify
	};
}
/**
* Compares an array of numbers as used in PathParser.score and returns a
* number. This function can be used to `sort` an array
*
* @param a - first array of numbers
* @param b - second array of numbers
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
* should be sorted first
*/
function compareScoreArray(a, b) {
	let i = 0;
	while (i < a.length && i < b.length) {
		const diff = b[i] - a[i];
		if (diff) return diff;
		i++;
	}
	if (a.length < b.length) return a.length === 1 && a[0] === PathScore.Static + PathScore.Segment ? -1 : 1;
	else if (a.length > b.length) return b.length === 1 && b[0] === PathScore.Static + PathScore.Segment ? 1 : -1;
	return 0;
}
/**
* Compare function that can be used with `sort` to sort an array of PathParser
*
* @param a - first PathParser
* @param b - second PathParser
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
*/
function comparePathParserScore(a, b) {
	let i = 0;
	const aScore = a.score;
	const bScore = b.score;
	while (i < aScore.length && i < bScore.length) {
		const comp = compareScoreArray(aScore[i], bScore[i]);
		if (comp) return comp;
		i++;
	}
	if (Math.abs(bScore.length - aScore.length) === 1) {
		if (isLastScoreNegative(aScore)) return 1;
		if (isLastScoreNegative(bScore)) return -1;
	}
	return bScore.length - aScore.length;
}
/**
* This allows detecting splats at the end of a path: /home/:id(.*)*
*
* @param score - score to check
* @returns true if the last entry is negative
*/
function isLastScoreNegative(score) {
	const last = score[score.length - 1];
	return score.length > 0 && last[last.length - 1] < 0;
}
var PATH_PARSER_OPTIONS_DEFAULTS = {
	strict: false,
	end: true,
	sensitive: false
};
function createRouteRecordMatcher(record, parent, options) {
	const matcher = assign(tokensToParser(tokenizePath(record.path), options), {
		record,
		parent,
		children: [],
		alias: []
	});
	if (parent) {
		if (!matcher.record.aliasOf === !parent.record.aliasOf) parent.children.push(matcher);
	}
	return matcher;
}
/**
* Creates a Router Matcher.
*
* @internal
* @param routes - array of initial routes
* @param globalOptions - global route options
*/
function createRouterMatcher(routes, globalOptions) {
	const matchers = [];
	const matcherMap = /* @__PURE__ */ new Map();
	globalOptions = mergeOptions(PATH_PARSER_OPTIONS_DEFAULTS, globalOptions);
	function getRecordMatcher(name) {
		return matcherMap.get(name);
	}
	function addRoute(record, parent, originalRecord) {
		const isRootAdd = !originalRecord;
		const mainNormalizedRecord = normalizeRouteRecord(record);
		mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
		const options = mergeOptions(globalOptions, record);
		const normalizedRecords = [mainNormalizedRecord];
		if ("alias" in record) {
			const aliases = typeof record.alias === "string" ? [record.alias] : record.alias;
			for (const alias of aliases) normalizedRecords.push(normalizeRouteRecord(assign({}, mainNormalizedRecord, {
				components: originalRecord ? originalRecord.record.components : mainNormalizedRecord.components,
				path: alias,
				aliasOf: originalRecord ? originalRecord.record : mainNormalizedRecord
			})));
		}
		let matcher;
		let originalMatcher;
		for (const normalizedRecord of normalizedRecords) {
			const { path } = normalizedRecord;
			if (parent && path[0] !== "/") {
				const parentPath = parent.record.path;
				const connectingSlash = parentPath[parentPath.length - 1] === "/" ? "" : "/";
				normalizedRecord.path = parent.record.path + (path && connectingSlash + path);
			}
			matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
			if (originalRecord) originalRecord.alias.push(matcher);
			else {
				originalMatcher = originalMatcher || matcher;
				if (originalMatcher !== matcher) originalMatcher.alias.push(matcher);
				if (isRootAdd && record.name && !isAliasRecord(matcher)) removeRoute(record.name);
			}
			if (isMatchable(matcher)) insertMatcher(matcher);
			if (mainNormalizedRecord.children) {
				const children = mainNormalizedRecord.children;
				for (let i = 0; i < children.length; i++) addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
			}
			originalRecord = originalRecord || matcher;
		}
		return originalMatcher ? () => {
			removeRoute(originalMatcher);
		} : noop;
	}
	function removeRoute(matcherRef) {
		if (isRouteName(matcherRef)) {
			const matcher = matcherMap.get(matcherRef);
			if (matcher) {
				matcherMap.delete(matcherRef);
				matchers.splice(matchers.indexOf(matcher), 1);
				matcher.children.forEach(removeRoute);
				matcher.alias.forEach(removeRoute);
			}
		} else {
			const index = matchers.indexOf(matcherRef);
			if (index > -1) {
				matchers.splice(index, 1);
				if (matcherRef.record.name) matcherMap.delete(matcherRef.record.name);
				matcherRef.children.forEach(removeRoute);
				matcherRef.alias.forEach(removeRoute);
			}
		}
	}
	function getRoutes() {
		return matchers;
	}
	function insertMatcher(matcher) {
		const index = findInsertionIndex(matcher, matchers);
		matchers.splice(index, 0, matcher);
		if (matcher.record.name && !isAliasRecord(matcher)) matcherMap.set(matcher.record.name, matcher);
	}
	function resolve(location, currentLocation) {
		let matcher;
		let params = {};
		let path;
		let name;
		if ("name" in location && location.name) {
			matcher = matcherMap.get(location.name);
			if (!matcher) throw createRouterError(ErrorTypes.MATCHER_NOT_FOUND, { location });
			name = matcher.record.name;
			params = assign(pickParams(currentLocation.params, matcher.keys.filter((k) => !k.optional).concat(matcher.parent ? matcher.parent.keys.filter((k) => k.optional) : []).map((k) => k.name)), location.params && pickParams(location.params, matcher.keys.map((k) => k.name)));
			path = matcher.stringify(params);
		} else if (location.path != null) {
			path = location.path;
			matcher = matchers.find((m) => m.re.test(path));
			if (matcher) {
				params = matcher.parse(path);
				name = matcher.record.name;
			}
		} else {
			matcher = currentLocation.name ? matcherMap.get(currentLocation.name) : matchers.find((m) => m.re.test(currentLocation.path));
			if (!matcher) throw createRouterError(ErrorTypes.MATCHER_NOT_FOUND, {
				location,
				currentLocation
			});
			name = matcher.record.name;
			params = assign({}, currentLocation.params, location.params);
			path = matcher.stringify(params);
		}
		const matched = [];
		let parentMatcher = matcher;
		while (parentMatcher) {
			matched.unshift(parentMatcher.record);
			parentMatcher = parentMatcher.parent;
		}
		return {
			name,
			path,
			params,
			matched,
			meta: mergeMetaFields(matched)
		};
	}
	routes.forEach((route) => addRoute(route));
	function clearRoutes() {
		matchers.length = 0;
		matcherMap.clear();
	}
	return {
		addRoute,
		resolve,
		removeRoute,
		clearRoutes,
		getRoutes,
		getRecordMatcher
	};
}
/**
* Picks an object param to contain only specified keys.
*
* @param params - params object to pick from
* @param keys - keys to pick
*/
function pickParams(params, keys) {
	const newParams = {};
	for (const key of keys) if (key in params) newParams[key] = params[key];
	return newParams;
}
/**
* Normalizes a RouteRecordRaw. Creates a copy
*
* @param record
* @returns the normalized version
*/
function normalizeRouteRecord(record) {
	const normalized = {
		path: record.path,
		redirect: record.redirect,
		name: record.name,
		meta: record.meta || {},
		aliasOf: record.aliasOf,
		beforeEnter: record.beforeEnter,
		props: normalizeRecordProps(record),
		children: record.children || [],
		instances: {},
		leaveGuards: /* @__PURE__ */ new Set(),
		updateGuards: /* @__PURE__ */ new Set(),
		enterCallbacks: {},
		components: "components" in record ? record.components || null : record.component && { default: record.component }
	};
	Object.defineProperty(normalized, "mods", { value: {} });
	return normalized;
}
/**
* Normalize the optional `props` in a record to always be an object similar to
* components. Also accept a boolean for components.
* @param record
*/
function normalizeRecordProps(record) {
	const propsObject = {};
	const props = record.props || false;
	if ("component" in record) propsObject.default = props;
	else for (const name in record.components) propsObject[name] = typeof props === "object" ? props[name] : props;
	return propsObject;
}
/**
* Checks if a record or any of its parent is an alias
* @param record
*/
function isAliasRecord(record) {
	while (record) {
		if (record.record.aliasOf) return true;
		record = record.parent;
	}
	return false;
}
/**
* Merge meta fields of an array of records
*
* @param matched - array of matched records
*/
function mergeMetaFields(matched) {
	return matched.reduce((meta, record) => assign(meta, record.meta), {});
}
/**
* Performs a binary search to find the correct insertion index for a new matcher.
*
* Matchers are primarily sorted by their score. If scores are tied then we also consider parent/child relationships,
* with descendants coming before ancestors. If there's still a tie, new routes are inserted after existing routes.
*
* @param matcher - new matcher to be inserted
* @param matchers - existing matchers
*/
function findInsertionIndex(matcher, matchers) {
	let lower = 0;
	let upper = matchers.length;
	while (lower !== upper) {
		const mid = lower + upper >> 1;
		if (comparePathParserScore(matcher, matchers[mid]) < 0) upper = mid;
		else lower = mid + 1;
	}
	const insertionAncestor = getInsertionAncestor(matcher);
	if (insertionAncestor) upper = matchers.lastIndexOf(insertionAncestor, upper - 1);
	return upper;
}
function getInsertionAncestor(matcher) {
	let ancestor = matcher;
	while (ancestor = ancestor.parent) if (isMatchable(ancestor) && comparePathParserScore(matcher, ancestor) === 0) return ancestor;
}
/**
* Checks if a matcher can be reachable. This means if it's possible to reach it as a route. For example, routes without
* a component, or name, or redirect, are just used to group other routes.
* @param matcher
* @param matcher.record record of the matcher
* @returns
*/
function isMatchable({ record }) {
	return !!(record.name || record.components && Object.keys(record.components).length || record.redirect);
}
/**
* Returns the internal behavior of a {@link RouterLink} without the rendering part.
*
* @param props - a `to` location and an optional `replace` flag
*/
function useLink(props) {
	const router = inject(routerKey);
	const currentRoute = inject(routeLocationKey);
	const route = computed(() => {
		const to = unref(props.to);
		return router.resolve(to);
	});
	const activeRecordIndex = computed(() => {
		const { matched } = route.value;
		const { length } = matched;
		const routeMatched = matched[length - 1];
		const currentMatched = currentRoute.matched;
		if (!routeMatched || !currentMatched.length) return -1;
		const index = currentMatched.findIndex(isSameRouteRecord$1.bind(null, routeMatched));
		if (index > -1) return index;
		const parentRecordPath = getOriginalPath$1(matched[length - 2]);
		return length > 1 && getOriginalPath$1(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord$1.bind(null, matched[length - 2])) : index;
	});
	const isActive = computed(() => activeRecordIndex.value > -1 && includesParams$1(currentRoute.params, route.value.params));
	const isExactActive = computed(() => activeRecordIndex.value > -1 && activeRecordIndex.value === currentRoute.matched.length - 1 && isSameRouteLocationParams$1(currentRoute.params, route.value.params));
	function navigate(e = {}) {
		if (guardEvent(e)) {
			const p = router[unref(props.replace) ? "replace" : "push"](unref(props.to)).catch(noop);
			if (props.viewTransition && typeof document !== "undefined" && "startViewTransition" in document) document.startViewTransition(() => p);
			return p;
		}
		return Promise.resolve();
	}
	/**
	* NOTE: update {@link _RouterLinkI}'s `$slots` type when updating this
	*/
	return {
		route,
		href: computed(() => route.value.href),
		isActive,
		isExactActive,
		navigate
	};
}
function preferSingleVNode(vnodes) {
	return vnodes.length === 1 ? vnodes[0] : vnodes;
}
/**
* Component to render a link that triggers a navigation on click.
*/
var RouterLink = /* @__PURE__ */ defineComponent({
	name: "RouterLink",
	compatConfig: { MODE: 3 },
	props: {
		to: {
			type: [String, Object],
			required: true
		},
		replace: Boolean,
		activeClass: String,
		exactActiveClass: String,
		custom: Boolean,
		ariaCurrentValue: {
			type: String,
			default: "page"
		},
		viewTransition: Boolean
	},
	useLink,
	setup(props, { slots }) {
		const link = reactive(useLink(props));
		const { options } = inject(routerKey);
		const elClass = computed(() => ({
			[getLinkClass(props.activeClass, options.linkActiveClass, "router-link-active")]: link.isActive,
			[getLinkClass(props.exactActiveClass, options.linkExactActiveClass, "router-link-exact-active")]: link.isExactActive
		}));
		return () => {
			const children = slots.default && preferSingleVNode(slots.default(link));
			return props.custom ? children : h("a", {
				"aria-current": link.isExactActive ? props.ariaCurrentValue : null,
				href: link.href,
				onClick: link.navigate,
				class: elClass.value
			}, children);
		};
	}
});
function guardEvent(e) {
	if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
	if (e.defaultPrevented) return;
	if (e.button !== void 0 && e.button !== 0) return;
	if (e.currentTarget && e.currentTarget.getAttribute) {
		const target = e.currentTarget.getAttribute("target");
		if (/\b_blank\b/i.test(target)) return;
	}
	if (e.preventDefault) e.preventDefault();
	return true;
}
function includesParams$1(outer, inner) {
	for (const key in inner) {
		const innerValue = inner[key];
		const outerValue = outer[key];
		if (typeof innerValue === "string") {
			if (innerValue !== outerValue) return false;
		} else if (!isArray(outerValue) || outerValue.length !== innerValue.length || innerValue.some((value, i) => value.valueOf() !== outerValue[i].valueOf())) return false;
	}
	return true;
}
/**
* Get the original path value of a record by following its aliasOf
* @param record
*/
function getOriginalPath$1(record) {
	return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
}
/**
* Utility class to get the active class based on defaults.
* @param propClass
* @param globalClass
* @param defaultClass
*/
var getLinkClass = (propClass, globalClass, defaultClass) => propClass != null ? propClass : globalClass != null ? globalClass : defaultClass;
var RouterViewImpl = /* @__PURE__ */ defineComponent({
	name: "RouterView",
	inheritAttrs: false,
	props: {
		name: {
			type: String,
			default: "default"
		},
		route: Object
	},
	compatConfig: { MODE: 3 },
	setup(props, { attrs, slots }) {
		const injectedRoute = inject(routerViewLocationKey);
		const routeToDisplay = computed(() => props.route || injectedRoute.value);
		const injectedDepth = inject(viewDepthKey, 0);
		const depth = computed(() => {
			let initialDepth = unref(injectedDepth);
			const { matched } = routeToDisplay.value;
			let matchedRoute;
			while ((matchedRoute = matched[initialDepth]) && !matchedRoute.components) initialDepth++;
			return initialDepth;
		});
		const matchedRouteRef = computed(() => routeToDisplay.value.matched[depth.value]);
		provide(viewDepthKey, computed(() => depth.value + 1));
		provide(matchedRouteKey, matchedRouteRef);
		provide(routerViewLocationKey, routeToDisplay);
		const viewRef = ref();
		watch(() => [
			viewRef.value,
			matchedRouteRef.value,
			props.name
		], ([instance, to, name], [oldInstance, from, oldName]) => {
			if (to) {
				to.instances[name] = instance;
				if (from && from !== to && instance && instance === oldInstance) {
					if (!to.leaveGuards.size) to.leaveGuards = from.leaveGuards;
					if (!to.updateGuards.size) to.updateGuards = from.updateGuards;
				}
			}
			if (instance && to && (!from || !isSameRouteRecord$1(to, from) || !oldInstance)) (to.enterCallbacks[name] || []).forEach((callback) => callback(instance));
		}, { flush: "post" });
		return () => {
			const route = routeToDisplay.value;
			const currentName = props.name;
			const matchedRoute = matchedRouteRef.value;
			const ViewComponent = matchedRoute && matchedRoute.components[currentName];
			if (!ViewComponent) return normalizeSlot(slots.default, {
				Component: ViewComponent,
				route
			});
			const routePropsOption = matchedRoute.props[currentName];
			const routeProps = routePropsOption ? routePropsOption === true ? route.params : typeof routePropsOption === "function" ? routePropsOption(route) : routePropsOption : null;
			const onVnodeUnmounted = (vnode) => {
				if (vnode.component.isUnmounted) matchedRoute.instances[currentName] = null;
			};
			const component = h(ViewComponent, assign({}, routeProps, attrs, {
				onVnodeUnmounted,
				ref: viewRef
			}));
			return normalizeSlot(slots.default, {
				Component: component,
				route
			}) || component;
		};
	}
});
function normalizeSlot(slot, data) {
	if (!slot) return null;
	const slotContent = slot(data);
	return slotContent.length === 1 ? slotContent[0] : slotContent;
}
/**
* Component to display the current route the user is at.
*/
var RouterView = RouterViewImpl;
/**
* Creates a Router instance that can be used by a Vue app.
*
* @param options - {@link RouterOptions}
*/
function createRouter(options) {
	const matcher = createRouterMatcher(options.routes, options);
	const parseQuery$1 = options.parseQuery || parseQuery;
	const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
	const routerHistory = options.history;
	const beforeGuards = useCallbacks();
	const beforeResolveGuards = useCallbacks();
	const afterGuards = useCallbacks();
	const currentRoute = shallowRef(START_LOCATION_NORMALIZED);
	let pendingLocation = START_LOCATION_NORMALIZED;
	if (isBrowser && options.scrollBehavior && "scrollRestoration" in history) history.scrollRestoration = "manual";
	const normalizeParams = applyToParams.bind(null, (paramValue) => "" + paramValue);
	const encodeParams = applyToParams.bind(null, encodeParam);
	const decodeParams = applyToParams.bind(null, decode$1);
	function addRoute(parentOrRoute, route) {
		let parent;
		let record;
		if (isRouteName(parentOrRoute)) {
			parent = matcher.getRecordMatcher(parentOrRoute);
			record = route;
		} else record = parentOrRoute;
		return matcher.addRoute(record, parent);
	}
	function removeRoute(name) {
		const recordMatcher = matcher.getRecordMatcher(name);
		if (recordMatcher) matcher.removeRoute(recordMatcher);
	}
	function getRoutes() {
		return matcher.getRoutes().map((routeMatcher) => routeMatcher.record);
	}
	function hasRoute(name) {
		return !!matcher.getRecordMatcher(name);
	}
	function resolve(rawLocation, currentLocation) {
		currentLocation = assign({}, currentLocation || currentRoute.value);
		if (typeof rawLocation === "string") {
			const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
			const matchedRoute = matcher.resolve({ path: locationNormalized.path }, currentLocation);
			const href = routerHistory.createHref(locationNormalized.fullPath);
			return assign(locationNormalized, matchedRoute, {
				params: decodeParams(matchedRoute.params),
				hash: decode$1(locationNormalized.hash),
				redirectedFrom: void 0,
				href
			});
		}
		let matcherLocation;
		if (rawLocation.path != null) matcherLocation = assign({}, rawLocation, { path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path });
		else {
			const targetParams = assign({}, rawLocation.params);
			for (const key in targetParams) if (targetParams[key] == null) delete targetParams[key];
			matcherLocation = assign({}, rawLocation, { params: encodeParams(targetParams) });
			currentLocation.params = encodeParams(currentLocation.params);
		}
		const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
		const hash = rawLocation.hash || "";
		matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
		const fullPath = stringifyURL(stringifyQuery$1, assign({}, rawLocation, {
			hash: encodeHash(hash),
			path: matchedRoute.path
		}));
		const href = routerHistory.createHref(fullPath);
		return assign({
			fullPath,
			hash,
			query: stringifyQuery$1 === stringifyQuery ? normalizeQuery(rawLocation.query) : rawLocation.query || {}
		}, matchedRoute, {
			redirectedFrom: void 0,
			href
		});
	}
	function locationAsObject(to) {
		return typeof to === "string" ? parseURL(parseQuery$1, to, currentRoute.value.path) : assign({}, to);
	}
	function checkCanceledNavigation(to, from) {
		if (pendingLocation !== to) return createRouterError(ErrorTypes.NAVIGATION_CANCELLED, {
			from,
			to
		});
	}
	function push(to) {
		return pushWithRedirect(to);
	}
	function replace(to) {
		return push(assign(locationAsObject(to), { replace: true }));
	}
	function handleRedirectRecord(to, from) {
		const lastMatched = to.matched[to.matched.length - 1];
		if (lastMatched && lastMatched.redirect) {
			const { redirect } = lastMatched;
			let newTargetLocation = typeof redirect === "function" ? redirect(to, from) : redirect;
			if (typeof newTargetLocation === "string") {
				newTargetLocation = newTargetLocation.includes("?") || newTargetLocation.includes("#") ? newTargetLocation = locationAsObject(newTargetLocation) : { path: newTargetLocation };
				newTargetLocation.params = {};
			}
			return assign({
				query: to.query,
				hash: to.hash,
				params: newTargetLocation.path != null ? {} : to.params
			}, newTargetLocation);
		}
	}
	function pushWithRedirect(to, redirectedFrom) {
		const targetLocation = pendingLocation = resolve(to);
		const from = currentRoute.value;
		const data = to.state;
		const force = to.force;
		const replace = to.replace === true;
		const shouldRedirect = handleRedirectRecord(targetLocation, from);
		if (shouldRedirect) return pushWithRedirect(assign(locationAsObject(shouldRedirect), {
			state: typeof shouldRedirect === "object" ? assign({}, data, shouldRedirect.state) : data,
			force,
			replace
		}), redirectedFrom || targetLocation);
		const toLocation = targetLocation;
		toLocation.redirectedFrom = redirectedFrom;
		let failure;
		if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
			failure = createRouterError(ErrorTypes.NAVIGATION_DUPLICATED, {
				to: toLocation,
				from
			});
			handleScroll(from, from, true, false);
		}
		return (failure ? Promise.resolve(failure) : navigate(toLocation, from)).catch((error) => isNavigationFailure(error) ? isNavigationFailure(error, ErrorTypes.NAVIGATION_GUARD_REDIRECT) ? error : markAsReady(error) : triggerError(error, toLocation, from)).then((failure) => {
			if (failure) {
				if (isNavigationFailure(failure, ErrorTypes.NAVIGATION_GUARD_REDIRECT)) return pushWithRedirect(assign({ replace }, locationAsObject(failure.to), {
					state: typeof failure.to === "object" ? assign({}, data, failure.to.state) : data,
					force
				}), redirectedFrom || toLocation);
			} else failure = finalizeNavigation(toLocation, from, true, replace, data);
			triggerAfterEach(toLocation, from, failure);
			return failure;
		});
	}
	/**
	* Helper to reject and skip all navigation guards if a new navigation happened
	* @param to
	* @param from
	*/
	function checkCanceledNavigationAndReject(to, from) {
		const error = checkCanceledNavigation(to, from);
		return error ? Promise.reject(error) : Promise.resolve();
	}
	function runWithContext(fn) {
		const app = installedApps.values().next().value;
		return app && typeof app.runWithContext === "function" ? app.runWithContext(fn) : fn();
	}
	function navigate(to, from) {
		let guards;
		const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
		guards = extractComponentsGuards(leavingRecords.reverse(), "beforeRouteLeave", to, from);
		for (const record of leavingRecords) record.leaveGuards.forEach((guard) => {
			guards.push(guardToPromiseFn(guard, to, from));
		});
		const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
		guards.push(canceledNavigationCheck);
		return runGuardQueue(guards).then(() => {
			guards = [];
			for (const guard of beforeGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = extractComponentsGuards(updatingRecords, "beforeRouteUpdate", to, from);
			for (const record of updatingRecords) record.updateGuards.forEach((guard) => {
				guards.push(guardToPromiseFn(guard, to, from));
			});
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const record of enteringRecords) if (record.beforeEnter) if (isArray(record.beforeEnter)) for (const beforeEnter of record.beforeEnter) guards.push(guardToPromiseFn(beforeEnter, to, from));
			else guards.push(guardToPromiseFn(record.beforeEnter, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			to.matched.forEach((record) => record.enterCallbacks = {});
			guards = extractComponentsGuards(enteringRecords, "beforeRouteEnter", to, from, runWithContext);
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const guard of beforeResolveGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).catch((err) => isNavigationFailure(err, ErrorTypes.NAVIGATION_CANCELLED) ? err : Promise.reject(err));
	}
	function triggerAfterEach(to, from, failure) {
		afterGuards.list().forEach((guard) => runWithContext(() => guard(to, from, failure)));
	}
	/**
	* - Cleans up any navigation guards
	* - Changes the url if necessary
	* - Calls the scrollBehavior
	*/
	function finalizeNavigation(toLocation, from, isPush, replace, data) {
		const error = checkCanceledNavigation(toLocation, from);
		if (error) return error;
		const isFirstNavigation = from === START_LOCATION_NORMALIZED;
		const state = !isBrowser ? {} : history.state;
		if (isPush) if (replace || isFirstNavigation) routerHistory.replace(toLocation.fullPath, assign({ scroll: isFirstNavigation && state && state.scroll }, data));
		else routerHistory.push(toLocation.fullPath, data);
		currentRoute.value = toLocation;
		handleScroll(toLocation, from, isPush, isFirstNavigation);
		markAsReady();
	}
	let removeHistoryListener;
	function setupListeners() {
		if (removeHistoryListener) return;
		removeHistoryListener = routerHistory.listen((to, _from, info) => {
			if (!router.listening) return;
			const toLocation = resolve(to);
			const shouldRedirect = handleRedirectRecord(toLocation, router.currentRoute.value);
			if (shouldRedirect) {
				pushWithRedirect(assign(shouldRedirect, {
					replace: true,
					force: true
				}), toLocation).catch(noop);
				return;
			}
			pendingLocation = toLocation;
			const from = currentRoute.value;
			if (isBrowser) saveScrollPosition(getScrollKey(from.fullPath, info.delta), computeScrollPosition());
			navigate(toLocation, from).catch((error) => {
				if (isNavigationFailure(error, ErrorTypes.NAVIGATION_ABORTED | ErrorTypes.NAVIGATION_CANCELLED)) return error;
				if (isNavigationFailure(error, ErrorTypes.NAVIGATION_GUARD_REDIRECT)) {
					pushWithRedirect(assign(locationAsObject(error.to), { force: true }), toLocation).then((failure) => {
						if (isNavigationFailure(failure, ErrorTypes.NAVIGATION_ABORTED | ErrorTypes.NAVIGATION_DUPLICATED) && !info.delta && info.type === NavigationType.pop) routerHistory.go(-1, false);
					}).catch(noop);
					return Promise.reject();
				}
				if (info.delta) routerHistory.go(-info.delta, false);
				return triggerError(error, toLocation, from);
			}).then((failure) => {
				failure = failure || finalizeNavigation(toLocation, from, false);
				if (failure) {
					if (info.delta && !isNavigationFailure(failure, ErrorTypes.NAVIGATION_CANCELLED)) routerHistory.go(-info.delta, false);
					else if (info.type === NavigationType.pop && isNavigationFailure(failure, ErrorTypes.NAVIGATION_ABORTED | ErrorTypes.NAVIGATION_DUPLICATED)) routerHistory.go(-1, false);
				}
				triggerAfterEach(toLocation, from, failure);
			}).catch(noop);
		});
	}
	let readyHandlers = useCallbacks();
	let errorListeners = useCallbacks();
	let ready;
	/**
	* Trigger errorListeners added via onError and throws the error as well
	*
	* @param error - error to throw
	* @param to - location we were navigating to when the error happened
	* @param from - location we were navigating from when the error happened
	* @returns the error as a rejected promise
	*/
	function triggerError(error, to, from) {
		markAsReady(error);
		const list = errorListeners.list();
		if (list.length) list.forEach((handler) => handler(error, to, from));
		else console.error(error);
		return Promise.reject(error);
	}
	function isReady() {
		if (ready && currentRoute.value !== START_LOCATION_NORMALIZED) return Promise.resolve();
		return new Promise((resolve, reject) => {
			readyHandlers.add([resolve, reject]);
		});
	}
	function markAsReady(err) {
		if (!ready) {
			ready = !err;
			setupListeners();
			readyHandlers.list().forEach(([resolve, reject]) => err ? reject(err) : resolve());
			readyHandlers.reset();
		}
		return err;
	}
	function handleScroll(to, from, isPush, isFirstNavigation) {
		const { scrollBehavior } = options;
		if (!isBrowser || !scrollBehavior) return Promise.resolve();
		const scrollPosition = !isPush && getSavedScrollPosition(getScrollKey(to.fullPath, 0)) || (isFirstNavigation || !isPush) && history.state && history.state.scroll || null;
		return nextTick().then(() => scrollBehavior(to, from, scrollPosition)).then((position) => position && scrollToPosition(position)).catch((err) => triggerError(err, to, from));
	}
	const go = (delta) => routerHistory.go(delta);
	let started;
	const installedApps = /* @__PURE__ */ new Set();
	const router = {
		currentRoute,
		listening: true,
		addRoute,
		removeRoute,
		clearRoutes: matcher.clearRoutes,
		hasRoute,
		getRoutes,
		resolve,
		options,
		push,
		replace,
		go,
		back: () => go(-1),
		forward: () => go(1),
		beforeEach: beforeGuards.add,
		beforeResolve: beforeResolveGuards.add,
		afterEach: afterGuards.add,
		onError: errorListeners.add,
		isReady,
		install(app) {
			app.component("RouterLink", RouterLink);
			app.component("RouterView", RouterView);
			app.config.globalProperties.$router = router;
			Object.defineProperty(app.config.globalProperties, "$route", {
				enumerable: true,
				get: () => unref(currentRoute)
			});
			if (isBrowser && !started && currentRoute.value === START_LOCATION_NORMALIZED) {
				started = true;
				push(routerHistory.location).catch((err) => {});
			}
			const reactiveRoute = {};
			for (const key in START_LOCATION_NORMALIZED) Object.defineProperty(reactiveRoute, key, {
				get: () => currentRoute.value[key],
				enumerable: true
			});
			app.provide(routerKey, router);
			app.provide(routeLocationKey, shallowReactive(reactiveRoute));
			app.provide(routerViewLocationKey, currentRoute);
			const unmountApp = app.unmount;
			installedApps.add(app);
			app.unmount = function() {
				installedApps.delete(app);
				if (installedApps.size < 1) {
					pendingLocation = START_LOCATION_NORMALIZED;
					removeHistoryListener && removeHistoryListener();
					removeHistoryListener = null;
					currentRoute.value = START_LOCATION_NORMALIZED;
					started = false;
					ready = false;
				}
				unmountApp();
			};
		}
	};
	function runGuardQueue(guards) {
		return guards.reduce((promise, guard) => promise.then(() => runWithContext(guard)), Promise.resolve());
	}
	return router;
}
//#endregion
//#region \0vite/preload-helper.js
var scriptRel = /* @__PURE__ */ (function detectScriptRel() {
	const relList = typeof document !== "undefined" && document.createElement("link").relList;
	return relList && relList.supports && relList.supports("modulepreload") ? "modulepreload" : "preload";
})();
var assetsURL = function(dep, importerUrl) {
	return new URL(dep, importerUrl).href;
};
var seen = {};
var __vitePreload = function preload(baseModule, deps, importerUrl) {
	let promise = Promise.resolve();
	if (deps && deps.length > 0) {
		const links = document.getElementsByTagName("link");
		const cspNonceMeta = document.querySelector("meta[property=csp-nonce]");
		const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
		function allSettled(promises) {
			return Promise.all(promises.map((p) => Promise.resolve(p).then((value) => ({
				status: "fulfilled",
				value
			}), (reason) => ({
				status: "rejected",
				reason
			}))));
		}
		promise = allSettled(deps.map((dep) => {
			dep = assetsURL(dep, importerUrl);
			if (dep in seen) return;
			seen[dep] = true;
			const isCss = dep.endsWith(".css");
			const cssSelector = isCss ? "[rel=\"stylesheet\"]" : "";
			if (!!importerUrl) for (let i = links.length - 1; i >= 0; i--) {
				const link = links[i];
				if (link.href === dep && (!isCss || link.rel === "stylesheet")) return;
			}
			else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) return;
			const link = document.createElement("link");
			link.rel = isCss ? "stylesheet" : scriptRel;
			if (!isCss) link.as = "script";
			link.crossOrigin = "";
			link.href = dep;
			if (cspNonce) link.setAttribute("nonce", cspNonce);
			document.head.appendChild(link);
			if (isCss) return new Promise((res, rej) => {
				link.addEventListener("load", res);
				link.addEventListener("error", () => rej(/* @__PURE__ */ new Error(`Unable to preload CSS for ${dep}`)));
			});
		}));
	}
	function handlePreloadError(err) {
		const e = new Event("vite:preloadError", { cancelable: true });
		e.payload = err;
		window.dispatchEvent(e);
		if (!e.defaultPrevented) throw err;
	}
	return promise.then((res) => {
		for (const item of res || []) {
			if (item.status !== "rejected") continue;
			handlePreloadError(item.reason);
		}
		return baseModule().catch(handlePreloadError);
	});
};
//#endregion
//#region src/router/routes.ts
var routes = [
	{
		path: "/",
		component: () => __vitePreload(() => import("./BexLayout-lZsJkOj5.js"), __vite__mapDeps([0,1,2,3,4,5,6]), import.meta.url),
		children: [{
			path: "",
			component: () => __vitePreload(() => import("./TranslatorPage-Crkpck8y.js"), __vite__mapDeps([7,1,2,3,8,9,10,11,5,12,4,13,14,15,16]), import.meta.url)
		}]
	},
	{
		path: "/assistant",
		component: () => __vitePreload(() => import("./BexLayout-lZsJkOj5.js"), __vite__mapDeps([0,1,2,3,4,5,6]), import.meta.url),
		children: [{
			path: "",
			component: () => __vitePreload(() => import("./AssistantPage-B1_zPi0t.js"), __vite__mapDeps([17,1,2,3,8,10,12,13,11,5,18]), import.meta.url)
		}]
	},
	{
		path: "/subtitle",
		component: () => __vitePreload(() => import("./SubtitlePage-Bsx5aCVk.js"), __vite__mapDeps([19,1,2,3,8,10,13,11,5,14,15,20]), import.meta.url)
	},
	{
		path: "/settings",
		component: () => __vitePreload(() => import("./BexLayout-lZsJkOj5.js"), __vite__mapDeps([0,1,2,3,4,5,6]), import.meta.url),
		children: [{
			path: "",
			component: () => __vitePreload(() => import("./SettingsPage-DvL3mpg3.js"), __vite__mapDeps([21,1,2,3,8,9,10,11,5,12,15,22]), import.meta.url)
		}]
	},
	{
		path: "/:catchAll(.*)*",
		component: () => __vitePreload(() => import("./ErrorNotFound-BeelMfgp.js"), __vite__mapDeps([23,3,10,2]), import.meta.url)
	}
];
//#endregion
//#region src/router/index.ts
var router_default = defineRouter(function() {
	return createRouter({
		scrollBehavior: () => ({
			left: 0,
			top: 0
		}),
		routes,
		history: createWebHashHistory("")
	});
});
//#endregion
//#region .quasar/prod-bex-chrome/app.js
/**
* THIS FILE IS GENERATED AUTOMATICALLY.
* DO NOT EDIT.
*
* You are probably looking on adding startup/initialization code.
* Use "quasar new boot <name>" and add it there.
* One boot file per concern. Then reference the file(s) in quasar.config file > boot:
* boot: ['file', ...] // do not add ".js" extension to it.
*
* Boot files are your "main.js"
**/
async function app_default(createAppFn, quasarUserOptions) {
	await bex.promise;
	delete bex.promise;
	const app = createAppFn(App_default);
	app.use(vue_plugin_default, quasarUserOptions);
	app.config.globalProperties.$q.bex = bex.bridge;
	const store = typeof stores_default === "function" ? await stores_default({}) : stores_default;
	app.use(store);
	const router = markRaw(typeof router_default === "function" ? await router_default({ store }) : router_default);
	store.use(({ store }) => {
		store.router = router;
	});
	return {
		app,
		store,
		router
	};
}
//#endregion
//#region node_modules/quasar/src/components/avatar/QAvatar.js
var QAvatar_default = createComponent({
	name: "QAvatar",
	props: {
		...useSizeProps,
		fontSize: String,
		color: String,
		textColor: String,
		icon: String,
		square: Boolean,
		rounded: Boolean
	},
	setup(props, { slots }) {
		const sizeStyle = use_size_default(props);
		const classes = computed(() => "q-avatar" + (props.color ? ` bg-${props.color}` : "") + (props.textColor ? ` text-${props.textColor} q-chip--colored` : "") + (props.square === true ? " q-avatar--square" : props.rounded === true ? " rounded-borders" : ""));
		const contentStyle = computed(() => props.fontSize ? { fontSize: props.fontSize } : null);
		return () => {
			const icon = props.icon !== void 0 ? [h(QIcon_default, { name: props.icon })] : void 0;
			return h("div", {
				class: classes.value,
				style: sizeStyle.value
			}, [h("div", {
				class: "q-avatar__content row flex-center overflow-hidden",
				style: contentStyle.value
			}, hMergeSlotSafely(slots.default, icon))]);
		};
	}
});
//#endregion
//#region node_modules/quasar/src/components/spinner/use-spinner.js
var useSpinnerProps = {
	size: {
		type: [String, Number],
		default: "1em"
	},
	color: String
};
function useSpinner(props) {
	return {
		cSize: computed(() => props.size in useSizeDefaults ? `${useSizeDefaults[props.size]}px` : props.size),
		classes: computed(() => "q-spinner" + (props.color ? ` text-${props.color}` : ""))
	};
}
//#endregion
//#region node_modules/quasar/src/components/spinner/QSpinner.js
var QSpinner_default = createComponent({
	name: "QSpinner",
	props: {
		...useSpinnerProps,
		thickness: {
			type: Number,
			default: 5
		}
	},
	setup(props) {
		const { cSize, classes } = useSpinner(props);
		return () => h("svg", {
			class: classes.value + " q-spinner-mat",
			width: cSize.value,
			height: cSize.value,
			viewBox: "25 25 50 50"
		}, [h("circle", {
			class: "path",
			cx: "50",
			cy: "50",
			r: "20",
			fill: "none",
			stroke: "currentColor",
			"stroke-width": props.thickness,
			"stroke-miterlimit": "10"
		})]);
	}
});
//#endregion
//#region node_modules/quasar/src/utils/throttle/throttle.js
function throttle_default(fn, limit = 250) {
	let wait = false, result;
	return function() {
		if (wait === false) {
			wait = true;
			setTimeout(() => {
				wait = false;
			}, limit);
			result = fn.apply(this, arguments);
		}
		return result;
	};
}
//#endregion
//#region node_modules/quasar/src/directives/ripple/Ripple.js
function showRipple(evt, el, ctx, forceCenter) {
	ctx.modifiers.stop === true && stop(evt);
	const color = ctx.modifiers.color;
	let center = ctx.modifiers.center;
	center = center === true || forceCenter === true;
	const node = document.createElement("span"), innerNode = document.createElement("span"), pos = position(evt), { left, top, width, height } = el.getBoundingClientRect(), diameter = Math.sqrt(width * width + height * height), radius = diameter / 2, centerX = `${(width - diameter) / 2}px`, x = center ? centerX : `${pos.left - left - radius}px`, centerY = `${(height - diameter) / 2}px`, y = center ? centerY : `${pos.top - top - radius}px`;
	innerNode.className = "q-ripple__inner";
	css(innerNode, {
		height: `${diameter}px`,
		width: `${diameter}px`,
		transform: `translate3d(${x},${y},0) scale3d(.2,.2,1)`,
		opacity: 0
	});
	node.className = `q-ripple${color ? " text-" + color : ""}`;
	node.setAttribute("dir", "ltr");
	node.appendChild(innerNode);
	el.appendChild(node);
	const abort = () => {
		node.remove();
		clearTimeout(timer);
	};
	ctx.abort.push(abort);
	let timer = setTimeout(() => {
		innerNode.classList.add("q-ripple__inner--enter");
		innerNode.style.transform = `translate3d(${centerX},${centerY},0) scale3d(1,1,1)`;
		innerNode.style.opacity = .2;
		timer = setTimeout(() => {
			innerNode.classList.remove("q-ripple__inner--enter");
			innerNode.classList.add("q-ripple__inner--leave");
			innerNode.style.opacity = 0;
			timer = setTimeout(() => {
				node.remove();
				ctx.abort.splice(ctx.abort.indexOf(abort), 1);
			}, 275);
		}, 250);
	}, 50);
}
function updateModifiers(ctx, { modifiers, value, arg }) {
	const cfg = Object.assign({}, ctx.cfg.ripple, modifiers, value);
	ctx.modifiers = {
		early: cfg.early === true,
		stop: cfg.stop === true,
		center: cfg.center === true,
		color: cfg.color || arg,
		keyCodes: [].concat(cfg.keyCodes || 13)
	};
}
var Ripple_default = createDirective({
	name: "ripple",
	beforeMount(el, binding) {
		const cfg = binding.instance.$.appContext.config.globalProperties.$q.config || {};
		if (cfg.ripple === false) return;
		const ctx = {
			cfg,
			enabled: binding.value !== false,
			modifiers: {},
			abort: [],
			start(evt) {
				if (ctx.enabled === true && evt.qSkipRipple !== true && evt.type === (ctx.modifiers.early === true ? "pointerdown" : "click")) showRipple(evt, el, ctx, evt.qKeyEvent === true);
			},
			keystart: throttle_default((evt) => {
				if (ctx.enabled === true && evt.qSkipRipple !== true && isKeyCode(evt, ctx.modifiers.keyCodes) === true && evt.type === `key${ctx.modifiers.early === true ? "down" : "up"}`) showRipple(evt, el, ctx, true);
			}, 300)
		};
		updateModifiers(ctx, binding);
		el.__qripple = ctx;
		addEvt(ctx, "main", [
			[
				el,
				"pointerdown",
				"start",
				"passive"
			],
			[
				el,
				"click",
				"start",
				"passive"
			],
			[
				el,
				"keydown",
				"keystart",
				"passive"
			],
			[
				el,
				"keyup",
				"keystart",
				"passive"
			]
		]);
	},
	updated(el, binding) {
		if (binding.oldValue !== binding.value) {
			const ctx = el.__qripple;
			if (ctx !== void 0) {
				ctx.enabled = binding.value !== false;
				if (ctx.enabled === true && Object(binding.value) === binding.value) updateModifiers(ctx, binding);
			}
		}
	},
	beforeUnmount(el) {
		const ctx = el.__qripple;
		if (ctx !== void 0) {
			ctx.abort.forEach((fn) => {
				fn();
			});
			cleanEvt(ctx, "main");
			delete el._qripple;
		}
	}
});
//#endregion
//#region node_modules/quasar/src/composables/private.use-align/use-align.js
var alignMap = {
	left: "start",
	center: "center",
	right: "end",
	between: "between",
	around: "around",
	evenly: "evenly",
	stretch: "stretch"
};
var alignValues = Object.keys(alignMap);
var useAlignProps = { align: {
	type: String,
	validator: (v) => alignValues.includes(v)
} };
function use_align_default(props) {
	return computed(() => {
		const align = props.align === void 0 ? props.vertical === true ? "stretch" : "left" : props.align;
		return `${props.vertical === true ? "items" : "justify"}-${alignMap[align]}`;
	});
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-router-link/use-router-link.js
function getOriginalPath(record) {
	return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
}
function isSameRouteRecord(a, b) {
	return (a.aliasOf || a) === (b.aliasOf || b);
}
function includesParams(outer, inner) {
	for (const key in inner) {
		const innerValue = inner[key], outerValue = outer[key];
		if (typeof innerValue === "string") {
			if (innerValue !== outerValue) return false;
		} else if (Array.isArray(outerValue) === false || outerValue.length !== innerValue.length || innerValue.some((value, i) => value !== outerValue[i])) return false;
	}
	return true;
}
function isEquivalentArray(a, b) {
	return Array.isArray(b) === true ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
}
function isSameRouteLocationParamsValue(a, b) {
	return Array.isArray(a) === true ? isEquivalentArray(a, b) : Array.isArray(b) === true ? isEquivalentArray(b, a) : a === b;
}
function isSameRouteLocationParams(a, b) {
	if (Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (isSameRouteLocationParamsValue(a[key], b[key]) === false) return false;
	return true;
}
var useRouterLinkNonMatchingProps = {
	to: [String, Object],
	replace: Boolean,
	href: String,
	target: String,
	disable: Boolean
};
var useRouterLinkProps = {
	...useRouterLinkNonMatchingProps,
	exact: Boolean,
	activeClass: {
		type: String,
		default: "q-router-link--active"
	},
	exactActiveClass: {
		type: String,
		default: "q-router-link--exact-active"
	}
};
function use_router_link_default({ fallbackTag, useDisableForRouterLinkProps = true } = {}) {
	const vm = getCurrentInstance();
	const { props, proxy, emit } = vm;
	const hasRouter = vmHasRouter(vm);
	const hasHrefLink = computed(() => props.disable !== true && props.href !== void 0);
	const hasRouterLinkProps = useDisableForRouterLinkProps === true ? computed(() => hasRouter === true && props.disable !== true && hasHrefLink.value !== true && props.to !== void 0 && props.to !== null && props.to !== "") : computed(() => hasRouter === true && hasHrefLink.value !== true && props.to !== void 0 && props.to !== null && props.to !== "");
	const resolvedLink = computed(() => hasRouterLinkProps.value === true ? getLink(props.to) : null);
	const hasRouterLink = computed(() => resolvedLink.value !== null);
	const hasLink = computed(() => hasHrefLink.value === true || hasRouterLink.value === true);
	const linkTag = computed(() => props.type === "a" || hasLink.value === true ? "a" : props.tag || fallbackTag || "div");
	const linkAttrs = computed(() => hasHrefLink.value === true ? {
		href: props.href,
		target: props.target
	} : hasRouterLink.value === true ? {
		href: resolvedLink.value.href,
		target: props.target
	} : {});
	const linkActiveIndex = computed(() => {
		if (hasRouterLink.value === false) return -1;
		const { matched } = resolvedLink.value, { length } = matched, routeMatched = matched[length - 1];
		if (routeMatched === void 0) return -1;
		const currentMatched = proxy.$route.matched;
		if (currentMatched.length === 0) return -1;
		const index = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
		if (index !== -1) return index;
		const parentRecordPath = getOriginalPath(matched[length - 2]);
		return length > 1 && getOriginalPath(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2])) : index;
	});
	const linkIsActive = computed(() => hasRouterLink.value === true && linkActiveIndex.value !== -1 && includesParams(proxy.$route.params, resolvedLink.value.params));
	const linkIsExactActive = computed(() => linkIsActive.value === true && linkActiveIndex.value === proxy.$route.matched.length - 1 && isSameRouteLocationParams(proxy.$route.params, resolvedLink.value.params));
	const linkClass = computed(() => hasRouterLink.value === true ? linkIsExactActive.value === true ? ` ${props.exactActiveClass} ${props.activeClass}` : props.exact === true ? "" : linkIsActive.value === true ? ` ${props.activeClass}` : "" : "");
	function getLink(to) {
		try {
			return proxy.$router.resolve(to);
		} catch (_) {}
		return null;
	}
	/**
	* @returns Promise<RouterError | false | undefined>
	*/
	function navigateToRouterLink(e, { returnRouterError, to = props.to, replace = props.replace } = {}) {
		if (props.disable === true) {
			e.preventDefault();
			return Promise.resolve(false);
		}
		if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey || e.button !== void 0 && e.button !== 0 || props.target === "_blank") return Promise.resolve(false);
		e.preventDefault();
		const promise = proxy.$router[replace === true ? "replace" : "push"](to);
		return returnRouterError === true ? promise : promise.then(() => {}).catch(() => {});
	}
	function navigateOnClick(e) {
		if (hasRouterLink.value === true) {
			const go = (opts) => navigateToRouterLink(e, opts);
			emit("click", e, go);
			e.defaultPrevented !== true && go();
		} else emit("click", e);
	}
	return {
		hasRouterLink,
		hasHrefLink,
		hasLink,
		linkTag,
		resolvedLink,
		linkIsActive,
		linkIsExactActive,
		linkClass,
		linkAttrs,
		getLink,
		navigateToRouterLink,
		navigateOnClick
	};
}
//#endregion
//#region node_modules/quasar/src/components/btn/use-btn.js
var btnPadding = {
	none: 0,
	xs: 4,
	sm: 8,
	md: 16,
	lg: 24,
	xl: 32
};
var defaultSizes = {
	xs: 8,
	sm: 10,
	md: 14,
	lg: 20,
	xl: 24
};
var formTypes = [
	"button",
	"submit",
	"reset"
];
var mediaTypeRE = /[^\s]\/[^\s]/;
var btnDesignOptions = [
	"flat",
	"outline",
	"push",
	"unelevated"
];
function getBtnDesign(props, defaultValue) {
	if (props.flat === true) return "flat";
	if (props.outline === true) return "outline";
	if (props.push === true) return "push";
	if (props.unelevated === true) return "unelevated";
	return defaultValue;
}
var useBtnProps = {
	...useSizeProps,
	...useRouterLinkNonMatchingProps,
	type: {
		type: String,
		default: "button"
	},
	label: [Number, String],
	icon: String,
	iconRight: String,
	...btnDesignOptions.reduce((acc, val) => (acc[val] = Boolean) && acc, {}),
	square: Boolean,
	rounded: Boolean,
	glossy: Boolean,
	size: String,
	fab: Boolean,
	fabMini: Boolean,
	padding: String,
	color: String,
	textColor: String,
	noCaps: Boolean,
	noWrap: Boolean,
	dense: Boolean,
	tabindex: [Number, String],
	ripple: {
		type: [Boolean, Object],
		default: true
	},
	align: {
		...useAlignProps.align,
		default: "center"
	},
	stack: Boolean,
	stretch: Boolean,
	loading: {
		type: Boolean,
		default: null
	},
	disable: Boolean,
	round: Boolean
};
function use_btn_default(props) {
	const sizeStyle = use_size_default(props, defaultSizes);
	const alignClass = use_align_default(props);
	const { hasRouterLink, hasLink, linkTag, linkAttrs, navigateOnClick } = use_router_link_default({ fallbackTag: "button" });
	const style = computed(() => {
		const obj = props.fab === false && props.fabMini === false ? sizeStyle.value : {};
		return props.padding !== void 0 ? Object.assign({}, obj, {
			padding: props.padding.split(/\s+/).map((v) => v in btnPadding ? btnPadding[v] + "px" : v).join(" "),
			minWidth: "0",
			minHeight: "0"
		}) : obj;
	});
	const isRounded = computed(() => props.rounded === true || props.fab === true || props.fabMini === true);
	const isActionable = computed(() => props.disable !== true && props.loading !== true);
	const tabIndex = computed(() => isActionable.value === true ? props.tabindex || 0 : -1);
	const design = computed(() => getBtnDesign(props, "standard"));
	const attributes = computed(() => {
		const acc = { tabindex: tabIndex.value };
		if (hasLink.value === true) Object.assign(acc, linkAttrs.value);
		else if (formTypes.includes(props.type) === true) acc.type = props.type;
		if (linkTag.value === "a") {
			if (props.disable === true) acc["aria-disabled"] = "true";
			else if (acc.href === void 0) acc.role = "button";
			if (hasRouterLink.value !== true && mediaTypeRE.test(props.type) === true) acc.type = props.type;
		} else if (props.disable === true) {
			acc.disabled = "";
			acc["aria-disabled"] = "true";
		}
		if (props.loading === true && props.percentage !== void 0) Object.assign(acc, {
			role: "progressbar",
			"aria-valuemin": 0,
			"aria-valuemax": 100,
			"aria-valuenow": props.percentage
		});
		return acc;
	});
	return {
		classes: computed(() => {
			let colors;
			if (props.color !== void 0) if (props.flat === true || props.outline === true) colors = `text-${props.textColor || props.color}`;
			else colors = `bg-${props.color} text-${props.textColor || "white"}`;
			else if (props.textColor) colors = `text-${props.textColor}`;
			const shape = props.round === true ? "round" : `rectangle${isRounded.value === true ? " q-btn--rounded" : props.square === true ? " q-btn--square" : ""}`;
			return `q-btn--${design.value} q-btn--${shape}` + (colors !== void 0 ? " " + colors : "") + (isActionable.value === true ? " q-btn--actionable q-focusable q-hoverable" : props.disable === true ? " disabled" : "") + (props.fab === true ? " q-btn--fab" : props.fabMini === true ? " q-btn--fab-mini" : "") + (props.noCaps === true ? " q-btn--no-uppercase" : "") + (props.dense === true ? " q-btn--dense" : "") + (props.stretch === true ? " no-border-radius self-stretch" : "") + (props.glossy === true ? " glossy" : "") + (props.square ? " q-btn--square" : "");
		}),
		style,
		innerClasses: computed(() => alignClass.value + (props.stack === true ? " column" : " row") + (props.noWrap === true ? " no-wrap text-no-wrap" : "") + (props.loading === true ? " q-btn__content--hidden" : "")),
		attributes,
		hasLink,
		linkTag,
		navigateOnClick,
		isActionable
	};
}
//#endregion
//#region node_modules/quasar/src/components/btn/QBtn.js
var { passiveCapture } = listenOpts;
var touchTarget = null, keyboardTarget = null, mouseTarget = null;
var QBtn_default = createComponent({
	name: "QBtn",
	props: {
		...useBtnProps,
		percentage: Number,
		darkPercentage: Boolean,
		onTouchstart: [Function, Array]
	},
	emits: [
		"click",
		"keydown",
		"mousedown",
		"keyup"
	],
	setup(props, { slots, emit }) {
		const { proxy } = getCurrentInstance();
		const { classes, style, innerClasses, attributes, hasLink, linkTag, navigateOnClick, isActionable } = use_btn_default(props);
		const rootRef = ref(null);
		const blurTargetRef = ref(null);
		let localTouchTargetEl = null, avoidMouseRipple, mouseTimer = null;
		const hasLabel = computed(() => props.label !== void 0 && props.label !== null && props.label !== "");
		const ripple = computed(() => props.disable === true || props.ripple === false ? false : {
			keyCodes: hasLink.value === true ? [13, 32] : [13],
			...props.ripple === true ? {} : props.ripple
		});
		const rippleProps = computed(() => ({ center: props.round }));
		const percentageStyle = computed(() => {
			const val = Math.max(0, Math.min(100, props.percentage));
			return val > 0 ? {
				transition: "transform 0.6s",
				transform: `translateX(${val - 100}%)`
			} : {};
		});
		const onEvents = computed(() => {
			if (props.loading === true) return {
				onMousedown: onLoadingEvt,
				onTouchstart: onLoadingEvt,
				onClick: onLoadingEvt,
				onKeydown: onLoadingEvt,
				onKeyup: onLoadingEvt
			};
			if (isActionable.value === true) {
				const acc = {
					onClick,
					onKeydown,
					onMousedown
				};
				if (proxy.$q.platform.has.touch === true) {
					const suffix = props.onTouchstart !== void 0 ? "" : "Passive";
					acc[`onTouchstart${suffix}`] = onTouchstart;
				}
				return acc;
			}
			return { onClick: stopAndPrevent };
		});
		const nodeProps = computed(() => ({
			ref: rootRef,
			class: "q-btn q-btn-item non-selectable no-outline " + classes.value,
			style: style.value,
			...attributes.value,
			...onEvents.value
		}));
		function onClick(e) {
			if (rootRef.value === null) return;
			if (e !== void 0) {
				if (e.defaultPrevented === true) return;
				const el = document.activeElement;
				if (props.type === "submit" && el !== document.body && rootRef.value.contains(el) === false && el.contains(rootRef.value) === false) {
					e.qAvoidFocus !== true && rootRef.value.focus();
					const onClickCleanup = () => {
						document.removeEventListener("keydown", stopAndPrevent, true);
						document.removeEventListener("keyup", onClickCleanup, passiveCapture);
						rootRef.value?.removeEventListener("blur", onClickCleanup, passiveCapture);
					};
					document.addEventListener("keydown", stopAndPrevent, true);
					document.addEventListener("keyup", onClickCleanup, passiveCapture);
					rootRef.value.addEventListener("blur", onClickCleanup, passiveCapture);
				}
			}
			navigateOnClick(e);
		}
		function onKeydown(e) {
			if (rootRef.value === null) return;
			emit("keydown", e);
			if (isKeyCode(e, [13, 32]) === true && keyboardTarget !== rootRef.value) {
				keyboardTarget !== null && cleanup();
				if (e.defaultPrevented !== true) {
					e.qAvoidFocus !== true && rootRef.value.focus();
					keyboardTarget = rootRef.value;
					rootRef.value.classList.add("q-btn--active");
					document.addEventListener("keyup", onPressEnd, true);
					rootRef.value.addEventListener("blur", onPressEnd, passiveCapture);
				}
				stopAndPrevent(e);
			}
		}
		function onTouchstart(e) {
			if (rootRef.value === null) return;
			emit("touchstart", e);
			if (e.defaultPrevented === true) return;
			if (touchTarget !== rootRef.value) {
				touchTarget !== null && cleanup();
				touchTarget = rootRef.value;
				localTouchTargetEl = e.target;
				localTouchTargetEl.addEventListener("touchcancel", onPressEnd, passiveCapture);
				localTouchTargetEl.addEventListener("touchend", onPressEnd, passiveCapture);
			}
			avoidMouseRipple = true;
			mouseTimer !== null && clearTimeout(mouseTimer);
			mouseTimer = setTimeout(() => {
				mouseTimer = null;
				avoidMouseRipple = false;
			}, 200);
		}
		function onMousedown(e) {
			if (rootRef.value === null) return;
			e.qSkipRipple = avoidMouseRipple === true;
			emit("mousedown", e);
			if (e.defaultPrevented !== true && mouseTarget !== rootRef.value) {
				mouseTarget !== null && cleanup();
				mouseTarget = rootRef.value;
				rootRef.value.classList.add("q-btn--active");
				document.addEventListener("mouseup", onPressEnd, passiveCapture);
			}
		}
		function onPressEnd(e) {
			if (rootRef.value === null) return;
			if (e?.type === "blur" && document.activeElement === rootRef.value) return;
			if (e?.type === "keyup") {
				if (keyboardTarget === rootRef.value && isKeyCode(e, [13, 32]) === true) {
					const evt = new MouseEvent("click", e);
					evt.qKeyEvent = true;
					e.defaultPrevented === true && prevent(evt);
					e.cancelBubble === true && stop(evt);
					rootRef.value.dispatchEvent(evt);
					stopAndPrevent(e);
					e.qKeyEvent = true;
				}
				emit("keyup", e);
			}
			cleanup();
		}
		function cleanup(destroying) {
			const blurTarget = blurTargetRef.value;
			if (destroying !== true && (touchTarget === rootRef.value || mouseTarget === rootRef.value) && blurTarget !== null && blurTarget !== document.activeElement) {
				blurTarget.setAttribute("tabindex", -1);
				blurTarget.focus();
			}
			if (touchTarget === rootRef.value) {
				if (localTouchTargetEl !== null) {
					localTouchTargetEl.removeEventListener("touchcancel", onPressEnd, passiveCapture);
					localTouchTargetEl.removeEventListener("touchend", onPressEnd, passiveCapture);
				}
				touchTarget = localTouchTargetEl = null;
			}
			if (mouseTarget === rootRef.value) {
				document.removeEventListener("mouseup", onPressEnd, passiveCapture);
				mouseTarget = null;
			}
			if (keyboardTarget === rootRef.value) {
				document.removeEventListener("keyup", onPressEnd, true);
				rootRef.value?.removeEventListener("blur", onPressEnd, passiveCapture);
				keyboardTarget = null;
			}
			rootRef.value?.classList.remove("q-btn--active");
		}
		function onLoadingEvt(evt) {
			stopAndPrevent(evt);
			evt.qSkipRipple = true;
		}
		onBeforeUnmount(() => {
			cleanup(true);
		});
		Object.assign(proxy, { click: (e) => {
			if (isActionable.value === true) onClick(e);
		} });
		return () => {
			let inner = [];
			props.icon !== void 0 && inner.push(h(QIcon_default, {
				name: props.icon,
				left: props.stack !== true && hasLabel.value === true,
				role: "img"
			}));
			hasLabel.value === true && inner.push(h("span", { class: "block" }, [props.label]));
			inner = hMergeSlot(slots.default, inner);
			if (props.iconRight !== void 0 && props.round === false) inner.push(h(QIcon_default, {
				name: props.iconRight,
				right: props.stack !== true && hasLabel.value === true,
				role: "img"
			}));
			const child = [h("span", {
				class: "q-focus-helper",
				ref: blurTargetRef
			})];
			if (props.loading === true && props.percentage !== void 0) child.push(h("span", { class: "q-btn__progress absolute-full overflow-hidden" + (props.darkPercentage === true ? " q-btn__progress--dark" : "") }, [h("span", {
				class: "q-btn__progress-indicator fit block",
				style: percentageStyle.value
			})]));
			child.push(h("span", { class: "q-btn__content text-center col items-center q-anchor--skip " + innerClasses.value }, inner));
			props.loading !== null && child.push(h(Transition, { name: "q-transition--fade" }, () => props.loading === true ? [h("span", {
				key: "loading",
				class: "absolute-full flex flex-center"
			}, slots.loading !== void 0 ? slots.loading() : [h(QSpinner_default)])] : null));
			return withDirectives(h(linkTag.value, nodeProps.value, child), [[
				Ripple_default,
				ripple.value,
				void 0,
				rippleProps.value
			]]);
		};
	}
});
//#endregion
//#region node_modules/quasar/src/utils/private.config/nodes.js
var nodesList = [];
var portalTypeList = [];
var portalIndex = 1;
var target = document.body;
function createGlobalNode(id, portalType) {
	const el = document.createElement("div");
	el.id = portalType !== void 0 ? `q-portal--${portalType}--${portalIndex++}` : id;
	if (globalConfig.globalNodes !== void 0) {
		const cls = globalConfig.globalNodes.class;
		if (cls !== void 0) el.className = cls;
	}
	target.appendChild(el);
	nodesList.push(el);
	portalTypeList.push(portalType);
	return el;
}
function removeGlobalNode(el) {
	const nodeIndex = nodesList.indexOf(el);
	nodesList.splice(nodeIndex, 1);
	portalTypeList.splice(nodeIndex, 1);
	el.remove();
}
//#endregion
//#region node_modules/quasar/src/plugins/notify/Notify.js
var uid = 0;
var defaults = {};
var groups = {};
var notificationsList = {};
var positionClass = {};
var emptyRE = /^\s*$/;
var notifRefs = [];
var invalidTimeoutValues = [
	void 0,
	null,
	true,
	false,
	""
];
var positionList = [
	"top-left",
	"top-right",
	"bottom-left",
	"bottom-right",
	"top",
	"bottom",
	"left",
	"right",
	"center"
];
var badgePositions = [
	"top-left",
	"top-right",
	"bottom-left",
	"bottom-right"
];
var notifTypes = {
	positive: {
		icon: ($q) => $q.iconSet.type.positive,
		color: "positive"
	},
	negative: {
		icon: ($q) => $q.iconSet.type.negative,
		color: "negative"
	},
	warning: {
		icon: ($q) => $q.iconSet.type.warning,
		color: "warning",
		textColor: "dark"
	},
	info: {
		icon: ($q) => $q.iconSet.type.info,
		color: "info"
	},
	ongoing: {
		group: false,
		timeout: 0,
		spinner: true,
		color: "grey-8"
	}
};
function addNotification(config, $q, originalApi) {
	if (!config) return logError("parameter required");
	let Api;
	const notif = { textColor: "white" };
	if (config.ignoreDefaults !== true) Object.assign(notif, defaults);
	if (isObject(config) === false) {
		if (notif.type) Object.assign(notif, notifTypes[notif.type]);
		config = { message: config };
	}
	Object.assign(notif, notifTypes[config.type || notif.type], config);
	if (typeof notif.icon === "function") notif.icon = notif.icon($q);
	if (!notif.spinner) notif.spinner = false;
	else {
		if (notif.spinner === true) notif.spinner = QSpinner_default;
		notif.spinner = markRaw(notif.spinner);
	}
	notif.meta = {
		hasMedia: Boolean(notif.spinner !== false || notif.icon || notif.avatar),
		hasText: hasContent(notif.message) || hasContent(notif.caption)
	};
	if (notif.position) {
		if (positionList.includes(notif.position) === false) return logError("wrong position", config);
	} else notif.position = "bottom";
	if (invalidTimeoutValues.includes(notif.timeout) === true) notif.timeout = 5e3;
	else {
		const t = Number(notif.timeout);
		if (isNaN(t) || t < 0) return logError("wrong timeout", config);
		notif.timeout = Number.isFinite(t) ? t : 0;
	}
	if (notif.timeout === 0) notif.progress = false;
	else if (notif.progress === true) {
		notif.meta.progressClass = "q-notification__progress" + (notif.progressClass ? ` ${notif.progressClass}` : "");
		notif.meta.progressStyle = { animationDuration: `${notif.timeout + 1e3}ms` };
	}
	const actions = (Array.isArray(config.actions) === true ? config.actions : []).concat(config.ignoreDefaults !== true && Array.isArray(defaults.actions) === true ? defaults.actions : []).concat(Array.isArray(notifTypes[config.type]?.actions) === true ? notifTypes[config.type].actions : []);
	const { closeBtn } = notif;
	closeBtn && actions.push({ label: typeof closeBtn === "string" ? closeBtn : $q.lang.label.close });
	notif.actions = actions.map(({ handler, noDismiss, ...item }) => ({
		flat: true,
		...item,
		onClick: typeof handler === "function" ? () => {
			handler();
			noDismiss !== true && dismiss();
		} : () => {
			dismiss();
		}
	}));
	if (notif.multiLine === void 0) notif.multiLine = notif.actions.length > 1;
	Object.assign(notif.meta, {
		class: `q-notification row items-stretch q-notification--${notif.multiLine === true ? "multi-line" : "standard"}` + (notif.color !== void 0 ? ` bg-${notif.color}` : "") + (notif.textColor !== void 0 ? ` text-${notif.textColor}` : "") + (notif.classes !== void 0 ? ` ${notif.classes}` : ""),
		wrapperClass: "q-notification__wrapper col relative-position border-radius-inherit " + (notif.multiLine === true ? "column no-wrap justify-center" : "row items-center"),
		contentClass: "q-notification__content row items-center" + (notif.multiLine === true ? "" : " col"),
		leftClass: notif.meta.hasText === true ? "additional" : "single",
		attrs: {
			role: "alert",
			...notif.attrs
		}
	});
	if (notif.group === false) {
		notif.group = void 0;
		notif.meta.group = void 0;
	} else {
		if (notif.group === void 0 || notif.group === true) notif.group = [
			notif.message,
			notif.caption,
			notif.multiline
		].concat(notif.actions.map((props) => `${props.label}*${props.icon}`)).join("|");
		notif.meta.group = notif.group + "|" + notif.position;
	}
	if (notif.actions.length === 0) notif.actions = void 0;
	else notif.meta.actionsClass = "q-notification__actions row items-center " + (notif.multiLine === true ? "justify-end" : "col-auto") + (notif.meta.hasMedia === true ? " q-notification__actions--with-media" : "");
	if (originalApi !== void 0) {
		if (originalApi.notif.meta.timer) {
			clearTimeout(originalApi.notif.meta.timer);
			originalApi.notif.meta.timer = void 0;
		}
		notif.meta.uid = originalApi.notif.meta.uid;
		const index = notificationsList[notif.position].value.indexOf(originalApi.notif);
		notificationsList[notif.position].value[index] = notif;
	} else {
		const original = groups[notif.meta.group];
		if (original === void 0) {
			notif.meta.uid = uid++;
			notif.meta.badge = 1;
			if ([
				"left",
				"right",
				"center"
			].indexOf(notif.position) !== -1) notificationsList[notif.position].value.splice(Math.floor(notificationsList[notif.position].value.length / 2), 0, notif);
			else {
				const action = notif.position.indexOf("top") !== -1 ? "unshift" : "push";
				notificationsList[notif.position].value[action](notif);
			}
			if (notif.group !== void 0) groups[notif.meta.group] = notif;
		} else {
			if (original.meta.timer) {
				clearTimeout(original.meta.timer);
				original.meta.timer = void 0;
			}
			if (notif.badgePosition !== void 0) {
				if (badgePositions.includes(notif.badgePosition) === false) return logError("wrong badgePosition", config);
			} else notif.badgePosition = `top-${notif.position.indexOf("left") !== -1 ? "right" : "left"}`;
			notif.meta.uid = original.meta.uid;
			notif.meta.badge = original.meta.badge + 1;
			notif.meta.badgeClass = `q-notification__badge q-notification__badge--${notif.badgePosition}` + (notif.badgeColor !== void 0 ? ` bg-${notif.badgeColor}` : "") + (notif.badgeTextColor !== void 0 ? ` text-${notif.badgeTextColor}` : "") + (notif.badgeClass ? ` ${notif.badgeClass}` : "");
			const index = notificationsList[notif.position].value.indexOf(original);
			notificationsList[notif.position].value[index] = groups[notif.meta.group] = notif;
		}
	}
	const dismiss = () => {
		removeNotification(notif);
		Api = void 0;
	};
	if (notif.timeout > 0) notif.meta.timer = setTimeout(() => {
		notif.meta.timer = void 0;
		dismiss();
	}, notif.timeout + 1e3);
	if (notif.group !== void 0) return (props) => {
		if (props !== void 0) logError("trying to update a grouped one which is forbidden", config);
		else dismiss();
	};
	Api = {
		dismiss,
		config,
		notif
	};
	if (originalApi !== void 0) {
		Object.assign(originalApi, Api);
		return;
	}
	return (props) => {
		if (Api !== void 0) if (props === void 0) Api.dismiss();
		else addNotification(Object.assign({}, Api.config, props, {
			group: false,
			position: notif.position
		}), $q, Api);
	};
}
function removeNotification(notif) {
	if (notif.meta.timer) {
		clearTimeout(notif.meta.timer);
		notif.meta.timer = void 0;
	}
	const index = notificationsList[notif.position].value.indexOf(notif);
	if (index !== -1) {
		if (notif.group !== void 0) delete groups[notif.meta.group];
		const el = notifRefs["" + notif.meta.uid];
		if (el) {
			const { width, height } = getComputedStyle(el);
			el.style.left = `${el.offsetLeft}px`;
			el.style.width = width;
			el.style.height = height;
		}
		notificationsList[notif.position].value.splice(index, 1);
		if (typeof notif.onDismiss === "function") notif.onDismiss();
	}
}
function hasContent(str) {
	return str !== void 0 && str !== null && emptyRE.test(str) !== true;
}
function logError(error, config) {
	console.error(`Notify: ${error}`, config);
	return false;
}
function getComponent() {
	return createComponent({
		name: "QNotifications",
		devtools: { hide: true },
		setup() {
			return () => h("div", { class: "q-notifications" }, positionList.map((pos) => {
				return h(TransitionGroup, {
					key: pos,
					class: positionClass[pos],
					tag: "div",
					name: `q-notification--${pos}`
				}, () => notificationsList[pos].value.map((notif) => {
					const meta = notif.meta;
					const mainChild = [];
					if (meta.hasMedia === true) {
						if (notif.spinner !== false) mainChild.push(h(notif.spinner, {
							class: "q-notification__spinner q-notification__spinner--" + meta.leftClass,
							color: notif.spinnerColor,
							size: notif.spinnerSize
						}));
						else if (notif.icon) mainChild.push(h(QIcon_default, {
							class: "q-notification__icon q-notification__icon--" + meta.leftClass,
							name: notif.icon,
							color: notif.iconColor,
							size: notif.iconSize,
							role: "img"
						}));
						else if (notif.avatar) mainChild.push(h(QAvatar_default, { class: "q-notification__avatar q-notification__avatar--" + meta.leftClass }, () => h("img", {
							src: notif.avatar,
							"aria-hidden": "true"
						})));
					}
					if (meta.hasText === true) {
						let msgChild;
						const msgData = { class: "q-notification__message col" };
						if (notif.html === true) msgData.innerHTML = notif.caption ? `<div>${notif.message}</div><div class="q-notification__caption">${notif.caption}</div>` : notif.message;
						else {
							const msgNode = [notif.message];
							msgChild = notif.caption ? [h("div", msgNode), h("div", { class: "q-notification__caption" }, [notif.caption])] : msgNode;
						}
						mainChild.push(h("div", msgData, msgChild));
					}
					const child = [h("div", { class: meta.contentClass }, mainChild)];
					notif.progress === true && child.push(h("div", {
						key: `${meta.uid}|p|${meta.badge}`,
						class: meta.progressClass,
						style: meta.progressStyle
					}));
					notif.actions !== void 0 && child.push(h("div", { class: meta.actionsClass }, notif.actions.map((props) => h(QBtn_default, props))));
					meta.badge > 1 && child.push(h("div", {
						key: `${meta.uid}|${meta.badge}`,
						class: notif.meta.badgeClass,
						style: notif.badgeStyle
					}, [meta.badge]));
					return h("div", {
						ref: (el) => {
							notifRefs["" + meta.uid] = el;
						},
						key: meta.uid,
						class: meta.class,
						...meta.attrs
					}, [h("div", { class: meta.wrapperClass }, child)]);
				}));
			}));
		}
	});
}
var Notify_default = {
	setDefaults(opts) {
		isObject(opts) === true && Object.assign(defaults, opts);
	},
	registerType(typeName, typeOpts) {
		if (isObject(typeOpts) === true) notifTypes[typeName] = typeOpts;
	},
	install({ $q, parentApp }) {
		$q.notify = this.create = (opts) => addNotification(opts, $q);
		$q.notify.setDefaults = this.setDefaults;
		$q.notify.registerType = this.registerType;
		if ($q.config.notify !== void 0) this.setDefaults($q.config.notify);
		if (this.__installed !== true) {
			positionList.forEach((pos) => {
				notificationsList[pos] = ref([]);
				const vert = [
					"left",
					"center",
					"right"
				].includes(pos) === true ? "center" : pos.indexOf("top") !== -1 ? "top" : "bottom", align = pos.indexOf("left") !== -1 ? "start" : pos.indexOf("right") !== -1 ? "end" : "center";
				positionClass[pos] = `q-notifications__list q-notifications__list--${vert} fixed column no-wrap ${["left", "right"].includes(pos) ? `items-${pos === "left" ? "start" : "end"} justify-center` : pos === "center" ? "flex-center" : `items-${align}`}`;
			});
			const el = createGlobalNode("q-notify");
			createChildApp(getComponent(), parentApp).mount(el);
		}
	}
};
//#endregion
//#region node_modules/quasar/src/plugins/storage/engine/web-storage.js
function encode(value) {
	if (isDate(value) === true) return "__q_date|" + value.getTime();
	if (isRegexp(value) === true) return "__q_expr|" + value.source;
	if (typeof value === "number") return "__q_numb|" + value;
	if (typeof value === "boolean") return "__q_bool|" + (value ? "1" : "0");
	if (typeof value === "string") return "__q_strn|" + value;
	if (typeof value === "function") return "__q_strn|" + value.toString();
	if (value === Object(value)) return "__q_objt|" + JSON.stringify(value);
	return value;
}
function decode(value) {
	if (value.length < 9) return value;
	const type = value.substring(0, 8);
	const source = value.substring(9);
	switch (type) {
		case "__q_date":
			const number = Number(source);
			return new Date(Number.isNaN(number) === true ? source : number);
		case "__q_expr": return new RegExp(source);
		case "__q_numb": return Number(source);
		case "__q_bool": return Boolean(source === "1");
		case "__q_strn": return "" + source;
		case "__q_objt": return JSON.parse(source);
		default: return value;
	}
}
function getEmptyStorage() {
	const getVal = () => null;
	return {
		has: () => false,
		hasItem: () => false,
		getLength: () => 0,
		getItem: getVal,
		getIndex: getVal,
		getKey: getVal,
		getAll: () => {},
		getAllKeys: () => [],
		set: noop$2,
		setItem: noop$2,
		remove: noop$2,
		removeItem: noop$2,
		clear: noop$2,
		isEmpty: () => true
	};
}
function getStorage(type) {
	const webStorage = window[type + "Storage"], get = (key) => {
		const item = webStorage.getItem(key);
		return item ? decode(item) : null;
	};
	const hasItem = (key) => webStorage.getItem(key) !== null;
	const setItem = (key, value) => {
		webStorage.setItem(key, encode(value));
	};
	const removeItem = (key) => {
		webStorage.removeItem(key);
	};
	return {
		has: hasItem,
		hasItem,
		getLength: () => webStorage.length,
		getItem: get,
		getIndex: (index) => {
			return index < webStorage.length ? get(webStorage.key(index)) : null;
		},
		getKey: (index) => {
			return index < webStorage.length ? webStorage.key(index) : null;
		},
		getAll: () => {
			let key;
			const result = {}, len = webStorage.length;
			for (let i = 0; i < len; i++) {
				key = webStorage.key(i);
				result[key] = get(key);
			}
			return result;
		},
		getAllKeys: () => {
			const result = [], len = webStorage.length;
			for (let i = 0; i < len; i++) result.push(webStorage.key(i));
			return result;
		},
		set: setItem,
		setItem,
		remove: removeItem,
		removeItem,
		clear: () => {
			webStorage.clear();
		},
		isEmpty: () => webStorage.length === 0
	};
}
//#endregion
//#region node_modules/quasar/src/plugins/storage/LocalStorage.js
var storage = client.has.webStorage === false ? getEmptyStorage() : getStorage("local");
var Plugin = { install({ $q }) {
	$q.localStorage = storage;
} };
Object.assign(Plugin, storage);
//#endregion
//#region .quasar/prod-bex-chrome/quasar-user-options.js
/**
* THIS FILE IS GENERATED AUTOMATICALLY.
* DO NOT EDIT.
*
* You are probably looking on adding startup/initialization code.
* Use "quasar new boot <name>" and add it there.
* One boot file per concern. Then reference the file(s) in quasar.config file > boot:
* boot: ['file', ...] // do not add ".js" extension to it.
*
* Boot files are your "main.js"
**/
var quasar_user_options_default = {
	config: {
		"dark": true,
		"notify": {
			"position": "top",
			"timeout": 3e3
		}
	},
	plugins: {
		Notify: Notify_default,
		LocalStorage: Plugin
	}
};
//#endregion
//#region .quasar/prod-bex-chrome/client-entry.js
/**
* THIS FILE IS GENERATED AUTOMATICALLY.
* DO NOT EDIT.
*
* You are probably looking on adding startup/initialization code.
* Use "quasar new boot <name>" and add it there.
* One boot file per concern. Then reference the file(s) in quasar.config file > boot:
* boot: ['file', ...] // do not add ".js" extension to it.
*
* Boot files are your "main.js"
**/
var publicPath = ``;
async function start({ app, router, store }, bootFiles) {
	let hasRedirected = false;
	const getRedirectUrl = (url) => {
		try {
			return router.resolve(url).href;
		} catch (err) {}
		return Object(url) === url ? null : url;
	};
	const redirect = (url) => {
		hasRedirected = true;
		if (typeof url === "string" && /^https?:\/\//.test(url)) {
			window.location.href = url;
			return;
		}
		const href = getRedirectUrl(url);
		if (href !== null) {
			window.location.href = href;
			window.location.reload();
		}
	};
	const urlPath = window.location.href.replace(window.location.origin, "");
	for (let i = 0; hasRedirected === false && i < bootFiles.length; i++) try {
		await bootFiles[i]({
			app,
			router,
			store,
			ssrContext: null,
			redirect,
			urlPath,
			publicPath
		});
	} catch (err) {
		if (err && err.url) {
			redirect(err.url);
			return;
		}
		console.error("[Quasar] boot error:", err);
		return;
	}
	if (hasRedirected === true) return;
	app.use(router);
	app.mount("#q-app");
}
app_default(createApp, quasar_user_options_default).then((app) => {
	const [method, mapFn] = Promise.allSettled !== void 0 ? ["allSettled", (bootFiles) => bootFiles.map((result) => {
		if (result.status === "rejected") {
			console.error("[Quasar] boot error:", result.reason);
			return;
		}
		return result.value.default;
	})] : ["all", (bootFiles) => bootFiles.map((entry) => entry.default)];
	return Promise[method]([__vitePreload(() => import("./i18n-CNFYrHnB.js"), __vite__mapDeps([24,8,3]), import.meta.url)]).then((bootFiles) => {
		start(app, mapFn(bootFiles).filter((entry) => typeof entry === "function"));
	});
});
//#endregion
export { pageContainerKey as C, layoutKey as S, debounce_default as T, isNumber as _, use_router_link_default as a, fabKey as b, Ripple_default as c, useSpinnerProps as d, useRoute as f, isDeepEqual as g, defineBoot as h, useRouterLinkProps as i, QSpinner_default as l, storeToRefs as m, removeGlobalNode as n, useAlignProps as o, defineStore as p, QBtn_default as r, use_align_default as s, createGlobalNode as t, useSpinner as u, isObject as v, History_default as w, formKey as x, emptyRenderFn as y };
