import { $ as normalizeStyle, C as onActivated, D as onDeactivated, F as watch, G as ref, I as withCtx, J as toRaw, L as withDirectives, M as provide, N as renderList, O as onMounted, Q as normalizeClass, S as nextTick, T as onBeforeUnmount, Z as unref, _ as defineComponent, d as createBaseVNode, et as toDisplayString, f as createBlock, g as createVNode, h as createTextVNode, j as openBlock, k as onUnmounted, m as createElementBlock, p as createCommentVNode, s as Fragment, u as computed, v as getCurrentInstance, x as inject, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { _ as preventDraggable, a as hMergeSlot, b as createComponent, f as leftClick, g as prevent, h as position, i as hDir, l as addEvt, m as noop, s as hSlot, u as cleanEvt, v as stop, x as createDirective, y as stopAndPrevent } from "./dom-ClQ5j7De.js";
import { n as client } from "./Platform-DVLU8Kjq.js";
import { i as QIcon_default, o as useSizeProps, s as use_size_default } from "./vm-BBDykFtW.js";
import { T as debounce_default, _ as isNumber, b as fabKey, d as useSpinnerProps, l as QSpinner_default, m as storeToRefs, p as defineStore, r as QBtn_default, u as useSpinner, v as isObject } from "./index-JMfXUqhI.js";
import { n as useI18n } from "./vue-i18n.runtime-0_E2riTW.js";
import { c as setHorizontalScrollPosition, l as setVerticalScrollPosition, t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import { n as QScrollObserver_default, t as QResizeObserver_default } from "./QResizeObserver-y6jkY3kf.js";
import { t as QPage_default } from "./QPage-DRy6HV2c.js";
import { S as clearSelection, _ as use_model_toggle_default, g as useModelToggleProps, h as useModelToggleEmits } from "./position-engine-B6rijeNv.js";
import { t as QTooltip_default } from "./QTooltip-D32R4QC4.js";
import { S as QBadge_default, _ as QBanner_default, b as useDarkProps, c as QDialog_default, d as QCardSection_default, f as QInput_default, g as use_id_default, h as useFormProps, l as QCard_default, m as useFormInject, n as useAuthStore, o as QSelect_default, p as useFormAttrs, s as between, t as useQuasar, u as QCardActions_default, v as QSeparator_default, x as use_dark_default } from "./use-quasar-C08cASNM.js";
import { a as EXTENSION_HOMEPAGE, c as TTS_VOICES, i as DEFAULT_SETTINGS, n as normalizeSpeakerNames, o as SUPPORTED_LANGUAGES, r as resolveSpeakerLabel, s as TTS_BROWSER_DEFAULT_VOICE_ID, t as useSettingsStore } from "./settings-store-DcBcbD64.js";
import { t as useSubtitlePublisher } from "./useSubtitleSync-DENG9ngW.js";
//#region node_modules/quasar/src/components/spinner/QSpinnerDots.js
var innerHTML = "<circle cx=\"15\" cy=\"15\" r=\"15\"><animate attributeName=\"r\" from=\"15\" to=\"15\" begin=\"0s\" dur=\"0.8s\" values=\"15;9;15\" calcMode=\"linear\" repeatCount=\"indefinite\"></animate><animate attributeName=\"fill-opacity\" from=\"1\" to=\"1\" begin=\"0s\" dur=\"0.8s\" values=\"1;.5;1\" calcMode=\"linear\" repeatCount=\"indefinite\"></animate></circle><circle cx=\"60\" cy=\"15\" r=\"9\" fill-opacity=\".3\"><animate attributeName=\"r\" from=\"9\" to=\"9\" begin=\"0s\" dur=\"0.8s\" values=\"9;15;9\" calcMode=\"linear\" repeatCount=\"indefinite\"></animate><animate attributeName=\"fill-opacity\" from=\".5\" to=\".5\" begin=\"0s\" dur=\"0.8s\" values=\".5;1;.5\" calcMode=\"linear\" repeatCount=\"indefinite\"></animate></circle><circle cx=\"105\" cy=\"15\" r=\"15\"><animate attributeName=\"r\" from=\"15\" to=\"15\" begin=\"0s\" dur=\"0.8s\" values=\"15;9;15\" calcMode=\"linear\" repeatCount=\"indefinite\"></animate><animate attributeName=\"fill-opacity\" from=\"1\" to=\"1\" begin=\"0s\" dur=\"0.8s\" values=\"1;.5;1\" calcMode=\"linear\" repeatCount=\"indefinite\"></animate></circle>";
var QSpinnerDots_default = createComponent({
	name: "QSpinnerDots",
	props: useSpinnerProps,
	setup(props) {
		const { cSize, classes } = useSpinner(props);
		return () => h("svg", {
			class: classes.value,
			fill: "currentColor",
			width: cSize.value,
			height: cSize.value,
			viewBox: "0 0 120 30",
			xmlns: "http://www.w3.org/2000/svg",
			innerHTML
		});
	}
});
//#endregion
//#region src/stores/translator-store.ts
var useTranslatorStore = defineStore("translator", () => {
	const isActive = ref(false);
	const recordingState = ref("idle");
	const entries = ref([]);
	const activeTargetLanguage = ref(DEFAULT_SETTINGS.targetLanguage);
	const error = ref(null);
	const currentTab = ref({
		speakerId: null,
		original: "",
		translation: "",
		audioSource: "tab"
	});
	const currentMic = ref({
		speakerId: null,
		original: "",
		translation: "",
		audioSource: "mic"
	});
	const currentSpeakerId = computed(() => currentTab.value.speakerId ?? currentMic.value.speakerId);
	const currentOriginal = computed(() => currentTab.value.original || currentMic.value.original);
	const currentTranslation = computed(() => currentTab.value.translation || currentMic.value.translation);
	const isRecording = computed(() => recordingState.value === "recording");
	const isConnecting = computed(() => recordingState.value === "starting" || recordingState.value === "connecting");
	const hasError = computed(() => recordingState.value === "error");
	const canStart = computed(() => recordingState.value === "idle" || recordingState.value === "stopped" || recordingState.value === "error" || recordingState.value === "canceled");
	function addEntry(entry) {
		entries.value.push(entry);
	}
	function updateCurrentTokens(speakerId, original, translation, audioSource = "tab") {
		const target = audioSource === "mic" ? currentMic : currentTab;
		target.value = {
			speakerId,
			original,
			translation,
			audioSource
		};
	}
	function finalizeCurrent(speakerId, audioSource = "tab") {
		const target = audioSource === "mic" ? currentMic : currentTab;
		const current = target.value;
		const resolvedSpeakerId = speakerId ?? current.speakerId;
		if (!current.original && !current.translation || !resolvedSpeakerId) return;
		const entry = {
			id: crypto.randomUUID(),
			timestamp: Date.now(),
			speakerId: resolvedSpeakerId,
			originalText: current.original,
			translatedText: current.translation,
			sourceLanguage: "",
			targetLanguage: activeTargetLanguage.value,
			isFinal: true,
			audioSource
		};
		entries.value.push(entry);
		target.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource
		};
	}
	function clearEntries() {
		entries.value = [];
		currentTab.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "tab"
		};
		currentMic.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "mic"
		};
	}
	function setRecordingState(state) {
		recordingState.value = state;
		isActive.value = state === "recording" || state === "starting" || state === "connecting" || state === "paused";
	}
	function setError(message) {
		error.value = message;
		if (message) recordingState.value = "error";
	}
	function setTargetLanguage(targetLanguage) {
		activeTargetLanguage.value = targetLanguage;
	}
	function reset() {
		isActive.value = false;
		recordingState.value = "idle";
		entries.value = [];
		currentTab.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "tab"
		};
		currentMic.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "mic"
		};
		activeTargetLanguage.value = DEFAULT_SETTINGS.targetLanguage;
		error.value = null;
	}
	return {
		isActive,
		recordingState,
		entries,
		currentSpeakerId,
		currentOriginal,
		currentTranslation,
		currentTab,
		currentMic,
		error,
		isRecording,
		isConnecting,
		hasError,
		canStart,
		addEntry,
		updateCurrentTokens,
		finalizeCurrent,
		setTargetLanguage,
		clearEntries,
		setRecordingState,
		setError,
		reset
	};
});
//#endregion
//#region node_modules/@soniox/client/dist/index.mjs
var SonioxError = class extends Error {
	/**
	* Error code describing the type of error.
	* Typed as `string` at the base level to allow subclasses (e.g. HTTP errors)
	* to use their own error code unions.
	*/
	code;
	/**
	* HTTP status code when applicable (e.g., 401 for auth errors, 500 for server errors).
	*/
	statusCode;
	/**
	* The underlying error that caused this error, if any.
	*/
	cause;
	constructor(message, code = "soniox_error", statusCode, cause) {
		super(message);
		this.name = "SonioxError";
		this.code = code;
		this.statusCode = statusCode;
		this.cause = cause;
		if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
		Object.setPrototypeOf(this, new.target.prototype);
	}
	/**
	* Creates a human-readable string representation
	*/
	toString() {
		const parts = [`${this.name} [${this.code}]: ${this.message}`];
		if (this.statusCode !== void 0) parts.push(`  Status: ${this.statusCode}`);
		return parts.join("\n");
	}
	/**
	* Converts to a plain object for logging/serialization
	*/
	toJSON() {
		return {
			name: this.name,
			code: this.code,
			message: this.message,
			...this.statusCode !== void 0 && { statusCode: this.statusCode }
		};
	}
};
/**
* Generic async event queue that supports iteration with proper error propagation.
*
* This utility enables `for await...of` consumption of events while properly
* surfacing errors to consumers instead of silently ending iteration.
*/
var AsyncEventQueue = class {
	queue = [];
	waiters = [];
	done = false;
	error = null;
	/**
	* Push an event to the queue.
	* If there are waiting consumers, delivers immediately.
	*/
	push(event) {
		if (this.done) return;
		const waiter = this.waiters.shift();
		if (waiter) waiter.resolve({
			value: event,
			done: false
		});
		else this.queue.push(event);
	}
	/**
	* End the queue normally.
	* Waiting consumers will receive `{ done: true }`.
	*/
	end() {
		if (this.done) return;
		this.done = true;
		this.flushWaiters();
	}
	/**
	* End the queue with an error.
	* Waiting consumers will have their promises rejected.
	* Future `next()` calls will also reject with this error.
	* Any queued events are discarded.
	*/
	abort(error) {
		if (this.done) return;
		this.done = true;
		this.error = error;
		this.queue = [];
		this.flushWaiters();
	}
	/**
	* Whether the queue has ended (normally or with error).
	*/
	get isDone() {
		return this.done;
	}
	/**
	* Async iterator implementation.
	*/
	[Symbol.asyncIterator]() {
		return { next: () => this.next() };
	}
	/**
	* Get the next event from the queue.
	*/
	next() {
		const error = this.error;
		if (error) return Promise.reject(error);
		const event = this.queue.shift();
		if (event !== void 0) return Promise.resolve({
			value: event,
			done: false
		});
		if (this.done) return Promise.resolve({
			value: void 0,
			done: true
		});
		return new Promise((resolve, reject) => {
			this.waiters.push({
				resolve,
				reject
			});
		});
	}
	/**
	* Flush all waiting consumers when queue ends.
	*/
	flushWaiters() {
		for (const { resolve, reject } of this.waiters) if (this.error) reject(this.error);
		else resolve({
			value: void 0,
			done: true
		});
		this.waiters = [];
	}
};
/**
* A minimal, runtime-agnostic typed event emitter.
* Does not depend on Node.js EventEmitter.
*/
var TypedEmitter = class {
	listeners = /* @__PURE__ */ new Map();
	errorEvent = "error";
	/**
	* Register an event handler.
	*/
	on(event, handler) {
		let handlers = this.listeners.get(event);
		if (!handlers) {
			handlers = /* @__PURE__ */ new Set();
			this.listeners.set(event, handlers);
		}
		handlers.add(handler);
		return this;
	}
	/**
	* Register a one-time event handler.
	*/
	once(event, handler) {
		const wrapper = ((...args) => {
			this.off(event, wrapper);
			handler(...args);
		});
		return this.on(event, wrapper);
	}
	/**
	* Remove an event handler.
	*/
	off(event, handler) {
		const handlers = this.listeners.get(event);
		if (handlers) {
			handlers.delete(handler);
			if (handlers.size === 0) this.listeners.delete(event);
		}
		return this;
	}
	/**
	* Emit an event to all registered handlers.
	* Handler errors do not prevent other handlers from running.
	* Errors are reported to an `error` event if present, otherwise rethrown async.
	*/
	emit(event, ...args) {
		const handlers = this.listeners.get(event);
		if (handlers) for (const handler of [...handlers]) try {
			handler(...args);
		} catch (error) {
			if (event === this.errorEvent) this.scheduleThrow(this.normalizeError(error));
			else this.reportListenerError(error);
		}
	}
	/**
	* Remove all event handlers.
	*/
	removeAllListeners(event) {
		if (event !== void 0) this.listeners.delete(event);
		else this.listeners.clear();
	}
	reportListenerError(error) {
		const normalizedError = this.normalizeError(error);
		const handlers = this.listeners.get(this.errorEvent);
		if (!handlers || handlers.size === 0) {
			this.scheduleThrow(normalizedError);
			return;
		}
		for (const handler of [...handlers]) try {
			handler(normalizedError);
		} catch (handlerError) {
			this.scheduleThrow(this.normalizeError(handlerError));
		}
	}
	normalizeError(error) {
		if (error instanceof Error) return error;
		return new Error(String(error));
	}
	scheduleThrow(error) {
		setTimeout(() => {
			throw error;
		}, 0);
	}
};
/**
* Real-time (WebSocket) API error classes for the Soniox SDK
* All real-time errors extend SonioxError
*/
/**
* Base error class for all real-time (WebSocket) SDK errors
*/
var RealtimeError = class extends SonioxError {
	/**
	* Original response payload for debugging.
	* Contains the raw WebSocket message that caused the error.
	*/
	raw;
	constructor(message, code = "realtime_error", statusCode, raw) {
		super(message, code, statusCode);
		this.name = "RealtimeError";
		this.raw = raw;
	}
	/**
	* Creates a human-readable string representation
	*/
	toString() {
		const parts = [`${this.name} [${this.code}]: ${this.message}`];
		if (this.statusCode !== void 0) parts.push(`  Status: ${this.statusCode}`);
		return parts.join("\n");
	}
	/**
	* Converts to a plain object for logging/serialization
	*/
	toJSON() {
		return {
			name: this.name,
			code: this.code,
			message: this.message,
			...this.statusCode !== void 0 && { statusCode: this.statusCode },
			...this.raw !== void 0 && { raw: this.raw }
		};
	}
};
/**
* Authentication error (401).
* Thrown when the API key is invalid or expired.
*/
var AuthError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "auth_error", statusCode, raw);
		this.name = "AuthError";
	}
};
/**
* Bad request error (400).
* Thrown for invalid configuration or parameters.
*/
var BadRequestError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "bad_request", statusCode, raw);
		this.name = "BadRequestError";
	}
};
/**
* Quota error (402, 429).
* Thrown when rate limits are exceeded or quota is exhausted.
*/
var QuotaError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "quota_exceeded", statusCode, raw);
		this.name = "QuotaError";
	}
};
/**
* Connection error.
* Thrown for WebSocket connection failures and transport errors.
*/
var ConnectionError = class extends RealtimeError {
	constructor(message, raw) {
		super(message, "connection_error", void 0, raw);
		this.name = "ConnectionError";
	}
};
/**
* Network error.
* Thrown for server-side network issues (408, 500, 503).
*/
var NetworkError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "network_error", statusCode, raw);
		this.name = "NetworkError";
	}
};
/**
* Abort error.
* Thrown when an operation is cancelled via AbortSignal.
*/
var AbortError = class extends RealtimeError {
	constructor(message = "Operation aborted") {
		super(message, "aborted");
		this.name = "AbortError";
	}
};
/**
* State error.
* Thrown when an operation is attempted in an invalid state.
*/
var StateError = class extends RealtimeError {
	constructor(message) {
		super(message, "state_error");
		this.name = "StateError";
	}
};
/**
* Map a Soniox error response to a typed error class.
*
* @param response - Error response from the WebSocket
* @returns Appropriate error subclass
*/
function mapErrorResponse(response) {
	const { error_code, error_message } = response;
	const message = error_message ?? "Unknown error";
	switch (error_code) {
		case 401: return new AuthError(message, error_code, response);
		case 400: return new BadRequestError(message, error_code, response);
		case 402:
		case 429: return new QuotaError(message, error_code, response);
		case 408:
		case 500:
		case 503: return new NetworkError(message, error_code, response);
		default: return new RealtimeError(message, "realtime_error", error_code, response);
	}
}
var DEFAULT_KEEPALIVE_INTERVAL_MS = 5e3;
var MIN_KEEPALIVE_INTERVAL_MS = 1e3;
/**
* Convert audio data to Uint8Array
* Handles Uint8Array and ArrayBuffer
*/
function toUint8Array(data) {
	if (data instanceof ArrayBuffer) return new Uint8Array(data);
	return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
}
/**
* Build the configuration message to send after WebSocket connection
*/
function buildConfigMessage(config, apiKey) {
	return {
		api_key: apiKey,
		model: config.model,
		audio_format: config.audio_format ?? "auto",
		sample_rate: config.sample_rate,
		num_channels: config.num_channels,
		language_hints: config.language_hints,
		language_hints_strict: config.language_hints_strict,
		enable_speaker_diarization: config.enable_speaker_diarization,
		enable_language_identification: config.enable_language_identification,
		enable_endpoint_detection: config.enable_endpoint_detection,
		client_reference_id: config.client_reference_id,
		max_endpoint_delay_ms: config.max_endpoint_delay_ms,
		context: config.context,
		translation: config.translation
	};
}
/**
* Parse a result message from the WebSocket
*/
function parseResultMessage(data) {
	const raw = JSON.parse(data);
	if ("error_code" in raw || "error_message" in raw) throw mapErrorResponse(raw);
	return {
		tokens: (raw.tokens ?? []).map((t) => ({
			text: typeof t.text === "string" ? t.text : "",
			start_ms: typeof t.start_ms === "number" ? t.start_ms : void 0,
			end_ms: typeof t.end_ms === "number" ? t.end_ms : void 0,
			confidence: typeof t.confidence === "number" ? t.confidence : 0,
			is_final: Boolean(t.is_final),
			speaker: typeof t.speaker === "string" ? t.speaker : void 0,
			language: typeof t.language === "string" ? t.language : void 0,
			translation_status: t.translation_status === "none" || t.translation_status === "original" || t.translation_status === "translation" ? t.translation_status : void 0,
			source_language: typeof t.source_language === "string" ? t.source_language : void 0
		})),
		final_audio_proc_ms: typeof raw.final_audio_proc_ms === "number" ? raw.final_audio_proc_ms : 0,
		total_audio_proc_ms: typeof raw.total_audio_proc_ms === "number" ? raw.total_audio_proc_ms : 0,
		finished: raw.finished === true,
		raw
	};
}
/**
* Check if a token is a special control token
*/
function isSpecialToken(text) {
	return text === "<end>" || text === "<fin>";
}
/**
* Filter out special control tokens from tokens array
*/
function filterSpecialTokens(tokens) {
	return tokens.filter((t) => !isSpecialToken(t.text));
}
/**
* Real-time Speech-to-Text session
*
* Provides WebSocket-based streaming transcription with support for:
* - Event-based and async iterator consumption
* - Pause/resume with automatic keepalive while paused
* - AbortSignal cancellation
*
* @example
* ```typescript
* const session = new RealtimeSttSession(apiKey, wsUrl, { model: 'stt-rt-v4' });
*
* session.on('result', (result) => {
*   console.log(result.tokens.map(t => t.text).join(''));
* });
*
* await session.connect();
* session.sendAudio(audioChunk);
* await session.finish();
* ```
*/
var RealtimeSttSession = class {
	emitter = new TypedEmitter();
	eventQueue = new AsyncEventQueue();
	apiKey;
	wsBaseUrl;
	config;
	keepaliveIntervalMs;
	signal;
	ws = null;
	_state = "idle";
	_paused = false;
	_pauseWarned = false;
	keepaliveInterval = null;
	finishResolver = null;
	finishRejecter = null;
	abortHandler = null;
	constructor(apiKey, wsBaseUrl, config, options) {
		this.apiKey = apiKey;
		this.wsBaseUrl = wsBaseUrl;
		this.config = config;
		const keepaliveMs = options?.keepalive_interval_ms ?? DEFAULT_KEEPALIVE_INTERVAL_MS;
		this.keepaliveIntervalMs = Number.isFinite(keepaliveMs) && keepaliveMs > 0 ? Math.max(keepaliveMs, MIN_KEEPALIVE_INTERVAL_MS) : DEFAULT_KEEPALIVE_INTERVAL_MS;
		this.signal = options?.signal;
		if (this.signal) {
			this.abortHandler = () => this.handleAbort();
			this.signal.addEventListener("abort", this.abortHandler);
		}
	}
	/**
	* Current session state.
	*/
	get state() {
		return this._state;
	}
	/**
	* Whether the session is currently paused.
	*/
	get paused() {
		return this._paused;
	}
	/**
	* Connect to the Soniox WebSocket API.
	*
	* @throws {@link AbortError} If aborted
	* @throws {@link ConnectionError} If connection fails
	* @throws {@link StateError} If already connected
	*/
	async connect() {
		if (this._state !== "idle") throw new StateError(`Cannot connect: session is in "${this._state}" state`);
		this.checkAborted();
		this.setState("connecting");
		try {
			await this.createWebSocket();
			this.setState("connected");
			this.emitter.emit("connected");
			this.updateKeepalive();
		} catch (error) {
			if (!this.isTerminalState(this._state)) {
				const err = error instanceof Error ? error : new ConnectionError("Connection failed", error);
				this.cleanup("error", err);
			}
			throw error;
		}
	}
	/**
	* Send audio data to the server
	*
	* @param data - Audio data as Uint8Array or ArrayBuffer
	* @throws {@link AbortError} If aborted
	* @throws {@link StateError} If not connected
	*/
	sendAudio(data) {
		this.checkAborted();
		if (this._state !== "connected") throw new StateError(`Cannot send audio: session is in "${this._state}" state`);
		if (this._paused) return;
		const chunk = toUint8Array(data);
		this.sendMessage(chunk, true);
	}
	/**
	* Stream audio data from an async iterable source.
	*
	* @param stream - Async iterable yielding audio chunks
	* @param options - Optional pacing and auto-finish settings
	* @throws {@link AbortError} If aborted during streaming
	* @throws {@link StateError} If not connected
	*/
	async sendStream(stream, options) {
		for await (const chunk of stream) {
			this.sendAudio(chunk);
			if (options?.pace_ms) await new Promise((resolve) => setTimeout(resolve, options.pace_ms));
		}
		if (options?.finish) await this.finish();
	}
	/**
	* Pause audio transmission and starts automatic keepalive messages
	*/
	pause() {
		if (this._paused) return;
		this._paused = true;
		this.finalize();
		if (!this._pauseWarned && typeof process !== "undefined" && false);
		this.updateKeepalive();
	}
	/**
	* Resume audio transmission
	*/
	resume() {
		if (!this._paused) return;
		this._paused = false;
		this.updateKeepalive();
	}
	/**
	* Requests the server to finalize current transcription
	*/
	finalize(options) {
		if (this._state !== "connected" && this._state !== "finishing") return;
		const message = { type: "finalize" };
		if (options?.trailing_silence_ms !== void 0) message.trailing_silence_ms = options.trailing_silence_ms;
		this.sendMessage(JSON.stringify(message), false);
	}
	/**
	* Send a keepalive message
	*/
	keepAlive() {
		if (this._state !== "connected" && this._state !== "finishing") return;
		this.sendMessage(JSON.stringify({ type: "keepalive" }), false);
	}
	/**
	* Gracefully finish the session
	*/
	async finish() {
		this.checkAborted();
		if (this._state !== "connected") throw new StateError(`Cannot finish: session is in "${this._state}" state`);
		if (this._paused) this.resume();
		this.setState("finishing");
		this.updateKeepalive();
		const finishPromise = new Promise((resolve, reject) => {
			this.finishResolver = resolve;
			this.finishRejecter = reject;
		});
		this.sendMessage("", false);
		return finishPromise;
	}
	/**
	* Close (cancel) the session immediately without waiting
	*/
	close() {
		if (this.isTerminalState(this._state)) return;
		this.emitter.emit("disconnected", "client_closed");
		this.settleFinish(new StateError("Session canceled"));
		this.cleanup("canceled");
	}
	/**
	* Register an event handler
	*/
	on(event, handler) {
		this.emitter.on(event, handler);
		return this;
	}
	/**
	* Register a one-time event handler
	*/
	once(event, handler) {
		this.emitter.once(event, handler);
		return this;
	}
	/**
	* Remove an event handler
	*/
	off(event, handler) {
		this.emitter.off(event, handler);
		return this;
	}
	/**
	* Async iterator for consuming events.
	*/
	[Symbol.asyncIterator]() {
		return this.eventQueue[Symbol.asyncIterator]();
	}
	async createWebSocket() {
		return new Promise((resolve, reject) => {
			try {
				const ws = new WebSocket(this.wsBaseUrl);
				this.ws = ws;
				ws.binaryType = "arraybuffer";
				const cleanup = () => {
					ws.removeEventListener("open", onOpen);
					ws.removeEventListener("error", onError);
				};
				const onOpen = () => {
					cleanup();
					const configMessage = buildConfigMessage(this.config, this.apiKey);
					ws.send(JSON.stringify(configMessage));
					ws.addEventListener("message", this.handleMessage.bind(this));
					ws.addEventListener("close", this.handleClose.bind(this));
					ws.addEventListener("error", this.handleError.bind(this));
					resolve();
				};
				const onError = (event) => {
					cleanup();
					reject(new ConnectionError("WebSocket connection failed", event));
				};
				ws.addEventListener("open", onOpen);
				ws.addEventListener("error", onError);
				if (this.signal) this.signal.addEventListener("abort", () => {
					cleanup();
					ws.close();
					reject(new AbortError());
				}, { once: true });
			} catch (error) {
				reject(new ConnectionError("Failed to create WebSocket", error));
			}
		});
	}
	handleMessage(event) {
		if (typeof event.data !== "string") return;
		const data = event.data;
		try {
			const result = parseResultMessage(data);
			const hasEndpoint = result.tokens.some((t) => t.text === "<end>");
			const hasFinalized = result.tokens.some((t) => t.text === "<fin>");
			const userTokens = filterSpecialTokens(result.tokens);
			for (const token of userTokens) this.emitter.emit("token", token);
			const filteredResult = {
				...result,
				tokens: userTokens
			};
			this.emitter.emit("result", filteredResult);
			this.eventQueue.push({
				kind: "result",
				data: filteredResult
			});
			if (hasEndpoint) {
				this.emitter.emit("endpoint");
				this.eventQueue.push({ kind: "endpoint" });
			}
			if (hasFinalized) {
				this.emitter.emit("finalized");
				this.eventQueue.push({ kind: "finalized" });
			}
			if (result.finished) {
				this.emitter.emit("finished");
				this.eventQueue.push({ kind: "finished" });
				this.settleFinish();
				this.cleanup("finished");
			}
		} catch (error) {
			const err = error;
			this.emitter.emit("error", err);
			this.settleFinish(err);
			this.cleanup("error", err);
		}
	}
	handleClose(event) {
		if (this.isTerminalState(this._state)) return;
		this.emitter.emit("disconnected", event.reason || void 0);
		if (this._state === "finishing") {
			const error = new ConnectionError("WebSocket closed before finished response", event);
			this.emitter.emit("error", error);
			this.settleFinish(error);
			this.cleanup("error", error);
			return;
		}
		this.cleanup("closed");
	}
	handleError(event) {
		const error = new ConnectionError("WebSocket error", event);
		this.emitter.emit("error", error);
		this.settleFinish(error);
		this.cleanup("error", error);
	}
	handleAbort() {
		const error = new AbortError();
		this.emitter.emit("error", error);
		this.settleFinish(error);
		this.cleanup("canceled", error);
	}
	setState(newState) {
		if (this._state === newState) return;
		const oldState = this._state;
		this._state = newState;
		this.emitter.emit("state_change", {
			old_state: oldState,
			new_state: newState
		});
	}
	cleanup(finalState, error) {
		this.setState(finalState);
		this.stopKeepalive();
		if (this.signal && this.abortHandler) {
			this.signal.removeEventListener("abort", this.abortHandler);
			this.abortHandler = null;
		}
		if (this.ws) {
			this.ws.close();
			this.ws = null;
		}
		if (error) this.eventQueue.abort(error);
		else this.eventQueue.end();
		this.emitter.removeAllListeners();
	}
	isTerminalState(state) {
		return state === "closed" || state === "error" || state === "finished" || state === "canceled";
	}
	checkAborted() {
		if (this.signal?.aborted) throw new AbortError();
	}
	settleFinish(error) {
		if (!this.finishResolver && !this.finishRejecter) return;
		const resolve = this.finishResolver;
		const reject = this.finishRejecter;
		this.finishResolver = null;
		this.finishRejecter = null;
		if (error) reject?.(error);
		else resolve?.();
	}
	sendMessage(data, shouldThrow) {
		if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
			const error = new ConnectionError("WebSocket is not open");
			this.emitter.emit("error", error);
			this.settleFinish(error);
			this.cleanup("error", error);
			if (shouldThrow) throw error;
			return;
		}
		try {
			this.ws.send(data);
		} catch (err) {
			const error = new ConnectionError("WebSocket send failed", err);
			this.emitter.emit("error", error);
			this.settleFinish(error);
			this.cleanup("error", error);
			if (shouldThrow) throw error;
		}
	}
	startKeepalive() {
		if (this.keepaliveInterval) return;
		this.keepaliveInterval = setInterval(() => {
			this.keepAlive();
		}, this.keepaliveIntervalMs);
	}
	stopKeepalive() {
		if (this.keepaliveInterval) {
			clearInterval(this.keepaliveInterval);
			this.keepaliveInterval = null;
		}
	}
	updateKeepalive() {
		if ((this._state === "connected" || this._state === "finishing") && this._paused) this.startKeepalive();
		else this.stopKeepalive();
	}
};
/**
* Audio-specific error classes for the client SDK
* These errors are thrown by AudioSource implementations when capture cannot begin
*/
/**
* Thrown when microphone access is denied by the user or blocked by the browser.
*
* Maps to `getUserMedia` `NotAllowedError` DOMException.
*/
var AudioPermissionError = class extends SonioxError {
	constructor(message = "Microphone access denied", cause) {
		super(message, "permission_denied", void 0, cause);
		this.name = "AudioPermissionError";
	}
};
/**
* Thrown when no audio input device is found
*
* Maps to `getUserMedia` `NotFoundError` DOMException.
*/
var AudioDeviceError = class extends SonioxError {
	constructor(message = "No audio input device found", cause) {
		super(message, "device_not_found", void 0, cause);
		this.name = "AudioDeviceError";
	}
};
/**
* Thrown when audio capture is not supported in the current environment
*
* For example, when `getUserMedia` or `MediaRecorder` is not available.
*/
var AudioUnavailableError = class extends SonioxError {
	constructor(message = "Audio capture is not supported in this environment", cause) {
		super(message, "audio_unavailable", void 0, cause);
		this.name = "AudioUnavailableError";
	}
};
/**
* Browser microphone audio source using getUserMedia + MediaRecorder
*/
var DEFAULT_TIMESLICE_MS = 60;
var DEFAULT_AUDIO_CONSTRAINTS = {
	echoCancellation: false,
	noiseSuppression: false,
	autoGainControl: false,
	channelCount: 1,
	sampleRate: 16e3
};
/**
* Browser microphone audio source
*
* Uses `navigator.mediaDevices.getUserMedia` to capture audio from the microphone
* and `MediaRecorder` to encode it into chunks.
*
* @example
* ```typescript
* const source = new MicrophoneSource();
* await source.start({
*   onData: (chunk) => session.sendAudio(chunk),
*   onError: (err) => console.error(err),
* });
* // Later:
* source.stop();
* ```
*/
var MicrophoneSource = class {
	constraints;
	recorderOptions;
	timesliceMs;
	mediaRecorder = null;
	stream = null;
	boundOnData = null;
	boundOnError = null;
	boundOnMute = null;
	boundOnUnmute = null;
	startGeneration = 0;
	constructor(options = {}) {
		this.constraints = options.constraints ?? DEFAULT_AUDIO_CONSTRAINTS;
		this.recorderOptions = options.recorderOptions ?? {};
		this.timesliceMs = options.timesliceMs ?? DEFAULT_TIMESLICE_MS;
	}
	/**
	* Request microphone access and start recording
	*
	* @throws AudioUnavailableError if getUserMedia or MediaRecorder is not supported
	* @throws AudioPermissionError if microphone access is denied
	* @throws AudioDeviceError if no microphone is found
	*/
	async start(handlers) {
		this.stop();
		const generation = ++this.startGeneration;
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) throw new AudioUnavailableError("navigator.mediaDevices.getUserMedia is not available");
		if (typeof MediaRecorder === "undefined") throw new AudioUnavailableError("MediaRecorder is not available");
		let stream;
		try {
			stream = await navigator.mediaDevices.getUserMedia({ audio: this.constraints });
		} catch (err) {
			if (err instanceof DOMException) {
				if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") throw new AudioPermissionError("Microphone access denied by user", err);
				if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") throw new AudioDeviceError("No microphone found", err);
				if (err.name === "NotReadableError" || err.name === "TrackStartError") throw new AudioDeviceError("Microphone is already in use or not readable", err);
			}
			throw new AudioUnavailableError(err instanceof Error ? err.message : "Failed to access microphone", err);
		}
		if (generation !== this.startGeneration) {
			stream.getTracks().forEach((track$1) => track$1.stop());
			return;
		}
		this.stream = stream;
		const track = stream.getAudioTracks()[0];
		if (track) {
			const { onMuted, onUnmuted } = handlers;
			this.boundOnMute = onMuted ? () => {
				onMuted();
			} : null;
			this.boundOnUnmute = onUnmuted ? () => {
				onUnmuted();
			} : null;
			if (this.boundOnMute) track.addEventListener("mute", this.boundOnMute);
			if (this.boundOnUnmute) track.addEventListener("unmute", this.boundOnUnmute);
		}
		try {
			const recorder = new MediaRecorder(stream, this.recorderOptions);
			this.mediaRecorder = recorder;
			this.boundOnData = (event) => {
				if (event.data.size > 0) event.data.arrayBuffer().then((buffer) => handlers.onData(buffer), (err) => handlers.onError(err instanceof Error ? err : new Error(String(err))));
			};
			this.boundOnError = (event) => {
				const errorEvent = event;
				const error = new Error(errorEvent.message || "MediaRecorder error");
				handlers.onError(error);
			};
			recorder.addEventListener("dataavailable", this.boundOnData);
			recorder.addEventListener("error", this.boundOnError);
			recorder.start(this.timesliceMs);
		} catch (err) {
			stream.getTracks().forEach((track$1) => track$1.stop());
			this.stream = null;
			this.mediaRecorder = null;
			this.boundOnMute = null;
			this.boundOnUnmute = null;
			throw new AudioUnavailableError(err instanceof Error ? err.message : "Failed to start MediaRecorder", err);
		}
	}
	/**
	* Stop recording and release all resources
	*/
	stop() {
		if (this.mediaRecorder) {
			if (this.mediaRecorder.state !== "inactive") {
				const recorder = this.mediaRecorder;
				const onData = this.boundOnData;
				const onError = this.boundOnError;
				recorder.addEventListener("stop", () => {
					if (onData) recorder.removeEventListener("dataavailable", onData);
					if (onError) recorder.removeEventListener("error", onError);
				}, { once: true });
				recorder.stop();
			} else {
				if (this.boundOnData) this.mediaRecorder.removeEventListener("dataavailable", this.boundOnData);
				if (this.boundOnError) this.mediaRecorder.removeEventListener("error", this.boundOnError);
			}
			this.boundOnData = null;
			this.boundOnError = null;
			this.mediaRecorder = null;
		}
		if (this.stream) {
			if (this.boundOnMute || this.boundOnUnmute) {
				const track = this.stream.getAudioTracks()[0];
				if (track) {
					if (this.boundOnMute) track.removeEventListener("mute", this.boundOnMute);
					if (this.boundOnUnmute) track.removeEventListener("unmute", this.boundOnUnmute);
				}
				this.boundOnMute = null;
				this.boundOnUnmute = null;
			}
			this.stream.getTracks().forEach((track) => track.stop());
			this.stream = null;
		}
	}
	/**
	* Pause audio capture
	*/
	pause() {
		if (this.mediaRecorder && this.mediaRecorder.state === "recording") this.mediaRecorder.pause();
	}
	/**
	* Resume audio capture
	*/
	resume() {
		if (this.mediaRecorder && this.mediaRecorder.state === "paused") this.mediaRecorder.resume();
	}
};
/**
* Resolves an ApiKeyConfig to a plain API key string.
* @param config - The API key configuration
* @returns The resolved API key string
* @throws If the function rejects or returns a non-string value
*/
async function resolveApiKey(config) {
	if (typeof config === "function") {
		const key = await config();
		if (typeof key !== "string" || key.length === 0) throw new Error("api_key function must return a non-empty string");
		return key;
	}
	if (typeof config !== "string" || config.length === 0) throw new Error("api_key must be a non-empty string");
	return config;
}
/**
* Recording - high-level orchestrator for real-time speech-to-text.
*
* Returned by `client.realtime.record()`. Manages the lifecycle of an AudioSource
* and a RealtimeSttSession, including audio buffering during key fetch/connection.
*/
var TERMINAL_STATES = [
	"stopped",
	"canceled",
	"error"
];
var DEFAULT_BUFFER_QUEUE_SIZE = 1e3;
/**
* High-level recording orchestrator
*
* Manages the lifecycle of audio capture and real-time transcription:
* 1. Starts audio source immediately (buffers chunks)
* 2. Resolves the API key (from string or async function)
* 3. Connects to the Soniox WebSocket API
* 4. Drains buffered audio, then pipes live audio to the session
*
* @example
* ```typescript
* const recording = client.realtime.record({ model: 'stt-rt-v4' });
* recording.on('result', (r) => console.log(r.tokens));
* recording.on('error', (e) => console.error(e));
*
* // Later:
* await recording.stop();
* ```
*/
var Recording = class {
	emitter = new TypedEmitter();
	apiKeyConfig;
	wsBaseUrl;
	sttConfig;
	sessionOptions;
	source;
	maxBufferSize;
	signal;
	session = null;
	audioBuffer = [];
	_state = "idle";
	isBuffering = true;
	_isSourceMuted = false;
	stopResolver = null;
	stopRejecter = null;
	/** @internal */
	constructor(apiKeyConfig, wsBaseUrl, sttConfig, source, options) {
		this.apiKeyConfig = apiKeyConfig;
		this.wsBaseUrl = wsBaseUrl;
		this.sttConfig = sttConfig;
		this.source = source;
		this.maxBufferSize = options?.buffer_queue_size ?? DEFAULT_BUFFER_QUEUE_SIZE;
		this.sessionOptions = options?.session_options;
		this.signal = options?.signal;
		queueMicrotask(() => {
			this.run();
		});
	}
	/**
	* Current recording state
	*/
	get state() {
		return this._state;
	}
	/**
	* Register an event handler
	*/
	on(event, handler) {
		this.emitter.on(event, handler);
		return this;
	}
	/**
	* Register a one-time event handler
	*/
	once(event, handler) {
		this.emitter.once(event, handler);
		return this;
	}
	/**
	* Remove an event handler
	*/
	off(event, handler) {
		this.emitter.off(event, handler);
		return this;
	}
	/**
	* Gracefully stop recording
	*
	* Stops the audio source and waits for the server to process all
	* buffered audio and return final results.
	*
	* @returns Promise that resolves when the server acknowledges completion
	*/
	async stop() {
		if (this._state === "stopped" || this._state === "canceled" || this._state === "error") return;
		if (this._state === "stopping") return new Promise((resolve, reject) => {
			this.once("finished", resolve);
			this.once("error", reject);
		});
		this.setState("stopping");
		this.source.stop();
		if (this.session && this.session.state === "connected") {
			const finishPromise = new Promise((resolve, reject) => {
				this.stopResolver = resolve;
				this.stopRejecter = reject;
			});
			try {
				await this.session.finish();
			} catch (err) {
				const error = err instanceof Error ? err : new Error(String(err));
				this.settleStop(error);
				this.cleanup("error");
				return;
			}
			return finishPromise;
		}
		return new Promise((resolve, reject) => {
			this.stopResolver = resolve;
			this.stopRejecter = reject;
		});
	}
	/**
	* Immediately cancel recording without waiting for final results
	*/
	cancel() {
		if (this._state === "stopped" || this._state === "canceled" || this._state === "error") return;
		this.source.stop();
		this.session?.close();
		this.cleanup("canceled");
	}
	/**
	* Request the server to finalize current non-final tokens.
	*/
	finalize(options) {
		this.session?.finalize(options);
	}
	/**
	* Pause recording.
	*
	* Pauses the audio source (stops microphone capture) and pauses the
	* session (activates automatic keepalive to prevent server disconnect).
	*/
	pause() {
		if (this._state !== "recording") return;
		this.source.pause?.();
		this.session?.pause();
		this.setState("paused");
	}
	/**
	* Resume recording after pause.
	*
	* Resumes the audio source and session. Audio capture and transmission
	* continue from where they left off.
	*/
	resume() {
		if (this._state !== "paused") return;
		this.source.resume?.();
		if (!this._isSourceMuted) this.session?.resume();
		this.setState("recording");
	}
	async run() {
		if (this.signal?.aborted) {
			this.handleAbort();
			return;
		}
		const onAbort = () => this.handleAbort();
		this.signal?.addEventListener("abort", onAbort, { once: true });
		this.setState("starting");
		try {
			await this.source.start({
				onData: (chunk) => this.handleAudioData(chunk),
				onError: (err) => this.handleError(err),
				onMuted: () => this.handleSourceMuted(),
				onUnmuted: () => this.handleSourceUnmuted()
			});
		} catch (error) {
			this.signal?.removeEventListener("abort", onAbort);
			this.handleError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		if (this.isTerminalState()) {
			this.signal?.removeEventListener("abort", onAbort);
			return;
		}
		let apiKey;
		try {
			apiKey = await resolveApiKey(this.apiKeyConfig);
		} catch (error) {
			this.signal?.removeEventListener("abort", onAbort);
			this.source.stop();
			this.handleError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		this.signal?.removeEventListener("abort", onAbort);
		if (this.isTerminalState()) {
			this.source.stop();
			return;
		}
		this.setState("connecting");
		const sessionOptions = { ...this.sessionOptions };
		if (this.signal !== void 0) sessionOptions.signal = this.signal;
		const session = new RealtimeSttSession(apiKey, this.wsBaseUrl, this.sttConfig, sessionOptions);
		this.session = session;
		this.wireSessionEvents(session);
		try {
			await session.connect();
		} catch (error) {
			this.source.stop();
			this.handleError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		if (this.isTerminalState()) {
			session.close();
			return;
		}
		const stoppingEarly = this._state === "stopping";
		if (!stoppingEarly) {
			this.setState("recording");
			this.emitter.emit("connected");
		}
		this.isBuffering = false;
		for (const chunk of this.audioBuffer) {
			if (this._state !== "recording" && this._state !== "stopping") break;
			session.sendAudio(chunk);
		}
		this.audioBuffer = [];
		if (stoppingEarly) try {
			await session.finish();
		} catch (err) {
			const error = err instanceof Error ? err : new Error(String(err));
			this.settleStop(error);
			this.cleanup("error");
		}
	}
	handleAudioData(chunk) {
		if (this.isBuffering) {
			if (this.audioBuffer.length >= this.maxBufferSize) {
				this.handleError(/* @__PURE__ */ new Error("Audio buffer queue size exceeded before connection was established"));
				return;
			}
			this.audioBuffer.push(chunk);
			return;
		}
		if (this.session && (this._state === "recording" || this._state === "stopping")) try {
			this.session.sendAudio(chunk);
		} catch {}
	}
	handleSourceMuted() {
		if (this._state !== "recording" && this._state !== "paused") return;
		this._isSourceMuted = true;
		if (this._state === "recording") this.session?.pause();
		this.emitter.emit("source_muted");
	}
	handleSourceUnmuted() {
		if (this._state !== "recording" && this._state !== "paused") return;
		this._isSourceMuted = false;
		if (this._state === "recording") this.session?.resume();
		this.emitter.emit("source_unmuted");
	}
	wireSessionEvents(session) {
		session.on("result", (result) => this.emitter.emit("result", result));
		session.on("token", (token) => this.emitter.emit("token", token));
		session.on("endpoint", () => this.emitter.emit("endpoint"));
		session.on("finalized", () => this.emitter.emit("finalized"));
		session.on("finished", () => {
			this.source.stop();
			this.emitter.emit("finished");
			this.settleStop();
			this.cleanup("stopped");
		});
		session.on("error", (error) => {
			this.handleError(error);
		});
	}
	handleAbort() {
		if (this.isTerminalState()) return;
		this.source.stop();
		this.session?.close();
		const error = /* @__PURE__ */ new Error("Recording aborted");
		this.emitter.emit("error", error);
		this.settleStop(error);
		this.cleanup("canceled");
	}
	handleError(error) {
		if (this._state === "error" || this._state === "stopped" || this._state === "canceled") return;
		this.source.stop();
		this.session?.close();
		this.emitter.emit("error", error);
		this.settleStop(error);
		this.cleanup("error");
	}
	cleanup(finalState) {
		this.setState(finalState);
		this.audioBuffer = [];
		this.isBuffering = false;
		this._isSourceMuted = false;
	}
	setState(newState) {
		if (this._state === newState) return;
		const oldState = this._state;
		this._state = newState;
		this.emitter.emit("state_change", {
			old_state: oldState,
			new_state: newState
		});
	}
	isTerminalState() {
		return TERMINAL_STATES.includes(this._state);
	}
	settleStop(error) {
		const resolve = this.stopResolver;
		const reject = this.stopRejecter;
		this.stopResolver = null;
		this.stopRejecter = null;
		if (error) reject?.(error);
		else resolve?.();
	}
};
/**
* SonioxClient - main entry point for the @soniox/client SDK
*
* Provides high-level `record()` for audio capture + transcription,
* and low-level `stt()` for direct WebSocket session access
*/
var SONIOX_WS_URL = "wss://stt-rt.soniox.com/transcribe-websocket";
/**
* Main entry point for the Soniox client SDK.
*
* @example
* ```typescript
* const client = new SonioxClient({
*   api_key: async () => {
*     const res = await fetch('/api/get-temporary-key', { method: 'POST' });
*     return (await res.json()).api_key;
*   },
* });
*
* // High-level: record from microphone
* const recording = client.realtime.record({ model: 'stt-rt-v4' });
* recording.on('result', (r) => console.log(r.tokens));
* await recording.stop();
*
* // Low-level: direct session access
* const session = client.realtime.stt({ model: 'stt-rt-v4' }, { api_key: key });
* await session.connect();
* ```
*/
var SonioxClient = class {
	apiKeyConfig;
	wsBaseUrl;
	permissionResolver;
	defaultBufferQueueSize;
	defaultSessionOptions;
	/**
	* Real-time API namespace
	*/
	realtime;
	constructor(options) {
		this.apiKeyConfig = options.api_key;
		this.wsBaseUrl = options.ws_base_url ?? SONIOX_WS_URL;
		this.permissionResolver = options.permissions;
		this.defaultBufferQueueSize = options.buffer_queue_size ?? 1e3;
		this.defaultSessionOptions = options.default_session_options;
		this.realtime = {
			record: (recordOptions) => this.createRecording(recordOptions),
			stt: (config, sttOptions) => this.createSession(config, sttOptions)
		};
	}
	/**
	* Permission resolver, if configured.
	* Returns `undefined` if no resolver was provided (SSR-safe).
	*
	* @example
	* ```typescript
	* const mic = await client.permissions?.check('microphone');
	* if (mic?.status === 'denied') {
	*   showSettingsMessage();
	* }
	* ```
	*/
	get permissions() {
		return this.permissionResolver;
	}
	createRecording(options) {
		const { source, signal, buffer_queue_size, session_options, ...sttConfig } = options;
		const audioSource = source ?? new MicrophoneSource();
		return new Recording(this.apiKeyConfig, this.wsBaseUrl, sttConfig, audioSource, {
			buffer_queue_size: buffer_queue_size ?? this.defaultBufferQueueSize,
			session_options: {
				...this.defaultSessionOptions,
				...session_options,
				...signal !== void 0 ? { signal } : {}
			},
			...signal !== void 0 ? { signal } : {}
		});
	}
	createSession(config, options) {
		const mergedSessionOptions = {
			...this.defaultSessionOptions,
			...options.session_options
		};
		return new RealtimeSttSession(options.api_key, this.wsBaseUrl, config, mergedSessionOptions);
	}
};
/**
* Browser permission resolver for checking and requesting microphone access.
*
* @example
* ```typescript
* const resolver = new BrowserPermissionResolver();
* const mic = await resolver.check('microphone');
* if (mic.status === 'prompt') {
*   const result = await resolver.request('microphone');
*   if (result.status === 'denied') {
*     showDeniedMessage();
*   }
* }
* ```
*/
var BrowserPermissionResolver = class {
	/**
	* Check current microphone permission status without prompting the user.
	*/
	async check(permission) {
		if (permission === "microphone") return this.checkMicrophone();
		return {
			status: "unavailable",
			can_request: false
		};
	}
	/**
	* Request microphone permission from the user.
	* This may show a browser permission prompt.
	*/
	async request(permission) {
		if (permission === "microphone") return this.requestMicrophone();
		return {
			status: "unavailable",
			can_request: false
		};
	}
	async checkMicrophone() {
		if (typeof navigator !== "undefined" && navigator.permissions?.query) try {
			const result = await navigator.permissions.query({ name: "microphone" });
			return {
				status: result.state === "prompt" ? "prompt" : result.state,
				can_request: result.state !== "denied"
			};
		} catch {}
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) return {
			status: "unavailable",
			can_request: false
		};
		return {
			status: "prompt",
			can_request: true
		};
	}
	async requestMicrophone() {
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) return {
			status: "unavailable",
			can_request: false
		};
		try {
			(await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((track) => track.stop());
			return {
				status: "granted",
				can_request: true
			};
		} catch (err) {
			if (err instanceof DOMException) {
				if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") return {
					status: "denied",
					can_request: false
				};
				if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") return {
					status: "unavailable",
					can_request: false
				};
			}
			return {
				status: "denied",
				can_request: false
			};
		}
	}
};
//#endregion
//#region src/audio/mixed-audio-source.ts
var TIMESLICE_MS = 60;
var MIC_CONSTRAINTS = {
	echoCancellation: true,
	noiseSuppression: true,
	autoGainControl: true,
	channelCount: 1
};
/**
* AudioSource that merges tab audio (getDisplayMedia) and microphone
* (getUserMedia) into a single stream using the Web Audio API.
*
* Tab audio always starts first. Microphone is best-effort: if it
* fails (no hardware, permission denied), only tab audio feeds the
* mixer and no error is surfaced to the caller.
*
* The mic can be added or removed at any time via `setMicEnabled()`
* without restarting the Soniox session or tab capture.
*/
var MixedAudioSource = class {
	audioCtx = null;
	dest = null;
	tabStream = null;
	tabNode = null;
	micStream = null;
	micNode = null;
	recorder = null;
	active = false;
	micEnabled;
	micMuted = false;
	constructor(options) {
		this.micEnabled = options?.includeMic ?? false;
	}
	getAudioContext() {
		return this.audioCtx;
	}
	async start(handlers) {
		this.active = true;
		try {
			await this.ensureTabStream(handlers);
			this.ensureMixer();
			if (this.micEnabled) await this.ensureMic();
			else this.releaseMic();
			const outputStream = this.dest?.stream ?? this.tabStream;
			if (!outputStream) throw new Error("No audio stream available to start recording");
			this.recorder = new MediaRecorder(outputStream);
			this.recorder.ondataavailable = (event) => {
				if (!this.active || event.data.size === 0) return;
				event.data.arrayBuffer().then((buf) => {
					if (this.active) handlers.onData(buf);
				});
			};
			this.recorder.onerror = () => {
				if (this.active) handlers.onError(/* @__PURE__ */ new Error("Mixed audio capture recorder error"));
			};
			this.recorder.start(TIMESLICE_MS);
			console.log("[MixedAudio] Recording started —", this.micStream ? "tab + mic" : "tab only");
		} catch (err) {
			console.error("[MixedAudio] Failed to start:", err);
			this.releaseAll();
			throw err;
		}
	}
	/**
	* Temporarily mute mic in the mixer without releasing the stream.
	* Used for echo suppression: prevents TTS/Realtime audio picked up
	* by the mic from being sent to Soniox. Tab audio continues flowing.
	*/
	muteMicInput() {
		if (this.micMuted) return;
		this.micMuted = true;
		if (this.micNode) try {
			this.micNode.disconnect();
		} catch {}
		console.log("[MixedAudio] Mic muted in mixer (echo suppression)");
	}
	unmuteMicInput() {
		if (!this.micMuted) return;
		this.micMuted = false;
		if (this.micNode && this.dest) this.micNode.connect(this.dest);
		console.log("[MixedAudio] Mic unmuted in mixer");
	}
	/**
	* Hot-switch microphone on/off while recording continues.
	* Safe to call at any time; no-ops if not currently active.
	*/
	async setMicEnabled(enabled) {
		this.micEnabled = enabled;
		if (enabled) {
			if (this.active && !this.hasLiveAudioTrack(this.micStream)) await this.ensureMic();
		} else this.releaseMic();
		if (this.active) console.log("[MixedAudio] Mic toggled —", this.micStream ? "tab + mic" : "tab only");
	}
	stop() {
		this.active = false;
		this.releaseRecorder();
		this.releaseMic();
	}
	pause() {
		if (this.recorder?.state === "recording") this.recorder.pause();
	}
	resume() {
		if (this.recorder?.state === "paused") this.recorder.resume();
	}
	dispose() {
		this.active = false;
		this.releaseAll();
	}
	async ensureTabStream(handlers) {
		if (this.hasLiveAudioTrack(this.tabStream)) return;
		this.releaseTabStream();
		this.tabStream = await navigator.mediaDevices.getDisplayMedia({
			audio: true,
			video: true,
			preferCurrentTab: true
		});
		for (const vt of this.tabStream.getVideoTracks()) vt.stop();
		if (!this.hasLiveAudioTrack(this.tabStream)) throw new Error("getDisplayMedia returned no audio tracks");
		this.tabStream.getAudioTracks()[0].addEventListener("ended", () => {
			if (this.active) {
				console.warn("[MixedAudio] Tab audio sharing stopped by user");
				handlers.onError(/* @__PURE__ */ new Error("Tab audio sharing was stopped"));
			}
		});
	}
	/**
	* Ensure AudioContext + destination exist so we can always route
	* through the mixer (even tab-only). This lets us hot-add mic later.
	*/
	ensureMixer() {
		if (!this.audioCtx) this.audioCtx = new AudioContext();
		if (!this.dest) this.dest = this.audioCtx.createMediaStreamDestination();
		if (this.tabStream && !this.tabNode) {
			this.tabNode = this.audioCtx.createMediaStreamSource(this.tabStream);
			this.tabNode.connect(this.dest);
		}
	}
	async ensureMic() {
		if (this.hasLiveAudioTrack(this.micStream)) return;
		try {
			this.releaseMic();
			this.micStream = await navigator.mediaDevices.getUserMedia({ audio: MIC_CONSTRAINTS });
			this.ensureMixer();
			if (this.audioCtx && this.dest) {
				this.micNode = this.audioCtx.createMediaStreamSource(this.micStream);
				if (!this.micMuted) this.micNode.connect(this.dest);
			}
			console.log("[MixedAudio] Microphone added to mix", this.micMuted ? "(muted for echo suppression)" : "");
		} catch (micErr) {
			console.warn("[MixedAudio] Microphone unavailable, continuing with tab audio only:", micErr);
			this.micStream = null;
			this.micNode = null;
		}
	}
	releaseMic() {
		if (this.micNode) {
			try {
				this.micNode.disconnect();
			} catch {}
			this.micNode = null;
		}
		if (this.micStream) {
			for (const t of this.micStream.getTracks()) t.stop();
			this.micStream = null;
		}
	}
	releaseTabStream() {
		if (this.tabNode) {
			try {
				this.tabNode.disconnect();
			} catch {}
			this.tabNode = null;
		}
		if (this.tabStream) {
			for (const t of this.tabStream.getTracks()) t.stop();
			this.tabStream = null;
		}
	}
	releaseRecorder() {
		if (this.recorder) {
			try {
				if (this.recorder.state !== "inactive") this.recorder.stop();
			} catch {}
			this.recorder = null;
		}
	}
	hasLiveAudioTrack(stream) {
		if (!stream) return false;
		return stream.getAudioTracks().some((track) => track.readyState === "live");
	}
	releaseAll() {
		this.releaseRecorder();
		this.releaseMic();
		this.releaseTabStream();
		if (this.audioCtx) {
			try {
				this.audioCtx.close();
			} catch {}
			this.audioCtx = null;
		}
		this.dest = null;
		this.micMuted = false;
	}
};
//#endregion
//#region src/composables/useSoniox.ts
function useSoniox() {
	const state = ref("idle");
	const error = ref(null);
	let client = null;
	let recording = null;
	let audioSource = null;
	let currentApiKey = null;
	function createClient(apiKey) {
		return new SonioxClient({
			api_key: apiKey,
			permissions: new BrowserPermissionResolver()
		});
	}
	function ensureClient(apiKey) {
		if (!client || currentApiKey !== apiKey) {
			client = createClient(apiKey);
			currentApiKey = apiKey;
		}
		return client;
	}
	function ensureAudioSource(useMicrophone) {
		if (!audioSource) audioSource = new MixedAudioSource({ includeMic: useMicrophone });
		return audioSource;
	}
	function buildTranslationConfig(targetLanguage, theirLanguage) {
		if (theirLanguage && theirLanguage !== "none" && theirLanguage !== targetLanguage) return {
			type: "two_way",
			language_a: theirLanguage,
			language_b: targetLanguage
		};
		return {
			type: "one_way",
			target_language: targetLanguage
		};
	}
	function startRecording(apiKey, targetLanguage, callbacks = {}, useMicrophone = false, theirLanguage, context) {
		if (recording) try {
			recording.cancel();
		} catch {} finally {
			recording = null;
		}
		error.value = null;
		state.value = "starting";
		try {
			const sonioxClient = ensureClient(apiKey);
			const source = ensureAudioSource(useMicrophone);
			source.setMicEnabled(useMicrophone);
			const translation = buildTranslationConfig(targetLanguage, theirLanguage);
			console.info("[Soniox] translation config:", JSON.stringify(translation));
			if (context) console.info("[Soniox] context config:", JSON.stringify(context));
			const recordOptions = {
				model: "stt-rt-v4",
				translation,
				enable_speaker_diarization: true,
				enable_endpoint_detection: true,
				max_endpoint_delay_ms: 1500,
				language_hints: theirLanguage !== "none" ? [targetLanguage, theirLanguage] : [targetLanguage],
				source
			};
			if (context) recordOptions.context = context;
			recording = sonioxClient.realtime.record(recordOptions);
			recording.on("result", (result) => {
				const mapped = { tokens: result.tokens.map((t) => ({
					text: t.text,
					is_final: t.is_final,
					translation_status: t.translation_status,
					source_language: t.source_language,
					language: t.language,
					speaker: t.speaker
				})) };
				callbacks.onResult?.(mapped);
			});
			recording.on("endpoint", () => {
				console.debug("[Soniox] endpoint event");
				callbacks.onEndpoint?.();
			});
			recording.on("finalized", () => {
				console.debug("[Soniox] finalized event");
				callbacks.onFinalized?.();
			});
			recording.on("error", (err) => {
				console.error("[Soniox] error event:", err.message);
				error.value = resolveErrorMessage(err);
				state.value = "error";
				callbacks.onError?.(err);
			});
			recording.on("state_change", ({ old_state, new_state }) => {
				console.debug("[Soniox] state_change:", old_state, "->", new_state);
				state.value = new_state;
				callbacks.onStateChange?.(old_state, new_state);
			});
		} catch (err) {
			error.value = err instanceof Error ? err.message : "Failed to start recording";
			state.value = "error";
		}
	}
	async function stopRecording() {
		if (!recording) return;
		state.value = "stopping";
		try {
			await recording.stop();
		} catch {} finally {
			recording = null;
			state.value = "stopped";
		}
	}
	function cancelRecording() {
		if (!recording) return;
		try {
			recording.cancel();
		} catch {}
		recording = null;
		state.value = "canceled";
	}
	function pauseRecording() {
		if (!recording || !audioSource) return;
		audioSource.pause();
		state.value = "paused";
	}
	function resumeRecording() {
		if (!recording || !audioSource) return;
		audioSource.resume();
		state.value = "recording";
	}
	function cleanup() {
		if (recording) {
			try {
				recording.cancel();
			} catch {}
			recording = null;
		}
		if (audioSource) {
			audioSource.dispose();
			audioSource = null;
		}
		client = null;
		currentApiKey = null;
	}
	async function setMicEnabled(enabled) {
		if (audioSource) await audioSource.setMicEnabled(enabled);
	}
	async function checkPermission() {
		if (!client) return "prompt";
		try {
			return (await client.permissions?.check("microphone"))?.status ?? "prompt";
		} catch {
			return "unavailable";
		}
	}
	async function requestPermission() {
		if (!client) return false;
		try {
			return (await client.permissions?.request("microphone"))?.status === "granted";
		} catch {
			return false;
		}
	}
	function resolveErrorMessage(err) {
		const msg = err.message.toLowerCase();
		if (msg.includes("api_key") || msg.includes("unauthorized") || msg.includes("401")) return "Invalid API key. Please check your API key and try again.";
		if (msg.includes("permission") || msg.includes("notallowed")) return "Microphone access denied. Please allow microphone access in browser settings.";
		if (msg.includes("notfound") || msg.includes("no device")) return "No microphone found. Please connect a microphone and try again.";
		if (msg.includes("no audio received")) return "No audio received from current input device. Please check microphone/input source and restart translation.";
		if (msg.includes("audio device recovery failed")) return "Audio device changed and automatic recovery failed. Please stop and restart translation.";
		if (msg.includes("network") || msg.includes("websocket") || msg.includes("connection")) return "Connection lost. Please check your internet connection.";
		return err.message || "Translation service error. Please try again.";
	}
	onUnmounted(() => {
		cleanup();
	});
	function pauseCapture() {
		audioSource?.pause();
	}
	function resumeCapture() {
		audioSource?.resume();
	}
	function muteMicInMixer() {
		audioSource?.muteMicInput();
	}
	function unmuteMicInMixer() {
		audioSource?.unmuteMicInput();
	}
	return {
		state,
		error,
		startRecording,
		stopRecording,
		cancelRecording,
		pauseRecording,
		resumeRecording,
		setMicEnabled,
		pauseCapture,
		resumeCapture,
		muteMicInMixer,
		unmuteMicInMixer,
		cleanup,
		checkPermission,
		requestPermission
	};
}
//#endregion
//#region src/services/openai-tts-client.ts
var OpenAITTSClient = class {
	baseUrl = "https://api.openai.com/v1/audio/speech";
	apiKey;
	constructor(apiKey) {
		this.apiKey = apiKey;
	}
	setApiKey(apiKey) {
		this.apiKey = apiKey;
	}
	async synthesize(request, signal) {
		if (!this.apiKey) throw new Error("OpenAI API key is not configured");
		const body = {
			model: request.model,
			input: request.input,
			voice: request.voice,
			response_format: request.responseFormat ?? "mp3"
		};
		if (request.speed !== void 0) body.speed = request.speed;
		if (request.instructions) body.instructions = request.instructions;
		console.log("[TTS:API] POST", this.baseUrl, "— model:", request.model, "voice:", request.voice, "input length:", request.input.length);
		const response = await fetch(this.baseUrl, {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${this.apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body),
			signal: signal ?? null
		});
		if (!response.ok) {
			const errorText = await response.text().catch(() => "Unknown error");
			console.error("[TTS:API] Error response:", response.status, errorText);
			throw new TTSApiError(response.status, errorText);
		}
		const blob = await response.blob();
		console.log("[TTS:API] Success — blob size:", blob.size, "type:", blob.type);
		return blob;
	}
};
var TTSApiError = class extends Error {
	constructor(status, body) {
		const message = resolveApiErrorMessage$2(status, body);
		super(message);
		this.status = status;
		this.body = body;
		this.name = "TTSApiError";
	}
};
function resolveApiErrorMessage$2(status, body) {
	if (status === 401) return "Invalid OpenAI API key. Please check your key and try again.";
	if (status === 429) return "OpenAI rate limit reached. Please wait a moment and try again.";
	if (status >= 500) return "OpenAI service error. Please try again later.";
	try {
		return JSON.parse(body).error?.message ?? `OpenAI TTS error (${status})`;
	} catch {
		return `OpenAI TTS error (${status})`;
	}
}
//#endregion
//#region src/services/google-translate-tts-client.ts
/**
* Google Translate TTS client using the undocumented batchexecute API.
*
* Reverse-engineered from the Read Aloud extension. Uses the jQ1olc RPC
* to synthesize speech via translate.google.com and returns base64 MP3.
*
* Requires host_permissions for https://translate.google.com/ in manifest.
*
* CAVEAT: This relies on undocumented Google internals that can change
* without notice, similar to how Read Aloud handles it.
*/
var LOG$3 = "[GoogleTranslateTTS]";
var BASE_URL = "https://translate.google.com";
var WIZ_CACHE_TTL_MS = 3600 * 1e3;
var WIZ_FETCH_TIMEOUT_MS = 7500;
var cachedWiz = null;
var wizFetchPromise = null;
var batchNumber = 0;
function urlEncode(params) {
	return Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
}
async function fetchWizGlobalData() {
	console.log(LOG$3, "Fetching wiz tokens from", BASE_URL);
	const res = await fetch(BASE_URL);
	if (!res.ok) throw new Error(`Failed to fetch translate.google.com: ${res.status}`);
	const html = await res.text();
	const start = html.indexOf("WIZ_global_data = {");
	if (start === -1) throw new Error("WIZ_global_data not found in Google Translate page");
	const end = html.indexOf("<\/script>", start);
	const text = html.substring(start, end);
	const propFinders = {
		"f.sid": /"FdrFJe":"(.*?)"/,
		bl: /"cfb2h":"(.*?)"/,
		at: /"SNlM0e":"(.*?)"/
	};
	const wiz = { expire: Date.now() + WIZ_CACHE_TTL_MS };
	for (const [prop, regex] of Object.entries(propFinders)) {
		const match = regex.exec(text);
		if (match) wiz[prop] = match[1];
		else console.warn(LOG$3, `Wiz property not found: ${prop}`);
	}
	console.log(LOG$3, "Wiz tokens fetched, expires in 1h");
	return wiz;
}
async function getWiz() {
	if (cachedWiz && cachedWiz.expire > Date.now()) return cachedWiz;
	if (wizFetchPromise) return wizFetchPromise;
	wizFetchPromise = fetchWizGlobalData().then((wiz) => {
		cachedWiz = wiz;
		wizFetchPromise = null;
		return wiz;
	}).catch((err) => {
		wizFetchPromise = null;
		throw err;
	});
	const timeoutPromise = new Promise((_, reject) => {
		setTimeout(() => reject(/* @__PURE__ */ new Error("Wiz fetch timeout")), WIZ_FETCH_TIMEOUT_MS);
	});
	return Promise.race([wizFetchPromise, timeoutPromise]);
}
function getBatchExecuteParams(wiz, rpcId, payload) {
	return {
		query: {
			rpcids: rpcId,
			"f.sid": wiz["f.sid"] ?? "",
			bl: wiz.bl ?? "",
			hl: "en",
			"soc-app": 1,
			"soc-platform": 1,
			"soc-device": 1,
			_reqid: ++batchNumber * 1e5 + Math.floor(1e3 + Math.random() * 8e3),
			rt: "c"
		},
		body: {
			"f.req": JSON.stringify([[[
				rpcId,
				JSON.stringify(payload),
				null,
				"generic"
			]]]),
			...wiz.at ? { at: wiz.at } : {}
		}
	};
}
async function batchExecute(rpcId, payload) {
	const { query, body } = getBatchExecuteParams(await getWiz(), rpcId, payload);
	const res = await fetch(`${BASE_URL}/_/TranslateWebserverUi/data/batchexecute?${urlEncode(query)}`, {
		method: "POST",
		headers: { "Content-Type": "application/x-www-form-urlencoded" },
		body: urlEncode(body)
	});
	if (!res.ok) {
		if (res.status === 403 || res.status === 429) invalidateWizCache();
		throw new Error(`Google Translate batchexecute failed (${res.status})`);
	}
	const text = await res.text();
	const match = text.match(/\d+/);
	if (!match || match.index === void 0) throw new Error("Invalid batchexecute response format");
	const innerPayload = JSON.parse(text.substring(match.index + match[0].length, match.index + match[0].length + Number(match[0])))[0][2];
	return JSON.parse(innerPayload);
}
async function googleTranslateSynthesizeSpeech(text, lang, signal) {
	if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
	console.log(LOG$3, "Synthesize:", lang, "text length:", text.length);
	const audio = (await batchExecute("jQ1olc", [
		text,
		lang,
		null
	]))?.[0];
	if (!audio || typeof audio !== "string") throw new Error(`Google Translate TTS failed for "${text.slice(0, 25)}…" in ${lang}`);
	return `data:audio/mpeg;base64,${audio}`;
}
async function googleTranslateSynthesizeBlob(text, lang, signal) {
	const base64 = (await googleTranslateSynthesizeSpeech(text, lang, signal)).split(",")[1] ?? "";
	const binary = atob(base64);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	return new Blob([bytes], { type: "audio/mpeg" });
}
function invalidateWizCache() {
	cachedWiz = null;
	wizFetchPromise = null;
}
//#endregion
//#region src/audio/tts-audio-player.ts
/**
* Plays TTS audio blobs.
*
* Preferred path: background offscreen document (isolated from current tab
* audio capture, prevents Soniox duplicate capture).
*
* Fallback path: local <audio> playback (used in test/non-extension env).
*/
var TTSAudioPlayer = class {
	audio = null;
	currentBlobUrl = null;
	handlers = /* @__PURE__ */ new Map();
	_isSpeaking = false;
	offscreenPlaybackId = 0;
	_volume = 1;
	_playbackRate = 1;
	get isSpeaking() {
		return this._isSpeaking;
	}
	setVolume(volume) {
		this._volume = Math.max(0, Math.min(1, volume));
		if (this.audio) this.audio.volume = this._volume;
		if (this.canUseRuntimeMessaging()) this.sendRuntimeMessage({
			type: "tts.setVolume",
			volume: this._volume
		}).catch(() => {});
	}
	setPlaybackRate(rate) {
		this._playbackRate = Math.max(.25, Math.min(4, rate));
		if (this.audio) this.audio.playbackRate = this._playbackRate;
		if (this.canUseRuntimeMessaging()) this.sendRuntimeMessage({
			type: "tts.setPlaybackRate",
			playbackRate: this._playbackRate
		}).catch(() => {});
	}
	on(event, handler) {
		if (!this.handlers.has(event)) this.handlers.set(event, /* @__PURE__ */ new Set());
		this.handlers.get(event).add(handler);
	}
	off(event, handler) {
		this.handlers.get(event)?.delete(handler);
	}
	async play(audioBlob) {
		this.stop();
		if (this.canUseRuntimeMessaging()) {
			await this.playViaOffscreen(audioBlob);
			return;
		}
		await this.playLocally(audioBlob);
	}
	stop() {
		this.offscreenPlaybackId += 1;
		if (this.canUseRuntimeMessaging()) this.sendRuntimeMessage({ type: "tts.stop" }).catch((err) => {
			const msg = err instanceof Error ? err.message : String(err);
			console.warn("[TTS:Player] Failed to stop offscreen playback:", msg);
		});
		const audio = this.audio;
		if (audio) {
			audio.onplay = null;
			audio.onended = null;
			audio.onerror = null;
			audio.pause();
			this.audio = null;
		}
		if (this._isSpeaking) {
			this._isSpeaking = false;
			this.emit("end");
		}
		this.revokeBlobUrl();
	}
	dispose() {
		this.stop();
		this.handlers.clear();
	}
	async playViaOffscreen(audioBlob) {
		const playbackId = ++this.offscreenPlaybackId;
		const dataUrl = await this.blobToDataUrl(audioBlob);
		this._isSpeaking = true;
		this.emit("start");
		console.log("[TTS:Player] Playing via offscreen document, bytes:", audioBlob.size, "volume:", this._volume);
		try {
			const response = await this.sendRuntimeMessage({
				type: "tts.play",
				payload: {
					dataUrl,
					volume: this._volume,
					playbackRate: this._playbackRate
				}
			});
			if (playbackId !== this.offscreenPlaybackId) return;
			if (!response?.ok) throw new Error(response?.error ?? "Offscreen playback failed");
			this._isSpeaking = false;
			this.emit("end");
		} catch (err) {
			if (playbackId !== this.offscreenPlaybackId) return;
			const error = err instanceof Error ? err : /* @__PURE__ */ new Error("Offscreen TTS playback failed");
			this._isSpeaking = false;
			this.emit("error", error);
			throw error;
		}
	}
	async playLocally(audioBlob) {
		this.currentBlobUrl = URL.createObjectURL(audioBlob);
		this.audio = new Audio(this.currentBlobUrl);
		this.audio.volume = this._volume;
		this.audio.playbackRate = this._playbackRate;
		return new Promise((resolve, reject) => {
			const audio = this.audio;
			audio.onplay = () => {
				this._isSpeaking = true;
				this.emit("start");
			};
			audio.onended = () => {
				this._isSpeaking = false;
				this.cleanup();
				this.emit("end");
				resolve();
			};
			audio.onerror = () => {
				if (!this.audio || this.audio !== audio) return;
				this._isSpeaking = false;
				const err = /* @__PURE__ */ new Error("TTS audio playback failed");
				this.cleanup();
				this.emit("error", err);
				reject(err);
			};
			audio.play().catch((err) => {
				if (!this.audio || this.audio !== audio) return;
				this._isSpeaking = false;
				const error = err instanceof Error ? err : /* @__PURE__ */ new Error("Failed to play TTS audio");
				this.cleanup();
				this.emit("error", error);
				reject(error);
			});
		});
	}
	cleanup() {
		this.audio = null;
		this.revokeBlobUrl();
	}
	revokeBlobUrl() {
		if (this.currentBlobUrl) {
			URL.revokeObjectURL(this.currentBlobUrl);
			this.currentBlobUrl = null;
		}
	}
	canUseRuntimeMessaging() {
		return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id) && typeof chrome.runtime?.sendMessage === "function";
	}
	async sendRuntimeMessage(message) {
		if (!this.canUseRuntimeMessaging()) return null;
		return await new Promise((resolve, reject) => {
			try {
				chrome.runtime.sendMessage(message, (response) => {
					const runtimeErr = chrome.runtime.lastError;
					if (runtimeErr) {
						reject(new Error(runtimeErr.message));
						return;
					}
					resolve(response ?? null);
				});
			} catch (err) {
				reject(err instanceof Error ? err : /* @__PURE__ */ new Error("Runtime messaging failed"));
			}
		});
	}
	async blobToDataUrl(blob) {
		return await new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.onload = () => {
				const result = reader.result;
				if (typeof result === "string") {
					resolve(result);
					return;
				}
				reject(/* @__PURE__ */ new Error("Failed to convert TTS blob to data URL"));
			};
			reader.onerror = () => {
				reject(/* @__PURE__ */ new Error("Failed to read TTS blob"));
			};
			reader.readAsDataURL(blob);
		});
	}
	emit(event, error) {
		const handlers = this.handlers.get(event);
		if (handlers) for (const handler of handlers) try {
			handler(error);
		} catch {}
	}
};
//#endregion
//#region src/composables/useTTS.ts
var MAX_QUEUE_SIZE = 5;
/**
* Auto-sync: if the total backlog (pending synthesis + pending playback)
* exceeds this threshold, speed is boosted to drain the queue faster.
*/
var AUTO_SYNC_THRESHOLD = 1;
var AUTO_SYNC_BOOST_PER_ITEM = .35;
var AUTO_SYNC_WAIT_BOOST_PER_3S = .28;
var AUTO_SYNC_BASE_BACKLOG_BOOST = .15;
var AUTO_SYNC_MIN_EFFECTIVE_SPEED = 1.5;
var MAX_API_SPEED = 4;
var MIN_API_SPEED = .8;
var DURATION_SYNC_FAST_THRESHOLD = 1.04;
var DURATION_SYNC_SLOW_THRESHOLD = .85;
var BROWSER_CHROME_VOICE_PREFIX$1 = "chrome__";
var BROWSER_SPEECH_VOICE_PREFIX$1 = "speech__";
var BROWSER_VOICE_CACHE_TTL_MS = 6e4;
var langCodeToName$1 = new Map(SUPPORTED_LANGUAGES.map((l) => [l.value, l.label]));
function useTTS() {
	const isSpeaking = ref(false);
	const isEnabled = ref(false);
	const error = ref(null);
	const queueLength = ref(0);
	const effectiveSpeed = ref(1.5);
	let client = null;
	let player = null;
	let queue = [];
	const playbackQueue = [];
	let abortController = null;
	let callbacks = {};
	let playbackRunning = false;
	let browserActiveUtterances = 0;
	let currentModel = "gpt-4o-mini-tts";
	let currentVoice = "coral";
	let currentSpeed = 1.5;
	let currentVolume = 1;
	let autoSyncEnabled = true;
	let currentProvider = "openai";
	let currentGoogleVoiceId = "en";
	let currentBrowserVoiceId = TTS_BROWSER_DEFAULT_VOICE_ID;
	let chromeVoicesCache = null;
	let chromeVoicesCachedAt = 0;
	let speechVoicesCache = null;
	let speechVoicesCachedAt = 0;
	let cachedBrowserVoiceName;
	let cachedSpeechSynthVoice = null;
	let browserVoiceCacheKey = "";
	function ensureClient(apiKey) {
		if (!client) client = new OpenAITTSClient(apiKey);
		else client.setApiKey(apiKey);
		return client;
	}
	function ensurePlayer() {
		if (!player) {
			player = new TTSAudioPlayer();
			player.on("start", () => {
				isSpeaking.value = true;
				callbacks.onSpeakStart?.();
			});
			player.on("end", () => {
				isSpeaking.value = false;
				callbacks.onSpeakEnd?.();
			});
			player.on("error", (err) => {
				isSpeaking.value = false;
				if (err) {
					error.value = err.message;
					callbacks.onError?.(err);
				}
			});
		}
		player.setVolume(currentVolume);
		return player;
	}
	function getPlaybackRateForProvider(provider, speed) {
		if (provider !== "google") return 1;
		return Math.max(MIN_API_SPEED, Math.min(MAX_API_SPEED, speed));
	}
	function estimateSpeechDurationMs(text, speed) {
		const normalized = text.trim();
		if (!normalized) return 0;
		const words = normalized.split(/\s+/).filter(Boolean).length;
		const punctuationPauses = (normalized.match(/[,.!?;:]/g) ?? []).length;
		const cjkChars = (normalized.match(/[\u3040-\u30ff\u3400-\u9fff\uf900-\ufaff]/g) ?? []).length;
		const latinChars = (normalized.match(/[A-Za-z0-9]/g) ?? []).length;
		let baseDurationMs = 0;
		if (words > 0) baseDurationMs += words * 280;
		else if (cjkChars > 0) baseDurationMs += cjkChars * 210;
		else baseDurationMs += Math.max(latinChars, normalized.length) * 55;
		baseDurationMs += punctuationPauses * 110;
		baseDurationMs = Math.max(450, baseDurationMs);
		const normalizedSpeed = Math.max(MIN_API_SPEED, speed);
		return Math.round(baseDurationMs / normalizedSpeed);
	}
	function clampSpeed(speed) {
		return Math.max(MIN_API_SPEED, Math.min(MAX_API_SPEED, speed));
	}
	function decodeBrowserVoiceId(browserVoiceId) {
		if (browserVoiceId.startsWith(BROWSER_CHROME_VOICE_PREFIX$1)) return {
			source: "chrome",
			value: decodeURIComponent(browserVoiceId.slice(8))
		};
		if (browserVoiceId.startsWith(BROWSER_SPEECH_VOICE_PREFIX$1)) return {
			source: "speech",
			value: decodeURIComponent(browserVoiceId.slice(8))
		};
		return {
			source: "default",
			value: null
		};
	}
	function canUseChromeTts() {
		return typeof chrome !== "undefined" && typeof chrome.tts?.speak === "function" && typeof chrome.tts?.getVoices === "function";
	}
	async function getChromeVoices() {
		if (!canUseChromeTts()) return [];
		if (chromeVoicesCache && Date.now() - chromeVoicesCachedAt < BROWSER_VOICE_CACHE_TTL_MS) return chromeVoicesCache;
		return await new Promise((resolve) => {
			chrome.tts.getVoices((voices) => {
				if (chrome.runtime?.lastError) {
					resolve([]);
					return;
				}
				const normalized = Array.isArray(voices) ? voices : [];
				chromeVoicesCache = normalized;
				chromeVoicesCachedAt = Date.now();
				resolve(normalized);
			});
		});
	}
	async function resolveChromeVoiceName(language, browserVoiceId) {
		const voices = await getChromeVoices();
		if (voices.length === 0) return void 0;
		const decoded = decodeBrowserVoiceId(browserVoiceId);
		if (decoded.source === "chrome" && decoded.value) {
			const exact = voices.find((voice) => voice.voiceName === decoded.value);
			if (exact?.voiceName) return exact.voiceName;
		}
		const languageLower = language.toLowerCase();
		return voices.find((voice) => voice.lang?.toLowerCase().startsWith(languageLower))?.voiceName;
	}
	function speakViaChromeTts(text, language, speed, voiceName) {
		const rate = Math.max(.1, Math.min(10, speed));
		return new Promise((resolve, reject) => {
			let settled = false;
			const finish = (handler) => {
				if (settled) return;
				settled = true;
				handler();
			};
			const options = {
				lang: language,
				rate,
				enqueue: true,
				onEvent: (event) => {
					if (event.type === "error") {
						finish(() => reject(new Error(event.errorMessage || "Chrome TTS failed")));
						return;
					}
					if (event.type === "end" || event.type === "interrupted" || event.type === "cancelled") finish(resolve);
				}
			};
			if (voiceName) options.voiceName = voiceName;
			chrome.tts.speak(text, options);
			if (chrome.runtime?.lastError) finish(() => reject(new Error(chrome.runtime?.lastError?.message || "Chrome TTS failed to start")));
		});
	}
	async function getSpeechSynthesisVoices() {
		if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
		if (speechVoicesCache && Date.now() - speechVoicesCachedAt < BROWSER_VOICE_CACHE_TTL_MS) return speechVoicesCache;
		const synth = window.speechSynthesis;
		const existingVoices = synth.getVoices();
		if (existingVoices.length > 0) {
			speechVoicesCache = existingVoices;
			speechVoicesCachedAt = Date.now();
			return existingVoices;
		}
		return await new Promise((resolve) => {
			let settled = false;
			let timeoutId = 0;
			const finish = () => {
				if (settled) return;
				settled = true;
				clearTimeout(timeoutId);
				synth.removeEventListener?.("voiceschanged", handleVoicesChanged);
				const resolved = synth.getVoices();
				speechVoicesCache = resolved;
				speechVoicesCachedAt = Date.now();
				resolve(resolved);
			};
			const handleVoicesChanged = () => finish();
			timeoutId = window.setTimeout(() => finish(), 1e3);
			synth.addEventListener?.("voiceschanged", handleVoicesChanged);
		});
	}
	function prewarmBrowserVoices() {
		getChromeVoices().catch(() => {});
		getSpeechSynthesisVoices().catch(() => {});
	}
	async function resolveSpeechVoice(language, browserVoiceId) {
		const voices = await getSpeechSynthesisVoices();
		if (voices.length === 0) return null;
		const decoded = decodeBrowserVoiceId(browserVoiceId);
		if (decoded.source === "speech" && decoded.value) {
			const exact = voices.find((voice) => voice.voiceURI === decoded.value);
			if (exact) return exact;
		}
		if (decoded.source === "chrome" && decoded.value) {
			const byName = voices.find((voice) => voice.name === decoded.value);
			if (byName) return byName;
		}
		const languageLower = language.toLowerCase();
		return voices.find((voice) => voice.lang.toLowerCase().startsWith(languageLower)) ?? null;
	}
	async function ensureBrowserVoiceResolved(language) {
		const key = `${currentBrowserVoiceId}|${language}`;
		if (browserVoiceCacheKey === key) return;
		if (canUseChromeTts()) cachedBrowserVoiceName = await resolveChromeVoiceName(language, currentBrowserVoiceId);
		cachedSpeechSynthVoice = await resolveSpeechVoice(language, currentBrowserVoiceId);
		browserVoiceCacheKey = key;
	}
	function speakViaSpeechSynthesis(text, language, speed, voice) {
		if (typeof window === "undefined" || !("speechSynthesis" in window)) return Promise.reject(/* @__PURE__ */ new Error("Browser speech synthesis is unavailable"));
		const synth = window.speechSynthesis;
		const utterance = new SpeechSynthesisUtterance(text);
		utterance.lang = language;
		utterance.rate = Math.max(.1, Math.min(10, speed));
		if (voice) utterance.voice = voice;
		return new Promise((resolve, reject) => {
			let settled = false;
			const finish = (handler) => {
				if (settled) return;
				settled = true;
				handler();
			};
			utterance.onend = () => finish(resolve);
			utterance.onerror = (event) => finish(() => reject(new Error(event.error || "Web Speech API failed")));
			synth.speak(utterance);
		});
	}
	async function speakWithBrowserVoice(text, language, speed) {
		await ensureBrowserVoiceResolved(language);
		if (canUseChromeTts()) try {
			await speakViaChromeTts(text, language, speed, cachedBrowserVoiceName);
			return;
		} catch (error) {
			console.warn("[TTS] Chrome TTS failed, fallback to Web Speech API", error);
		}
		await speakViaSpeechSynthesis(text, language, speed, cachedSpeechSynthVoice);
	}
	async function playBrowserText(text, language, speed) {
		await speakWithBrowserVoice(text, language, speed);
	}
	function stopBrowserPlayback() {
		if (canUseChromeTts()) try {
			chrome.tts.stop();
		} catch {}
		if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
	}
	/**
	* Compute speed for the next synthesis request.
	* Auto-sync combines:
	* - backlog pressure (queue/playback wait)
	* - target segment duration (if provided)
	*/
	function computeEffectiveSpeed(item) {
		if (!autoSyncEnabled) {
			effectiveSpeed.value = currentSpeed;
			return currentSpeed;
		}
		const now = Date.now();
		const backlog = queue.length + playbackQueue.length + (playbackRunning ? 1 : 0) + browserActiveUtterances;
		const oldestPendingAt = [item.timestamp, ...queue.map((q) => q.timestamp)].reduce((min, ts) => Math.min(min, ts), item.timestamp);
		const oldestWaitMs = Math.max(0, now - oldestPendingAt);
		let backlogSpeed = currentSpeed;
		if (backlog >= AUTO_SYNC_THRESHOLD) {
			const backlogBoost = (backlog - AUTO_SYNC_THRESHOLD) * AUTO_SYNC_BOOST_PER_ITEM;
			const waitBoost = Math.min(1, oldestWaitMs / 3e3 * AUTO_SYNC_WAIT_BOOST_PER_3S);
			backlogSpeed = currentSpeed + AUTO_SYNC_BASE_BACKLOG_BOOST + backlogBoost + waitBoost;
		}
		let durationSpeed = currentSpeed;
		if (item.targetDurationMs && item.targetDurationMs > 0) {
			const ratio = estimateSpeechDurationMs(item.text, currentSpeed) / item.targetDurationMs;
			if (ratio >= DURATION_SYNC_FAST_THRESHOLD) durationSpeed = currentSpeed * Math.min(1.8, ratio);
			else if (ratio <= DURATION_SYNC_SLOW_THRESHOLD) durationSpeed = currentSpeed * Math.max(.65, ratio);
		}
		const combinedSpeed = backlogSpeed > currentSpeed ? Math.max(backlogSpeed, durationSpeed) : durationSpeed;
		const result = Math.max(AUTO_SYNC_MIN_EFFECTIVE_SPEED, clampSpeed(combinedSpeed));
		effectiveSpeed.value = result;
		return result;
	}
	function configure(options) {
		if (options.ttsProvider !== void 0) currentProvider = options.ttsProvider;
		if (options.googleVoiceId) currentGoogleVoiceId = options.googleVoiceId;
		if (options.browserVoiceId) {
			if (options.browserVoiceId !== currentBrowserVoiceId) browserVoiceCacheKey = "";
			currentBrowserVoiceId = options.browserVoiceId;
		}
		if (currentProvider === "openai") ensureClient(options.apiKey);
		else if (currentProvider === "browser") prewarmBrowserVoices();
		if (options.model) currentModel = options.model;
		if (options.voice) currentVoice = options.voice;
		if (options.speed !== void 0) currentSpeed = options.speed;
		if (options.volume !== void 0) {
			currentVolume = options.volume;
			player?.setVolume(currentVolume);
		}
		if (options.autoSyncSpeed !== void 0) autoSyncEnabled = options.autoSyncSpeed;
		if (options.callbacks) callbacks = options.callbacks;
		player?.setPlaybackRate(getPlaybackRateForProvider(currentProvider, currentSpeed));
		effectiveSpeed.value = currentSpeed;
	}
	async function speakOnce(options) {
		const text = options.text.trim();
		if (!text) throw new Error("No text provided for TTS preview");
		const volume = options.volume ?? currentVolume;
		const provider = options.ttsProvider ?? currentProvider;
		if (provider === "browser") {
			if (options.browserVoiceId) {
				if (options.browserVoiceId !== currentBrowserVoiceId) browserVoiceCacheKey = "";
				currentBrowserVoiceId = options.browserVoiceId;
			}
			await playBrowserText(text, options.language, options.speed ?? currentSpeed);
			return;
		}
		let blob;
		if (provider === "google") blob = await googleTranslateSynthesizeBlob(text, options.googleVoiceId ?? currentGoogleVoiceId);
		else {
			const previewClient = ensureClient(options.apiKey);
			const languageName = langCodeToName$1.get(options.language) ?? options.language;
			const model = options.model ?? currentModel;
			const voice = options.voice ?? currentVoice;
			const speed = options.speed ?? currentSpeed;
			blob = await previewClient.synthesize({
				input: text,
				model,
				voice,
				responseFormat: "mp3",
				speed,
				instructions: `Speak naturally in ${languageName}. Match the tone and style of the translated text.`
			});
		}
		const previewPlayer = new TTSAudioPlayer();
		previewPlayer.setVolume(volume);
		previewPlayer.setPlaybackRate(getPlaybackRateForProvider(provider, options.speed ?? currentSpeed));
		try {
			await previewPlayer.play(blob);
		} finally {
			previewPlayer.dispose();
		}
	}
	function enqueue(text, language, targetDurationMs) {
		if (!isEnabled.value) return;
		if (!text.trim()) return;
		if (currentProvider === "openai" && !client) return;
		const item = {
			id: crypto.randomUUID(),
			text: text.trim(),
			language,
			timestamp: Date.now()
		};
		if (targetDurationMs !== void 0) item.targetDurationMs = targetDurationMs;
		queue.push(item);
		while (queue.length > MAX_QUEUE_SIZE) queue.shift();
		queueLength.value = queue.length;
		synthesizeNext();
	}
	function synthesizeNext() {
		if (!isEnabled.value) return;
		if (currentProvider === "openai" && !client) return;
		if (currentProvider === "browser" && browserActiveUtterances > 0) return;
		const item = queue.shift();
		if (!item) return;
		queueLength.value = queue.length;
		const speed = computeEffectiveSpeed(item);
		if (currentProvider === "browser") {
			let fullText = item.text;
			while (queue.length > 0) fullText += " " + queue.shift().text;
			queueLength.value = queue.length;
			browserActiveUtterances += 1;
			if (browserActiveUtterances === 1) {
				isSpeaking.value = true;
				callbacks.onSpeakStart?.();
			}
			playBrowserText(fullText, item.language, speed).catch((err) => {
				const message = err instanceof Error ? err.message : "Browser TTS failed";
				console.error("[TTS] Browser playback error:", message);
				error.value = message;
				callbacks.onError?.(err instanceof Error ? err : new Error(message));
			}).finally(() => {
				browserActiveUtterances = Math.max(0, browserActiveUtterances - 1);
				if (browserActiveUtterances === 0 && queue.length === 0) {
					isSpeaking.value = false;
					callbacks.onSpeakEnd?.();
				}
				synthesizeNext();
			});
			return;
		}
		const ac = new AbortController();
		abortController = ac;
		(currentProvider === "google" ? googleTranslateSynthesizeBlob(item.text, currentGoogleVoiceId, ac.signal) : (() => {
			const currentClient = client;
			const languageName = langCodeToName$1.get(item.language) ?? item.language;
			return currentClient.synthesize({
				input: item.text,
				model: currentModel,
				voice: currentVoice,
				responseFormat: "mp3",
				speed,
				instructions: `Speak naturally in ${languageName}. Match the tone and style of the translated text.`
			}, ac.signal);
		})()).then((audioBlob) => {
			if (!isEnabled.value) return;
			enqueuePlayback(audioBlob, getPlaybackRateForProvider(currentProvider, speed));
		}).catch((err) => {
			if (err instanceof Error && err.name === "AbortError") return;
			const message = err instanceof Error ? err.message : "TTS synthesis failed";
			console.error("[TTS] Synthesis error:", message);
			error.value = message;
			callbacks.onError?.(err instanceof Error ? err : new Error(message));
		}).finally(() => {
			if (abortController === ac) abortController = null;
			synthesizeNext();
		});
	}
	async function enqueuePlayback(blob, playbackRate) {
		playbackQueue.push({
			blob,
			playbackRate
		});
		if (playbackRunning) return;
		playbackRunning = true;
		while (playbackQueue.length > 0 && isEnabled.value) {
			const next = playbackQueue.shift();
			try {
				const audioPlayer = ensurePlayer();
				audioPlayer.setPlaybackRate(next.playbackRate);
				await audioPlayer.play(next.blob);
			} catch (err) {
				const message = err instanceof Error ? err.message : "Playback failed";
				console.error("[TTS] Playback error in queue:", message);
				error.value = message;
				callbacks.onError?.(err instanceof Error ? err : new Error(message));
			}
		}
		playbackRunning = false;
	}
	function stop() {
		abortController?.abort();
		abortController = null;
		stopBrowserPlayback();
		player?.stop();
		queue = [];
		playbackQueue.length = 0;
		queueLength.value = 0;
		playbackRunning = false;
		browserActiveUtterances = 0;
		isSpeaking.value = false;
		effectiveSpeed.value = currentSpeed;
	}
	function setEnabled(enabled) {
		isEnabled.value = enabled;
		if (!enabled) stop();
	}
	function cleanup() {
		stop();
		player?.dispose();
		player = null;
		client = null;
		callbacks = {};
	}
	onUnmounted(() => {
		cleanup();
	});
	return {
		isSpeaking,
		isEnabled,
		error,
		queueLength,
		effectiveSpeed,
		configure,
		speakOnce,
		enqueue,
		stop,
		setEnabled,
		cleanup
	};
}
//#endregion
//#region src/composables/useVolumeDucker.ts
/**
* Controls volume ducking on the tab's media elements.
* When TTS is speaking, reduces all <audio>/<video> volumes to the configured level.
* When TTS stops, restores original media volumes captured before ducking.
*/
function useVolumeDucker() {
	const isDucked = ref(false);
	let duckLevel = .3;
	function setDuckLevel(level) {
		duckLevel = Math.max(0, Math.min(1, level));
		if (isDucked.value) broadcastVolumeChange(duckLevel);
	}
	function duck() {
		if (isDucked.value) return;
		isDucked.value = true;
		broadcastVolumeChange(duckLevel);
	}
	function restore() {
		if (!isDucked.value) return;
		isDucked.value = false;
		broadcastRestoreVolume();
	}
	function broadcastVolumeChange(volume) {
		try {
			window.parent.postMessage({
				type: "TTS_DUCK_VOLUME",
				volume
			}, "*");
		} catch {}
	}
	function broadcastRestoreVolume() {
		try {
			window.parent.postMessage({ type: "TTS_RESTORE_VOLUME" }, "*");
		} catch {}
	}
	function dispose() {
		if (isDucked.value) restore();
	}
	onUnmounted(() => {
		dispose();
	});
	return {
		isDucked,
		setDuckLevel,
		duck,
		restore,
		dispose
	};
}
//#endregion
//#region src/composables/useTranslation.ts
var SAMPLE_TEST_TEXT = "This is a narration voice test.";
var ECHO_DECAY_MS = 500;
var VOLUME_RESTORE_DELAY_MS = 5e3;
/**
* Convert UI voice speed (-100 to +100) to OpenAI speed (0.25 to 4.0).
* 0% → 1.0x, +100% → 2.0x, -100% → 0.25x
*/
function uiSpeedToApiSpeed(uiSpeed) {
	if (uiSpeed >= 0) return 1 + uiSpeed / 100;
	return Math.max(.25, 1 + uiSpeed / 100 * .75);
}
function useTranslation() {
	const SPEAKER_PAUSE_MS = 2e3;
	const BROWSER_SPEAKER_PAUSE_MS = 250;
	const BROWSER_MIN_VOICE_SPEED = 1.5;
	const BROWSER_DEFAULT_VOICE_SPEED = 1.75;
	const BROWSER_DEFAULT_UI_SPEED = 75;
	const soniox = useSoniox();
	const tts = useTTS();
	const ducker = useVolumeDucker();
	const store = useTranslatorStore();
	let session = createSessionState();
	let activeTargetLanguage = "vi";
	let activeTheirLanguage = "none";
	const isInterpreterActive = ref(false);
	const interpreterBuffer = ref("");
	const onInterpreterText = ref(null);
	const isNarrationInjecting = ref(false);
	const isNarrateMyVoiceActive = ref(false);
	let narrateMyVoiceBuffer = "";
	const onMyVoiceTranslation = ref(null);
	const onMyVoiceFlush = ref(null);
	let narrateAllSpeakers = false;
	let suppressSonioxNarration = false;
	let activeNarrationProvider = "openai";
	let echoSuppressCount = 0;
	let echoDecayTimer = null;
	let volumeRestoreTimer = null;
	const onTTSSpeakStart = ref(null);
	const onTTSSpeakEnd = ref(null);
	function setNarrateAllSpeakers(value) {
		narrateAllSpeakers = value;
	}
	function setSonioxNarrationSuppressed(value) {
		suppressSonioxNarration = value;
		if (value) {
			session.translationBuffer = "";
			session.originalBuffer = "";
			session.lastTTSCommitAt = Date.now();
		}
	}
	function requestEchoSuppression() {
		echoSuppressCount++;
		if (echoSuppressCount === 1) soniox.muteMicInMixer();
	}
	function releaseEchoSuppression() {
		echoSuppressCount = Math.max(0, echoSuppressCount - 1);
		if (echoSuppressCount === 0) soniox.unmuteMicInMixer();
	}
	function resetEchoSuppression() {
		if (echoDecayTimer) {
			clearTimeout(echoDecayTimer);
			echoDecayTimer = null;
		}
		if (echoSuppressCount > 0) {
			echoSuppressCount = 0;
			soniox.unmuteMicInMixer();
		}
		onTTSSpeakEnd.value?.();
	}
	function cancelVolumeRestoreTimer() {
		if (volumeRestoreTimer) {
			clearTimeout(volumeRestoreTimer);
			volumeRestoreTimer = null;
		}
	}
	function scheduleVolumeRestore() {
		cancelVolumeRestoreTimer();
		volumeRestoreTimer = setTimeout(() => {
			volumeRestoreTimer = null;
			ducker.restore();
		}, VOLUME_RESTORE_DELAY_MS);
	}
	function createSessionState() {
		return {
			activeSpeakerId: null,
			originalBuffer: "",
			translationBuffer: "",
			lastSpeakerActivityAt: 0,
			lastTTSCommitAt: 0,
			sourceLanguage: null
		};
	}
	watch(soniox.state, (newState) => {
		store.setRecordingState(newState);
	});
	watch(soniox.error, (newError) => {
		if (newError) store.setError(newError);
	});
	function shouldRouteToInterpreter(token) {
		if (isNarrationInjecting.value) return false;
		if (!isInterpreterActive.value) return false;
		if (activeTheirLanguage === "none") return false;
		return token.translation_status === "translation" && token.language === activeTheirLanguage;
	}
	function isNarrateMyVoiceToken(token) {
		if (!isNarrateMyVoiceActive.value) return false;
		if (activeTheirLanguage === "none") return false;
		return token.translation_status === "translation" && token.language === activeTheirLanguage;
	}
	const TWO_WAY_LOG_PREFIX = "[TwoWay]";
	function handleResult(result) {
		const audioSource = "tab";
		const isTwoWay = activeTheirLanguage !== "none";
		const speakerOrder = [];
		const bySpeaker = /* @__PURE__ */ new Map();
		let interpreterFinalChunk = "";
		let narrateMyVoiceFinalChunk = "";
		for (const token of result.tokens) {
			if (token.text === "<end>") continue;
			if (isTwoWay && token.is_final) {}
			if (shouldRouteToInterpreter(token) && token.is_final) interpreterFinalChunk += token.text;
			if (isNarrateMyVoiceToken(token) && token.is_final) narrateMyVoiceFinalChunk += token.text;
			const text = token.text;
			const status = token.translation_status;
			const speakerId = normalizeSpeakerId(token.speaker, session.activeSpeakerId);
			if (!bySpeaker.has(speakerId)) {
				bySpeaker.set(speakerId, {
					speakerId,
					finalOriginal: "",
					finalTranslation: "",
					nonFinalOriginal: "",
					nonFinalTranslation: "",
					sourceLanguage: null
				});
				speakerOrder.push(speakerId);
			}
			const bucket = bySpeaker.get(speakerId);
			if (token.is_final && token.source_language) bucket.sourceLanguage = token.source_language;
			if (status === "original" || status === void 0 || status === "none") if (token.is_final) bucket.finalOriginal += text;
			else bucket.nonFinalOriginal += text;
			if (status === "translation") if (token.is_final) bucket.finalTranslation += text;
			else bucket.nonFinalTranslation += text;
		}
		if (interpreterFinalChunk) {
			interpreterBuffer.value += interpreterFinalChunk;
			console.debug(TWO_WAY_LOG_PREFIX, "interpreter-buffer", interpreterFinalChunk.substring(0, 60));
		}
		if (narrateMyVoiceFinalChunk) {
			narrateMyVoiceBuffer += narrateMyVoiceFinalChunk;
			onMyVoiceTranslation.value?.(narrateMyVoiceFinalChunk);
		}
		for (const speakerId of speakerOrder) {
			const chunk = bySpeaker.get(speakerId);
			if (!chunk) continue;
			processSpeakerChunk(chunk, audioSource);
		}
	}
	function processSpeakerChunk(chunk, audioSource) {
		if (session.activeSpeakerId && chunk.speakerId !== session.activeSpeakerId) commitSessionEntry(audioSource);
		if (!session.activeSpeakerId) session.activeSpeakerId = chunk.speakerId;
		if (chunk.sourceLanguage) session.sourceLanguage = chunk.sourceLanguage;
		const now = Date.now();
		const hasIncomingText = Boolean(chunk.finalOriginal || chunk.finalTranslation || chunk.nonFinalOriginal || chunk.nonFinalTranslation);
		if (session.activeSpeakerId === chunk.speakerId && hasIncomingText && session.lastSpeakerActivityAt > 0 && now - session.lastSpeakerActivityAt >= getSpeakerPauseMs() && (session.originalBuffer || session.translationBuffer)) {
			commitSessionEntry(audioSource);
			session.activeSpeakerId = chunk.speakerId;
		}
		if (chunk.finalOriginal) session.originalBuffer += chunk.finalOriginal;
		if (chunk.finalTranslation) session.translationBuffer += chunk.finalTranslation;
		const displayOriginal = session.originalBuffer + chunk.nonFinalOriginal;
		const displayTranslation = session.translationBuffer + chunk.nonFinalTranslation;
		if (displayOriginal || displayTranslation) store.updateCurrentTokens(chunk.speakerId, displayOriginal, displayTranslation, audioSource);
		if (hasIncomingText) session.lastSpeakerActivityAt = now;
		maybeFlushForTTS(audioSource);
	}
	function maybeFlushForTTS(audioSource) {
		if (!tts.isEnabled.value) return;
		if (suppressSonioxNarration) return;
		if (!shouldNarrateSession()) return;
		const translationText = session.translationBuffer;
		if (!translationText.trim()) return;
		const now = Date.now();
		const sinceLast = now - session.lastTTSCommitAt;
		if (sinceLast < getSpeakerPauseMs()) return;
		const targetDurationMs = Math.max(1200, Math.min(12e3, sinceLast));
		session.lastTTSCommitAt = now;
		tts.enqueue(translationText, activeTargetLanguage, targetDurationMs);
		session.translationBuffer = "";
		session.originalBuffer = "";
		store.finalizeCurrent(session.activeSpeakerId ?? "unknown", audioSource);
	}
	function flushInterpreterBuffer() {
		const text = interpreterBuffer.value.trim();
		if (text) {
			console.debug(TWO_WAY_LOG_PREFIX, "flush-buffer", {
				text: text.substring(0, 80),
				interpreterActive: isInterpreterActive.value,
				hasCallback: !!onInterpreterText.value
			});
			if (isInterpreterActive.value && onInterpreterText.value) onInterpreterText.value(text);
		}
		interpreterBuffer.value = "";
	}
	function flushNarrateMyVoiceBuffer() {
		if (narrateMyVoiceBuffer.trim()) console.debug(TWO_WAY_LOG_PREFIX, "flush-narrate-my-voice", narrateMyVoiceBuffer.substring(0, 80));
		narrateMyVoiceBuffer = "";
		onMyVoiceFlush.value?.();
	}
	function handleEndpoint() {
		commitSessionEntry("tab");
		flushInterpreterBuffer();
		flushNarrateMyVoiceBuffer();
	}
	function handleFinalized() {
		commitSessionEntry("tab");
		flushInterpreterBuffer();
		flushNarrateMyVoiceBuffer();
	}
	function commitSessionEntry(audioSource) {
		const currentEntry = audioSource === "mic" ? store.currentMic : store.currentTab;
		const fallbackTranslation = currentEntry.translation ?? "";
		const hasAnyText = Boolean(session.originalBuffer || session.translationBuffer || currentEntry.original || fallbackTranslation);
		if (!session.activeSpeakerId || !hasAnyText) return;
		const translationText = session.translationBuffer || fallbackTranslation;
		store.finalizeCurrent(session.activeSpeakerId, audioSource);
		const now = Date.now();
		const targetDurationMs = Math.max(1200, Math.min(12e3, now - session.lastTTSCommitAt));
		if (translationText.trim() && tts.isEnabled.value && !suppressSonioxNarration && shouldNarrateSession()) tts.enqueue(translationText, activeTargetLanguage, targetDurationMs);
		session.activeSpeakerId = null;
		session.originalBuffer = "";
		session.translationBuffer = "";
		session.sourceLanguage = null;
		session.lastSpeakerActivityAt = 0;
		session.lastTTSCommitAt = now;
	}
	function normalizeSpeakerId(rawSpeaker, fallbackSpeaker) {
		const normalizedSpeaker = rawSpeaker?.trim();
		if (normalizedSpeaker) return normalizedSpeaker;
		if (fallbackSpeaker) return fallbackSpeaker;
		return "unknown";
	}
	function shouldNarrateSession() {
		if (activeTheirLanguage === "none") return true;
		if (narrateAllSpeakers) return true;
		if (!session.sourceLanguage) return true;
		if (session.sourceLanguage === activeTargetLanguage) return false;
		return true;
	}
	function getSpeakerPauseMs() {
		return activeNarrationProvider === "browser" ? BROWSER_SPEAKER_PAUSE_MS : SPEAKER_PAUSE_MS;
	}
	function configureTTS(settings) {
		activeNarrationProvider = settings.ttsProvider ?? "openai";
		let apiSpeed = uiSpeedToApiSpeed(Number.isFinite(settings.voiceSpeed) ? settings.voiceSpeed : activeNarrationProvider === "browser" ? BROWSER_DEFAULT_UI_SPEED : 0);
		if (activeNarrationProvider === "browser") {
			apiSpeed = Math.max(BROWSER_MIN_VOICE_SPEED, apiSpeed);
			if (!Number.isFinite(apiSpeed)) apiSpeed = BROWSER_DEFAULT_VOICE_SPEED;
		}
		const voiceVol = settings.voiceVolume / 100;
		const duckLevel = settings.originalVolume / 100;
		ducker.setDuckLevel(duckLevel);
		const config = {
			apiKey: settings.apiKey,
			speed: apiSpeed,
			volume: voiceVol,
			autoSyncSpeed: settings.autoSyncSpeed ?? true,
			callbacks: {
				onSpeakStart: () => {
					cancelVolumeRestoreTimer();
					ducker.duck();
					requestEchoSuppression();
					onTTSSpeakStart.value?.();
				},
				onSpeakEnd: () => {
					scheduleVolumeRestore();
					if (echoDecayTimer) clearTimeout(echoDecayTimer);
					echoDecayTimer = setTimeout(() => {
						echoDecayTimer = null;
						releaseEchoSuppression();
						onTTSSpeakEnd.value?.();
					}, ECHO_DECAY_MS);
				},
				onError: (err) => {
					console.error("[TTS:Translation] TTS pipeline error:", err.message);
					scheduleVolumeRestore();
					releaseEchoSuppression();
					onTTSSpeakEnd.value?.();
				}
			}
		};
		if (settings.model) config.model = settings.model;
		if (settings.voice) config.voice = settings.voice;
		if (settings.ttsProvider) config.ttsProvider = settings.ttsProvider;
		if (settings.googleVoiceId) config.googleVoiceId = settings.googleVoiceId;
		if (settings.browserVoiceId) config.browserVoiceId = settings.browserVoiceId;
		tts.configure(config);
	}
	function setNarrationEnabled(enabled) {
		if (enabled) {
			session.translationBuffer = "";
			session.originalBuffer = "";
			session.lastTTSCommitAt = Date.now();
		}
		tts.setEnabled(enabled);
		if (!enabled) scheduleVolumeRestore();
	}
	/**
	* Apply narration settings. If TTS is currently running,
	* restart the pipeline to apply new speed/voice/volume.
	*/
	function applyNarrationSettings(settings) {
		configureTTS(settings);
		if (tts.isEnabled.value) {
			tts.stop();
			session.translationBuffer = "";
			session.originalBuffer = "";
			session.lastTTSCommitAt = Date.now();
			tts.setEnabled(true);
		}
	}
	/**
	* Apply settings and start narration (enable TTS).
	*/
	function startNarration(settings) {
		configureTTS(settings);
		setNarrationEnabled(true);
	}
	async function testNarrationVoice(settings) {
		const provider = settings.ttsProvider ?? "openai";
		if (provider === "openai" && !settings.apiKey.trim()) throw new Error("Please configure OpenAI API key to use voice test");
		const apiSpeed = uiSpeedToApiSpeed(settings.voiceSpeed);
		const voiceVol = settings.voiceVolume / 100;
		const duckLevel = settings.originalVolume / 100;
		ducker.setDuckLevel(duckLevel);
		ducker.duck();
		try {
			const previewRequest = {
				apiKey: settings.apiKey,
				text: SAMPLE_TEST_TEXT,
				language: activeTargetLanguage,
				speed: apiSpeed,
				volume: voiceVol,
				ttsProvider: provider
			};
			if (settings.googleVoiceId) previewRequest.googleVoiceId = settings.googleVoiceId;
			if (settings.browserVoiceId) previewRequest.browserVoiceId = settings.browserVoiceId;
			if (settings.model) previewRequest.model = settings.model;
			if (settings.voice) previewRequest.voice = settings.voice;
			await tts.speakOnce(previewRequest);
		} finally {
			ducker.restore();
		}
	}
	function start(apiKey, targetLanguage, microphoneEnabled = false, theirLanguage, context) {
		store.reset();
		store.setTargetLanguage(targetLanguage);
		session = createSessionState();
		activeTargetLanguage = targetLanguage;
		activeTheirLanguage = theirLanguage ?? "none";
		interpreterBuffer.value = "";
		narrateMyVoiceBuffer = "";
		const mode = activeTheirLanguage !== "none" && activeTheirLanguage !== targetLanguage ? "two_way" : "one_way";
		console.info(TWO_WAY_LOG_PREFIX, "start", {
			mode,
			targetLanguage,
			theirLanguage: activeTheirLanguage,
			microphoneEnabled,
			hasContext: Boolean(context)
		});
		soniox.startRecording(apiKey, targetLanguage, {
			onResult: handleResult,
			onEndpoint: handleEndpoint,
			onFinalized: handleFinalized
		}, microphoneEnabled, theirLanguage, context);
	}
	function pause() {
		soniox.pauseRecording();
	}
	function resume() {
		soniox.resumeRecording();
	}
	async function end() {
		await soniox.stopRecording();
		commitSessionEntry("tab");
		tts.stop();
		scheduleVolumeRestore();
		resetEchoSuppression();
	}
	function cancel() {
		soniox.cancelRecording();
		session = createSessionState();
		tts.stop();
		scheduleVolumeRestore();
		resetEchoSuppression();
	}
	async function setMicEnabled(enabled) {
		await soniox.setMicEnabled(enabled);
	}
	function clear() {
		store.clearEntries();
		session = createSessionState();
	}
	function stopNarration() {
		tts.stop();
		tts.setEnabled(false);
		scheduleVolumeRestore();
		resetEchoSuppression();
		session.translationBuffer = "";
		session.originalBuffer = "";
		session.lastTTSCommitAt = 0;
	}
	function enqueueTTSText(text, language, targetDurationMs) {
		if (!tts.isEnabled.value) return;
		tts.enqueue(text, language, targetDurationMs);
	}
	function startInterpreterMode(callback) {
		isInterpreterActive.value = true;
		interpreterBuffer.value = "";
		onInterpreterText.value = callback;
	}
	function stopInterpreterMode() {
		flushInterpreterBuffer();
		isInterpreterActive.value = false;
		interpreterBuffer.value = "";
		onInterpreterText.value = null;
	}
	return {
		state: soniox.state,
		error: soniox.error,
		ttsState: {
			isSpeaking: tts.isSpeaking,
			isEnabled: tts.isEnabled,
			error: tts.error,
			queueLength: tts.queueLength,
			effectiveSpeed: tts.effectiveSpeed
		},
		start,
		pause,
		resume,
		end,
		cancel,
		clear,
		setMicEnabled,
		configureTTS,
		setNarrationEnabled,
		applyNarrationSettings,
		startNarration,
		testNarrationVoice,
		stopNarration,
		isInterpreterActive,
		isNarrationInjecting,
		isNarrateMyVoiceActive,
		onMyVoiceTranslation,
		onMyVoiceFlush,
		startInterpreterMode,
		stopInterpreterMode,
		setNarrateAllSpeakers,
		setSonioxNarrationSuppressed,
		onTTSSpeakStart,
		onTTSSpeakEnd,
		enqueueTTSText
	};
}
//#endregion
//#region src/services/openai-streaming-tts-provider.ts
var LOG$2 = "[OpenAIStreamTTS]";
var API_URL = "https://api.openai.com/v1/audio/speech";
var OUTPUT_SAMPLE_RATE$1 = 24e3;
var langCodeToName = new Map(SUPPORTED_LANGUAGES.map((l) => [l.value, l.label]));
function uint8ArrayToBase64$1(bytes) {
	let binary = "";
	const chunkSize = 32768;
	for (let i = 0; i < bytes.length; i += chunkSize) {
		const chunk = bytes.subarray(i, i + chunkSize);
		binary += String.fromCharCode.apply(null, Array.from(chunk));
	}
	return btoa(binary);
}
function resolveErrorMessage(status, body) {
	if (status === 401) return "Invalid OpenAI API key. Please check your key and try again.";
	if (status === 429) return "OpenAI rate limit reached. Please wait a moment and try again.";
	if (status >= 500) return "OpenAI service error. Please try again later.";
	try {
		return JSON.parse(body).error?.message ?? `OpenAI TTS error (${status})`;
	} catch {
		return `OpenAI TTS error (${status})`;
	}
}
var OpenAIStreamingTTSProvider = class {
	id = "openai";
	name = "OpenAI TTS";
	apiKey;
	model;
	constructor(apiKey, model = "gpt-4o-mini-tts") {
		this.apiKey = apiKey;
		this.model = model;
	}
	setApiKey(apiKey) {
		this.apiKey = apiKey;
	}
	async synthesizeStream(request, signal) {
		if (!this.apiKey) throw new Error("OpenAI API key is not configured");
		const languageName = langCodeToName.get(request.language) ?? request.language;
		const instructions = request.instructions ?? `Speak naturally in ${languageName}. Match the tone and style of the translated text.`;
		const body = {
			model: this.model,
			input: request.text,
			voice: request.voice,
			response_format: "pcm",
			speed: request.speed ?? 1,
			instructions
		};
		console.log(LOG$2, "POST", API_URL, "— voice:", request.voice, "input length:", request.text.length);
		request.telemetry?.onRequestStart?.();
		const response = await fetch(API_URL, {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${this.apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body),
			signal: signal ?? null
		});
		request.telemetry?.onResponseHeaders?.();
		if (!response.ok) {
			const errorText = await response.text().catch(() => "Unknown error");
			console.error(LOG$2, "Error response:", response.status, errorText);
			throw new TTSStreamError(response.status, resolveErrorMessage(response.status, errorText));
		}
		const body_ = response.body;
		if (!body_) throw new Error("Response body is not readable");
		const reader = body_.getReader();
		async function* readChunks() {
			let firstChunkSeen = false;
			let leftoverByte = null;
			try {
				while (true) {
					const { done, value } = await reader.read();
					if (done) break;
					if (value && value.length > 0) {
						let bytes = value;
						if (leftoverByte !== null) {
							const prefixed = new Uint8Array(bytes.length + 1);
							prefixed[0] = leftoverByte;
							prefixed.set(bytes, 1);
							bytes = prefixed;
							leftoverByte = null;
						}
						if ((bytes.length & 1) === 1) {
							leftoverByte = bytes[bytes.length - 1] ?? null;
							bytes = bytes.subarray(0, bytes.length - 1);
						}
						if (bytes.length === 0) continue;
						if (!firstChunkSeen) {
							firstChunkSeen = true;
							request.telemetry?.onFirstChunk?.();
						}
						yield { pcm16Base64: uint8ArrayToBase64$1(bytes) };
					}
				}
				if (leftoverByte !== null) {
					const padded = new Uint8Array(2);
					padded[0] = leftoverByte;
					padded[1] = 0;
					if (!firstChunkSeen) {
						firstChunkSeen = true;
						request.telemetry?.onFirstChunk?.();
					}
					yield { pcm16Base64: uint8ArrayToBase64$1(padded) };
				}
			} finally {
				request.telemetry?.onStreamEnd?.();
				reader.releaseLock();
			}
		}
		return {
			stream: readChunks(),
			sampleRate: OUTPUT_SAMPLE_RATE$1
		};
	}
	dispose() {}
};
var TTSStreamError = class extends Error {
	constructor(status, message) {
		super(message);
		this.status = status;
		this.name = "TTSStreamError";
	}
};
//#endregion
//#region src/services/google-translate-tts-provider.ts
var CHUNK_BYTES = 4096;
var OUTPUT_SAMPLE_RATE = 24e3;
function uint8ArrayToBase64(bytes) {
	let binary = "";
	const chunkSize = 32768;
	for (let i = 0; i < bytes.length; i += chunkSize) {
		const chunk = bytes.subarray(i, i + chunkSize);
		binary += String.fromCharCode.apply(null, Array.from(chunk));
	}
	return btoa(binary);
}
function floatTo16BitPCM(float32) {
	const buffer = /* @__PURE__ */ new ArrayBuffer(float32.length * 2);
	const view = new DataView(buffer);
	for (let i = 0; i < float32.length; i++) {
		const s = Math.max(-1, Math.min(1, float32[i]));
		view.setInt16(i * 2, s < 0 ? s * 32768 : s * 32767, true);
	}
	return buffer;
}
function resampleToTargetRate(sourceBuffer, targetRate) {
	const sourceRate = sourceBuffer.sampleRate;
	const sourceData = sourceBuffer.getChannelData(0);
	if (sourceRate === targetRate) return sourceData;
	const ratio = sourceRate / targetRate;
	const targetLength = Math.round(sourceData.length / ratio);
	const result = new Float32Array(targetLength);
	for (let i = 0; i < targetLength; i++) {
		const srcIndex = i * ratio;
		const srcFloor = Math.floor(srcIndex);
		const srcCeil = Math.min(srcFloor + 1, sourceData.length - 1);
		const frac = srcIndex - srcFloor;
		result[i] = (sourceData[srcFloor] ?? 0) * (1 - frac) + (sourceData[srcCeil] ?? 0) * frac;
	}
	return result;
}
var GoogleTranslateTTSProvider = class {
	id = "google";
	name = "Google Translate TTS";
	async synthesizeStream(request, signal) {
		if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
		request.telemetry?.onRequestStart?.();
		const blob = await googleTranslateSynthesizeBlob(request.text, request.voice, signal);
		if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
		request.telemetry?.onResponseHeaders?.();
		const arrayBuffer = await blob.arrayBuffer();
		const audioCtx = new AudioContext();
		let decoded;
		try {
			decoded = await audioCtx.decodeAudioData(arrayBuffer);
		} finally {
			await audioCtx.close();
		}
		const pcm16 = floatTo16BitPCM(resampleToTargetRate(decoded, OUTPUT_SAMPLE_RATE));
		const telemetry = request.telemetry;
		async function* yieldChunks() {
			let firstChunk = true;
			for (let offset = 0; offset < pcm16.byteLength; offset += CHUNK_BYTES) {
				if (signal?.aborted) break;
				const end = Math.min(offset + CHUNK_BYTES, pcm16.byteLength);
				const slice = new Uint8Array(pcm16, offset, end - offset);
				if (firstChunk) {
					telemetry?.onFirstChunk?.();
					firstChunk = false;
				}
				yield { pcm16Base64: uint8ArrayToBase64(slice) };
				await Promise.resolve();
			}
			telemetry?.onStreamEnd?.();
		}
		return {
			stream: yieldChunks(),
			sampleRate: OUTPUT_SAMPLE_RATE
		};
	}
	dispose() {}
};
//#endregion
//#region src/utils/sentence-buffer.ts
/**
* Accumulates text tokens and flushes on sentence boundaries.
*
* Designed for Soniox interpreter tokens → TTS sentence input.
* Flushes on: punctuation pattern match, max buffer length, or explicit forceFlush().
*/
var SENTENCE_END_RE = /[.!?。！？]\s*$/;
var SentenceBuffer = class {
	buffer = "";
	onSentence;
	maxLength;
	minLength;
	flushPattern;
	constructor(options) {
		this.onSentence = options.onSentence;
		this.maxLength = options.maxBufferLength ?? 200;
		this.minLength = options.minSentenceLength ?? 3;
		this.flushPattern = options.flushPattern ?? SENTENCE_END_RE;
	}
	push(text) {
		this.buffer += text;
		this.tryFlush();
	}
	forceFlush() {
		const text = this.buffer.trim();
		if (text.length >= this.minLength) this.onSentence(text);
		this.buffer = "";
	}
	clear() {
		this.buffer = "";
	}
	get pending() {
		return this.buffer;
	}
	tryFlush() {
		if (this.flushPattern.test(this.buffer) && this.buffer.trim().length >= this.minLength) {
			this.onSentence(this.buffer.trim());
			this.buffer = "";
			return;
		}
		if (this.buffer.length >= this.maxLength) {
			const trimmed = this.buffer.trim();
			if (trimmed.length >= this.minLength) this.onSentence(trimmed);
			this.buffer = "";
		}
	}
};
//#endregion
//#region src/config/feature-flags.ts
var NARRATION_FEATURE_FLAGS = {
	narrateAllSpeakersToggle: false,
	earlyNarrateMyVoiceFlush: true,
	captionNarration: true
};
//#endregion
//#region src/composables/useNarrateMyVoice.ts
var LOG$1 = "[NarrateMyVoice]";
var MAX_SENTENCE_QUEUE = 3;
var ANTI_FEEDBACK_COOLDOWN_MS = 2e3;
var INJECTION_DONE_TIMEOUT_MS = 1e4;
function nowMs() {
	return performance.now();
}
function deltaMs(start, end) {
	if (start === void 0 || end === void 0) return null;
	return Math.max(0, end - start);
}
function formatSec(ms) {
	if (ms === null) return null;
	return (ms / 1e3).toFixed(3);
}
function resolveLanguageName(code) {
	return SUPPORTED_LANGUAGES.find((l) => l.value === code)?.label ?? code;
}
function useNarrateMyVoice() {
	const isEnabled = ref(false);
	const isInjecting = ref(false);
	const isPlatformSupported = ref(false);
	let provider = null;
	let sentenceBuffer = null;
	let sentenceQueue = [];
	let abortController = null;
	let processingActive = false;
	let statusListenerActive = false;
	let injectionDoneResolve = null;
	let traceCounter = 0;
	let buildingTraceWindow = null;
	let activeVoice = "coral";
	let activeSpeed = 1;
	let activeLanguage = "";
	let activeTtsProvider = "openai";
	const onInjectionStart = ref(null);
	const onInjectionEnd = ref(null);
	function logTraceMilestone(trace, milestone, extra = {}) {
		console.info(`${LOG$1}[Trace:${trace.id}] ${milestone}`, {
			textLength: trace.textLength,
			preview: trace.textPreview,
			...extra
		});
	}
	function logTraceSummary(trace) {
		const sonioxToSentenceReady = deltaMs(trace.sonioxFirstAt, trace.sentenceReadyAt);
		const sonioxToTtsStart = deltaMs(trace.sonioxFirstAt, trace.ttsRequestStartAt);
		const ttsStartToHeaders = deltaMs(trace.ttsRequestStartAt, trace.ttsResponseHeadersAt);
		const ttsStartToFirstChunk = deltaMs(trace.ttsRequestStartAt, trace.ttsFirstChunkAt);
		const sonioxToFirstInject = deltaMs(trace.sonioxFirstAt, trace.firstInjectAt);
		const sonioxToInjectionDone = deltaMs(trace.sonioxFirstAt, trace.injectionDoneAt);
		console.info(`${LOG$1}[Trace:${trace.id}] timeline`, {
			reason: trace.injectionDoneReason ?? "unknown",
			chunks: trace.chunkCount,
			sonioxToSentenceReadyMs: sonioxToSentenceReady,
			sonioxToSentenceReadySec: formatSec(sonioxToSentenceReady),
			sonioxToTtsStartMs: sonioxToTtsStart,
			sonioxToTtsStartSec: formatSec(sonioxToTtsStart),
			ttsStartToHeadersMs: ttsStartToHeaders,
			ttsStartToHeadersSec: formatSec(ttsStartToHeaders),
			ttsStartToFirstChunkMs: ttsStartToFirstChunk,
			ttsStartToFirstChunkSec: formatSec(ttsStartToFirstChunk),
			sonioxToFirstInjectMs: sonioxToFirstInject,
			sonioxToFirstInjectSec: formatSec(sonioxToFirstInject),
			sonioxToInjectionDoneMs: sonioxToInjectionDone,
			sonioxToInjectionDoneSec: formatSec(sonioxToInjectionDone)
		});
	}
	function applyTtsTelemetry(trace) {
		return {
			onRequestStart: () => {
				if (trace.ttsRequestStartAt !== void 0) return;
				trace.ttsRequestStartAt = nowMs();
				logTraceMilestone(trace, "openai_request_start", {
					sonioxToTtsStartMs: deltaMs(trace.sonioxFirstAt, trace.ttsRequestStartAt),
					sonioxToTtsStartSec: formatSec(deltaMs(trace.sonioxFirstAt, trace.ttsRequestStartAt))
				});
			},
			onResponseHeaders: () => {
				if (trace.ttsResponseHeadersAt !== void 0) return;
				trace.ttsResponseHeadersAt = nowMs();
				logTraceMilestone(trace, "openai_response_headers", {
					ttsStartToHeadersMs: deltaMs(trace.ttsRequestStartAt, trace.ttsResponseHeadersAt),
					ttsStartToHeadersSec: formatSec(deltaMs(trace.ttsRequestStartAt, trace.ttsResponseHeadersAt))
				});
			},
			onFirstChunk: () => {
				if (trace.ttsFirstChunkAt !== void 0) return;
				trace.ttsFirstChunkAt = nowMs();
				logTraceMilestone(trace, "openai_first_chunk", {
					ttsStartToFirstChunkMs: deltaMs(trace.ttsRequestStartAt, trace.ttsFirstChunkAt),
					ttsStartToFirstChunkSec: formatSec(deltaMs(trace.ttsRequestStartAt, trace.ttsFirstChunkAt))
				});
			},
			onStreamEnd: () => {
				if (trace.ttsStreamEndAt !== void 0) return;
				trace.ttsStreamEndAt = nowMs();
				logTraceMilestone(trace, "openai_stream_end", { ttsTotalStreamMs: deltaMs(trace.ttsRequestStartAt, trace.ttsStreamEndAt) });
			}
		};
	}
	function sendToContentScript(message) {
		try {
			window.parent.postMessage({
				...message,
				source: "live-translator-panel"
			}, "*");
		} catch {}
	}
	function handleContentScriptMessage(event) {
		const data = event.data;
		if (data?.source === "live-translator-mic-interceptor") {
			if (data.type === "VIRTUAL_MIC_STATUS") isPlatformSupported.value = event.data.payload?.supported ?? false;
			else if (data.type === "AUDIO_INJECTION_DONE") handleInjectionDone();
		}
	}
	function handleInjectionDone() {
		injectionDoneResolve?.();
		injectionDoneResolve = null;
		setTimeout(() => {
			if (!processingActive) {
				isInjecting.value = false;
				onInjectionEnd.value?.();
			}
		}, ANTI_FEEDBACK_COOLDOWN_MS);
	}
	function startStatusListener() {
		if (statusListenerActive) return;
		statusListenerActive = true;
		window.addEventListener("message", handleContentScriptMessage);
	}
	function checkPlatformSupport() {
		startStatusListener();
		sendToContentScript({ type: "REQUEST_STATUS" });
		for (const delay of [
			500,
			1500,
			3e3
		]) setTimeout(() => {
			if (!isPlatformSupported.value) sendToContentScript({ type: "REQUEST_STATUS" });
		}, delay);
	}
	function handleSentenceReady(sentence) {
		if (!isEnabled.value) return;
		const capturedAt = nowMs();
		const window_ = buildingTraceWindow ?? {
			id: ++traceCounter,
			firstAt: capturedAt,
			lastAt: capturedAt
		};
		buildingTraceWindow = null;
		const trace = {
			id: window_.id,
			textPreview: sentence.substring(0, 120),
			textLength: sentence.length,
			sonioxFirstAt: window_.firstAt,
			sonioxLastAt: window_.lastAt,
			sentenceReadyAt: capturedAt,
			chunkCount: 0
		};
		logTraceMilestone(trace, "sentence_ready", {
			sonioxToSentenceReadyMs: deltaMs(trace.sonioxFirstAt, trace.sentenceReadyAt),
			sonioxToSentenceReadySec: formatSec(deltaMs(trace.sonioxFirstAt, trace.sentenceReadyAt))
		});
		sentenceQueue.push({
			sentence,
			trace
		});
		while (sentenceQueue.length > MAX_SENTENCE_QUEUE) {
			const dropped = sentenceQueue.shift();
			if (dropped) logTraceMilestone(dropped.trace, "queue_dropped_oldest", { queuedSentencePreview: dropped.sentence.substring(0, 40) });
		}
		processQueue();
	}
	async function processQueue() {
		if (processingActive || !provider || !isEnabled.value) return;
		processingActive = true;
		while (sentenceQueue.length > 0 && isEnabled.value) {
			const item = sentenceQueue.shift();
			try {
				await injectSentence(item);
			} catch (err) {
				if (err.name !== "AbortError") console.error(`${LOG$1}[Trace:${item.trace.id}] Sentence injection failed:`, err);
			}
		}
		processingActive = false;
		if (!isInjecting.value) return;
		isInjecting.value = false;
		onInjectionEnd.value?.();
	}
	async function injectSentence(item) {
		if (!provider || !isEnabled.value) return;
		const { sentence: text, trace } = item;
		const ac = new AbortController();
		abortController = ac;
		if (!isInjecting.value) {
			isInjecting.value = true;
			onInjectionStart.value?.();
		}
		sendToContentScript({ type: "START_AUDIO_INJECTION" });
		logTraceMilestone(trace, "inject_start");
		try {
			const { stream, sampleRate } = await provider.synthesizeStream({
				text,
				language: activeLanguage,
				voice: activeVoice,
				speed: activeSpeed,
				telemetry: applyTtsTelemetry(trace)
			}, ac.signal);
			for await (const chunk of stream) {
				if (!isEnabled.value || ac.signal.aborted) break;
				trace.chunkCount++;
				if (trace.firstInjectAt === void 0) {
					trace.firstInjectAt = nowMs();
					logTraceMilestone(trace, "first_chunk_injected", {
						sonioxToFirstInjectMs: deltaMs(trace.sonioxFirstAt, trace.firstInjectAt),
						sonioxToFirstInjectSec: formatSec(deltaMs(trace.sonioxFirstAt, trace.firstInjectAt))
					});
				}
				sendToContentScript({
					type: "INJECT_AUDIO_CHUNK",
					pcm16Base64: chunk.pcm16Base64,
					sampleRate
				});
			}
			sendToContentScript({ type: "STOP_AUDIO_INJECTION" });
			await waitForInjectionDone(ac.signal, trace);
		} catch (err) {
			sendToContentScript({ type: "STOP_AUDIO_INJECTION" });
			throw err;
		} finally {
			if (abortController === ac) abortController = null;
		}
	}
	function waitForInjectionDone(signal, trace) {
		return new Promise((resolve) => {
			if (signal.aborted) {
				trace.injectionDoneAt = nowMs();
				trace.injectionDoneReason = "aborted";
				logTraceSummary(trace);
				resolve();
				return;
			}
			injectionDoneResolve = () => {
				clearTimeout(timeout);
				trace.injectionDoneAt = nowMs();
				trace.injectionDoneReason = "audio_injection_done";
				logTraceSummary(trace);
				resolve();
			};
			const timeout = setTimeout(() => {
				injectionDoneResolve = null;
				trace.injectionDoneAt = nowMs();
				trace.injectionDoneReason = "timeout";
				logTraceSummary(trace);
				resolve();
			}, INJECTION_DONE_TIMEOUT_MS);
			signal.addEventListener("abort", () => {
				clearTimeout(timeout);
				injectionDoneResolve = null;
				trace.injectionDoneAt = nowMs();
				trace.injectionDoneReason = "aborted";
				logTraceSummary(trace);
				resolve();
			}, { once: true });
		});
	}
	function pushText(text) {
		if (!isEnabled.value || !sentenceBuffer) return;
		const capturedAt = nowMs();
		if (!buildingTraceWindow) buildingTraceWindow = {
			id: ++traceCounter,
			firstAt: capturedAt,
			lastAt: capturedAt
		};
		else buildingTraceWindow.lastAt = capturedAt;
		console.info(`${LOG$1}[Trace:${buildingTraceWindow.id}] soniox_translation_received`, {
			chunkLength: text.length,
			chunkPreview: text.substring(0, 80),
			queueLength: sentenceQueue.length
		});
		sentenceBuffer.push(text);
	}
	function flushText() {
		if (!isEnabled.value || !sentenceBuffer) return;
		const traceId = buildingTraceWindow?.id;
		if (traceId !== void 0) console.info(`${LOG$1}[Trace:${traceId}] soniox_flush_signal`);
		else console.info(`${LOG$1} soniox_flush_signal (no active trace)`);
		sentenceBuffer.forceFlush();
	}
	const EARLY_FLUSH_PATTERN = /[.!?。！？,;:，；：]\s*$/;
	function buildBufferOptions(ttsProvider) {
		if (NARRATION_FEATURE_FLAGS.earlyNarrateMyVoiceFlush) return {
			onSentence: handleSentenceReady,
			maxBufferLength: ttsProvider === "google" ? 120 : 80,
			minSentenceLength: 15,
			flushPattern: EARLY_FLUSH_PATTERN
		};
		return {
			onSentence: handleSentenceReady,
			maxBufferLength: ttsProvider === "google" ? 180 : 200
		};
	}
	function createProvider(ttsProvider, apiKey) {
		if (ttsProvider === "google") return new GoogleTranslateTTSProvider();
		return new OpenAIStreamingTTSProvider(apiKey);
	}
	function enable(apiKey, voice, myLanguage, theirLanguage, speed = 1, ttsProvider = "openai", googleVoiceId = "en") {
		if (isEnabled.value) return;
		if (theirLanguage === "none") return;
		isEnabled.value = true;
		activeVoice = ttsProvider === "google" ? googleVoiceId : voice;
		activeSpeed = speed;
		activeLanguage = resolveLanguageName(theirLanguage);
		activeTtsProvider = ttsProvider;
		provider = createProvider(ttsProvider, apiKey);
		sentenceBuffer = new SentenceBuffer(buildBufferOptions(ttsProvider));
		sentenceQueue = [];
		buildingTraceWindow = null;
		startStatusListener();
		sendToContentScript({ type: "ACTIVATE_VIRTUAL_MIC" });
		const voiceDisplay = ttsProvider === "google" ? googleVoiceId : voice;
		console.log(LOG$1, "Enabled — provider:", ttsProvider, "voice:", voiceDisplay, "language:", activeLanguage);
	}
	function switchProvider(ttsProvider, apiKey, voice, googleVoiceId = "en") {
		if (!isEnabled.value) return;
		const providerChanged = ttsProvider !== activeTtsProvider;
		const nextVoice = ttsProvider === "google" ? googleVoiceId : voice;
		if (!providerChanged && !(nextVoice !== activeVoice)) return;
		activeTtsProvider = ttsProvider;
		activeVoice = nextVoice;
		if (providerChanged) {
			provider?.dispose();
			provider = createProvider(ttsProvider, apiKey);
			sentenceBuffer = new SentenceBuffer(buildBufferOptions(ttsProvider));
		}
		console.log(LOG$1, "Switched narrate-my-voice output:", {
			provider: ttsProvider,
			voice: activeVoice
		});
	}
	function disable() {
		if (!isEnabled.value) return;
		isEnabled.value = false;
		abortController?.abort();
		abortController = null;
		sentenceBuffer?.clear();
		sentenceBuffer = null;
		sentenceQueue = [];
		buildingTraceWindow = null;
		processingActive = false;
		provider?.dispose();
		provider = null;
		injectionDoneResolve?.();
		injectionDoneResolve = null;
		isInjecting.value = false;
		sendToContentScript({ type: "DEACTIVATE_VIRTUAL_MIC" });
		console.log(LOG$1, "Disabled");
	}
	function dispose() {
		disable();
		if (statusListenerActive) {
			window.removeEventListener("message", handleContentScriptMessage);
			statusListenerActive = false;
		}
	}
	return {
		isEnabled,
		isInjecting,
		isPlatformSupported,
		onInjectionStart,
		onInjectionEnd,
		checkPlatformSupport,
		pushText,
		flushText,
		enable,
		disable,
		dispose,
		switchProvider
	};
}
//#endregion
//#region src/config/caption-narration-config.ts
/**
* Per-provider lead time (ms) for preloading TTS synthesis ahead of
* the caption timeline. Compensates for each provider's typical
* synthesis latency so that TTS playback starts closer to the moment
* the video character speaks.
*
* Tune these values based on observed real-world latency.
*/
var CAPTION_NARRATION_CONFIG = {
	providerLeadMs: {
		google: 500,
		openai: 1500,
		browser: 0
	},
	maxPreloadSegments: 3
};
//#endregion
//#region src/composables/useCaptionNarration.ts
var YT_CAPTION_SOURCE = "live-translator-yt-caption";
var PANEL_SOURCE = "live-translator-panel";
var REQUEST_TIMEOUT_MS = 8e3;
var LOG = "[CaptionNarration]";
var FORWARD_SEEK_THRESHOLD_MS = 4e3;
var BACKWARD_SEEK_THRESHOLD_MS = 1e3;
var MIN_SEGMENT_DURATION_MS = 500;
/**
* Composable that uses YouTube's translated captions for TTS narration
* instead of routing audio through Soniox.
*
* Communication: panel iframe ↔ content script ↔ MAIN world inject script.
* Currently scoped to YouTube but designed for future platform extension.
*/
function useCaptionNarration() {
	const isActive = ref(false);
	const segments = ref([]);
	const trackSelection = ref(null);
	let activeLanguage = "";
	let nextSegmentIndex = 0;
	let lastVideoTimeMs = null;
	let hasInitialTimeSync = false;
	let callbacks = null;
	let messageHandler = null;
	let leadTimeMs = 0;
	let pendingTracks = null;
	let pendingSegments = null;
	function isYouTubeWatchUrl(url) {
		try {
			const u = new URL(url);
			return u.hostname === "www.youtube.com" && u.pathname === "/watch";
		} catch {
			return false;
		}
	}
	function extractVideoId(url) {
		try {
			return new URL(url).searchParams.get("v") || null;
		} catch {
			return null;
		}
	}
	function sendToContentScript(data) {
		window.parent.postMessage({
			...data,
			source: PANEL_SOURCE
		}, "*");
	}
	function handleMessage(event) {
		const data = event.data;
		if (!data || data.source !== YT_CAPTION_SOURCE) return;
		switch (data.type) {
			case "CAPTION_TRACKS_RESULT": {
				const tracks = data.tracks ?? [];
				console.debug(LOG, "received CAPTION_TRACKS_RESULT", {
					trackCount: tracks.length,
					videoId: data.videoId,
					tracks: tracks.map((t) => `${t.languageCode} (${t.kind}, translatable=${t.isTranslatable})`)
				});
				if (pendingTracks) {
					clearTimeout(pendingTracks.timer);
					pendingTracks.resolve(tracks);
					pendingTracks = null;
				}
				break;
			}
			case "TRANSLATED_CAPTIONS_RESULT": {
				const segs = data.segments ?? [];
				console.debug(LOG, "received TRANSLATED_CAPTIONS_RESULT", {
					language: data.language,
					segmentCount: segs.length,
					firstSegment: segs[0]?.text?.substring(0, 50)
				});
				if (pendingSegments) {
					clearTimeout(pendingSegments.timer);
					pendingSegments.resolve(segs);
					pendingSegments = null;
				}
				break;
			}
			case "CAPTION_ERROR":
				console.warn(LOG, "received CAPTION_ERROR", {
					error: data.error,
					code: data.code
				});
				if (pendingTracks) {
					clearTimeout(pendingTracks.timer);
					pendingTracks.resolve([]);
					pendingTracks = null;
				}
				if (pendingSegments) {
					clearTimeout(pendingSegments.timer);
					pendingSegments.resolve([]);
					pendingSegments = null;
				}
				break;
			case "VIDEO_TIME_UPDATE": {
				if (!isActive.value) return;
				const currentTimeMs = data.currentTimeMs;
				const state = data.state;
				handleTimeUpdate(currentTimeMs, state);
				break;
			}
		}
	}
	function requestCaptionTracks() {
		console.debug(LOG, "requesting caption tracks from inject script...");
		return new Promise((resolve) => {
			pendingTracks = {
				resolve,
				timer: setTimeout(() => {
					console.warn(LOG, `REQUEST_CAPTION_TRACKS timed out after ${REQUEST_TIMEOUT_MS}ms`);
					pendingTracks = null;
					resolve([]);
				}, REQUEST_TIMEOUT_MS)
			};
			sendToContentScript({ type: "REQUEST_CAPTION_TRACKS" });
		});
	}
	function requestTranslatedCaptions(targetLanguage) {
		console.debug(LOG, "requesting translated captions...", { targetLanguage });
		return new Promise((resolve) => {
			pendingSegments = {
				resolve,
				timer: setTimeout(() => {
					console.warn(LOG, `REQUEST_TRANSLATED_CAPTIONS timed out after ${REQUEST_TIMEOUT_MS}ms`, { targetLanguage });
					pendingSegments = null;
					resolve([]);
				}, REQUEST_TIMEOUT_MS)
			};
			sendToContentScript({
				type: "REQUEST_TRANSLATED_CAPTIONS",
				targetLanguage
			});
		});
	}
	function findMatchingTrack(tracks, targetLanguage) {
		const directMatch = tracks.find((t) => t.languageCode === targetLanguage);
		if (directMatch) return {
			track: directMatch,
			needsTranslation: false
		};
		const translatable = tracks.find((t) => t.isTranslatable);
		if (translatable) return {
			track: translatable,
			needsTranslation: true
		};
		return null;
	}
	/**
	* Start caption-based narration for the given page URL.
	* Returns `true` if caption narration was successfully started,
	* `false` if not available (caller should fall back to Soniox).
	*/
	function setProvider(provider) {
		leadTimeMs = CAPTION_NARRATION_CONFIG.providerLeadMs[provider] ?? 0;
	}
	async function start(pageUrl, targetLanguage, cbs, ttsProvider) {
		callbacks = cbs;
		if (ttsProvider) setProvider(ttsProvider);
		console.info(LOG, "start()", {
			pageUrl: pageUrl.substring(0, 80),
			targetLanguage,
			leadTimeMs
		});
		if (!isYouTubeWatchUrl(pageUrl)) {
			console.debug(LOG, "not a YouTube watch URL — skipping caption narration");
			return false;
		}
		const videoId = extractVideoId(pageUrl);
		if (!videoId) {
			console.warn(LOG, "could not extract video ID from URL");
			cbs.onWarning("Could not determine YouTube video ID.");
			return false;
		}
		console.debug(LOG, "detected YouTube video", {
			videoId,
			targetLanguage
		});
		if (!messageHandler) {
			messageHandler = handleMessage;
			window.addEventListener("message", messageHandler);
		}
		const tracks = await requestCaptionTracks();
		if (!tracks.length) {
			console.warn(LOG, "no caption tracks available — fallback to Soniox");
			cbs.onWarning("No captions available for this video. Using standard narration.");
			cbs.onFallbackToSoniox();
			return false;
		}
		console.debug(LOG, "available tracks:", tracks.map((t) => `${t.languageCode} (${t.languageName}, ${t.kind}, translatable=${t.isTranslatable})`));
		const match = findMatchingTrack(tracks, targetLanguage);
		if (!match) {
			const availableLangs = tracks.map((t) => t.languageCode).join(", ");
			console.warn(LOG, `no matching track for "${targetLanguage}" — available: [${availableLangs}] — fallback to Soniox`);
			cbs.onWarning(`No caption matching "${targetLanguage}" found for this video. Using standard narration.`);
			cbs.onFallbackToSoniox();
			return false;
		}
		console.info(LOG, "matched track", {
			trackLang: match.track.languageCode,
			trackKind: match.track.kind,
			needsTranslation: match.needsTranslation
		});
		trackSelection.value = match.track;
		let captionSegments;
		if (match.needsTranslation) {
			console.debug(LOG, `requesting YouTube auto-translation: ${match.track.languageCode} → ${targetLanguage}`);
			captionSegments = await requestTranslatedCaptions(targetLanguage);
		} else {
			console.debug(LOG, `direct caption match for "${targetLanguage}" — loading segments`);
			captionSegments = await requestTranslatedCaptions(targetLanguage);
		}
		if (!captionSegments.length) {
			console.warn(LOG, "translated captions returned 0 segments — fallback to Soniox");
			cbs.onWarning("Failed to load translated captions. Using standard narration.");
			cbs.onFallbackToSoniox();
			return false;
		}
		segments.value = captionSegments;
		activeLanguage = targetLanguage;
		nextSegmentIndex = 0;
		lastVideoTimeMs = null;
		hasInitialTimeSync = false;
		isActive.value = true;
		console.info(LOG, "caption narration started", {
			videoId,
			targetLanguage,
			segmentCount: captionSegments.length,
			totalDurationMs: captionSegments.reduce((sum, s) => sum + s.durationMs, 0)
		});
		sendToContentScript({ type: "START_VIDEO_TIME_MONITOR" });
		cbs.onStarted();
		return true;
	}
	function findSeekIndex(timeMs, includeActiveSegment) {
		const segs = segments.value;
		let idx = 0;
		if (includeActiveSegment) {
			while (idx < segs.length) {
				const seg = segs[idx];
				if (seg.startMs + Math.max(seg.durationMs, MIN_SEGMENT_DURATION_MS) > timeMs) break;
				idx++;
			}
			return idx;
		}
		while (idx < segs.length && segs[idx].startMs <= timeMs) idx++;
		return idx;
	}
	function realignForSeek(timeMs) {
		const prevIndex = nextSegmentIndex;
		nextSegmentIndex = findSeekIndex(timeMs, true);
		console.info(LOG, "seek detected: realigned caption index", {
			timeMs,
			previousIndex: prevIndex,
			nextIndex: nextSegmentIndex
		});
	}
	function handleTimeUpdate(currentTimeMs, state) {
		if (!callbacks) return;
		if (!hasInitialTimeSync) {
			nextSegmentIndex = findSeekIndex(currentTimeMs, true);
			hasInitialTimeSync = true;
			console.info(LOG, "initial timeline sync completed", {
				currentTimeMs,
				nextIndex: nextSegmentIndex
			});
		}
		if (lastVideoTimeMs !== null) {
			const deltaMs = currentTimeMs - lastVideoTimeMs;
			const isForwardSeek = deltaMs >= FORWARD_SEEK_THRESHOLD_MS;
			const isBackwardSeek = deltaMs <= -BACKWARD_SEEK_THRESHOLD_MS;
			if (isForwardSeek || isBackwardSeek) realignForSeek(currentTimeMs);
		}
		lastVideoTimeMs = currentTimeMs;
		if (state !== "playing") return;
		const segs = segments.value;
		const lookAheadMs = currentTimeMs + leadTimeMs;
		const maxPreload = CAPTION_NARRATION_CONFIG.maxPreloadSegments;
		let preloadedCount = 0;
		while (nextSegmentIndex < segs.length && preloadedCount < maxPreload) {
			const seg = segs[nextSegmentIndex];
			if (seg.startMs > lookAheadMs) break;
			const isPreloaded = seg.startMs > currentTimeMs;
			callbacks.onSegmentReady(seg.text, activeLanguage, seg.durationMs);
			nextSegmentIndex++;
			if (isPreloaded) preloadedCount++;
		}
	}
	function handleSeek(timeMs) {
		nextSegmentIndex = findSeekIndex(timeMs, false);
		lastVideoTimeMs = timeMs;
		hasInitialTimeSync = true;
	}
	function stop() {
		const wasActive = isActive.value;
		console.debug(LOG, "stop()", {
			wasActive,
			segmentCount: segments.value.length
		});
		if (wasActive) {
			sendToContentScript({ type: "STOP_VIDEO_TIME_MONITOR" });
			callbacks?.onStopped();
		}
		isActive.value = false;
		segments.value = [];
		trackSelection.value = null;
		nextSegmentIndex = 0;
		lastVideoTimeMs = null;
		hasInitialTimeSync = false;
		activeLanguage = "";
		leadTimeMs = 0;
		if (pendingTracks) {
			clearTimeout(pendingTracks.timer);
			pendingTracks = null;
		}
		if (pendingSegments) {
			clearTimeout(pendingSegments.timer);
			pendingSegments = null;
		}
	}
	function dispose() {
		console.debug(LOG, "dispose()");
		stop();
		if (messageHandler) {
			window.removeEventListener("message", messageHandler);
			messageHandler = null;
		}
		callbacks = null;
	}
	return {
		isActive,
		segments,
		trackSelection,
		start,
		stop,
		dispose,
		handleSeek,
		setProvider
	};
}
//#endregion
//#region src/services/openai-meeting-insights-provider.ts
var OpenAIMeetingInsightsProvider = class {
	id = "openai";
	name = "OpenAI Responses API";
	baseUrl = "https://api.openai.com/v1/responses";
	apiKey;
	constructor(apiKey) {
		this.apiKey = apiKey;
	}
	setApiKey(apiKey) {
		this.apiKey = apiKey;
	}
	async generateInsight(request, signal) {
		if (!this.apiKey.trim()) throw new Error("OpenAI API key is not configured");
		const response = await fetch(this.baseUrl, {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${this.apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				model: request.model,
				input: [{
					role: "system",
					content: [{
						type: "input_text",
						text: request.systemPrompt
					}]
				}, {
					role: "user",
					content: [{
						type: "input_text",
						text: buildUserPrompt$1(request)
					}]
				}]
			}),
			signal: signal ?? null
		});
		if (!response.ok) {
			const errorText = await response.text().catch(() => "Unknown error");
			throw new MeetingInsightsApiError(response.status, errorText);
		}
		const output = extractOutputText$1(await response.json()).trim();
		if (!output) throw new Error("AI provider returned an empty response");
		return output;
	}
};
function buildUserPrompt$1(request) {
	return [
		`Requested output: ${request.kind === "summary" ? "Meeting summary" : "Meeting task breakdown"}`,
		"",
		"Translated transcript:",
		request.translatedTranscript || "(empty)"
	].join("\n");
}
function extractOutputText$1(payload) {
	if (typeof payload.output_text === "string" && payload.output_text.trim()) return payload.output_text;
	const textParts = [];
	for (const item of payload.output ?? []) for (const content of item.content ?? []) {
		if (typeof content.text === "string" && content.text.trim()) {
			textParts.push(content.text);
			continue;
		}
		if (content.text && typeof content.text === "object" && typeof content.text.value === "string" && content.text.value.trim()) textParts.push(content.text.value);
	}
	return textParts.join("\n\n");
}
var MeetingInsightsApiError = class extends Error {
	constructor(status, body) {
		super(resolveApiErrorMessage$1(status, body));
		this.status = status;
		this.body = body;
		this.name = "MeetingInsightsApiError";
	}
};
function resolveApiErrorMessage$1(status, body) {
	if (status === 401) return "Invalid OpenAI API key. Please check your key and try again.";
	if (status === 429) return "OpenAI rate limit reached. Please wait a moment and try again.";
	if (status >= 500) return "OpenAI service error. Please try again later.";
	try {
		return JSON.parse(body).error?.message ?? `OpenAI meeting insight error (${status})`;
	} catch {
		return `OpenAI meeting insight error (${status})`;
	}
}
//#endregion
//#region src/services/meeting-insights-provider-factory.ts
var providerBuilders = { openai: (context) => new OpenAIMeetingInsightsProvider(context.apiKey) };
function createMeetingInsightsProvider(providerId, context) {
	const builder = providerBuilders[providerId];
	if (!builder) throw new Error(`Unsupported meeting insights provider: ${providerId}`);
	return builder(context);
}
//#endregion
//#region src/composables/useDownloadTranscript.ts
function formatTimestamp(ms) {
	const totalSeconds = Math.max(0, Math.floor(ms / 1e3));
	const minutes = Math.floor(totalSeconds / 60);
	const seconds = totalSeconds % 60;
	return `${minutes}:${String(seconds).padStart(2, "0")}`;
}
function computeRelativeTimes(entries) {
	if (entries.length === 0) return [];
	const baseTimestamp = entries[0].timestamp;
	return entries.map((entry, index) => {
		const start = entry.timestamp - baseTimestamp;
		const nextEntry = entries[index + 1];
		return {
			start,
			end: nextEntry ? nextEntry.timestamp - baseTimestamp : start + 2e3
		};
	});
}
function resolveSpeaker(entry, speakerNames, speakerPrefix, fallbackLabel) {
	if (entry.audioSource === "mic") return fallbackLabel;
	return resolveSpeakerLabel(entry.speakerId, speakerNames, speakerPrefix, fallbackLabel);
}
function formatAsText(entries, speakerNames, speakerPrefix, fallbackLabel) {
	if (entries.length === 0) return "";
	const times = computeRelativeTimes(entries);
	const lines = [];
	entries.forEach((entry, index) => {
		const { start, end } = times[index];
		const startStr = formatTimestamp(start);
		const endStr = formatTimestamp(end);
		const speaker = resolveSpeaker(entry, speakerNames, speakerPrefix, fallbackLabel);
		if (entry.originalText) lines.push(`[${startStr} - ${endStr}] [${speaker}] [${entry.sourceLanguage || "unknown"}]: ${entry.originalText}`);
		if (entry.translatedText) lines.push(`[${startStr} - ${endStr}] [${speaker}] [${entry.targetLanguage}]: ${entry.translatedText}`);
	});
	return lines.join("\n");
}
function formatAsJson(entries, speakerNames, speakerPrefix, fallbackLabel) {
	if (entries.length === 0) return "[]";
	const times = computeRelativeTimes(entries);
	const result = entries.map((entry, index) => {
		const { start, end } = times[index];
		const speaker = resolveSpeaker(entry, speakerNames, speakerPrefix, fallbackLabel);
		const transcript = {};
		if (entry.originalText) transcript[entry.sourceLanguage || "unknown"] = entry.originalText;
		if (entry.translatedText) transcript[entry.targetLanguage] = entry.translatedText;
		return {
			start: formatTimestamp(start),
			end: formatTimestamp(end),
			speaker,
			transcript
		};
	});
	return JSON.stringify(result, null, 2);
}
function formatSrtTimestamp(ms) {
	const totalMs = Math.max(0, Math.floor(ms));
	const hours = Math.floor(totalMs / 36e5);
	const minutes = Math.floor(totalMs % 36e5 / 6e4);
	const seconds = Math.floor(totalMs % 6e4 / 1e3);
	const milliseconds = totalMs % 1e3;
	return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")},${String(milliseconds).padStart(3, "0")}`;
}
function resolveSrtText(entry, mode) {
	if (mode === "translated") return entry.translatedText?.trim() || "";
	return entry.originalText?.trim() || "";
}
function formatAsSrt(entries, speakerNames, speakerPrefix, fallbackLabel, mode) {
	if (entries.length === 0) return "";
	const times = computeRelativeTimes(entries);
	const blocks = [];
	let subtitleIndex = 1;
	entries.forEach((entry, index) => {
		const text = resolveSrtText(entry, mode);
		if (!text) return;
		const { start, end } = times[index];
		const startStr = formatSrtTimestamp(start);
		const endStr = formatSrtTimestamp(end);
		const speaker = resolveSpeaker(entry, speakerNames, speakerPrefix, fallbackLabel);
		blocks.push(`${subtitleIndex}\n${startStr} --> ${endStr}\n${speaker}: ${text}`);
		subtitleIndex += 1;
	});
	return blocks.join("\n\n");
}
function formatAsTranslatedTranscript(entries, speakerNames, speakerPrefix, fallbackLabel) {
	if (entries.length === 0) return "";
	const times = computeRelativeTimes(entries);
	const lines = [];
	entries.forEach((entry, index) => {
		const translatedText = entry.translatedText?.trim();
		if (!translatedText) return;
		const { start, end } = times[index];
		const speaker = resolveSpeaker(entry, speakerNames, speakerPrefix, fallbackLabel);
		lines.push(`[${formatTimestamp(start)} - ${formatTimestamp(end)}] [${speaker}] [${entry.targetLanguage}]: ${translatedText}`);
	});
	return lines.join("\n");
}
function downloadFile(content, filename, mimeType) {
	const blob = new Blob([content], { type: mimeType });
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	document.body.appendChild(anchor);
	anchor.click();
	document.body.removeChild(anchor);
	URL.revokeObjectURL(url);
}
function buildFilename(prefix, extension) {
	const now = /* @__PURE__ */ new Date();
	return `${prefix}-${now.toISOString().slice(0, 10)}-${now.toTimeString().slice(0, 5).replace(":", "")}.${extension}`;
}
function useDownloadTranscript() {
	const { t } = useI18n();
	const settingsStore = useSettingsStore();
	function resolveMeetingInsightsPrompt(kind) {
		const fallback = kind === "summary" ? DEFAULT_SETTINGS.openaiDownloadSummaryPrompt : DEFAULT_SETTINGS.openaiDownloadTaskPrompt;
		return ((kind === "summary" ? settingsStore.openaiDownloadSummaryPrompt : settingsStore.openaiDownloadTaskPrompt)?.trim() || fallback || "").trim();
	}
	async function generateMeetingInsight(entries, kind, signal) {
		const apiKey = settingsStore.openaiApiKey?.trim() || "";
		if (!apiKey) throw new Error(t("errors.openaiApiKeyRequiredDownload"));
		const translatedTranscript = formatAsTranslatedTranscript(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"));
		if (!translatedTranscript.trim()) throw new Error(t("errors.translatedTranscriptRequired"));
		return await createMeetingInsightsProvider(settingsStore.meetingInsightsProvider ?? "openai", { apiKey }).generateInsight({
			kind,
			model: settingsStore.openaiAssistantModel?.trim() || DEFAULT_SETTINGS.openaiAssistantModel || "gpt-4.1-mini",
			systemPrompt: resolveMeetingInsightsPrompt(kind),
			translatedTranscript
		}, signal);
	}
	function downloadTxt(entries) {
		downloadFile(formatAsText(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown")), buildFilename("transcript", "txt"), "text/plain;charset=utf-8");
	}
	function downloadJson(entries) {
		downloadFile(formatAsJson(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown")), buildFilename("transcript", "json"), "application/json;charset=utf-8");
	}
	function downloadSrtOriginal(entries) {
		downloadFile(formatAsSrt(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"), "original"), buildFilename("transcript-original", "srt"), "text/srt;charset=utf-8");
	}
	function downloadSrtTranslated(entries) {
		downloadFile(formatAsSrt(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"), "translated"), buildFilename("transcript-translated", "srt"), "text/srt;charset=utf-8");
	}
	async function downloadMeetingSummary(entries, signal) {
		downloadFile(await generateMeetingInsight(entries, "summary", signal), buildFilename("meeting-summary", "txt"), "text/plain;charset=utf-8");
	}
	async function downloadMeetingTaskBreakdown(entries, signal) {
		downloadFile(await generateMeetingInsight(entries, "task-breakdown", signal), buildFilename("meeting-task-breakdown", "txt"), "text/plain;charset=utf-8");
	}
	return {
		downloadTxt,
		downloadJson,
		downloadSrtOriginal,
		downloadSrtTranslated,
		downloadMeetingSummary,
		downloadMeetingTaskBreakdown
	};
}
//#endregion
//#region src/composables/useProFeature.ts
function useProFeature(options = {}) {
	const authStore = useAuthStore();
	const isPro = computed(() => authStore.hasActiveLicense);
	async function requirePro(feature) {
		if (!await authStore.revalidateFromStorage()) {
			options.onLocked?.(feature);
			return false;
		}
		return true;
	}
	function openLearnMore() {
		try {
			if (typeof chrome !== "undefined" && chrome.tabs?.create) chrome.tabs.create({ url: EXTENSION_HOMEPAGE });
			else window.open(EXTENSION_HOMEPAGE, "_blank", "noopener");
		} catch {
			window.open(EXTENSION_HOMEPAGE, "_blank", "noopener");
		}
	}
	return {
		isPro,
		requirePro,
		openLearnMore
	};
}
//#endregion
//#region src/components/translator/TranslatorHeader.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$8 = { class: "translator-header" };
var _hoisted_2$8 = { class: "translator-header__inner" };
//#endregion
//#region src/components/translator/TranslatorHeader.vue
var TranslatorHeader_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorHeader",
	props: {
		targetLanguage: {},
		theirLanguage: {},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	emits: ["update:targetLanguage", "update:theirLanguage"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const languageOptions = [...SUPPORTED_LANGUAGES].sort((left, right) => left.label.localeCompare(right.label, "en", { sensitivity: "base" })).map((lang) => ({
			label: `${lang.label} (${lang.nativeLabel})`,
			value: lang.value
		}));
		const theirLanguageOptions = computed(() => [{
			label: "None",
			value: "none"
		}, ...languageOptions]);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$8, [createBaseVNode("div", _hoisted_2$8, [
				createVNode(QSelect_default, {
					"model-value": __props.targetLanguage,
					options: unref(languageOptions),
					dense: "",
					outlined: "",
					"emit-value": "",
					"map-options": "",
					label: _ctx.$t("translator.myLanguage"),
					disable: __props.disabled,
					"popup-content-class": "translator-language-menu",
					class: "translator-language-select",
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:targetLanguage", $event))
				}, {
					prepend: withCtx(() => [createVNode(QIcon_default, {
						name: "person",
						size: "xs"
					})]),
					_: 1
				}, 8, [
					"model-value",
					"options",
					"label",
					"disable"
				]),
				createVNode(QIcon_default, {
					name: "swap_horiz",
					size: "xs",
					class: "translator-header__swap-icon"
				}),
				createVNode(QSelect_default, {
					"model-value": __props.theirLanguage,
					options: theirLanguageOptions.value,
					dense: "",
					outlined: "",
					"emit-value": "",
					"map-options": "",
					label: _ctx.$t("translator.theirLanguage"),
					disable: __props.disabled,
					"popup-content-class": "translator-language-menu",
					class: "translator-language-select",
					"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => emit("update:theirLanguage", $event))
				}, {
					prepend: withCtx(() => [createVNode(QIcon_default, {
						name: "groups",
						size: "xs"
					})]),
					_: 1
				}, 8, [
					"model-value",
					"options",
					"label",
					"disable"
				])
			])]);
		};
	}
}), [["__scopeId", "data-v-5c3f7937"]]);
//#endregion
//#region node_modules/quasar/src/components/scroll-area/ScrollAreaControls.js
/**
* We are using a sub-component to avoid unnecessary re-renders
* of the QScrollArea content when the scrollbars are interacted with.
*/
var ScrollAreaControls_default = createComponent({
	props: [
		"store",
		"barStyle",
		"verticalBarStyle",
		"horizontalBarStyle"
	],
	setup(props) {
		return () => [
			h("div", {
				class: props.store.scroll.vertical.barClass.value,
				style: [props.barStyle, props.verticalBarStyle],
				"aria-hidden": "true",
				onMousedown: props.store.onVerticalMousedown
			}),
			h("div", {
				class: props.store.scroll.horizontal.barClass.value,
				style: [props.barStyle, props.horizontalBarStyle],
				"aria-hidden": "true",
				onMousedown: props.store.onHorizontalMousedown
			}),
			withDirectives(h("div", {
				ref: props.store.scroll.vertical.ref,
				class: props.store.scroll.vertical.thumbClass.value,
				style: props.store.scroll.vertical.style.value,
				"aria-hidden": "true"
			}), props.store.thumbVertDir),
			withDirectives(h("div", {
				ref: props.store.scroll.horizontal.ref,
				class: props.store.scroll.horizontal.thumbClass.value,
				style: props.store.scroll.horizontal.style.value,
				"aria-hidden": "true"
			}), props.store.thumbHorizDir)
		];
	}
});
//#endregion
//#region node_modules/quasar/src/utils/private.touch/touch.js
var modifiersAll = {
	left: true,
	right: true,
	up: true,
	down: true,
	horizontal: true,
	vertical: true
};
var directionList = Object.keys(modifiersAll);
modifiersAll.all = true;
function getModifierDirections(mod) {
	const dir = {};
	for (const direction of directionList) if (mod[direction] === true) dir[direction] = true;
	if (Object.keys(dir).length === 0) return modifiersAll;
	if (dir.horizontal === true) dir.left = dir.right = true;
	else if (dir.left === true && dir.right === true) dir.horizontal = true;
	if (dir.vertical === true) dir.up = dir.down = true;
	else if (dir.up === true && dir.down === true) dir.vertical = true;
	if (dir.horizontal === true && dir.vertical === true) dir.all = true;
	return dir;
}
var avoidNodeNamesList = ["INPUT", "TEXTAREA"];
function shouldStart(evt, ctx) {
	return ctx.event === void 0 && evt.target !== void 0 && evt.target.draggable !== true && typeof ctx.handler === "function" && avoidNodeNamesList.includes(evt.target.nodeName.toUpperCase()) === false && (evt.qClonedBy === void 0 || evt.qClonedBy.indexOf(ctx.uid) === -1);
}
//#endregion
//#region node_modules/quasar/src/directives/touch-pan/TouchPan.js
function getChanges(evt, ctx, isFinal) {
	const pos = position(evt);
	let dir, distX = pos.left - ctx.event.x, distY = pos.top - ctx.event.y, absX = Math.abs(distX), absY = Math.abs(distY);
	const direction = ctx.direction;
	if (direction.horizontal === true && direction.vertical !== true) dir = distX < 0 ? "left" : "right";
	else if (direction.horizontal !== true && direction.vertical === true) dir = distY < 0 ? "up" : "down";
	else if (direction.up === true && distY < 0) {
		dir = "up";
		if (absX > absY) {
			if (direction.left === true && distX < 0) dir = "left";
			else if (direction.right === true && distX > 0) dir = "right";
		}
	} else if (direction.down === true && distY > 0) {
		dir = "down";
		if (absX > absY) {
			if (direction.left === true && distX < 0) dir = "left";
			else if (direction.right === true && distX > 0) dir = "right";
		}
	} else if (direction.left === true && distX < 0) {
		dir = "left";
		if (absX < absY) {
			if (direction.up === true && distY < 0) dir = "up";
			else if (direction.down === true && distY > 0) dir = "down";
		}
	} else if (direction.right === true && distX > 0) {
		dir = "right";
		if (absX < absY) {
			if (direction.up === true && distY < 0) dir = "up";
			else if (direction.down === true && distY > 0) dir = "down";
		}
	}
	let synthetic = false;
	if (dir === void 0 && isFinal === false) {
		if (ctx.event.isFirst === true || ctx.event.lastDir === void 0) return {};
		dir = ctx.event.lastDir;
		synthetic = true;
		if (dir === "left" || dir === "right") {
			pos.left -= distX;
			absX = 0;
			distX = 0;
		} else {
			pos.top -= distY;
			absY = 0;
			distY = 0;
		}
	}
	return {
		synthetic,
		payload: {
			evt,
			touch: ctx.event.mouse !== true,
			mouse: ctx.event.mouse === true,
			position: pos,
			direction: dir,
			isFirst: ctx.event.isFirst,
			isFinal: isFinal === true,
			duration: Date.now() - ctx.event.time,
			distance: {
				x: absX,
				y: absY
			},
			offset: {
				x: distX,
				y: distY
			},
			delta: {
				x: pos.left - ctx.event.lastX,
				y: pos.top - ctx.event.lastY
			}
		}
	};
}
var uid = 0;
var TouchPan_default = createDirective({
	name: "touch-pan",
	beforeMount(el, { value, modifiers }) {
		if (modifiers.mouse !== true && client.has.touch !== true) return;
		function handleEvent(evt, mouseEvent) {
			if (modifiers.mouse === true && mouseEvent === true) stopAndPrevent(evt);
			else {
				modifiers.stop === true && stop(evt);
				modifiers.prevent === true && prevent(evt);
			}
		}
		const ctx = {
			uid: "qvtp_" + uid++,
			handler: value,
			modifiers,
			direction: getModifierDirections(modifiers),
			noop,
			mouseStart(evt) {
				if (shouldStart(evt, ctx) && leftClick(evt)) {
					addEvt(ctx, "temp", [[
						document,
						"mousemove",
						"move",
						"notPassiveCapture"
					], [
						document,
						"mouseup",
						"end",
						"passiveCapture"
					]]);
					ctx.start(evt, true);
				}
			},
			touchStart(evt) {
				if (shouldStart(evt, ctx)) {
					const target = evt.target;
					addEvt(ctx, "temp", [
						[
							target,
							"touchmove",
							"move",
							"notPassiveCapture"
						],
						[
							target,
							"touchcancel",
							"end",
							"passiveCapture"
						],
						[
							target,
							"touchend",
							"end",
							"passiveCapture"
						]
					]);
					ctx.start(evt);
				}
			},
			start(evt, mouseEvent) {
				client.is.firefox === true && preventDraggable(el, true);
				ctx.lastEvt = evt;
				if (mouseEvent === true || modifiers.stop === true) {
					if (ctx.direction.all !== true && (mouseEvent !== true || ctx.modifiers.mouseAllDir !== true && ctx.modifiers.mousealldir !== true)) {
						const clone = evt.type.indexOf("mouse") !== -1 ? new MouseEvent(evt.type, evt) : new TouchEvent(evt.type, evt);
						evt.defaultPrevented === true && prevent(clone);
						evt.cancelBubble === true && stop(clone);
						Object.assign(clone, {
							qKeyEvent: evt.qKeyEvent,
							qClickOutside: evt.qClickOutside,
							qAnchorHandled: evt.qAnchorHandled,
							qClonedBy: evt.qClonedBy === void 0 ? [ctx.uid] : evt.qClonedBy.concat(ctx.uid)
						});
						ctx.initialEvent = {
							target: evt.target,
							event: clone
						};
					}
					stop(evt);
				}
				const { left, top } = position(evt);
				ctx.event = {
					x: left,
					y: top,
					time: Date.now(),
					mouse: mouseEvent === true,
					detected: false,
					isFirst: true,
					isFinal: false,
					lastX: left,
					lastY: top
				};
			},
			move(evt) {
				if (ctx.event === void 0) return;
				const pos = position(evt), distX = pos.left - ctx.event.x, distY = pos.top - ctx.event.y;
				if (distX === 0 && distY === 0) return;
				ctx.lastEvt = evt;
				const isMouseEvt = ctx.event.mouse === true;
				const start = () => {
					handleEvent(evt, isMouseEvt);
					let cursor;
					if (modifiers.preserveCursor !== true && modifiers.preservecursor !== true) {
						cursor = document.documentElement.style.cursor || "";
						document.documentElement.style.cursor = "grabbing";
					}
					isMouseEvt === true && document.body.classList.add("no-pointer-events--children");
					document.body.classList.add("non-selectable");
					clearSelection();
					ctx.styleCleanup = (withDelayedFn) => {
						ctx.styleCleanup = void 0;
						if (cursor !== void 0) document.documentElement.style.cursor = cursor;
						document.body.classList.remove("non-selectable");
						if (isMouseEvt === true) {
							const remove = () => {
								document.body.classList.remove("no-pointer-events--children");
							};
							if (withDelayedFn !== void 0) setTimeout(() => {
								remove();
								withDelayedFn();
							}, 50);
							else remove();
						} else if (withDelayedFn !== void 0) withDelayedFn();
					};
				};
				if (ctx.event.detected === true) {
					ctx.event.isFirst !== true && handleEvent(evt, ctx.event.mouse);
					const { payload, synthetic } = getChanges(evt, ctx, false);
					if (payload !== void 0) if (ctx.handler(payload) === false) ctx.end(evt);
					else {
						if (ctx.styleCleanup === void 0 && ctx.event.isFirst === true) start();
						ctx.event.lastX = payload.position.left;
						ctx.event.lastY = payload.position.top;
						ctx.event.lastDir = synthetic === true ? void 0 : payload.direction;
						ctx.event.isFirst = false;
					}
					return;
				}
				if (ctx.direction.all === true || isMouseEvt === true && (ctx.modifiers.mouseAllDir === true || ctx.modifiers.mousealldir === true)) {
					start();
					ctx.event.detected = true;
					ctx.move(evt);
					return;
				}
				const absX = Math.abs(distX), absY = Math.abs(distY);
				if (absX !== absY) if (ctx.direction.horizontal === true && absX > absY || ctx.direction.vertical === true && absX < absY || ctx.direction.up === true && absX < absY && distY < 0 || ctx.direction.down === true && absX < absY && distY > 0 || ctx.direction.left === true && absX > absY && distX < 0 || ctx.direction.right === true && absX > absY && distX > 0) {
					ctx.event.detected = true;
					ctx.move(evt);
				} else ctx.end(evt, true);
			},
			end(evt, abort) {
				if (ctx.event === void 0) return;
				cleanEvt(ctx, "temp");
				client.is.firefox === true && preventDraggable(el, false);
				if (abort === true) {
					ctx.styleCleanup?.();
					if (ctx.event.detected !== true && ctx.initialEvent !== void 0) ctx.initialEvent.target.dispatchEvent(ctx.initialEvent.event);
				} else if (ctx.event.detected === true) {
					ctx.event.isFirst === true && ctx.handler(getChanges(evt === void 0 ? ctx.lastEvt : evt, ctx).payload);
					const { payload } = getChanges(evt === void 0 ? ctx.lastEvt : evt, ctx, true);
					const fn = () => {
						ctx.handler(payload);
					};
					if (ctx.styleCleanup !== void 0) ctx.styleCleanup(fn);
					else fn();
				}
				ctx.event = void 0;
				ctx.initialEvent = void 0;
				ctx.lastEvt = void 0;
			}
		};
		el.__qtouchpan = ctx;
		if (modifiers.mouse === true) addEvt(ctx, "main", [[
			el,
			"mousedown",
			"mouseStart",
			`passive${modifiers.mouseCapture === true || modifiers.mousecapture === true ? "Capture" : ""}`
		]]);
		client.has.touch === true && addEvt(ctx, "main", [[
			el,
			"touchstart",
			"touchStart",
			`passive${modifiers.capture === true ? "Capture" : ""}`
		], [
			el,
			"touchmove",
			"noop",
			"notPassiveCapture"
		]]);
	},
	updated(el, bindings) {
		const ctx = el.__qtouchpan;
		if (ctx !== void 0) {
			if (bindings.oldValue !== bindings.value) {
				typeof value !== "function" && ctx.end();
				ctx.handler = bindings.value;
			}
			ctx.direction = getModifierDirections(bindings.modifiers);
		}
	},
	beforeUnmount(el) {
		const ctx = el.__qtouchpan;
		if (ctx !== void 0) {
			ctx.event !== void 0 && ctx.end();
			cleanEvt(ctx, "main");
			cleanEvt(ctx, "temp");
			client.is.firefox === true && preventDraggable(el, false);
			ctx.styleCleanup?.();
			delete el.__qtouchpan;
		}
	}
});
//#endregion
//#region node_modules/quasar/src/components/scroll-area/QScrollArea.js
var axisList = ["vertical", "horizontal"];
var dirProps = {
	vertical: {
		offset: "offsetY",
		scroll: "scrollTop",
		dir: "down",
		dist: "y"
	},
	horizontal: {
		offset: "offsetX",
		scroll: "scrollLeft",
		dir: "right",
		dist: "x"
	}
};
var panOpts = {
	prevent: true,
	mouse: true,
	mouseAllDir: true
};
var getMinThumbSize = (size) => size >= 250 ? 50 : Math.ceil(size / 5);
var QScrollArea_default = createComponent({
	name: "QScrollArea",
	props: {
		...useDarkProps,
		thumbStyle: Object,
		verticalThumbStyle: Object,
		horizontalThumbStyle: Object,
		barStyle: [
			Array,
			String,
			Object
		],
		verticalBarStyle: [
			Array,
			String,
			Object
		],
		horizontalBarStyle: [
			Array,
			String,
			Object
		],
		verticalOffset: {
			type: Array,
			default: [0, 0]
		},
		horizontalOffset: {
			type: Array,
			default: [0, 0]
		},
		contentStyle: [
			Array,
			String,
			Object
		],
		contentActiveStyle: [
			Array,
			String,
			Object
		],
		delay: {
			type: [String, Number],
			default: 1e3
		},
		visible: {
			type: Boolean,
			default: null
		},
		tabindex: [String, Number],
		onScroll: Function
	},
	setup(props, { slots, emit }) {
		const tempShowing = ref(false);
		const panning = ref(false);
		const hover = ref(false);
		const container = {
			vertical: ref(0),
			horizontal: ref(0)
		};
		const scroll = {
			vertical: {
				ref: ref(null),
				position: ref(0),
				size: ref(0)
			},
			horizontal: {
				ref: ref(null),
				position: ref(0),
				size: ref(0)
			}
		};
		const { proxy } = getCurrentInstance();
		const isDark = use_dark_default(props, proxy.$q);
		let timer = null, panRefPos;
		const targetRef = ref(null);
		const classes = computed(() => "q-scrollarea" + (isDark.value === true ? " q-scrollarea--dark" : ""));
		Object.assign(container, {
			verticalInner: computed(() => container.vertical.value - props.verticalOffset[0] - props.verticalOffset[1]),
			horizontalInner: computed(() => container.horizontal.value - props.horizontalOffset[0] - props.horizontalOffset[1])
		});
		scroll.vertical.percentage = computed(() => {
			const diff = scroll.vertical.size.value - container.vertical.value;
			if (diff <= 0) return 0;
			const p = between(scroll.vertical.position.value / diff, 0, 1);
			return Math.round(p * 1e4) / 1e4;
		});
		scroll.vertical.thumbHidden = computed(() => (props.visible === null ? hover.value : props.visible) !== true && tempShowing.value === false && panning.value === false || scroll.vertical.size.value <= container.vertical.value + 1);
		scroll.vertical.thumbStart = computed(() => props.verticalOffset[0] + scroll.vertical.percentage.value * (container.verticalInner.value - scroll.vertical.thumbSize.value));
		scroll.vertical.thumbSize = computed(() => Math.round(between(container.verticalInner.value * container.verticalInner.value / scroll.vertical.size.value, getMinThumbSize(container.verticalInner.value), container.verticalInner.value)));
		scroll.vertical.style = computed(() => ({
			...props.thumbStyle,
			...props.verticalThumbStyle,
			top: `${scroll.vertical.thumbStart.value}px`,
			height: `${scroll.vertical.thumbSize.value}px`,
			right: `${props.horizontalOffset[1]}px`
		}));
		scroll.vertical.thumbClass = computed(() => "q-scrollarea__thumb q-scrollarea__thumb--v absolute-right" + (scroll.vertical.thumbHidden.value === true ? " q-scrollarea__thumb--invisible" : ""));
		scroll.vertical.barClass = computed(() => "q-scrollarea__bar q-scrollarea__bar--v absolute-right" + (scroll.vertical.thumbHidden.value === true ? " q-scrollarea__bar--invisible" : ""));
		scroll.horizontal.percentage = computed(() => {
			const diff = scroll.horizontal.size.value - container.horizontal.value;
			if (diff <= 0) return 0;
			const p = between(Math.abs(scroll.horizontal.position.value) / diff, 0, 1);
			return Math.round(p * 1e4) / 1e4;
		});
		scroll.horizontal.thumbHidden = computed(() => (props.visible === null ? hover.value : props.visible) !== true && tempShowing.value === false && panning.value === false || scroll.horizontal.size.value <= container.horizontal.value + 1);
		scroll.horizontal.thumbStart = computed(() => props.horizontalOffset[0] + scroll.horizontal.percentage.value * (container.horizontalInner.value - scroll.horizontal.thumbSize.value));
		scroll.horizontal.thumbSize = computed(() => Math.round(between(container.horizontalInner.value * container.horizontalInner.value / scroll.horizontal.size.value, getMinThumbSize(container.horizontalInner.value), container.horizontalInner.value)));
		scroll.horizontal.style = computed(() => ({
			...props.thumbStyle,
			...props.horizontalThumbStyle,
			[proxy.$q.lang.rtl === true ? "right" : "left"]: `${scroll.horizontal.thumbStart.value}px`,
			width: `${scroll.horizontal.thumbSize.value}px`,
			bottom: `${props.verticalOffset[1]}px`
		}));
		scroll.horizontal.thumbClass = computed(() => "q-scrollarea__thumb q-scrollarea__thumb--h absolute-bottom" + (scroll.horizontal.thumbHidden.value === true ? " q-scrollarea__thumb--invisible" : ""));
		scroll.horizontal.barClass = computed(() => "q-scrollarea__bar q-scrollarea__bar--h absolute-bottom" + (scroll.horizontal.thumbHidden.value === true ? " q-scrollarea__bar--invisible" : ""));
		const mainStyle = computed(() => scroll.vertical.thumbHidden.value === true && scroll.horizontal.thumbHidden.value === true ? props.contentStyle : props.contentActiveStyle);
		function getScroll() {
			const info = {};
			axisList.forEach((axis) => {
				const data = scroll[axis];
				Object.assign(info, {
					[axis + "Position"]: data.position.value,
					[axis + "Percentage"]: data.percentage.value,
					[axis + "Size"]: data.size.value,
					[axis + "ContainerSize"]: container[axis].value,
					[axis + "ContainerInnerSize"]: container[axis + "Inner"].value
				});
			});
			return info;
		}
		const emitScroll = debounce_default(() => {
			const info = getScroll();
			info.ref = proxy;
			emit("scroll", info);
		}, 0);
		function localSetScrollPosition(axis, offset, duration) {
			if (axisList.includes(axis) === false) {
				console.error("[QScrollArea]: wrong first param of setScrollPosition (vertical/horizontal)");
				return;
			}
			(axis === "vertical" ? setVerticalScrollPosition : setHorizontalScrollPosition)(targetRef.value, offset, duration);
		}
		function updateContainer({ height, width }) {
			let change = false;
			if (container.vertical.value !== height) {
				container.vertical.value = height;
				change = true;
			}
			if (container.horizontal.value !== width) {
				container.horizontal.value = width;
				change = true;
			}
			change === true && startTimer();
		}
		function updateScroll({ position }) {
			let change = false;
			if (scroll.vertical.position.value !== position.top) {
				scroll.vertical.position.value = position.top;
				change = true;
			}
			if (scroll.horizontal.position.value !== position.left) {
				scroll.horizontal.position.value = position.left;
				change = true;
			}
			change === true && startTimer();
		}
		function updateScrollSize({ height, width }) {
			if (scroll.horizontal.size.value !== width) {
				scroll.horizontal.size.value = width;
				startTimer();
			}
			if (scroll.vertical.size.value !== height) {
				scroll.vertical.size.value = height;
				startTimer();
			}
		}
		function onPanThumb(e, axis) {
			const data = scroll[axis];
			if (e.isFirst === true) {
				if (data.thumbHidden.value === true) return;
				panRefPos = data.position.value;
				panning.value = true;
			} else if (panning.value !== true) return;
			if (e.isFinal === true) panning.value = false;
			const dProp = dirProps[axis];
			const multiplier = (data.size.value - container[axis].value) / (container[axis + "Inner"].value - data.thumbSize.value);
			const distance = e.distance[dProp.dist];
			setScroll(panRefPos + (e.direction === dProp.dir ? 1 : -1) * distance * multiplier, axis);
		}
		function onMousedown(evt, axis) {
			const data = scroll[axis];
			if (data.thumbHidden.value !== true) {
				const startOffset = axis === "vertical" ? props.verticalOffset[0] : props.horizontalOffset[0];
				const offset = evt[dirProps[axis].offset] - startOffset;
				const thumbStart = data.thumbStart.value - startOffset;
				if (offset < thumbStart || offset > thumbStart + data.thumbSize.value) setScroll(between((offset - data.thumbSize.value / 2) / (container[axis + "Inner"].value - data.thumbSize.value), 0, 1) * Math.max(0, data.size.value - container[axis].value), axis);
				if (data.ref.value !== null) data.ref.value.dispatchEvent(new MouseEvent(evt.type, evt));
			}
		}
		function startTimer() {
			tempShowing.value = true;
			timer !== null && clearTimeout(timer);
			timer = setTimeout(() => {
				timer = null;
				tempShowing.value = false;
			}, props.delay);
			props.onScroll !== void 0 && emitScroll();
		}
		function setScroll(offset, axis) {
			targetRef.value[dirProps[axis].scroll] = offset;
		}
		let mouseEventTimer = null;
		function onMouseenter() {
			if (mouseEventTimer !== null) clearTimeout(mouseEventTimer);
			mouseEventTimer = setTimeout(() => {
				mouseEventTimer = null;
				hover.value = true;
			}, proxy.$q.platform.is.ios ? 50 : 0);
		}
		function onMouseleave() {
			if (mouseEventTimer !== null) {
				clearTimeout(mouseEventTimer);
				mouseEventTimer = null;
			}
			hover.value = false;
		}
		let scrollPosition = null;
		watch(() => proxy.$q.lang.rtl, (rtl) => {
			if (targetRef.value !== null) setHorizontalScrollPosition(targetRef.value, Math.abs(scroll.horizontal.position.value) * (rtl === true ? -1 : 1));
		});
		onDeactivated(() => {
			scrollPosition = {
				top: scroll.vertical.position.value,
				left: scroll.horizontal.position.value
			};
		});
		onActivated(() => {
			if (scrollPosition === null) return;
			const scrollTarget = targetRef.value;
			if (scrollTarget !== null) {
				setHorizontalScrollPosition(scrollTarget, scrollPosition.left);
				setVerticalScrollPosition(scrollTarget, scrollPosition.top);
			}
		});
		onBeforeUnmount(emitScroll.cancel);
		Object.assign(proxy, {
			getScrollTarget: () => targetRef.value,
			getScroll,
			getScrollPosition: () => ({
				top: scroll.vertical.position.value,
				left: scroll.horizontal.position.value
			}),
			getScrollPercentage: () => ({
				top: scroll.vertical.percentage.value,
				left: scroll.horizontal.percentage.value
			}),
			setScrollPosition: localSetScrollPosition,
			setScrollPercentage(axis, percentage, duration) {
				localSetScrollPosition(axis, percentage * (scroll[axis].size.value - container[axis].value) * (axis === "horizontal" && proxy.$q.lang.rtl === true ? -1 : 1), duration);
			}
		});
		const store = {
			scroll,
			thumbVertDir: [[
				TouchPan_default,
				(e) => {
					onPanThumb(e, "vertical");
				},
				void 0,
				{
					vertical: true,
					...panOpts
				}
			]],
			thumbHorizDir: [[
				TouchPan_default,
				(e) => {
					onPanThumb(e, "horizontal");
				},
				void 0,
				{
					horizontal: true,
					...panOpts
				}
			]],
			onVerticalMousedown(evt) {
				onMousedown(evt, "vertical");
			},
			onHorizontalMousedown(evt) {
				onMousedown(evt, "horizontal");
			}
		};
		return () => {
			return h("div", {
				class: classes.value,
				onMouseenter,
				onMouseleave
			}, [
				h("div", {
					ref: targetRef,
					class: "q-scrollarea__container scroll relative-position fit hide-scrollbar",
					tabindex: props.tabindex !== void 0 ? props.tabindex : void 0
				}, [h("div", {
					class: "q-scrollarea__content absolute",
					style: mainStyle.value
				}, hMergeSlot(slots.default, [h(QResizeObserver_default, {
					debounce: 0,
					onResize: updateScrollSize
				})])), h(QScrollObserver_default, {
					axis: "both",
					onScroll: updateScroll
				})]),
				h(QResizeObserver_default, {
					debounce: 0,
					onResize: updateContainer
				}),
				h(ScrollAreaControls_default, {
					store,
					barStyle: props.barStyle,
					verticalBarStyle: props.verticalBarStyle,
					horizontalBarStyle: props.horizontalBarStyle
				})
			]);
		};
	}
});
//#endregion
//#region src/components/translator/TranslatorDisplay.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$7 = { class: "translator-display-wrapper" };
var _hoisted_2$7 = { class: "translator-display__inner" };
var _hoisted_3$7 = {
	key: 0,
	class: "empty-state"
};
var _hoisted_4$7 = { class: "empty-state__text" };
var _hoisted_5$7 = ["onMouseenter", "onMouseleave"];
var _hoisted_6$5 = { class: "original-text" };
var _hoisted_7$5 = { class: "translated-row" };
var _hoisted_8$5 = ["onClick"];
var _hoisted_9$4 = { class: "speaker-label" };
var _hoisted_10$4 = { class: "original-text" };
var _hoisted_11$4 = { class: "translated-row" };
var _hoisted_12$4 = { class: "speaker-label speaker-label--mic" };
var _hoisted_13$3 = { class: "original-text" };
var _hoisted_14$3 = { class: "translated-row" };
var _hoisted_15$3 = {
	key: 0,
	class: "scroll-to-latest-wrapper"
};
var pauseThresholdPx = 40;
var INLINE_ASSISTANT_LOG_PREFIX$1 = "[InlineAssistant:UI]";
//#endregion
//#region src/components/translator/TranslatorDisplay.vue
var TranslatorDisplay_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorDisplay",
	props: {
		entries: {},
		currentSpeakerId: {},
		currentOriginal: {},
		currentTranslation: {},
		isActive: { type: Boolean },
		translationFontSize: { default: "medium" }
	},
	emits: ["open-assistant", "open-settings"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const { t } = useI18n();
		const store = useTranslatorStore();
		const settingsStore = useSettingsStore();
		const scrollRef = ref(null);
		const autoScrollEnabled = ref(true);
		const showScrollToLatest = computed(() => !autoScrollEnabled.value);
		const hoveredEntryId = ref(null);
		const scrollThumbStyle = {
			right: "2px",
			width: "6px",
			borderRadius: "999px",
			background: "rgba(138, 180, 248, 0.45)",
			opacity: "0.92"
		};
		const scrollBarStyle = {
			right: "1px",
			width: "8px",
			borderRadius: "999px",
			background: "rgba(255, 255, 255, 0.07)",
			opacity: "0.8"
		};
		const hasTabCurrent = computed(() => Boolean(store.currentTab.original || store.currentTab.translation));
		const hasMicCurrent = computed(() => Boolean(store.currentMic.original || store.currentMic.translation));
		const hasConfiguredApiKey = computed(() => Boolean(settingsStore.apiKey?.trim()));
		const emptyStateMessageKey = computed(() => hasConfiguredApiKey.value ? "translator.emptyStateReady" : "translator.emptyState");
		const translatedFontClass = computed(() => `translated-text--${props.translationFontSize}`);
		const assistantBtnSize = computed(() => {
			if (props.translationFontSize === "small") return "24px";
			if (props.translationFontSize === "large") return "32px";
			return "28px";
		});
		const fallbackTargetLanguage = computed(() => props.entries[props.entries.length - 1]?.targetLanguage ?? "vi");
		const currentTabInlineEntry = computed(() => ({
			id: "current-tab-inline",
			timestamp: Date.now(),
			speakerId: store.currentTab.speakerId ?? "unknown",
			originalText: store.currentTab.original,
			translatedText: store.currentTab.translation,
			sourceLanguage: "",
			targetLanguage: fallbackTargetLanguage.value,
			isFinal: false,
			audioSource: "tab"
		}));
		const currentMicInlineEntry = computed(() => ({
			id: "current-mic-inline",
			timestamp: Date.now(),
			speakerId: store.currentMic.speakerId ?? "unknown",
			originalText: store.currentMic.original,
			translatedText: store.currentMic.translation,
			sourceLanguage: "",
			targetLanguage: fallbackTargetLanguage.value,
			isFinal: false,
			audioSource: "mic"
		}));
		function getDistanceFromBottom(el) {
			return Math.max(0, el.scrollHeight - (el.scrollTop + el.clientHeight));
		}
		function isScrollAreaPayload(value) {
			if (!value || typeof value !== "object") return false;
			const payload = value;
			return typeof payload.verticalPosition === "number" && typeof payload.verticalSize === "number" && typeof payload.verticalContainerSize === "number";
		}
		function isScrollableDomElement(value) {
			if (!value || typeof value !== "object") return false;
			const candidate = value;
			return typeof candidate.scrollTop === "number" && typeof candidate.scrollHeight === "number" && typeof candidate.clientHeight === "number";
		}
		function getScrollContainerFromRef() {
			const current = scrollRef.value;
			if (isScrollableDomElement(current)) return current;
			return null;
		}
		function scrollToBottom() {
			nextTick(() => {
				const current = scrollRef.value;
				if (!current) return;
				if ("setScrollPosition" in current && typeof current.setScrollPosition === "function") {
					current.setScrollPosition("vertical", Number.MAX_SAFE_INTEGER, 0);
					return;
				}
				const scrollContainer = getScrollContainerFromRef();
				if (scrollContainer) scrollContainer.scrollTop = scrollContainer.scrollHeight;
			});
		}
		watch(() => [props.entries.length, props.currentTranslation], () => {
			if (autoScrollEnabled.value) scrollToBottom();
		});
		function speakerLabel(entry) {
			if (entry.audioSource === "mic") return t("translator.you");
			return resolveSpeakerLabel(entry.speakerId, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"));
		}
		function currentSpeakerLabel(speakerId, isMic) {
			if (isMic) return t("translator.you");
			return resolveSpeakerLabel(speakerId, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"));
		}
		function handleScroll(payload) {
			let distance = null;
			if (isScrollAreaPayload(payload)) distance = Math.max(0, payload.verticalSize - (payload.verticalPosition + payload.verticalContainerSize));
			else if (payload && "target" in payload) {
				const target = payload.target;
				if (isScrollableDomElement(target)) distance = getDistanceFromBottom(target);
			}
			if (distance === null) {
				const scrollContainer = getScrollContainerFromRef();
				if (scrollContainer) distance = getDistanceFromBottom(scrollContainer);
			}
			if (distance !== null && distance > pauseThresholdPx) autoScrollEnabled.value = false;
		}
		function scrollToLatestAndResume() {
			autoScrollEnabled.value = true;
			scrollToBottom();
		}
		function handleEntryMouseEnter(entryId) {
			hoveredEntryId.value = entryId;
		}
		function handleEntryMouseLeave(entryId) {
			if (hoveredEntryId.value === entryId) hoveredEntryId.value = null;
		}
		function isAssistantVisible(entryId) {
			return hoveredEntryId.value === entryId;
		}
		function openAssistant(entry) {
			console.log(INLINE_ASSISTANT_LOG_PREFIX$1, "assistant-opened", {
				entryId: entry.id,
				isFinal: entry.isFinal,
				audioSource: entry.audioSource ?? "tab"
			});
			emit("open-assistant", { entry });
		}
		function openSettings() {
			emit("open-settings");
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$7, [createVNode(QScrollArea_default, {
				ref_key: "scrollRef",
				ref: scrollRef,
				class: "translator-display",
				"thumb-style": scrollThumbStyle,
				"bar-style": scrollBarStyle,
				onScroll: handleScroll
			}, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_2$7, [
					__props.entries.length === 0 && !__props.currentOriginal && !__props.currentTranslation ? (openBlock(), createElementBlock("div", _hoisted_3$7, [
						createVNode(QIcon_default, {
							name: "subtitles",
							size: "48px",
							class: "empty-state__icon"
						}),
						createBaseVNode("p", _hoisted_4$7, toDisplayString(_ctx.$t(emptyStateMessageKey.value)), 1),
						!hasConfiguredApiKey.value ? (openBlock(), createElementBlock("button", {
							key: 0,
							class: "empty-state__settings-link",
							type: "button",
							onClick: openSettings
						}, toDisplayString(_ctx.$t("settings.goToSettings")), 1)) : createCommentVNode("", true)
					])) : createCommentVNode("", true),
					(openBlock(true), createElementBlock(Fragment, null, renderList(__props.entries, (entry) => {
						return openBlock(), createElementBlock("div", {
							key: entry.id,
							class: normalizeClass(["translation-entry", { "translation-entry--mic": entry.audioSource === "mic" }]),
							onMouseenter: ($event) => handleEntryMouseEnter(entry.id),
							onMouseleave: ($event) => handleEntryMouseLeave(entry.id)
						}, [
							createBaseVNode("div", { class: normalizeClass(["speaker-label", { "speaker-label--mic": entry.audioSource === "mic" }]) }, toDisplayString(speakerLabel(entry)), 3),
							createBaseVNode("div", _hoisted_6$5, toDisplayString(entry.originalText), 1),
							createBaseVNode("div", _hoisted_7$5, [createBaseVNode("div", { class: normalizeClass(["translated-text", translatedFontClass.value]) }, toDisplayString(entry.translatedText), 3), createBaseVNode("div", { class: normalizeClass(["inline-assistant-wrapper", { "inline-assistant-wrapper--visible": isAssistantVisible(entry.id) }]) }, [createBaseVNode("button", {
								class: "inline-assistant-btn",
								style: normalizeStyle({
									width: assistantBtnSize.value,
									height: assistantBtnSize.value
								}),
								onClick: ($event) => openAssistant(entry)
							}, [createVNode(QIcon_default, {
								name: "smart_toy",
								size: "16px"
							}), createVNode(QTooltip_default, null, {
								default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
								_: 1
							})], 12, _hoisted_8$5)], 2)])
						], 42, _hoisted_5$7);
					}), 128)),
					hasTabCurrent.value ? (openBlock(), createElementBlock("div", {
						key: 1,
						class: "translation-entry translation-entry--active",
						onMouseenter: _cache[1] || (_cache[1] = ($event) => handleEntryMouseEnter("current-tab-inline")),
						onMouseleave: _cache[2] || (_cache[2] = ($event) => handleEntryMouseLeave("current-tab-inline"))
					}, [
						createBaseVNode("div", _hoisted_9$4, toDisplayString(currentSpeakerLabel(unref(store).currentTab.speakerId, false)), 1),
						createBaseVNode("div", _hoisted_10$4, toDisplayString(unref(store).currentTab.original), 1),
						createBaseVNode("div", _hoisted_11$4, [createBaseVNode("div", { class: normalizeClass(["translated-text", translatedFontClass.value]) }, [createTextVNode(toDisplayString(unref(store).currentTab.translation) + " ", 1), _cache[6] || (_cache[6] = createBaseVNode("span", { class: "typing-indicator" }, [
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" })
						], -1))], 2), createBaseVNode("div", { class: normalizeClass(["inline-assistant-wrapper", { "inline-assistant-wrapper--visible": isAssistantVisible("current-tab-inline") }]) }, [createBaseVNode("button", {
							class: "inline-assistant-btn",
							style: normalizeStyle({
								width: assistantBtnSize.value,
								height: assistantBtnSize.value
							}),
							onClick: _cache[0] || (_cache[0] = ($event) => openAssistant(currentTabInlineEntry.value))
						}, [createVNode(QIcon_default, {
							name: "smart_toy",
							size: "16px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
							_: 1
						})], 4)], 2)])
					], 32)) : createCommentVNode("", true),
					hasMicCurrent.value ? (openBlock(), createElementBlock("div", {
						key: 2,
						class: "translation-entry translation-entry--active translation-entry--mic",
						onMouseenter: _cache[4] || (_cache[4] = ($event) => handleEntryMouseEnter("current-mic-inline")),
						onMouseleave: _cache[5] || (_cache[5] = ($event) => handleEntryMouseLeave("current-mic-inline"))
					}, [
						createBaseVNode("div", _hoisted_12$4, toDisplayString(currentSpeakerLabel(unref(store).currentMic.speakerId, true)), 1),
						createBaseVNode("div", _hoisted_13$3, toDisplayString(unref(store).currentMic.original), 1),
						createBaseVNode("div", _hoisted_14$3, [createBaseVNode("div", { class: normalizeClass(["translated-text", translatedFontClass.value]) }, [createTextVNode(toDisplayString(unref(store).currentMic.translation) + " ", 1), _cache[7] || (_cache[7] = createBaseVNode("span", { class: "typing-indicator" }, [
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" })
						], -1))], 2), createBaseVNode("div", { class: normalizeClass(["inline-assistant-wrapper", { "inline-assistant-wrapper--visible": isAssistantVisible("current-mic-inline") }]) }, [createBaseVNode("button", {
							class: "inline-assistant-btn",
							style: normalizeStyle({
								width: assistantBtnSize.value,
								height: assistantBtnSize.value
							}),
							onClick: _cache[3] || (_cache[3] = ($event) => openAssistant(currentMicInlineEntry.value))
						}, [createVNode(QIcon_default, {
							name: "smart_toy",
							size: "16px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
							_: 1
						})], 4)], 2)])
					], 32)) : createCommentVNode("", true)
				])]),
				_: 1
			}, 512), showScrollToLatest.value ? (openBlock(), createElementBlock("div", _hoisted_15$3, [createVNode(QBtn_default, {
				color: "primary",
				unelevated: "",
				"no-caps": "",
				dense: "",
				rounded: "",
				label: _ctx.$t("translator.scrollToLatest"),
				onClick: scrollToLatestAndResume
			}, null, 8, ["label"])])) : createCommentVNode("", true)]);
		};
	}
}), [["__scopeId", "data-v-85fd2f2b"]]);
//#endregion
//#region node_modules/quasar/src/components/fab/use-fab.js
var labelPositions = [
	"top",
	"right",
	"bottom",
	"left"
];
var useFabProps = {
	type: {
		type: String,
		default: "a"
	},
	outline: Boolean,
	push: Boolean,
	flat: Boolean,
	unelevated: Boolean,
	color: String,
	textColor: String,
	glossy: Boolean,
	square: Boolean,
	padding: String,
	label: {
		type: [String, Number],
		default: ""
	},
	labelPosition: {
		type: String,
		default: "right",
		validator: (v) => labelPositions.includes(v)
	},
	externalLabel: Boolean,
	hideLabel: { type: Boolean },
	labelClass: [
		Array,
		String,
		Object
	],
	labelStyle: [
		Array,
		String,
		Object
	],
	disable: Boolean,
	tabindex: [Number, String]
};
function use_fab_default(props, showing) {
	return {
		formClass: computed(() => `q-fab--form-${props.square === true ? "square" : "rounded"}`),
		stacked: computed(() => props.externalLabel === false && ["top", "bottom"].includes(props.labelPosition)),
		labelProps: computed(() => {
			if (props.externalLabel === true) {
				const hideLabel = props.hideLabel === null ? showing.value === false : props.hideLabel;
				return {
					action: "push",
					data: {
						class: [props.labelClass, `q-fab__label q-tooltip--style q-fab__label--external q-fab__label--external-${props.labelPosition}` + (hideLabel === true ? " q-fab__label--external-hidden" : "")],
						style: props.labelStyle
					}
				};
			}
			return {
				action: ["left", "top"].includes(props.labelPosition) ? "unshift" : "push",
				data: {
					class: [props.labelClass, `q-fab__label q-fab__label--internal q-fab__label--internal-${props.labelPosition}` + (props.hideLabel === true ? " q-fab__label--internal-hidden" : "")],
					style: props.labelStyle
				}
			};
		})
	};
}
//#endregion
//#region node_modules/quasar/src/components/fab/QFabAction.js
var anchorMap = {
	start: "self-end",
	center: "self-center",
	end: "self-start"
};
var anchorValues = Object.keys(anchorMap);
var QFabAction_default = createComponent({
	name: "QFabAction",
	props: {
		...useFabProps,
		icon: {
			type: String,
			default: ""
		},
		anchor: {
			type: String,
			validator: (v) => anchorValues.includes(v)
		},
		to: [String, Object],
		replace: Boolean
	},
	emits: ["click"],
	setup(props, { slots, emit }) {
		const $fab = inject(fabKey, () => ({
			showing: { value: true },
			onChildClick: noop
		}));
		const { formClass, labelProps } = use_fab_default(props, $fab.showing);
		const classes = computed(() => {
			const align = anchorMap[props.anchor];
			return formClass.value + (align !== void 0 ? ` ${align}` : "");
		});
		const isDisabled = computed(() => props.disable === true || $fab.showing.value !== true);
		function click(e) {
			$fab.onChildClick(e);
			emit("click", e);
		}
		function getContent() {
			const child = [];
			if (slots.icon !== void 0) child.push(slots.icon());
			else if (props.icon !== "") child.push(h(QIcon_default, { name: props.icon }));
			if (props.label !== "" || slots.label !== void 0) child[labelProps.value.action](h("div", labelProps.value.data, slots.label !== void 0 ? slots.label() : [props.label]));
			return hMergeSlot(slots.default, child);
		}
		const vm = getCurrentInstance();
		Object.assign(vm.proxy, { click });
		return () => h(QBtn_default, {
			class: classes.value,
			...props,
			noWrap: true,
			stack: props.stacked,
			icon: void 0,
			label: void 0,
			noCaps: true,
			fabMini: true,
			disable: isDisabled.value,
			onClick: click
		}, getContent);
	}
});
//#endregion
//#region node_modules/quasar/src/components/fab/QFab.js
var directions = [
	"up",
	"right",
	"down",
	"left"
];
var alignValues = [
	"left",
	"center",
	"right"
];
var QFab_default = createComponent({
	name: "QFab",
	props: {
		...useFabProps,
		...useModelToggleProps,
		icon: String,
		activeIcon: String,
		hideIcon: Boolean,
		hideLabel: {
			...useFabProps.hideLabel,
			default: null
		},
		direction: {
			type: String,
			default: "right",
			validator: (v) => directions.includes(v)
		},
		persistent: Boolean,
		verticalActionsAlign: {
			type: String,
			default: "center",
			validator: (v) => alignValues.includes(v)
		}
	},
	emits: useModelToggleEmits,
	setup(props, { slots }) {
		const triggerRef = ref(null);
		const showing = ref(props.modelValue === true);
		const targetUid = use_id_default();
		const { proxy: { $q } } = getCurrentInstance();
		const { formClass, labelProps } = use_fab_default(props, showing);
		const { hide, toggle } = use_model_toggle_default({
			showing,
			hideOnRouteChange: computed(() => props.persistent !== true)
		});
		const slotScope = computed(() => ({ opened: showing.value }));
		const classes = computed(() => `q-fab z-fab row inline justify-center q-fab--align-${props.verticalActionsAlign} ${formClass.value}` + (showing.value === true ? " q-fab--opened" : " q-fab--closed"));
		const actionClass = computed(() => `q-fab__actions flex no-wrap inline q-fab__actions--${props.direction} q-fab__actions--${showing.value === true ? "opened" : "closed"}`);
		const actionAttrs = computed(() => {
			const attrs = {
				id: targetUid.value,
				role: "menu"
			};
			if (showing.value !== true) attrs["aria-hidden"] = "true";
			return attrs;
		});
		const iconHolderClass = computed(() => `q-fab__icon-holder  q-fab__icon-holder--${showing.value === true ? "opened" : "closed"}`);
		function getIcon(kebab, camel) {
			const slotFn = slots[kebab];
			const classes = `q-fab__${kebab} absolute-full`;
			return slotFn === void 0 ? h(QIcon_default, {
				class: classes,
				name: props[camel] || $q.iconSet.fab[camel]
			}) : h("div", { class: classes }, slotFn(slotScope.value));
		}
		function getTriggerContent() {
			const child = [];
			props.hideIcon !== true && child.push(h("div", { class: iconHolderClass.value }, [getIcon("icon", "icon"), getIcon("active-icon", "activeIcon")]));
			if (props.label !== "" || slots.label !== void 0) child[labelProps.value.action](h("div", labelProps.value.data, slots.label !== void 0 ? slots.label(slotScope.value) : [props.label]));
			return hMergeSlot(slots.tooltip, child);
		}
		provide(fabKey, {
			showing,
			onChildClick(evt) {
				hide(evt);
				if (evt?.qAvoidFocus !== true) triggerRef.value?.$el.focus();
			}
		});
		return () => h("div", { class: classes.value }, [h(QBtn_default, {
			ref: triggerRef,
			class: formClass.value,
			...props,
			noWrap: true,
			stack: props.stacked,
			align: void 0,
			icon: void 0,
			label: void 0,
			noCaps: true,
			fab: true,
			"aria-expanded": showing.value === true ? "true" : "false",
			"aria-haspopup": "true",
			"aria-controls": targetUid.value,
			onClick: toggle
		}, getTriggerContent), h("div", {
			class: actionClass.value,
			...actionAttrs.value
		}, hSlot(slots.default))]);
	}
});
//#endregion
//#region src/components/translator/TranslatorControls.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = { class: "translator-controls" };
var _hoisted_2$6 = {
	key: 0,
	class: "state-indicator"
};
var _hoisted_3$6 = {
	key: 0,
	class: "realtime-badge realtime-badge--translating"
};
var _hoisted_4$6 = {
	key: 1,
	class: "realtime-badge realtime-badge--listening"
};
var _hoisted_5$6 = { class: "controls-row" };
var _hoisted_6$4 = ["disabled"];
var _hoisted_7$4 = ["disabled"];
var _hoisted_8$4 = { class: "font-size-fab-wrapper" };
var unavailableFeatureTooltip = "translator.featureUnavailableOnThisPage";
//#endregion
//#region src/components/translator/TranslatorControls.vue
var TranslatorControls_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorControls",
	props: {
		recordingState: {},
		hasApiKey: { type: Boolean },
		microphoneEnabled: { type: Boolean },
		sendMyTranslationViaChat: { type: Boolean },
		narrationEnabled: { type: Boolean },
		ttsSpeaking: { type: Boolean },
		showSaveTranscript: { type: Boolean },
		translationFontSize: {},
		isPro: { type: Boolean },
		narrateMyVoice: { type: Boolean },
		isRealtimeListening: { type: Boolean },
		isNarrating: { type: Boolean },
		hasActiveContext: { type: Boolean },
		callFeaturesAvailable: { type: Boolean }
	},
	emits: [
		"start",
		"pause",
		"resume",
		"end",
		"toggle-microphone",
		"toggle-send-my-translation-via-chat",
		"open-narration-settings",
		"open-assistant",
		"open-speaker-settings",
		"open-context-settings",
		"save-transcript",
		"update-translation-font-size",
		"locked-action"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const isFontSizeMenuOpen = ref(false);
		const isContextMenuOpen = ref(false);
		const fontSizeOptions = [
			{
				value: "small",
				labelKey: "translator.fontSizeSmall",
				buttonClass: "font-size-action--small"
			},
			{
				value: "medium",
				labelKey: "translator.fontSizeMedium",
				buttonClass: "font-size-action--medium"
			},
			{
				value: "large",
				labelKey: "translator.fontSizeLarge",
				buttonClass: "font-size-action--large"
			}
		];
		const isStartState = computed(() => props.recordingState === "idle" || props.recordingState === "stopped" || props.recordingState === "error" || props.recordingState === "canceled");
		const canStart = computed(() => props.hasApiKey && isStartState.value);
		const showStart = computed(() => isStartState.value);
		const isPreparing = computed(() => props.recordingState === "starting" || props.recordingState === "connecting");
		const showPause = computed(() => props.recordingState === "recording" || props.recordingState === "starting" || props.recordingState === "connecting");
		const showResume = computed(() => props.recordingState === "paused");
		const showEnd = computed(() => showPause.value || showResume.value);
		const stateColor = computed(() => {
			if (!props.hasApiKey && isStartState.value) return "warning";
			switch (props.recordingState) {
				case "recording": return "positive";
				case "starting":
				case "connecting": return "warning";
				case "paused": return "warning";
				case "error": return "negative";
				default: return "grey";
			}
		});
		const stateLabel = computed(() => {
			if (!props.hasApiKey && isStartState.value) return "settings.noApiKey";
			switch (props.recordingState) {
				case "recording": return "translator.recording";
				case "starting":
				case "connecting": return "translator.connecting";
				case "paused": return "translator.paused";
				case "error": return "translator.error";
				case "stopped": return "translator.stopped";
				default: return "";
			}
		});
		const areCallFeatureControlsDisabled = computed(() => props.callFeaturesAvailable === false);
		const microphoneTooltip = computed(() => areCallFeatureControlsDisabled.value ? unavailableFeatureTooltip : "translator.microphone");
		const sendMyTranslationViaChatTooltip = computed(() => {
			if (areCallFeatureControlsDisabled.value) return unavailableFeatureTooltip;
			if (!props.isPro) return "pro.featureLocked";
			if (props.sendMyTranslationViaChat) return "translator.interpreterModeActive";
			return "translator.sendMyTranslationViaChatHint";
		});
		const isAnyNarrationModeEnabled = computed(() => Boolean(props.narrationEnabled || props.narrateMyVoice));
		const narrationSettingsIcon = computed(() => {
			if (props.narrationEnabled) return "transcribe";
			if (props.narrateMyVoice) return "record_voice_over";
			return "voice_over_off";
		});
		function handleSendMyTranslationViaChatToggle() {
			if (areCallFeatureControlsDisabled.value) return;
			if (!props.isPro) {
				emit("locked-action");
				return;
			}
			emit("toggle-send-my-translation-via-chat", !(props.sendMyTranslationViaChat ?? false));
		}
		function handleMicrophoneToggle() {
			if (areCallFeatureControlsDisabled.value) return;
			emit("toggle-microphone", !props.microphoneEnabled);
		}
		function handleTranslationFontSizeSelect(size) {
			emit("update-translation-font-size", size);
			isFontSizeMenuOpen.value = false;
		}
		function handleOpenContextSettings() {
			emit("open-context-settings");
			isContextMenuOpen.value = false;
		}
		function handleOpenSpeakerSettings() {
			emit("open-speaker-settings");
			isContextMenuOpen.value = false;
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$6, [stateLabel.value ? (openBlock(), createElementBlock("div", _hoisted_2$6, [
				createVNode(QBadge_default, {
					color: stateColor.value,
					rounded: "",
					class: "state-dot"
				}, null, 8, ["color"]),
				createBaseVNode("span", { class: normalizeClass(["state-text", `text-${stateColor.value}`]) }, toDisplayString(_ctx.$t(stateLabel.value)), 3),
				__props.narrateMyVoice && __props.isNarrating ? (openBlock(), createElementBlock("span", _hoisted_3$6, [createVNode(QIcon_default, {
					name: "interpreter_mode",
					size: "12px"
				}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.narratingMyVoice")), 1)])) : __props.narrateMyVoice && __props.isRealtimeListening ? (openBlock(), createElementBlock("span", _hoisted_4$6, [createVNode(QIcon_default, {
					name: "mic",
					size: "12px"
				}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.narrateMyVoiceReady")), 1)])) : createCommentVNode("", true)
			])) : createCommentVNode("", true), createBaseVNode("div", _hoisted_5$6, [
				showStart.value ? (openBlock(), createElementBlock("button", {
					key: 0,
					class: normalizeClass(["gc-btn", { "gc-btn--disabled": !canStart.value }]),
					disabled: !canStart.value,
					onClick: _cache[0] || (_cache[0] = ($event) => emit("start"))
				}, [createVNode(QIcon_default, {
					name: "play_arrow",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.start")), 1)]),
					_: 1
				})], 10, _hoisted_6$4)) : createCommentVNode("", true),
				showEnd.value ? (openBlock(), createElementBlock("button", {
					key: 1,
					class: "gc-btn gc-btn--end",
					onClick: _cache[1] || (_cache[1] = ($event) => emit("end"))
				}, [createVNode(QIcon_default, {
					name: "stop",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.end")), 1)]),
					_: 1
				})])) : createCommentVNode("", true),
				showPause.value ? (openBlock(), createElementBlock("button", {
					key: 2,
					class: normalizeClass(["gc-btn", { "gc-btn--disabled": isPreparing.value }]),
					disabled: isPreparing.value,
					onClick: _cache[2] || (_cache[2] = ($event) => emit("pause"))
				}, [createVNode(QIcon_default, {
					name: "pause",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.pause")), 1)]),
					_: 1
				})], 10, _hoisted_7$4)) : showResume.value ? (openBlock(), createElementBlock("button", {
					key: 3,
					class: "gc-btn",
					onClick: _cache[3] || (_cache[3] = ($event) => emit("resume"))
				}, [createVNode(QIcon_default, {
					name: "play_arrow",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.resume")), 1)]),
					_: 1
				})])) : createCommentVNode("", true),
				createBaseVNode("button", {
					class: normalizeClass(["gc-btn", {
						"gc-btn--enabled": __props.microphoneEnabled,
						"gc-btn--disabled-unavailable": areCallFeatureControlsDisabled.value
					}]),
					onClick: handleMicrophoneToggle
				}, [createVNode(QIcon_default, {
					name: __props.microphoneEnabled ? "mic" : "mic_off",
					size: "20px"
				}, null, 8, ["name"]), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(microphoneTooltip.value)), 1)]),
					_: 1
				})], 2),
				createBaseVNode("button", {
					class: normalizeClass(["gc-btn", {
						"gc-btn--enabled": __props.sendMyTranslationViaChat,
						"gc-btn--locked": !__props.isPro,
						"gc-btn--disabled-unavailable": areCallFeatureControlsDisabled.value
					}]),
					onClick: handleSendMyTranslationViaChatToggle
				}, [
					createVNode(QIcon_default, {
						name: "read_more",
						size: "20px"
					}),
					!__props.isPro ? (openBlock(), createBlock(QIcon_default, {
						key: 0,
						name: "lock",
						size: "10px",
						class: "lock-badge"
					})) : createCommentVNode("", true),
					createVNode(QTooltip_default, null, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(sendMyTranslationViaChatTooltip.value)), 1)]),
						_: 1
					})
				], 2),
				createBaseVNode("button", {
					class: normalizeClass(["gc-btn", {
						"gc-btn--enabled": isAnyNarrationModeEnabled.value,
						"gc-btn--narration-speaking": __props.narrationEnabled && __props.ttsSpeaking
					}]),
					onClick: _cache[4] || (_cache[4] = ($event) => emit("open-narration-settings"))
				}, [createVNode(QIcon_default, {
					name: narrationSettingsIcon.value,
					size: "20px"
				}, null, 8, ["name"]), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrationSettings")), 1)]),
					_: 1
				})], 2),
				__props.isPro ? (openBlock(), createElementBlock("button", {
					key: 4,
					class: "gc-btn",
					onClick: _cache[5] || (_cache[5] = ($event) => emit("open-assistant"))
				}, [createVNode(QIcon_default, {
					name: "assistant",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
					_: 1
				})])) : (openBlock(), createElementBlock("button", {
					key: 5,
					class: "gc-btn gc-btn--locked",
					onClick: _cache[6] || (_cache[6] = ($event) => emit("locked-action"))
				}, [
					createVNode(QIcon_default, {
						name: "assistant",
						size: "20px"
					}),
					createVNode(QIcon_default, {
						name: "lock",
						size: "10px",
						class: "lock-badge"
					}),
					createVNode(QTooltip_default, null, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
						_: 1
					})
				])),
				createBaseVNode("div", _hoisted_8$4, [createVNode(QFab_default, {
					modelValue: isFontSizeMenuOpen.value,
					"onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => isFontSizeMenuOpen.value = $event),
					icon: "format_size",
					"active-icon": "close",
					direction: "up",
					flat: "",
					padding: "0",
					class: "font-size-fab"
				}, {
					default: withCtx(() => [(openBlock(), createElementBlock(Fragment, null, renderList(fontSizeOptions, (option) => {
						return createVNode(QFabAction_default, {
							key: option.value,
							icon: "format_size",
							class: normalizeClass(["font-size-action", option.buttonClass]),
							color: props.translationFontSize === option.value ? "primary" : "grey-8",
							"text-color": "white",
							onClick: ($event) => handleTranslationFontSizeSelect(option.value)
						}, {
							default: withCtx(() => [createVNode(QTooltip_default, null, {
								default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.fontSize")) + ": " + toDisplayString(_ctx.$t(option.labelKey)), 1)]),
								_: 2
							}, 1024)]),
							_: 2
						}, 1032, [
							"class",
							"color",
							"onClick"
						]);
					}), 64))]),
					_: 1
				}, 8, ["modelValue"])]),
				props.showSaveTranscript && __props.isPro ? (openBlock(), createElementBlock("button", {
					key: 6,
					class: "gc-btn gc-btn--pill gc-btn--save",
					onClick: _cache[8] || (_cache[8] = ($event) => emit("save-transcript"))
				}, [createVNode(QIcon_default, {
					name: "save_alt",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.downloadTranscript")), 1)]),
					_: 1
				})])) : props.showSaveTranscript ? (openBlock(), createElementBlock("button", {
					key: 7,
					class: "gc-btn gc-btn--pill gc-btn--locked",
					onClick: _cache[9] || (_cache[9] = ($event) => emit("locked-action"))
				}, [
					createVNode(QIcon_default, {
						name: "save_alt",
						size: "20px"
					}),
					createVNode(QIcon_default, {
						name: "lock",
						size: "10px",
						class: "lock-badge"
					}),
					createVNode(QTooltip_default, null, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.downloadTranscript")), 1)]),
						_: 1
					})
				])) : createCommentVNode("", true),
				createVNode(QFab_default, {
					modelValue: isContextMenuOpen.value,
					"onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => isContextMenuOpen.value = $event),
					icon: "more_horiz",
					"active-icon": "close",
					direction: "up",
					flat: "",
					padding: "0",
					class: "context-fab"
				}, {
					default: withCtx(() => [createVNode(QFabAction_default, {
						icon: "groups",
						class: "speaker-settings-action",
						color: "grey-8",
						"text-color": "white",
						onClick: handleOpenSpeakerSettings
					}, {
						default: withCtx(() => [createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.speakerSettings")), 1)]),
							_: 1
						})]),
						_: 1
					}), createVNode(QFabAction_default, {
						icon: "auto_graph",
						class: "context-action",
						color: props.hasActiveContext ? "primary" : "grey-8",
						"text-color": "white",
						onClick: handleOpenContextSettings
					}, {
						default: withCtx(() => [createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("context.title")), 1)]),
							_: 1
						})]),
						_: 1
					}, 8, ["color"])]),
					_: 1
				}, 8, ["modelValue"])
			])]);
		};
	}
}), [["__scopeId", "data-v-dd7ead78"]]);
//#endregion
//#region src/components/translator/SpeakerSettingsDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = { class: "panel-card__title" };
var _hoisted_2$5 = { class: "speaker-grid__header" };
var _hoisted_3$5 = { class: "speaker-grid__header speaker-grid__header--right" };
var _hoisted_4$5 = { class: "speaker-grid__label" };
var _hoisted_5$5 = { class: "actions-main" };
//#endregion
//#region src/components/translator/SpeakerSettingsDialog.vue
var SpeakerSettingsDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "SpeakerSettingsDialog",
	props: {
		modelValue: { type: Boolean },
		speakerNames: {},
		isPro: { type: Boolean }
	},
	emits: [
		"update:modelValue",
		"save",
		"locked-action"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const localSpeakerNames = ref(normalizeSpeakerNames([], 10));
		const speakerRows = computed(() => localSpeakerNames.value.map((name, index) => ({
			index: index + 1,
			name
		})));
		watch(() => props.modelValue, (isOpen) => {
			if (!isOpen) return;
			localSpeakerNames.value = normalizeSpeakerNames(props.speakerNames, 10);
		}, { immediate: true });
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function updateSpeakerName(index, value) {
			const nextNames = [...localSpeakerNames.value];
			nextNames[index] = value;
			localSpeakerNames.value = nextNames;
		}
		function addSpeaker() {
			localSpeakerNames.value = [...localSpeakerNames.value, ""];
		}
		function saveSpeakerSettings() {
			const minSlots = Math.max(10, localSpeakerNames.value.length);
			emit("save", normalizeSpeakerNames(localSpeakerNames.value, minSlots));
			closeDialog();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				class: "panel-dialog panel-dialog--speaker",
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "speaker-settings-dialog panel-card" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, { class: "panel-card__header" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_1$5, [createVNode(QIcon_default, {
								name: "groups",
								size: "18px"
							}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.speakerSettingsTitle")), 1)]), createBaseVNode("button", {
								class: "panel-icon-btn",
								"data-no-panel-drag": "",
								onClick: closeDialog
							}, [createVNode(QIcon_default, {
								name: "close",
								size: "18px"
							})])]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardSection_default, { class: "panel-card__body speaker-settings-body" }, {
							default: withCtx(() => [
								createBaseVNode("div", _hoisted_2$5, toDisplayString(_ctx.$t("translator.speakerColumn")), 1),
								createBaseVNode("div", _hoisted_3$5, toDisplayString(_ctx.$t("translator.speakerNameColumn")), 1),
								(openBlock(true), createElementBlock(Fragment, null, renderList(speakerRows.value, (row) => {
									return openBlock(), createElementBlock(Fragment, { key: row.index }, [createBaseVNode("div", _hoisted_4$5, toDisplayString(_ctx.$t("translator.speaker")) + " " + toDisplayString(row.index), 1), createVNode(QInput_default, {
										"model-value": row.name,
										dense: "",
										outlined: "",
										class: "speaker-name-input",
										placeholder: _ctx.$t("translator.speakerNamePlaceholder"),
										"onUpdate:modelValue": ($event) => updateSpeakerName(row.index - 1, String($event ?? ""))
									}, null, 8, [
										"model-value",
										"placeholder",
										"onUpdate:modelValue"
									])], 64);
								}), 128))
							]),
							_: 1
						}),
						createVNode(QCardActions_default, { class: "panel-card__actions" }, {
							default: withCtx(() => [createBaseVNode("button", {
								class: "speaker-btn speaker-btn--subtle",
								onClick: addSpeaker
							}, [createVNode(QIcon_default, {
								name: "add",
								size: "17px"
							}), createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.addSpeaker")), 1)]), createBaseVNode("div", _hoisted_5$5, [createBaseVNode("button", {
								class: "speaker-btn",
								onClick: closeDialog
							}, [createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.cancel")), 1)]), __props.isPro ? (openBlock(), createElementBlock("button", {
								key: 0,
								class: "speaker-btn speaker-btn--primary",
								onClick: saveSpeakerSettings
							}, [createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.save")), 1)])) : (openBlock(), createElementBlock("button", {
								key: 1,
								class: "speaker-btn speaker-btn--locked",
								onClick: _cache[0] || (_cache[0] = ($event) => emit("locked-action"))
							}, [createVNode(QIcon_default, {
								name: "lock",
								size: "16px"
							}), createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.save")), 1)]))])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-238c2a56"]]);
//#endregion
//#region src/components/translator/DownloadTranscriptDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = { class: "download-option-main" };
var _hoisted_2$4 = { class: "download-option-icon" };
var _hoisted_3$4 = { class: "download-option-copy" };
var _hoisted_4$4 = { class: "download-option-label text-body1 text-weight-medium" };
var _hoisted_5$4 = { class: "download-option-desc text-caption text-grey-5" };
var _hoisted_6$3 = { class: "download-option-main" };
var _hoisted_7$3 = { class: "download-option-icon" };
var _hoisted_8$3 = { class: "download-option-copy" };
var _hoisted_9$3 = { class: "download-option-label text-body1 text-weight-medium" };
var _hoisted_10$3 = { class: "download-option-desc text-caption text-grey-5" };
var _hoisted_11$3 = { class: "download-option-main" };
var _hoisted_12$3 = { class: "download-option-icon" };
var _hoisted_13$2 = { class: "download-option-copy" };
var _hoisted_14$2 = { class: "download-option-label text-body1 text-weight-medium" };
var _hoisted_15$2 = { class: "download-option-desc text-caption text-grey-5" };
var _hoisted_16$2 = { class: "download-option-main" };
var _hoisted_17$2 = { class: "download-option-icon" };
var _hoisted_18$2 = { class: "download-option-copy" };
var _hoisted_19$2 = { class: "download-option-label text-body1 text-weight-medium" };
var _hoisted_20$2 = { class: "download-option-desc text-caption text-grey-5" };
var _hoisted_21$2 = { class: "download-option-main" };
var _hoisted_22$2 = { class: "download-option-icon" };
var _hoisted_23$2 = { class: "download-option-copy" };
var _hoisted_24$2 = { class: "download-option-label text-body1 text-weight-medium" };
var _hoisted_25$2 = { class: "download-option-desc text-caption text-grey-5" };
var _hoisted_26$2 = { class: "download-option-main" };
var _hoisted_27$2 = { class: "download-option-icon" };
var _hoisted_28$1 = { class: "download-option-copy" };
var _hoisted_29$1 = { class: "download-option-label text-body1 text-weight-medium" };
var _hoisted_30$1 = { class: "download-option-desc text-caption text-grey-5" };
//#endregion
//#region src/components/translator/DownloadTranscriptDialog.vue
var DownloadTranscriptDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "DownloadTranscriptDialog",
	props: {
		modelValue: { type: Boolean },
		isSummaryLoading: { type: Boolean },
		isTaskBreakdownLoading: { type: Boolean }
	},
	emits: [
		"update:modelValue",
		"download-txt",
		"download-json",
		"download-srt-original",
		"download-srt-translated",
		"download-summary",
		"download-task-breakdown"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function handleDownloadTxt() {
			emit("download-txt");
			closeDialog();
		}
		function handleDownloadJson() {
			emit("download-json");
			closeDialog();
		}
		function handleDownloadSrtOriginal() {
			emit("download-srt-original");
			closeDialog();
		}
		function handleDownloadSrtTranslated() {
			emit("download-srt-translated");
			closeDialog();
		}
		function handleDownloadSummary() {
			emit("download-summary");
		}
		function handleDownloadTaskBreakdown() {
			emit("download-task-breakdown");
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "download-transcript-dialog" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, { class: "row items-center justify-between q-pb-sm" }, {
							default: withCtx(() => [_cache[1] || (_cache[1] = createBaseVNode("div", { class: "text-subtitle1 text-weight-medium" }, "Download", -1)), createVNode(QBtn_default, {
								flat: "",
								round: "",
								dense: "",
								icon: "close",
								"data-no-panel-drag": "",
								onClick: closeDialog
							})]),
							_: 1
						}),
						createVNode(QSeparator_default),
						createVNode(QCardSection_default, { class: "download-options-list q-pt-md" }, {
							default: withCtx(() => [
								createVNode(QBtn_default, {
									unelevated: "",
									"no-caps": "",
									class: "download-option-item",
									align: "left",
									loading: __props.isSummaryLoading,
									disable: Boolean(__props.isTaskBreakdownLoading),
									onClick: handleDownloadSummary
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_1$4, [createBaseVNode("div", _hoisted_2$4, [createVNode(QIcon_default, {
										name: "summarize",
										size: "24px",
										color: "teal-4"
									})]), createBaseVNode("div", _hoisted_3$4, [createBaseVNode("div", _hoisted_4$4, toDisplayString(_ctx.$t("translator.downloadSummary")), 1), createBaseVNode("div", _hoisted_5$4, toDisplayString(_ctx.$t("translator.downloadSummaryDesc")), 1)])])]),
									_: 1
								}, 8, ["loading", "disable"]),
								createVNode(QBtn_default, {
									unelevated: "",
									"no-caps": "",
									class: "download-option-item",
									align: "left",
									loading: __props.isTaskBreakdownLoading,
									disable: Boolean(__props.isSummaryLoading),
									onClick: handleDownloadTaskBreakdown
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_6$3, [createBaseVNode("div", _hoisted_7$3, [createVNode(QIcon_default, {
										name: "checklist_rtl",
										size: "24px",
										color: "deep-orange-4"
									})]), createBaseVNode("div", _hoisted_8$3, [createBaseVNode("div", _hoisted_9$3, toDisplayString(_ctx.$t("translator.downloadTaskBreakdown")), 1), createBaseVNode("div", _hoisted_10$3, toDisplayString(_ctx.$t("translator.downloadTaskBreakdownDesc")), 1)])])]),
									_: 1
								}, 8, ["loading", "disable"]),
								createVNode(QBtn_default, {
									unelevated: "",
									"no-caps": "",
									class: "download-option-item",
									align: "left",
									onClick: handleDownloadTxt
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_11$3, [createBaseVNode("div", _hoisted_12$3, [createVNode(QIcon_default, {
										name: "description",
										size: "24px",
										color: "blue-4"
									})]), createBaseVNode("div", _hoisted_13$2, [createBaseVNode("div", _hoisted_14$2, toDisplayString(_ctx.$t("translator.downloadTxt")), 1), createBaseVNode("div", _hoisted_15$2, toDisplayString(_ctx.$t("translator.downloadTxtDesc")), 1)])])]),
									_: 1
								}),
								createVNode(QBtn_default, {
									unelevated: "",
									"no-caps": "",
									class: "download-option-item",
									align: "left",
									onClick: handleDownloadJson
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_16$2, [createBaseVNode("div", _hoisted_17$2, [createVNode(QIcon_default, {
										name: "data_object",
										size: "24px",
										color: "amber-6"
									})]), createBaseVNode("div", _hoisted_18$2, [createBaseVNode("div", _hoisted_19$2, toDisplayString(_ctx.$t("translator.downloadJson")), 1), createBaseVNode("div", _hoisted_20$2, toDisplayString(_ctx.$t("translator.downloadJsonDesc")), 1)])])]),
									_: 1
								}),
								createVNode(QBtn_default, {
									unelevated: "",
									"no-caps": "",
									class: "download-option-item",
									align: "left",
									onClick: handleDownloadSrtOriginal
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_21$2, [createBaseVNode("div", _hoisted_22$2, [createVNode(QIcon_default, {
										name: "subtitles",
										size: "24px",
										color: "blue-4"
									})]), createBaseVNode("div", _hoisted_23$2, [createBaseVNode("div", _hoisted_24$2, toDisplayString(_ctx.$t("translator.downloadSrtOriginal")), 1), createBaseVNode("div", _hoisted_25$2, toDisplayString(_ctx.$t("translator.downloadSrtOriginalDesc")), 1)])])]),
									_: 1
								}),
								createVNode(QBtn_default, {
									unelevated: "",
									"no-caps": "",
									class: "download-option-item",
									align: "left",
									onClick: handleDownloadSrtTranslated
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_26$2, [createBaseVNode("div", _hoisted_27$2, [createVNode(QIcon_default, {
										name: "translate",
										size: "24px",
										color: "amber-6"
									})]), createBaseVNode("div", _hoisted_28$1, [createBaseVNode("div", _hoisted_29$1, toDisplayString(_ctx.$t("translator.downloadSrtTranslated")), 1), createBaseVNode("div", _hoisted_30$1, toDisplayString(_ctx.$t("translator.downloadSrtTranslatedDesc")), 1)])])]),
									_: 1
								})
							]),
							_: 1
						}),
						createVNode(QCardActions_default, {
							align: "right",
							class: "q-pa-md q-pt-none"
						}, {
							default: withCtx(() => [createVNode(QBtn_default, {
								flat: "",
								color: "grey-5",
								label: _ctx.$t("translator.cancel"),
								onClick: closeDialog
							}, null, 8, ["label"])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-b0c43e2f"]]);
//#endregion
//#region node_modules/quasar/src/components/slider/use-slider.js
var markerPrefixClass = "q-slider__marker-labels";
var defaultMarkerConvertFn = (v) => ({ value: v });
var defaultMarkerLabelRenderFn = ({ marker }) => h("div", {
	key: marker.value,
	style: marker.style,
	class: marker.classes
}, marker.label);
var keyCodes = [
	34,
	37,
	40,
	33,
	39,
	38
];
var useSliderProps = {
	...useDarkProps,
	...useFormProps,
	min: {
		type: Number,
		default: 0
	},
	max: {
		type: Number,
		default: 100
	},
	innerMin: Number,
	innerMax: Number,
	step: {
		type: Number,
		default: 1,
		validator: (v) => v >= 0
	},
	snap: Boolean,
	vertical: Boolean,
	reverse: Boolean,
	color: String,
	markerLabelsClass: String,
	label: Boolean,
	labelColor: String,
	labelTextColor: String,
	labelAlways: Boolean,
	switchLabelSide: Boolean,
	markers: [Boolean, Number],
	markerLabels: [
		Boolean,
		Array,
		Object,
		Function
	],
	switchMarkerLabelsSide: Boolean,
	trackImg: String,
	trackColor: String,
	innerTrackImg: String,
	innerTrackColor: String,
	selectionColor: String,
	selectionImg: String,
	thumbSize: {
		type: String,
		default: "20px"
	},
	trackSize: {
		type: String,
		default: "4px"
	},
	disable: Boolean,
	readonly: Boolean,
	dense: Boolean,
	tabindex: [String, Number],
	thumbColor: String,
	thumbPath: {
		type: String,
		default: "M 4, 10 a 6,6 0 1,0 12,0 a 6,6 0 1,0 -12,0"
	}
};
var useSliderEmits = [
	"pan",
	"update:modelValue",
	"change"
];
function use_slider_default({ updateValue, updatePosition, getDragging, formAttrs }) {
	const { props, emit, slots, proxy: { $q } } = getCurrentInstance();
	const isDark = use_dark_default(props, $q);
	const injectFormInput = useFormInject(formAttrs);
	const active = ref(false);
	const preventFocus = ref(false);
	const focus = ref(false);
	const dragging = ref(false);
	const axis = computed(() => props.vertical === true ? "--v" : "--h");
	const labelSide = computed(() => "-" + (props.switchLabelSide === true ? "switched" : "standard"));
	const isReversed = computed(() => props.vertical === true ? props.reverse === true : props.reverse !== ($q.lang.rtl === true));
	const innerMin = computed(() => isNaN(props.innerMin) === true || props.innerMin < props.min ? props.min : props.innerMin);
	const innerMax = computed(() => isNaN(props.innerMax) === true || props.innerMax > props.max ? props.max : props.innerMax);
	const editable = computed(() => props.disable !== true && props.readonly !== true && innerMin.value < innerMax.value);
	const roundValueFn = computed(() => {
		if (props.step === 0) return (v) => v;
		const decimals = (String(props.step).trim().split(".")[1] || "").length;
		return (v) => parseFloat(v.toFixed(decimals));
	});
	const keyStep = computed(() => props.step === 0 ? 1 : props.step);
	const tabindex = computed(() => editable.value === true ? props.tabindex || 0 : -1);
	const trackLen = computed(() => props.max - props.min);
	const innerBarLen = computed(() => innerMax.value - innerMin.value);
	const innerMinRatio = computed(() => convertModelToRatio(innerMin.value));
	const innerMaxRatio = computed(() => convertModelToRatio(innerMax.value));
	const positionProp = computed(() => props.vertical === true ? isReversed.value === true ? "bottom" : "top" : isReversed.value === true ? "right" : "left");
	const sizeProp = computed(() => props.vertical === true ? "height" : "width");
	const thicknessProp = computed(() => props.vertical === true ? "width" : "height");
	const orientation = computed(() => props.vertical === true ? "vertical" : "horizontal");
	const attributes = computed(() => {
		const acc = {
			role: "slider",
			"aria-valuemin": innerMin.value,
			"aria-valuemax": innerMax.value,
			"aria-orientation": orientation.value,
			"data-step": props.step
		};
		if (props.disable === true) acc["aria-disabled"] = "true";
		else if (props.readonly === true) acc["aria-readonly"] = "true";
		return acc;
	});
	const classes = computed(() => `q-slider q-slider${axis.value} q-slider--${active.value === true ? "" : "in"}active inline no-wrap ` + (props.vertical === true ? "row" : "column") + (props.disable === true ? " disabled" : " q-slider--enabled" + (editable.value === true ? " q-slider--editable" : "")) + (focus.value === "both" ? " q-slider--focus" : "") + (props.label || props.labelAlways === true ? " q-slider--label" : "") + (props.labelAlways === true ? " q-slider--label-always" : "") + (isDark.value === true ? " q-slider--dark" : "") + (props.dense === true ? " q-slider--dense q-slider--dense" + axis.value : ""));
	function getPositionClass(name) {
		const cls = "q-slider__" + name;
		return `${cls} ${cls}${axis.value} ${cls}${axis.value}${labelSide.value}`;
	}
	function getAxisClass(name) {
		const cls = "q-slider__" + name;
		return `${cls} ${cls}${axis.value}`;
	}
	const selectionBarClass = computed(() => {
		const color = props.selectionColor || props.color;
		return "q-slider__selection absolute" + (color !== void 0 ? ` text-${color}` : "");
	});
	const markerClass = computed(() => getAxisClass("markers") + " absolute overflow-hidden");
	const trackContainerClass = computed(() => getAxisClass("track-container"));
	const pinClass = computed(() => getPositionClass("pin"));
	const labelClass = computed(() => getPositionClass("label"));
	const textContainerClass = computed(() => getPositionClass("text-container"));
	const markerLabelsContainerClass = computed(() => getPositionClass("marker-labels-container") + (props.markerLabelsClass !== void 0 ? ` ${props.markerLabelsClass}` : ""));
	const trackClass = computed(() => "q-slider__track relative-position no-outline" + (props.trackColor !== void 0 ? ` bg-${props.trackColor}` : ""));
	const trackStyle = computed(() => {
		const acc = { [thicknessProp.value]: props.trackSize };
		if (props.trackImg !== void 0) acc.backgroundImage = `url(${props.trackImg}) !important`;
		return acc;
	});
	const innerBarClass = computed(() => "q-slider__inner absolute" + (props.innerTrackColor !== void 0 ? ` bg-${props.innerTrackColor}` : ""));
	const innerBarStyle = computed(() => {
		const innerDiff = innerMaxRatio.value - innerMinRatio.value;
		const acc = {
			[positionProp.value]: `${100 * innerMinRatio.value}%`,
			[sizeProp.value]: innerDiff === 0 ? "2px" : `${100 * innerDiff}%`
		};
		if (props.innerTrackImg !== void 0) acc.backgroundImage = `url(${props.innerTrackImg}) !important`;
		return acc;
	});
	function convertRatioToModel(ratio) {
		const { min, max, step } = props;
		let model = min + ratio * (max - min);
		if (step > 0) {
			const modulo = (model - innerMin.value) % step;
			model += (Math.abs(modulo) >= step / 2 ? (modulo < 0 ? -1 : 1) * step : 0) - modulo;
		}
		model = roundValueFn.value(model);
		return between(model, innerMin.value, innerMax.value);
	}
	function convertModelToRatio(model) {
		return trackLen.value === 0 ? 0 : (model - props.min) / trackLen.value;
	}
	function getDraggingRatio(evt, dragging) {
		const pos = position(evt), val = props.vertical === true ? between((pos.top - dragging.top) / dragging.height, 0, 1) : between((pos.left - dragging.left) / dragging.width, 0, 1);
		return between(isReversed.value === true ? 1 - val : val, innerMinRatio.value, innerMaxRatio.value);
	}
	const markerStep = computed(() => isNumber(props.markers) === true ? props.markers : keyStep.value);
	const markerTicks = computed(() => {
		const acc = [];
		const step = markerStep.value;
		const max = props.max;
		let value = props.min;
		do {
			acc.push(value);
			value += step;
		} while (value < max);
		acc.push(max);
		return acc;
	});
	const markerLabelClass = computed(() => {
		const prefix = ` ${markerPrefixClass}${axis.value}-`;
		return `q-slider__marker-labels${prefix}${props.switchMarkerLabelsSide === true ? "switched" : "standard"}${prefix}${isReversed.value === true ? "rtl" : "ltr"}`;
	});
	const markerLabelsList = computed(() => {
		if (props.markerLabels === false) return null;
		return getMarkerList(props.markerLabels).map((entry, index) => ({
			index,
			value: entry.value,
			label: entry.label || entry.value,
			classes: markerLabelClass.value + (entry.classes !== void 0 ? " " + entry.classes : ""),
			style: {
				...getMarkerLabelStyle(entry.value),
				...entry.style || {}
			}
		}));
	});
	const markerScope = computed(() => ({
		markerList: markerLabelsList.value,
		markerMap: markerLabelsMap.value,
		classes: markerLabelClass.value,
		getStyle: getMarkerLabelStyle
	}));
	const markerStyle = computed(() => {
		const size = innerBarLen.value === 0 ? "2px" : 100 * markerStep.value / innerBarLen.value;
		return {
			...innerBarStyle.value,
			backgroundSize: props.vertical === true ? `2px ${size}%` : `${size}% 2px`
		};
	});
	function getMarkerList(def) {
		if (def === false) return null;
		if (def === true) return markerTicks.value.map(defaultMarkerConvertFn);
		if (typeof def === "function") return markerTicks.value.map((value) => {
			const item = def(value);
			return isObject(item) === true ? {
				...item,
				value
			} : {
				value,
				label: item
			};
		});
		const filterFn = ({ value }) => value >= props.min && value <= props.max;
		if (Array.isArray(def) === true) return def.map((item) => isObject(item) === true ? item : { value: item }).filter(filterFn);
		return Object.keys(def).map((key) => {
			const item = def[key];
			const value = Number(key);
			return isObject(item) === true ? {
				...item,
				value
			} : {
				value,
				label: item
			};
		}).filter(filterFn);
	}
	function getMarkerLabelStyle(val) {
		return { [positionProp.value]: `${100 * (val - props.min) / trackLen.value}%` };
	}
	const markerLabelsMap = computed(() => {
		if (props.markerLabels === false) return null;
		const acc = {};
		markerLabelsList.value.forEach((entry) => {
			acc[entry.value] = entry;
		});
		return acc;
	});
	function getMarkerLabelsContent() {
		if (slots["marker-label-group"] !== void 0) return slots["marker-label-group"](markerScope.value);
		const fn = slots["marker-label"] || defaultMarkerLabelRenderFn;
		return markerLabelsList.value.map((marker) => fn({
			marker,
			...markerScope.value
		}));
	}
	const panDirective = computed(() => {
		return [[
			TouchPan_default,
			onPan,
			void 0,
			{
				[orientation.value]: true,
				prevent: true,
				stop: true,
				mouse: true,
				mouseAllDir: true
			}
		]];
	});
	function onPan(event) {
		if (event.isFinal === true) {
			if (dragging.value !== void 0) {
				updatePosition(event.evt);
				event.touch === true && updateValue(true);
				dragging.value = void 0;
				emit("pan", "end");
			}
			active.value = false;
			focus.value = false;
		} else if (event.isFirst === true) {
			dragging.value = getDragging(event.evt);
			updatePosition(event.evt);
			updateValue();
			active.value = true;
			emit("pan", "start");
		} else {
			updatePosition(event.evt);
			updateValue();
		}
	}
	function onBlur() {
		focus.value = false;
	}
	function onActivate(evt) {
		updatePosition(evt, getDragging(evt));
		updateValue();
		preventFocus.value = true;
		active.value = true;
		document.addEventListener("mouseup", onDeactivate, true);
	}
	function onDeactivate() {
		preventFocus.value = false;
		active.value = false;
		updateValue(true);
		onBlur();
		document.removeEventListener("mouseup", onDeactivate, true);
	}
	function onMobileClick(evt) {
		updatePosition(evt, getDragging(evt));
		updateValue(true);
	}
	function onKeyup(evt) {
		if (keyCodes.includes(evt.keyCode)) updateValue(true);
	}
	function getTextContainerStyle(ratio) {
		if (props.vertical === true) return null;
		const p = $q.lang.rtl !== props.reverse ? 1 - ratio : ratio;
		return { transform: `translateX(calc(${2 * p - 1} * ${props.thumbSize} / 2 + ${50 - 100 * p}%))` };
	}
	function getThumbRenderFn(thumb) {
		const focusClass = computed(() => preventFocus.value === false && (focus.value === thumb.focusValue || focus.value === "both") ? " q-slider--focus" : "");
		const classes = computed(() => `q-slider__thumb q-slider__thumb${axis.value} q-slider__thumb${axis.value}-${isReversed.value === true ? "rtl" : "ltr"} absolute non-selectable` + focusClass.value + (thumb.thumbColor.value !== void 0 ? ` text-${thumb.thumbColor.value}` : ""));
		const style = computed(() => ({
			width: props.thumbSize,
			height: props.thumbSize,
			[positionProp.value]: `${100 * thumb.ratio.value}%`,
			zIndex: focus.value === thumb.focusValue ? 2 : void 0
		}));
		const pinColor = computed(() => thumb.labelColor.value !== void 0 ? ` text-${thumb.labelColor.value}` : "");
		const textContainerStyle = computed(() => getTextContainerStyle(thumb.ratio.value));
		const textClass = computed(() => "q-slider__text" + (thumb.labelTextColor.value !== void 0 ? ` text-${thumb.labelTextColor.value}` : ""));
		return () => {
			const thumbContent = [h("svg", {
				class: "q-slider__thumb-shape absolute-full",
				viewBox: "0 0 20 20",
				"aria-hidden": "true"
			}, [h("path", { d: props.thumbPath })]), h("div", { class: "q-slider__focus-ring fit" })];
			if (props.label === true || props.labelAlways === true) {
				thumbContent.push(h("div", { class: pinClass.value + " absolute fit no-pointer-events" + pinColor.value }, [h("div", {
					class: labelClass.value,
					style: { minWidth: props.thumbSize }
				}, [h("div", {
					class: textContainerClass.value,
					style: textContainerStyle.value
				}, [h("span", { class: textClass.value }, thumb.label.value)])])]));
				if (props.name !== void 0 && props.disable !== true) injectFormInput(thumbContent, "push");
			}
			return h("div", {
				class: classes.value,
				style: style.value,
				...thumb.getNodeData()
			}, thumbContent);
		};
	}
	function getContent(selectionBarStyle, trackContainerTabindex, trackContainerEvents, injectThumb) {
		const trackContent = [];
		props.innerTrackColor !== "transparent" && trackContent.push(h("div", {
			key: "inner",
			class: innerBarClass.value,
			style: innerBarStyle.value
		}));
		props.selectionColor !== "transparent" && trackContent.push(h("div", {
			key: "selection",
			class: selectionBarClass.value,
			style: selectionBarStyle.value
		}));
		props.markers !== false && trackContent.push(h("div", {
			key: "marker",
			class: markerClass.value,
			style: markerStyle.value
		}));
		injectThumb(trackContent);
		const content = [hDir("div", {
			key: "trackC",
			class: trackContainerClass.value,
			tabindex: trackContainerTabindex.value,
			...trackContainerEvents.value
		}, [h("div", {
			class: trackClass.value,
			style: trackStyle.value
		}, trackContent)], "slide", editable.value, () => panDirective.value)];
		if (props.markerLabels !== false) content[props.switchMarkerLabelsSide === true ? "unshift" : "push"](h("div", {
			key: "markerL",
			class: markerLabelsContainerClass.value
		}, getMarkerLabelsContent()));
		return content;
	}
	onBeforeUnmount(() => {
		document.removeEventListener("mouseup", onDeactivate, true);
	});
	return {
		state: {
			active,
			focus,
			preventFocus,
			dragging,
			editable,
			classes,
			tabindex,
			attributes,
			roundValueFn,
			keyStep,
			trackLen,
			innerMin,
			innerMinRatio,
			innerMax,
			innerMaxRatio,
			positionProp,
			sizeProp,
			isReversed
		},
		methods: {
			onActivate,
			onMobileClick,
			onBlur,
			onKeyup,
			getContent,
			getThumbRenderFn,
			convertRatioToModel,
			convertModelToRatio,
			getDraggingRatio
		}
	};
}
//#endregion
//#region node_modules/quasar/src/components/slider/QSlider.js
var getNodeData = () => ({});
var QSlider_default = createComponent({
	name: "QSlider",
	props: {
		...useSliderProps,
		modelValue: {
			required: true,
			default: null,
			validator: (v) => typeof v === "number" || v === null
		},
		labelValue: [String, Number]
	},
	emits: useSliderEmits,
	setup(props, { emit }) {
		const { proxy: { $q } } = getCurrentInstance();
		const { state, methods } = use_slider_default({
			updateValue,
			updatePosition,
			getDragging,
			formAttrs: useFormAttrs(props)
		});
		const rootRef = ref(null);
		const curRatio = ref(0);
		const model = ref(0);
		function normalizeModel() {
			model.value = props.modelValue === null ? state.innerMin.value : between(props.modelValue, state.innerMin.value, state.innerMax.value);
		}
		watch(() => `${props.modelValue}|${state.innerMin.value}|${state.innerMax.value}`, normalizeModel);
		normalizeModel();
		const modelRatio = computed(() => methods.convertModelToRatio(model.value));
		const ratio = computed(() => state.active.value === true ? curRatio.value : modelRatio.value);
		const selectionBarStyle = computed(() => {
			const acc = {
				[state.positionProp.value]: `${100 * state.innerMinRatio.value}%`,
				[state.sizeProp.value]: `${100 * (ratio.value - state.innerMinRatio.value)}%`
			};
			if (props.selectionImg !== void 0) acc.backgroundImage = `url(${props.selectionImg}) !important`;
			return acc;
		});
		const getThumb = methods.getThumbRenderFn({
			focusValue: true,
			getNodeData,
			ratio,
			label: computed(() => props.labelValue !== void 0 ? props.labelValue : model.value),
			thumbColor: computed(() => props.thumbColor || props.color),
			labelColor: computed(() => props.labelColor),
			labelTextColor: computed(() => props.labelTextColor)
		});
		const trackContainerEvents = computed(() => {
			if (state.editable.value !== true) return {};
			return $q.platform.is.mobile === true ? { onClick: methods.onMobileClick } : {
				onMousedown: methods.onActivate,
				onFocus,
				onBlur: methods.onBlur,
				onKeydown,
				onKeyup: methods.onKeyup
			};
		});
		function updateValue(change) {
			if (model.value !== props.modelValue) emit("update:modelValue", model.value);
			change === true && emit("change", model.value);
		}
		function getDragging() {
			return rootRef.value.getBoundingClientRect();
		}
		function updatePosition(event, dragging = state.dragging.value) {
			const ratio = methods.getDraggingRatio(event, dragging);
			model.value = methods.convertRatioToModel(ratio);
			curRatio.value = props.snap !== true || props.step === 0 ? ratio : methods.convertModelToRatio(model.value);
		}
		function onFocus() {
			state.focus.value = true;
		}
		function onKeydown(evt) {
			if (keyCodes.includes(evt.keyCode) === false) return;
			stopAndPrevent(evt);
			const stepVal = ([34, 33].includes(evt.keyCode) ? 10 : 1) * state.keyStep.value, offset = ([
				34,
				37,
				40
			].includes(evt.keyCode) ? -1 : 1) * (state.isReversed.value === true ? -1 : 1) * (props.vertical === true ? -1 : 1) * stepVal;
			model.value = between(state.roundValueFn.value(model.value + offset), state.innerMin.value, state.innerMax.value);
			updateValue();
		}
		return () => {
			const content = methods.getContent(selectionBarStyle, state.tabindex, trackContainerEvents, (node) => {
				node.push(getThumb());
			});
			return h("div", {
				ref: rootRef,
				class: state.classes.value + (props.modelValue === null ? " q-slider--no-value" : ""),
				...state.attributes.value,
				"aria-valuenow": props.modelValue
			}, content);
		};
	}
});
//#endregion
//#region node_modules/quasar/src/composables/private.use-refocus-target/use-refocus-target.js
function use_refocus_target_default(props, rootRef) {
	const refocusRef = ref(null);
	const refocusTargetEl = computed(() => {
		if (props.disable === true) return null;
		return h("span", {
			ref: refocusRef,
			class: "no-outline",
			tabindex: -1
		});
	});
	function refocusTarget(e) {
		const root = rootRef.value;
		if (e?.qAvoidFocus === true) return;
		if (e?.type.indexOf("key") === 0) {
			if (document.activeElement !== root && root?.contains(document.activeElement) === true) root.focus();
		} else if (refocusRef.value !== null && (e === void 0 || root?.contains(e.target) === true)) refocusRef.value.focus();
	}
	return {
		refocusTargetEl,
		refocusTarget
	};
}
//#endregion
//#region node_modules/quasar/src/utils/private.option-sizes/option-sizes.js
var option_sizes_default = {
	xs: 30,
	sm: 35,
	md: 40,
	lg: 50,
	xl: 60
};
//#endregion
//#region node_modules/quasar/src/components/checkbox/use-checkbox.js
var useCheckboxProps = {
	...useDarkProps,
	...useSizeProps,
	...useFormProps,
	modelValue: {
		required: true,
		default: null
	},
	val: {},
	trueValue: { default: true },
	falseValue: { default: false },
	indeterminateValue: { default: null },
	checkedIcon: String,
	uncheckedIcon: String,
	indeterminateIcon: String,
	toggleOrder: {
		type: String,
		validator: (v) => v === "tf" || v === "ft"
	},
	toggleIndeterminate: Boolean,
	label: String,
	leftLabel: Boolean,
	color: String,
	keepColor: Boolean,
	dense: Boolean,
	disable: Boolean,
	tabindex: [String, Number]
};
var useCheckboxEmits = ["update:modelValue"];
function use_checkbox_default(type, getInner) {
	const { props, slots, emit, proxy } = getCurrentInstance();
	const { $q } = proxy;
	const isDark = use_dark_default(props, $q);
	const rootRef = ref(null);
	const { refocusTargetEl, refocusTarget } = use_refocus_target_default(props, rootRef);
	const sizeStyle = use_size_default(props, option_sizes_default);
	const modelIsArray = computed(() => props.val !== void 0 && Array.isArray(props.modelValue));
	const index = computed(() => {
		const val = toRaw(props.val);
		return modelIsArray.value === true ? props.modelValue.findIndex((opt) => toRaw(opt) === val) : -1;
	});
	const isTrue = computed(() => modelIsArray.value === true ? index.value !== -1 : toRaw(props.modelValue) === toRaw(props.trueValue));
	const isFalse = computed(() => modelIsArray.value === true ? index.value === -1 : toRaw(props.modelValue) === toRaw(props.falseValue));
	const isIndeterminate = computed(() => isTrue.value === false && isFalse.value === false);
	const tabindex = computed(() => props.disable === true ? -1 : props.tabindex || 0);
	const classes = computed(() => `q-${type} cursor-pointer no-outline row inline no-wrap items-center` + (props.disable === true ? " disabled" : "") + (isDark.value === true ? ` q-${type}--dark` : "") + (props.dense === true ? ` q-${type}--dense` : "") + (props.leftLabel === true ? " reverse" : ""));
	const innerClass = computed(() => {
		return `q-${type}__inner relative-position non-selectable q-${type}__inner--${isTrue.value === true ? "truthy" : isFalse.value === true ? "falsy" : "indet"}${props.color !== void 0 && (props.keepColor === true || (type === "toggle" ? isTrue.value === true : isFalse.value !== true)) ? ` text-${props.color}` : ""}`;
	});
	const injectFormInput = useFormInject(computed(() => {
		const prop = { type: "checkbox" };
		props.name !== void 0 && Object.assign(prop, {
			".checked": isTrue.value,
			"^checked": isTrue.value === true ? "checked" : void 0,
			name: props.name,
			value: modelIsArray.value === true ? props.val : props.trueValue
		});
		return prop;
	}));
	const attributes = computed(() => {
		const attrs = {
			tabindex: tabindex.value,
			role: type === "toggle" ? "switch" : "checkbox",
			"aria-label": props.label,
			"aria-checked": isIndeterminate.value === true ? "mixed" : isTrue.value === true ? "true" : "false"
		};
		if (props.disable === true) attrs["aria-disabled"] = "true";
		return attrs;
	});
	function onClick(e) {
		if (e !== void 0) {
			stopAndPrevent(e);
			refocusTarget(e);
		}
		if (props.disable !== true) emit("update:modelValue", getNextValue(), e);
	}
	function getNextValue() {
		if (modelIsArray.value === true) {
			if (isTrue.value === true) {
				const val = props.modelValue.slice();
				val.splice(index.value, 1);
				return val;
			}
			return props.modelValue.concat([props.val]);
		}
		if (isTrue.value === true) {
			if (props.toggleOrder !== "ft" || props.toggleIndeterminate === false) return props.falseValue;
		} else if (isFalse.value === true) {
			if (props.toggleOrder === "ft" || props.toggleIndeterminate === false) return props.trueValue;
		} else return props.toggleOrder !== "ft" ? props.trueValue : props.falseValue;
		return props.indeterminateValue;
	}
	function onKeydown(e) {
		if (e.keyCode === 13 || e.keyCode === 32) stopAndPrevent(e);
	}
	function onKeyup(e) {
		if (e.keyCode === 13 || e.keyCode === 32) onClick(e);
	}
	const getInnerContent = getInner(isTrue, isIndeterminate);
	Object.assign(proxy, { toggle: onClick });
	return () => {
		const inner = getInnerContent();
		props.disable !== true && injectFormInput(inner, "unshift", ` q-${type}__native absolute q-ma-none q-pa-none`);
		const child = [h("div", {
			class: innerClass.value,
			style: sizeStyle.value,
			"aria-hidden": "true"
		}, inner)];
		if (refocusTargetEl.value !== null) child.push(refocusTargetEl.value);
		const label = props.label !== void 0 ? hMergeSlot(slots.default, [props.label]) : hSlot(slots.default);
		label !== void 0 && child.push(h("div", { class: `q-${type}__label q-anchor--skip` }, label));
		return h("div", {
			ref: rootRef,
			class: classes.value,
			...attributes.value,
			onClick,
			onKeydown,
			onKeyup
		}, child);
	};
}
//#endregion
//#region node_modules/quasar/src/components/checkbox/QCheckbox.js
var createBgNode = () => h("div", {
	key: "svg",
	class: "q-checkbox__bg absolute"
}, [h("svg", {
	class: "q-checkbox__svg fit absolute-full",
	viewBox: "0 0 24 24"
}, [h("path", {
	class: "q-checkbox__truthy",
	fill: "none",
	d: "M1.73,12.91 8.1,19.28 22.79,4.59"
}), h("path", {
	class: "q-checkbox__indet",
	d: "M4,14H20V10H4"
})])]);
var QCheckbox_default = createComponent({
	name: "QCheckbox",
	props: useCheckboxProps,
	emits: useCheckboxEmits,
	setup(props) {
		const bgNode = createBgNode();
		function getInner(isTrue, isIndeterminate) {
			const icon = computed(() => (isTrue.value === true ? props.checkedIcon : isIndeterminate.value === true ? props.indeterminateIcon : props.uncheckedIcon) || null);
			return () => icon.value !== null ? [h("div", {
				key: "icon",
				class: "q-checkbox__icon-container absolute-full flex flex-center no-wrap"
			}, [h(QIcon_default, {
				class: "q-checkbox__icon",
				name: icon.value
			})])] : [bgNode];
		}
		return use_checkbox_default("checkbox", getInner);
	}
});
//#endregion
//#region node_modules/quasar/src/components/toggle/QToggle.js
var QToggle_default = createComponent({
	name: "QToggle",
	props: {
		...useCheckboxProps,
		icon: String,
		iconColor: String
	},
	emits: useCheckboxEmits,
	setup(props) {
		function getInner(isTrue, isIndeterminate) {
			const icon = computed(() => (isTrue.value === true ? props.checkedIcon : isIndeterminate.value === true ? props.indeterminateIcon : props.uncheckedIcon) || props.icon);
			const color = computed(() => isTrue.value === true ? props.iconColor : null);
			return () => [h("div", { class: "q-toggle__track" }), h("div", { class: "q-toggle__thumb absolute flex flex-center no-wrap" }, icon.value !== void 0 ? [h(QIcon_default, {
				name: icon.value,
				color: color.value
			})] : void 0)];
		}
		return use_checkbox_default("toggle", getInner);
	}
});
//#endregion
//#region src/config/google-translate-voices.ts
var GOOGLE_TRANSLATE_VOICES = [
	{
		id: "af",
		label: "Afrikaans",
		lang: "af"
	},
	{
		id: "sq",
		label: "Albanian",
		lang: "sq"
	},
	{
		id: "ar",
		label: "Arabic",
		lang: "ar"
	},
	{
		id: "hy",
		label: "Armenian",
		lang: "hy"
	},
	{
		id: "bn",
		label: "Bengali",
		lang: "bn"
	},
	{
		id: "bs",
		label: "Bosnian",
		lang: "bs"
	},
	{
		id: "bg",
		label: "Bulgarian",
		lang: "bg"
	},
	{
		id: "ca",
		label: "Catalan",
		lang: "ca"
	},
	{
		id: "zh-CN",
		label: "Chinese",
		lang: "zh-CN"
	},
	{
		id: "hr",
		label: "Croatian",
		lang: "hr"
	},
	{
		id: "cs",
		label: "Czech",
		lang: "cs"
	},
	{
		id: "da",
		label: "Danish",
		lang: "da"
	},
	{
		id: "nl",
		label: "Dutch",
		lang: "nl"
	},
	{
		id: "en",
		label: "English",
		lang: "en"
	},
	{
		id: "eo",
		label: "Esperanto",
		lang: "eo"
	},
	{
		id: "et",
		label: "Estonian",
		lang: "et"
	},
	{
		id: "fi",
		label: "Finnish",
		lang: "fi"
	},
	{
		id: "fr",
		label: "French",
		lang: "fr"
	},
	{
		id: "de",
		label: "German",
		lang: "de"
	},
	{
		id: "el",
		label: "Greek",
		lang: "el"
	},
	{
		id: "gu",
		label: "Gujarati",
		lang: "gu"
	},
	{
		id: "hi",
		label: "Hindi",
		lang: "hi"
	},
	{
		id: "hu",
		label: "Hungarian",
		lang: "hu"
	},
	{
		id: "id",
		label: "Indonesian",
		lang: "id"
	},
	{
		id: "it",
		label: "Italian",
		lang: "it"
	},
	{
		id: "ja",
		label: "Japanese",
		lang: "ja"
	},
	{
		id: "jw",
		label: "Javanese",
		lang: "jw"
	},
	{
		id: "kn",
		label: "Kannada",
		lang: "kn"
	},
	{
		id: "km",
		label: "Khmer",
		lang: "km"
	},
	{
		id: "ko",
		label: "Korean",
		lang: "ko"
	},
	{
		id: "lv",
		label: "Latvian",
		lang: "lv"
	},
	{
		id: "mk",
		label: "Macedonian",
		lang: "mk"
	},
	{
		id: "ms",
		label: "Malay",
		lang: "ms"
	},
	{
		id: "ml",
		label: "Malayalam",
		lang: "ml"
	},
	{
		id: "mr",
		label: "Marathi",
		lang: "mr"
	},
	{
		id: "my",
		label: "Myanmar (Burmese)",
		lang: "my"
	},
	{
		id: "ne",
		label: "Nepali",
		lang: "ne"
	},
	{
		id: "no",
		label: "Norwegian",
		lang: "no"
	},
	{
		id: "pl",
		label: "Polish",
		lang: "pl"
	},
	{
		id: "pt",
		label: "Portuguese",
		lang: "pt"
	},
	{
		id: "ro",
		label: "Romanian",
		lang: "ro"
	},
	{
		id: "ru",
		label: "Russian",
		lang: "ru"
	},
	{
		id: "sr",
		label: "Serbian",
		lang: "sr"
	},
	{
		id: "si",
		label: "Sinhala",
		lang: "si"
	},
	{
		id: "sk",
		label: "Slovak",
		lang: "sk"
	},
	{
		id: "sl",
		label: "Slovenian",
		lang: "sl"
	},
	{
		id: "es",
		label: "Spanish",
		lang: "es"
	},
	{
		id: "su",
		label: "Sundanese",
		lang: "su"
	},
	{
		id: "sw",
		label: "Swahili",
		lang: "sw"
	},
	{
		id: "sv",
		label: "Swedish",
		lang: "sv"
	},
	{
		id: "tl",
		label: "Tagalog",
		lang: "tl"
	},
	{
		id: "ta",
		label: "Tamil",
		lang: "ta"
	},
	{
		id: "te",
		label: "Telugu",
		lang: "te"
	},
	{
		id: "th",
		label: "Thai",
		lang: "th"
	},
	{
		id: "tr",
		label: "Turkish",
		lang: "tr"
	},
	{
		id: "uk",
		label: "Ukrainian",
		lang: "uk"
	},
	{
		id: "ur",
		label: "Urdu",
		lang: "ur"
	},
	{
		id: "vi",
		label: "Vietnamese",
		lang: "vi"
	},
	{
		id: "cy",
		label: "Welsh",
		lang: "cy"
	}
];
new Map(GOOGLE_TRANSLATE_VOICES.map((v) => [v.id, v]));
//#endregion
//#region src/components/translator/NarrationSettingsDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "panel-card__title" };
var _hoisted_2$3 = { class: "setting-row" };
var _hoisted_3$3 = { class: "setting-label" };
var _hoisted_4$3 = { class: "voice-row" };
var _hoisted_5$3 = ["disabled"];
var _hoisted_6$2 = {
	key: 0,
	class: "test-voice-error"
};
var _hoisted_7$2 = { class: "setting-row" };
var _hoisted_8$2 = { class: "setting-label" };
var _hoisted_9$2 = { class: "voice-row" };
var _hoisted_10$2 = ["disabled"];
var _hoisted_11$2 = { class: "setting-row" };
var _hoisted_12$2 = { class: "setting-label" };
var _hoisted_13$1 = { class: "setting-value-group" };
var _hoisted_14$1 = { class: "setting-value" };
var _hoisted_15$1 = ["title"];
var _hoisted_16$1 = { class: "autosync-label" };
var _hoisted_17$1 = {
	key: 0,
	class: "autosync-badge"
};
var _hoisted_18$1 = { class: "setting-row" };
var _hoisted_19$1 = { class: "setting-label" };
var _hoisted_20$1 = { class: "setting-value" };
var _hoisted_21$1 = { class: "setting-row" };
var _hoisted_22$1 = { class: "setting-label" };
var _hoisted_23$1 = { class: "setting-value" };
var _hoisted_24$1 = {
	key: 0,
	class: "setting-row"
};
var _hoisted_25$1 = { class: "mode-toggle-label" };
var _hoisted_26$1 = { class: "autosync-label" };
var _hoisted_27$1 = { class: "mode-toggle-hint" };
var _hoisted_28 = { class: "setting-row narration-modes-row" };
var _hoisted_29 = { class: "mode-toggle-label" };
var _hoisted_30 = { class: "autosync-label" };
var _hoisted_31 = { class: "mode-toggle-hint" };
var _hoisted_32 = {
	key: 1,
	class: "mode-status-row"
};
var _hoisted_33 = {
	key: 0,
	class: "narrate-status narrate-status--connecting"
};
var _hoisted_34 = {
	key: 1,
	class: "narrate-status narrate-status--translating"
};
var _hoisted_35 = {
	key: 2,
	class: "narrate-pro-badge"
};
var _hoisted_36 = { class: "actions-main narration-mode-actions" };
var _hoisted_37 = { class: "gc-btn__label" };
var _hoisted_38 = ["disabled"];
var _hoisted_39 = { class: "gc-btn__label" };
var _hoisted_40 = { class: "gc-btn__label" };
var _hoisted_41 = ["disabled"];
var _hoisted_42 = { class: "gc-btn__label" };
var _hoisted_43 = { class: "gc-btn__label" };
var BROWSER_CHROME_VOICE_PREFIX = "chrome__";
var BROWSER_SPEECH_VOICE_PREFIX = "speech__";
var BROWSER_DEFAULT_SPEED_UI_PERCENT = 75;
var BROWSER_MIN_SPEED_UI_PERCENT = 50;
//#endregion
//#region src/components/translator/NarrationSettingsDialog.vue
var NarrationSettingsDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "NarrationSettingsDialog",
	props: {
		modelValue: { type: Boolean },
		ttsVoice: {},
		myTtsVoice: {},
		voiceSpeed: {},
		voiceVolume: {},
		originalVolume: {},
		autoSyncSpeed: { type: Boolean },
		narrationEnabled: { type: Boolean },
		ttsQueueLength: {},
		ttsEffectiveSpeed: {},
		isTestingVoice: { type: Boolean },
		testVoiceError: {},
		isPro: { type: Boolean },
		narrateMyVoice: { type: Boolean },
		narrateMyVoiceAvailable: { type: Boolean },
		narrateAllSpeakers: { type: Boolean },
		isInterpreterActive: { type: Boolean },
		isRealtimeConnecting: { type: Boolean },
		isNarrating: { type: Boolean },
		isTranslationStarted: { type: Boolean },
		ttsProvider: {},
		myTtsProvider: {},
		googleVoiceId: {},
		browserVoiceId: {},
		myGoogleVoiceId: {},
		isYouTubePage: { type: Boolean },
		captionNarrationEnabled: { type: Boolean },
		isCallPageSupported: { type: Boolean }
	},
	emits: [
		"update:modelValue",
		"start-narrate-my-voice",
		"start-narrate-their-voice",
		"stop-mode",
		"test",
		"locked-action",
		"toggle-narrate-all-speakers",
		"toggle-caption-narration"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const OPENAI_VOICE_OPTIONS = TTS_VOICES.map((voice) => ({
			label: `OpenAI - ${voice.charAt(0).toUpperCase() + voice.slice(1)}`,
			value: `openai:${voice}`
		}));
		const GOOGLE_VOICE_OPTIONS = GOOGLE_TRANSLATE_VOICES.map((voice) => ({
			label: `Google - ${voice.label} (Free)`,
			value: `google:${voice.id}`
		}));
		const BROWSER_DEFAULT_OPTION = {
			label: "Browser - Default voice",
			value: `browser:${TTS_BROWSER_DEFAULT_VOICE_ID}`
		};
		const localTTSVoice = ref(props.ttsVoice);
		const localMyTTSVoice = ref(props.myTtsVoice ?? props.ttsVoice);
		const localSpeed = ref(props.voiceSpeed);
		const localVoiceVolume = ref(props.voiceVolume);
		const localOriginalVolume = ref(props.originalVolume);
		const localAutoSync = ref(props.autoSyncSpeed);
		const localTtsProvider = ref(props.ttsProvider ?? "openai");
		const localMyTtsProvider = ref(props.myTtsProvider ?? props.ttsProvider ?? "openai");
		const localGoogleVoiceId = ref(props.googleVoiceId ?? "en");
		const localBrowserVoiceId = ref(props.browserVoiceId ?? "default");
		const localMyGoogleVoiceId = ref(props.myGoogleVoiceId ?? props.googleVoiceId ?? "en");
		const selectedTheirVoiceOption = ref("google:vi");
		const selectedMyVoiceOption = ref("google:en");
		const showNarrateAllSpeakersToggle = NARRATION_FEATURE_FLAGS.narrateAllSpeakersToggle;
		const browserVoiceOptions = ref([BROWSER_DEFAULT_OPTION]);
		const theirVoiceOptions = computed(() => [
			...OPENAI_VOICE_OPTIONS,
			...GOOGLE_VOICE_OPTIONS,
			...browserVoiceOptions.value
		]);
		const myVoiceOptions = computed(() => [...OPENAI_VOICE_OPTIONS, ...GOOGLE_VOICE_OPTIONS]);
		const filteredTheirVoiceOptions = ref(theirVoiceOptions.value);
		const filteredMyVoiceOptions = ref(myVoiceOptions.value);
		function encodeBrowserVoiceId(prefix, value) {
			return `${prefix}${encodeURIComponent(value)}`;
		}
		function resolveTheirVoiceSelection(provider, ttsVoice, googleVoiceId, browserVoiceId) {
			if (provider === "google") return `google:${googleVoiceId}`;
			if (provider === "browser") return `browser:${browserVoiceId || "default"}`;
			return `openai:${ttsVoice}`;
		}
		function resolveMyVoiceSelection(provider, ttsVoice, googleVoiceId) {
			if (provider === "google") return `google:${googleVoiceId}`;
			return `openai:${ttsVoice}`;
		}
		function parseTheirVoiceSelection(selection) {
			const [providerRaw, voiceIdRaw] = selection.split(":");
			const voiceId = voiceIdRaw ?? "";
			if (providerRaw === "google" && voiceId) return {
				provider: "google",
				voiceId
			};
			if (providerRaw === "browser") return {
				provider: "browser",
				voiceId: voiceId || "default"
			};
			if (providerRaw === "openai" && voiceId) return {
				provider: "openai",
				voiceId
			};
			return {
				provider: "openai",
				voiceId: "coral"
			};
		}
		function parseMyVoiceSelection(selection) {
			const [providerRaw, voiceIdRaw] = selection.split(":");
			const voiceId = voiceIdRaw ?? "";
			if (providerRaw === "google" && voiceId) return {
				provider: "google",
				voiceId
			};
			if (providerRaw === "openai" && voiceId) return {
				provider: "openai",
				voiceId
			};
			return {
				provider: "openai",
				voiceId: "coral"
			};
		}
		function normalizeBrowserVoiceSpeed(speed) {
			if (!Number.isFinite(speed)) return BROWSER_DEFAULT_SPEED_UI_PERCENT;
			return Math.max(BROWSER_MIN_SPEED_UI_PERCENT, speed);
		}
		async function fetchChromeVoiceOptions() {
			if (typeof chrome === "undefined" || typeof chrome.tts?.getVoices !== "function") return [];
			return await new Promise((resolve) => {
				chrome.tts.getVoices((voices) => {
					if (chrome.runtime?.lastError || !Array.isArray(voices)) {
						resolve([]);
						return;
					}
					resolve(voices.filter((voice) => Boolean(voice.voiceName)).map((voice) => ({
						label: `${voice.voiceName}`,
						value: `browser:${encodeBrowserVoiceId(BROWSER_CHROME_VOICE_PREFIX, voice.voiceName)}`
					})).sort((left, right) => left.label.localeCompare(right.label)));
				});
			});
		}
		async function getSpeechSynthesisVoices() {
			if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
			const synth = window.speechSynthesis;
			const initialVoices = synth.getVoices();
			if (initialVoices.length > 0) return initialVoices;
			return await new Promise((resolve) => {
				let settled = false;
				let timeoutId = 0;
				const finish = () => {
					if (settled) return;
					settled = true;
					clearTimeout(timeoutId);
					synth.removeEventListener?.("voiceschanged", handleVoicesChanged);
					resolve(synth.getVoices());
				};
				const handleVoicesChanged = () => finish();
				timeoutId = window.setTimeout(() => finish(), 1e3);
				synth.addEventListener?.("voiceschanged", handleVoicesChanged);
			});
		}
		async function fetchWebSpeechVoiceOptions() {
			return (await getSpeechSynthesisVoices()).filter((voice) => Boolean(voice.voiceURI) && voice.localService !== false).map((voice) => ({
				label: `Browser - ${voice.name} (${voice.lang || "auto"})`,
				value: `browser:${encodeBrowserVoiceId(BROWSER_SPEECH_VOICE_PREFIX, voice.voiceURI)}`
			})).sort((left, right) => left.label.localeCompare(right.label));
		}
		async function refreshBrowserVoiceOptions() {
			const chromeOptions = await fetchChromeVoiceOptions();
			browserVoiceOptions.value = [BROWSER_DEFAULT_OPTION, ...chromeOptions.length > 0 ? chromeOptions : await fetchWebSpeechVoiceOptions()];
			filteredTheirVoiceOptions.value = theirVoiceOptions.value;
			if (localTtsProvider.value !== "browser") return;
			const desiredSelection = `browser:${localBrowserVoiceId.value || "default"}`;
			if (!browserVoiceOptions.value.some((option) => option.value === desiredSelection)) {
				localBrowserVoiceId.value = TTS_BROWSER_DEFAULT_VOICE_ID;
				selectedTheirVoiceOption.value = `browser:${TTS_BROWSER_DEFAULT_VOICE_ID}`;
			}
		}
		function handleVoiceFilter(val, update, sourceOptions, target) {
			update(() => {
				const needle = val.trim().toLowerCase();
				if (!needle) {
					target.value = sourceOptions;
					return;
				}
				target.value = sourceOptions.filter((option) => {
					return option.label.toLowerCase().includes(needle) || option.value.toLowerCase().includes(needle);
				});
			});
		}
		function handleTheirVoiceFilter(val, update) {
			handleVoiceFilter(val, update, theirVoiceOptions.value, filteredTheirVoiceOptions);
		}
		function handleMyVoiceFilter(val, update) {
			handleVoiceFilter(val, update, myVoiceOptions.value, filteredMyVoiceOptions);
		}
		watch(() => props.modelValue, (isOpen) => {
			if (!isOpen) return;
			localTTSVoice.value = props.ttsVoice;
			localMyTTSVoice.value = props.myTtsVoice ?? props.ttsVoice;
			localTtsProvider.value = props.ttsProvider ?? "openai";
			localMyTtsProvider.value = props.myTtsProvider ?? props.ttsProvider ?? "openai";
			localSpeed.value = localTtsProvider.value === "browser" ? normalizeBrowserVoiceSpeed(props.voiceSpeed) : props.voiceSpeed;
			localVoiceVolume.value = props.voiceVolume;
			localOriginalVolume.value = props.originalVolume;
			localAutoSync.value = props.autoSyncSpeed;
			localGoogleVoiceId.value = props.googleVoiceId ?? "en";
			localBrowserVoiceId.value = props.browserVoiceId ?? "default";
			localMyGoogleVoiceId.value = props.myGoogleVoiceId ?? props.googleVoiceId ?? "en";
			selectedTheirVoiceOption.value = resolveTheirVoiceSelection(localTtsProvider.value, localTTSVoice.value, localGoogleVoiceId.value, localBrowserVoiceId.value);
			selectedMyVoiceOption.value = resolveMyVoiceSelection(localMyTtsProvider.value, localMyTTSVoice.value, localMyGoogleVoiceId.value);
			filteredTheirVoiceOptions.value = theirVoiceOptions.value;
			filteredMyVoiceOptions.value = myVoiceOptions.value;
			refreshBrowserVoiceOptions();
		}, { immediate: true });
		watch(selectedTheirVoiceOption, (selection) => {
			const parsed = parseTheirVoiceSelection(selection);
			localTtsProvider.value = parsed.provider;
			if (parsed.provider === "google") {
				localGoogleVoiceId.value = parsed.voiceId;
				return;
			}
			if (parsed.provider === "browser") {
				localBrowserVoiceId.value = parsed.voiceId || "default";
				return;
			}
			localTTSVoice.value = parsed.voiceId;
		}, { immediate: true });
		watch(localTtsProvider, (provider, previousProvider) => {
			if (provider !== "browser") return;
			if (previousProvider !== "browser") {
				localSpeed.value = Math.max(BROWSER_DEFAULT_SPEED_UI_PERCENT, normalizeBrowserVoiceSpeed(localSpeed.value));
				return;
			}
			localSpeed.value = normalizeBrowserVoiceSpeed(localSpeed.value);
		});
		watch(selectedMyVoiceOption, (selection) => {
			const parsed = parseMyVoiceSelection(selection);
			localMyTtsProvider.value = parsed.provider;
			if (parsed.provider === "google") {
				localMyGoogleVoiceId.value = parsed.voiceId;
				return;
			}
			localMyTTSVoice.value = parsed.voiceId;
		}, { immediate: true });
		const selectedTheirVoiceIcon = computed(() => {
			if (localTtsProvider.value === "google") return "translate";
			if (localTtsProvider.value === "browser") return "computer";
			return "record_voice_over";
		});
		const selectedMyVoiceIcon = computed(() => localMyTtsProvider.value === "google" ? "translate" : "record_voice_over");
		const speedLabel = computed(() => {
			const v = localSpeed.value;
			if (v === 0) return "1.0×";
			if (v > 0) return `+${v}%`;
			return `${v}%`;
		});
		const speedSliderMin = computed(() => {
			return localTtsProvider.value === "browser" ? BROWSER_MIN_SPEED_UI_PERCENT : -100;
		});
		/** Show effective (boosted) speed when auto-sync is active and boosting */
		const effectiveSpeedLabel = computed(() => {
			if (!props.narrationEnabled || !localAutoSync.value) return null;
			const boosted = props.ttsEffectiveSpeed;
			const base = localSpeed.value >= 0 ? 1 + localSpeed.value / 100 : Math.max(.25, 1 + localSpeed.value / 100 * .75);
			if (Math.abs(boosted - base) < .05) return null;
			return `${boosted.toFixed(1)}×`;
		});
		const isAnyNarrationModeEnabled = computed(() => Boolean(props.narrationEnabled || props.narrateMyVoice));
		const narrateMyVoiceTooltipKey = computed(() => props.isCallPageSupported === false ? "translator.featureUnavailableOnThisPage" : "translator.narrateMyVoiceHint");
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function getSettings() {
			const normalizedSpeed = localTtsProvider.value === "browser" ? normalizeBrowserVoiceSpeed(localSpeed.value) : localSpeed.value;
			return {
				ttsVoice: localTTSVoice.value,
				myTtsVoice: localMyTTSVoice.value,
				voiceSpeed: normalizedSpeed,
				voiceVolume: localVoiceVolume.value,
				originalVolume: localOriginalVolume.value,
				autoSyncSpeed: localAutoSync.value,
				ttsProvider: localTtsProvider.value,
				myTtsProvider: localMyTtsProvider.value,
				googleVoiceId: localGoogleVoiceId.value,
				browserVoiceId: localBrowserVoiceId.value,
				myGoogleVoiceId: localMyGoogleVoiceId.value
			};
		}
		function handleStartNarrateMyVoice() {
			emit("start-narrate-my-voice", getSettings());
			closeDialog();
		}
		function handleStartNarrateTheirVoice() {
			emit("start-narrate-their-voice", getSettings());
			closeDialog();
		}
		function handleStopMode() {
			emit("stop-mode");
			closeDialog();
		}
		function handleTestVoice() {
			emit("test", getSettings());
		}
		function handleTestMyVoice() {
			const settings = getSettings();
			emit("test", {
				...settings,
				ttsVoice: settings.myTtsVoice,
				ttsProvider: settings.myTtsProvider,
				googleVoiceId: settings.myGoogleVoiceId
			});
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				class: "panel-dialog panel-dialog--narration",
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "narration-dialog panel-card" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, {
							class: "panel-card__header",
							"data-dialog-drag-handle": ""
						}, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_1$3, [createVNode(QIcon_default, {
								name: "record_voice_over",
								size: "18px"
							}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.narrationSettings")), 1)]), createBaseVNode("button", {
								class: "gc-btn panel-icon-btn dialog-close-btn",
								"data-no-panel-drag": "",
								onClick: closeDialog
							}, [createVNode(QIcon_default, {
								name: "close",
								size: "18px"
							})])]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardSection_default, { class: "panel-card__body narration-body" }, {
							default: withCtx(() => [
								createBaseVNode("div", _hoisted_2$3, [
									createBaseVNode("div", _hoisted_3$3, [createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.narrateTheirVoiceSelectLabel")), 1), createVNode(QIcon_default, {
										name: "info",
										size: "14px",
										class: "setting-help-icon"
									}, {
										default: withCtx(() => [createVNode(QTooltip_default, { "max-width": "240px" }, {
											default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrateTheirVoiceSelectHint")), 1)]),
											_: 1
										})]),
										_: 1
									})]),
									createBaseVNode("div", _hoisted_4$3, [createVNode(QSelect_default, {
										modelValue: selectedTheirVoiceOption.value,
										"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedTheirVoiceOption.value = $event),
										options: filteredTheirVoiceOptions.value,
										dense: "",
										outlined: "",
										"emit-value": "",
										"map-options": "",
										"use-input": "",
										"input-debounce": "0",
										autocomplete: "off",
										"popup-content-class": "narration-select-menu",
										class: "setting-select",
										onFilter: handleTheirVoiceFilter
									}, {
										prepend: withCtx(() => [createVNode(QIcon_default, {
											name: selectedTheirVoiceIcon.value,
											size: "xs"
										}, null, 8, ["name"])]),
										_: 1
									}, 8, ["modelValue", "options"]), createBaseVNode("button", {
										class: "gc-btn gc-btn--pill gc-btn--save voice-test-btn q-px-sm",
										disabled: props.isTestingVoice,
										onClick: handleTestVoice
									}, [!props.isTestingVoice ? (openBlock(), createBlock(QIcon_default, {
										key: 0,
										name: "graphic_eq",
										size: "16px"
									})) : (openBlock(), createBlock(QSpinner_default, {
										key: 1,
										size: "16px",
										color: "white"
									})), createVNode(QTooltip_default, null, {
										default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.test")), 1)]),
										_: 1
									})], 8, _hoisted_5$3)]),
									props.testVoiceError ? (openBlock(), createElementBlock("div", _hoisted_6$2, toDisplayString(props.testVoiceError), 1)) : createCommentVNode("", true)
								]),
								createBaseVNode("div", _hoisted_7$2, [createBaseVNode("div", _hoisted_8$2, [createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.narrateMyVoiceSelectLabel")), 1), createVNode(QIcon_default, {
									name: "info",
									size: "14px",
									class: "setting-help-icon"
								}, {
									default: withCtx(() => [createVNode(QTooltip_default, { "max-width": "240px" }, {
										default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrateMyVoiceSelectHint")), 1)]),
										_: 1
									})]),
									_: 1
								})]), createBaseVNode("div", _hoisted_9$2, [createVNode(QSelect_default, {
									modelValue: selectedMyVoiceOption.value,
									"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => selectedMyVoiceOption.value = $event),
									options: filteredMyVoiceOptions.value,
									dense: "",
									outlined: "",
									"emit-value": "",
									"map-options": "",
									"use-input": "",
									"input-debounce": "0",
									autocomplete: "off",
									"popup-content-class": "narration-select-menu",
									class: "setting-select",
									onFilter: handleMyVoiceFilter
								}, {
									prepend: withCtx(() => [createVNode(QIcon_default, {
										name: selectedMyVoiceIcon.value,
										size: "xs"
									}, null, 8, ["name"])]),
									_: 1
								}, 8, ["modelValue", "options"]), createBaseVNode("button", {
									class: "gc-btn gc-btn--pill gc-btn--save voice-test-btn q-px-sm",
									disabled: props.isTestingVoice,
									onClick: handleTestMyVoice
								}, [!props.isTestingVoice ? (openBlock(), createBlock(QIcon_default, {
									key: 0,
									name: "graphic_eq",
									size: "16px"
								})) : (openBlock(), createBlock(QSpinner_default, {
									key: 1,
									size: "16px",
									color: "white"
								})), createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.test")), 1)]),
									_: 1
								})], 8, _hoisted_10$2)])]),
								createBaseVNode("div", _hoisted_11$2, [
									createBaseVNode("div", _hoisted_12$2, [createTextVNode(toDisplayString(_ctx.$t("translator.voiceSpeed")) + " ", 1), createBaseVNode("div", _hoisted_13$1, [createBaseVNode("span", _hoisted_14$1, toDisplayString(speedLabel.value), 1), effectiveSpeedLabel.value ? (openBlock(), createElementBlock("span", {
										key: 0,
										class: "setting-value setting-value--boosted",
										title: _ctx.$t("translator.autoSyncBoostedHint")
									}, [createTextVNode(" → " + toDisplayString(effectiveSpeedLabel.value) + " ", 1), createVNode(QIcon_default, {
										name: "bolt",
										size: "12px"
									})], 8, _hoisted_15$1)) : createCommentVNode("", true)])]),
									createVNode(QSlider_default, {
										modelValue: localSpeed.value,
										"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => localSpeed.value = $event),
										min: speedSliderMin.value,
										max: 100,
										step: 10,
										color: "primary",
										class: "setting-slider"
									}, null, 8, ["modelValue", "min"]),
									createVNode(QCheckbox_default, {
										modelValue: localAutoSync.value,
										"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => localAutoSync.value = $event),
										class: "autosync-checkbox",
										color: "primary",
										size: "sm"
									}, {
										default: withCtx(() => [createBaseVNode("span", _hoisted_16$1, [createTextVNode(toDisplayString(_ctx.$t("translator.autoSyncSpeed")) + " ", 1), __props.ttsQueueLength > 3 ? (openBlock(), createElementBlock("span", _hoisted_17$1, toDisplayString(_ctx.$t("translator.autoSyncQueue", { n: __props.ttsQueueLength })), 1)) : createCommentVNode("", true)]), createVNode(QTooltip_default, { "max-width": "220px" }, {
											default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.autoSyncSpeedHint")), 1)]),
											_: 1
										})]),
										_: 1
									}, 8, ["modelValue"])
								]),
								createBaseVNode("div", _hoisted_18$1, [createBaseVNode("div", _hoisted_19$1, [createTextVNode(toDisplayString(_ctx.$t("translator.voiceVolume")) + " ", 1), createBaseVNode("span", _hoisted_20$1, toDisplayString(localVoiceVolume.value) + "%", 1)]), createVNode(QSlider_default, {
									modelValue: localVoiceVolume.value,
									"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => localVoiceVolume.value = $event),
									min: 1,
									max: 100,
									step: 1,
									color: "teal",
									class: "setting-slider"
								}, null, 8, ["modelValue"])]),
								createBaseVNode("div", _hoisted_21$1, [createBaseVNode("div", _hoisted_22$1, [createTextVNode(toDisplayString(_ctx.$t("translator.originalVolume")) + " ", 1), createBaseVNode("span", _hoisted_23$1, toDisplayString(localOriginalVolume.value) + "%", 1)]), createVNode(QSlider_default, {
									modelValue: localOriginalVolume.value,
									"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => localOriginalVolume.value = $event),
									min: 0,
									max: 100,
									step: 1,
									color: "orange",
									class: "setting-slider"
								}, null, 8, ["modelValue"])]),
								props.isYouTubePage && unref(NARRATION_FEATURE_FLAGS).captionNarration ? (openBlock(), createElementBlock("div", _hoisted_24$1, [createVNode(QSeparator_default, { class: "section-divider" }), createVNode(QToggle_default, {
									"model-value": props.captionNarrationEnabled ?? false,
									class: "mode-toggle",
									color: "teal",
									disable: !props.isYouTubePage,
									"onUpdate:modelValue": _cache[6] || (_cache[6] = (val) => emit("toggle-caption-narration", val ?? false))
								}, {
									default: withCtx(() => [createBaseVNode("div", _hoisted_25$1, [createBaseVNode("span", _hoisted_26$1, [createVNode(QIcon_default, {
										name: "closed_caption",
										size: "16px",
										class: "caption-toggle-icon"
									}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.captionNarrationToggle")), 1)]), createBaseVNode("span", _hoisted_27$1, toDisplayString(_ctx.$t("translator.captionNarrationHint")), 1)])]),
									_: 1
								}, 8, ["model-value", "disable"])])) : createCommentVNode("", true),
								createBaseVNode("div", _hoisted_28, [
									createVNode(QSeparator_default, { class: "section-divider" }),
									unref(showNarrateAllSpeakersToggle) ? (openBlock(), createBlock(QToggle_default, {
										key: 0,
										"model-value": props.narrateAllSpeakers ?? false,
										class: "mode-toggle",
										color: "blue-grey",
										"onUpdate:modelValue": _cache[7] || (_cache[7] = (val) => emit("toggle-narrate-all-speakers", val ?? false))
									}, {
										default: withCtx(() => [createBaseVNode("div", _hoisted_29, [createBaseVNode("span", _hoisted_30, toDisplayString(_ctx.$t("translator.narrateAllSpeakers")), 1), createBaseVNode("span", _hoisted_31, toDisplayString(_ctx.$t("translator.narrateAllSpeakersHint")), 1)])]),
										_: 1
									}, 8, ["model-value"])) : createCommentVNode("", true),
									props.isRealtimeConnecting || props.isNarrating ? (openBlock(), createElementBlock("div", _hoisted_32, [props.isRealtimeConnecting ? (openBlock(), createElementBlock("span", _hoisted_33, [createVNode(QSpinner_default, { size: "12px" }), createTextVNode(" " + toDisplayString(_ctx.$t("translator.realtimeConnecting")), 1)])) : props.isNarrating ? (openBlock(), createElementBlock("span", _hoisted_34, [createVNode(QIcon_default, {
										name: "graphic_eq",
										size: "14px"
									}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.narratingMyVoice")), 1)])) : createCommentVNode("", true)])) : createCommentVNode("", true),
									!props.isPro ? (openBlock(), createElementBlock("div", _hoisted_35, [createVNode(QIcon_default, {
										name: "lock",
										size: "12px"
									}), createTextVNode(" " + toDisplayString(_ctx.$t("pro.featureLocked")), 1)])) : createCommentVNode("", true)
								])
							]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardActions_default, { class: "panel-card__actions actions-row" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_36, [isAnyNarrationModeEnabled.value ? (openBlock(), createElementBlock("button", {
								key: 0,
								class: "gc-btn gc-btn--pill gc-btn--alert",
								onClick: handleStopMode
							}, [createVNode(QIcon_default, {
								name: "stop",
								size: "16px"
							}), createBaseVNode("span", _hoisted_37, toDisplayString(_ctx.$t("translator.stopNarration")), 1)])) : props.isPro ? (openBlock(), createElementBlock("button", {
								key: 1,
								class: "gc-btn gc-btn--pill gc-btn--enabled",
								disabled: !props.isTranslationStarted || !props.narrateMyVoiceAvailable,
								onClick: handleStartNarrateMyVoice
							}, [
								createVNode(QIcon_default, {
									name: "record_voice_over",
									size: "18px"
								}),
								createBaseVNode("span", _hoisted_39, toDisplayString(_ctx.$t("translator.narrateMyVoice")), 1),
								createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(narrateMyVoiceTooltipKey.value)), 1)]),
									_: 1
								})
							], 8, _hoisted_38)) : (openBlock(), createElementBlock("button", {
								key: 2,
								class: "gc-btn gc-btn--pill gc-btn--locked",
								onClick: _cache[8] || (_cache[8] = ($event) => emit("locked-action"))
							}, [
								createVNode(QIcon_default, {
									name: "lock",
									size: "16px"
								}),
								createBaseVNode("span", _hoisted_40, toDisplayString(_ctx.$t("translator.narrateMyVoice")), 1),
								createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrateMyVoiceHint")), 1)]),
									_: 1
								})
							])), !isAnyNarrationModeEnabled.value && props.isPro ? (openBlock(), createElementBlock("button", {
								key: 3,
								class: "gc-btn gc-btn--pill gc-btn--save",
								disabled: !props.isTranslationStarted,
								onClick: handleStartNarrateTheirVoice
							}, [
								createVNode(QIcon_default, {
									name: "transcribe",
									size: "18px"
								}),
								createBaseVNode("span", _hoisted_42, toDisplayString(_ctx.$t("translator.narrateTheirVoice")), 1),
								createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrateTheirVoiceHint")), 1)]),
									_: 1
								})
							], 8, _hoisted_41)) : !isAnyNarrationModeEnabled.value ? (openBlock(), createElementBlock("button", {
								key: 4,
								class: "gc-btn gc-btn--pill gc-btn--locked",
								onClick: _cache[9] || (_cache[9] = ($event) => emit("locked-action"))
							}, [
								createVNode(QIcon_default, {
									name: "lock",
									size: "16px"
								}),
								createBaseVNode("span", _hoisted_43, toDisplayString(_ctx.$t("translator.narrateTheirVoice")), 1),
								createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrateTheirVoiceHint")), 1)]),
									_: 1
								})
							])) : createCommentVNode("", true)])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-798d84d2"]]);
//#endregion
//#region src/components/translator/ProFeatureDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "pro-feature-dialog__title" };
var _hoisted_2$2 = { class: "actions-main" };
var _hoisted_3$2 = { class: "gc-btn__label" };
var _hoisted_4$2 = { class: "gc-btn__label" };
var _hoisted_5$2 = { class: "gc-btn__label" };
//#endregion
//#region src/components/translator/ProFeatureDialog.vue
var ProFeatureDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "ProFeatureDialog",
	props: { modelValue: { type: Boolean } },
	emits: [
		"update:modelValue",
		"enter-license",
		"learn-more"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function handleLearnMore() {
			emit("learn-more");
		}
		function handleEnterLicense() {
			emit("enter-license");
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "pro-feature-dialog" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, { class: "pro-feature-dialog__header" }, {
							default: withCtx(() => [createVNode(QIcon_default, {
								name: "lock",
								color: "warning",
								size: "20px"
							}), createBaseVNode("div", _hoisted_1$2, toDisplayString(_ctx.$t("pro.featureLockedTitle")), 1)]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "pro-feature-dialog__separator" }),
						createVNode(QCardSection_default, { class: "pro-feature-dialog__body" }, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("pro.featureLockedMessage")), 1)]),
							_: 1
						}),
						createVNode(QCardActions_default, { class: "pro-feature-dialog__actions" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_2$2, [
								createBaseVNode("button", {
									class: "gc-btn gc-btn--pill",
									onClick: closeDialog
								}, [createBaseVNode("span", _hoisted_3$2, toDisplayString(_ctx.$t("translator.close")), 1)]),
								createBaseVNode("button", {
									class: "gc-btn gc-btn--pill gc-btn--enabled",
									onClick: handleEnterLicense
								}, [createBaseVNode("span", _hoisted_4$2, toDisplayString(_ctx.$t("pro.enterLicense")), 1)]),
								createBaseVNode("button", {
									class: "gc-btn gc-btn--pill gc-btn--save",
									onClick: handleLearnMore
								}, [createBaseVNode("span", _hoisted_5$2, toDisplayString(_ctx.$t("pro.learnMore")), 1)])
							])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-60e93e2c"]]);
//#endregion
//#region src/components/translator/ContextSettingDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "panel-card__title" };
var _hoisted_2$1 = { class: "context-form" };
var _hoisted_3$1 = { class: "form-field" };
var _hoisted_4$1 = { class: "form-label" };
var _hoisted_5$1 = { class: "form-field" };
var _hoisted_6$1 = { class: "form-label" };
var _hoisted_7$1 = { class: "form-field" };
var _hoisted_8$1 = { class: "form-label" };
var _hoisted_9$1 = { class: "form-field" };
var _hoisted_10$1 = { class: "form-label" };
var _hoisted_11$1 = { class: "form-field" };
var _hoisted_12$1 = { class: "form-label" };
var _hoisted_13 = { class: "saved-contexts" };
var _hoisted_14 = { class: "saved-contexts__toolbar" };
var _hoisted_15 = { class: "saved-contexts__header" };
var _hoisted_16 = { class: "saved-contexts__actions" };
var _hoisted_17 = {
	key: 0,
	class: "saved-contexts-empty"
};
var _hoisted_18 = {
	key: 1,
	class: "saved-contexts__list"
};
var _hoisted_19 = { class: "saved-context-info" };
var _hoisted_20 = { class: "saved-context-name" };
var _hoisted_21 = { class: "saved-context-date" };
var _hoisted_22 = ["onClick"];
var _hoisted_23 = { class: "gc-btn__label" };
var _hoisted_24 = { class: "actions-right" };
var _hoisted_25 = ["disabled"];
var _hoisted_26 = { class: "gc-btn__label" };
var _hoisted_27 = { class: "gc-btn__label" };
//#endregion
//#region src/components/translator/ContextSettingDialog.vue
var ContextSettingDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "ContextSettingDialog",
	props: {
		modelValue: { type: Boolean },
		contextName: {},
		domain: {},
		topic: {},
		terms: {},
		speakers: {},
		savedContexts: {},
		isSaving: { type: Boolean }
	},
	emits: [
		"update:modelValue",
		"update:contextName",
		"update:domain",
		"update:topic",
		"update:terms",
		"update:speakers",
		"save",
		"apply",
		"apply-saved",
		"export-contexts",
		"import-contexts"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const fileInputRef = ref(null);
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function handleSave() {
			emit("save");
		}
		function handleApply() {
			emit("apply");
		}
		function handleApplySaved(ctx) {
			emit("apply-saved", ctx);
		}
		function handleExportContexts() {
			emit("export-contexts");
		}
		function triggerImportPicker() {
			fileInputRef.value?.click();
		}
		function handleImportFile(event) {
			const target = event.target;
			const file = target.files?.[0];
			if (file) emit("import-contexts", file);
			target.value = "";
		}
		function formatDate(timestamp) {
			const date = new Date(timestamp);
			const month = String(date.getMonth() + 1).padStart(2, "0");
			const day = String(date.getDate()).padStart(2, "0");
			const hours = String(date.getHours()).padStart(2, "0");
			const minutes = String(date.getMinutes()).padStart(2, "0");
			return `${date.getFullYear()}-${month}-${day} ${hours}:${minutes}`;
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				class: "panel-dialog panel-dialog--context",
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "context-dialog panel-card" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, {
							class: "panel-card__header",
							"data-dialog-drag-handle": ""
						}, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [createVNode(QIcon_default, {
								name: "auto_graph",
								size: "18px"
							}), createTextVNode(" " + toDisplayString(_ctx.$t("context.title")), 1)]), createBaseVNode("button", {
								class: "gc-btn panel-icon-btn dialog-close-btn",
								"data-no-panel-drag": "",
								onClick: closeDialog
							}, [createVNode(QIcon_default, {
								name: "close",
								size: "18px"
							})])]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardSection_default, { class: "panel-card__body context-body" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_2$1, [
								createBaseVNode("div", _hoisted_3$1, [createBaseVNode("label", _hoisted_4$1, toDisplayString(_ctx.$t("context.contextName")), 1), createVNode(QInput_default, {
									"model-value": __props.contextName,
									dense: "",
									outlined: "",
									placeholder: _ctx.$t("context.contextNamePlaceholder"),
									class: "context-input",
									"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:contextName", String($event ?? "")))
								}, null, 8, ["model-value", "placeholder"])]),
								createBaseVNode("div", _hoisted_5$1, [createBaseVNode("label", _hoisted_6$1, toDisplayString(_ctx.$t("context.domain")), 1), createVNode(QInput_default, {
									"model-value": __props.domain,
									dense: "",
									outlined: "",
									placeholder: _ctx.$t("context.domainPlaceholder"),
									class: "context-input",
									"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => emit("update:domain", String($event ?? "")))
								}, null, 8, ["model-value", "placeholder"])]),
								createBaseVNode("div", _hoisted_7$1, [createBaseVNode("label", _hoisted_8$1, toDisplayString(_ctx.$t("context.topic")), 1), createVNode(QInput_default, {
									"model-value": __props.topic,
									dense: "",
									outlined: "",
									type: "textarea",
									placeholder: _ctx.$t("context.topicPlaceholder"),
									class: "context-input",
									autogrow: "",
									"input-style": {
										minHeight: "48px",
										maxHeight: "80px"
									},
									"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => emit("update:topic", String($event ?? "")))
								}, null, 8, ["model-value", "placeholder"])]),
								createBaseVNode("div", _hoisted_9$1, [createBaseVNode("label", _hoisted_10$1, toDisplayString(_ctx.$t("context.terms")), 1), createVNode(QInput_default, {
									"model-value": __props.terms,
									dense: "",
									outlined: "",
									type: "textarea",
									placeholder: _ctx.$t("context.termsPlaceholder"),
									class: "context-input",
									autogrow: "",
									"input-style": {
										minHeight: "48px",
										maxHeight: "80px"
									},
									"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => emit("update:terms", String($event ?? "")))
								}, null, 8, ["model-value", "placeholder"])]),
								createBaseVNode("div", _hoisted_11$1, [createBaseVNode("label", _hoisted_12$1, toDisplayString(_ctx.$t("context.speakers")), 1), createVNode(QInput_default, {
									"model-value": __props.speakers,
									dense: "",
									outlined: "",
									type: "textarea",
									placeholder: _ctx.$t("context.speakersPlaceholder"),
									class: "context-input",
									autogrow: "",
									"input-style": {
										minHeight: "48px",
										maxHeight: "80px"
									},
									"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => emit("update:speakers", String($event ?? "")))
								}, null, 8, ["model-value", "placeholder"])])
							]), createBaseVNode("div", _hoisted_13, [
								createBaseVNode("div", _hoisted_14, [createBaseVNode("div", _hoisted_15, [createVNode(QIcon_default, {
									name: "bookmark",
									size: "14px"
								}), createTextVNode(" " + toDisplayString(_ctx.$t("context.savedContexts")), 1)]), createBaseVNode("div", _hoisted_16, [createBaseVNode("button", {
									class: "gc-btn gc-btn--mini gc-btn--import-export",
									onClick: triggerImportPicker
								}, [createVNode(QIcon_default, {
									name: "file_upload",
									size: "14px"
								}), createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("context.import")), 1)]),
									_: 1
								})]), createBaseVNode("button", {
									class: "gc-btn gc-btn--mini gc-btn--import-export",
									onClick: handleExportContexts
								}, [createVNode(QIcon_default, {
									name: "file_download",
									size: "14px"
								}), createVNode(QTooltip_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("context.export")), 1)]),
									_: 1
								})])])]),
								createBaseVNode("input", {
									ref_key: "fileInputRef",
									ref: fileInputRef,
									type: "file",
									accept: "application/json,.json",
									class: "context-file-input",
									onChange: handleImportFile
								}, null, 544),
								__props.savedContexts.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_17, toDisplayString(_ctx.$t("context.noSavedContexts")), 1)) : (openBlock(), createElementBlock("div", _hoisted_18, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.savedContexts, (ctx) => {
									return openBlock(), createElementBlock("div", {
										key: ctx.id,
										class: "saved-context-item"
									}, [createBaseVNode("div", _hoisted_19, [createBaseVNode("span", _hoisted_20, toDisplayString(ctx.name), 1), createBaseVNode("span", _hoisted_21, toDisplayString(formatDate(ctx.savedAt)), 1)]), createBaseVNode("button", {
										class: "gc-btn gc-btn--mini",
										onClick: ($event) => handleApplySaved(ctx)
									}, [createVNode(QIcon_default, {
										name: "input",
										size: "14px"
									}), createVNode(QTooltip_default, null, {
										default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("context.applySaved")), 1)]),
										_: 1
									})], 8, _hoisted_22)]);
								}), 128))]))
							])]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardActions_default, { class: "panel-card__actions actions-row" }, {
							default: withCtx(() => [createBaseVNode("button", {
								class: "gc-btn gc-btn--pill",
								onClick: closeDialog
							}, [createBaseVNode("span", _hoisted_23, toDisplayString(_ctx.$t("translator.close")), 1)]), createBaseVNode("div", _hoisted_24, [createBaseVNode("button", {
								class: "gc-btn gc-btn--pill gc-btn--save",
								disabled: !__props.contextName.trim(),
								onClick: handleSave
							}, [createVNode(QIcon_default, {
								name: "save",
								size: "16px"
							}), createBaseVNode("span", _hoisted_26, toDisplayString(_ctx.$t("translator.save")), 1)], 8, _hoisted_25), createBaseVNode("button", {
								class: "gc-btn gc-btn--pill gc-btn--enabled",
								onClick: handleApply
							}, [createVNode(QIcon_default, {
								name: "check",
								size: "16px"
							}), createBaseVNode("span", _hoisted_27, toDisplayString(_ctx.$t("translator.apply")), 1)])])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-27e08cb0"]]);
//#endregion
//#region src/composables/useContextSettings.ts
function normalizeImportedContexts(raw) {
	return (Array.isArray(raw) ? raw : raw && typeof raw === "object" && Array.isArray(raw.contexts) ? raw.contexts : []).map((item) => {
		if (!item || typeof item !== "object") return null;
		const source = item;
		const name = typeof source.name === "string" ? source.name.trim() : "";
		if (!name) return null;
		return {
			id: typeof source.id === "string" && source.id.trim() ? source.id : `ctx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
			name,
			domain: typeof source.domain === "string" ? source.domain : "",
			topic: typeof source.topic === "string" ? source.topic : "",
			terms: typeof source.terms === "string" ? source.terms : "",
			speakers: typeof source.speakers === "string" ? source.speakers : "",
			savedAt: typeof source.savedAt === "number" ? source.savedAt : Date.now()
		};
	}).filter((ctx) => Boolean(ctx));
}
function useContextSettings() {
	const settingsStore = useSettingsStore();
	const contextName = ref("");
	const domain = ref("");
	const topic = ref("");
	const terms = ref("");
	const speakers = ref("");
	const savedContexts = ref([]);
	const isLoaded = ref(false);
	const activeContext = computed(() => {
		const general = [];
		if (domain.value.trim()) general.push({
			key: "domain",
			value: domain.value.trim()
		});
		if (topic.value.trim()) general.push({
			key: "topic",
			value: topic.value.trim()
		});
		if (speakers.value.trim()) general.push({
			key: "speakers",
			value: speakers.value.trim()
		});
		const termsList = terms.value.split(",").map((t) => t.trim()).filter(Boolean);
		if (general.length === 0 && termsList.length === 0) return void 0;
		const ctx = {};
		if (general.length > 0) ctx.general = general;
		if (termsList.length > 0) ctx.terms = termsList;
		return ctx;
	});
	const hasContextData = computed(() => Boolean(domain.value.trim() || topic.value.trim() || terms.value.trim() || speakers.value.trim()));
	function loadSavedContexts() {
		savedContexts.value = [...settingsStore.savedContexts].map((ctx) => ({ ...ctx })).sort((a, b) => b.savedAt - a.savedAt);
		isLoaded.value = true;
	}
	async function saveContext() {
		const name = contextName.value.trim();
		if (!name) return false;
		const existing = savedContexts.value.findIndex((c) => c.name === name);
		const entry = {
			id: (existing >= 0 ? savedContexts.value[existing]?.id : void 0) ?? `ctx-${Date.now()}`,
			name,
			domain: domain.value.trim(),
			topic: topic.value.trim(),
			terms: terms.value.trim(),
			speakers: speakers.value.trim(),
			savedAt: Date.now()
		};
		if (existing >= 0) savedContexts.value[existing] = entry;
		else savedContexts.value.unshift(entry);
		savedContexts.value.sort((a, b) => b.savedAt - a.savedAt);
		settingsStore.savedContexts = savedContexts.value.map((ctx) => ({ ...ctx }));
		await settingsStore.saveSettings();
		return true;
	}
	function exportSavedContextsJson() {
		if (savedContexts.value.length === 0) return null;
		const payload = {
			version: 1,
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			contexts: savedContexts.value.map((ctx) => ({ ...ctx }))
		};
		return {
			filename: `saved-contexts-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`,
			content: JSON.stringify(payload, null, 2)
		};
	}
	async function importSavedContextsJson(jsonText) {
		const importedContexts = normalizeImportedContexts(JSON.parse(jsonText));
		const result = {
			imported: 0,
			updated: 0,
			skipped: 0,
			total: importedContexts.length
		};
		if (importedContexts.length === 0) return result;
		const merged = [...savedContexts.value];
		for (const incoming of importedContexts) {
			const existingIndex = merged.findIndex((ctx) => ctx.name.trim().toLowerCase() === incoming.name.trim().toLowerCase());
			if (existingIndex >= 0) {
				merged[existingIndex] = {
					...merged[existingIndex],
					...incoming,
					id: merged[existingIndex]?.id ?? incoming.id
				};
				result.updated += 1;
			} else {
				merged.push({
					...incoming,
					id: incoming.id || `ctx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
				});
				result.imported += 1;
			}
		}
		savedContexts.value = merged.sort((a, b) => b.savedAt - a.savedAt);
		settingsStore.savedContexts = savedContexts.value.map((ctx) => ({ ...ctx }));
		await settingsStore.saveSettings();
		return result;
	}
	function applySavedContext(ctx) {
		contextName.value = ctx.name;
		domain.value = ctx.domain;
		topic.value = ctx.topic;
		terms.value = ctx.terms;
		speakers.value = ctx.speakers;
	}
	function applyPageContext(title, description) {
		if (title.trim()) domain.value = title.trim();
		if (description.trim()) {
			const maxLen = 500;
			const text = description.trim();
			topic.value = text.length > maxLen ? text.substring(0, maxLen) + "..." : text;
		}
	}
	function clearForm() {
		contextName.value = "";
		domain.value = "";
		topic.value = "";
		terms.value = "";
		speakers.value = "";
	}
	return {
		contextName,
		domain,
		topic,
		terms,
		speakers,
		savedContexts,
		activeContext,
		hasContextData,
		isLoaded,
		loadSavedContexts,
		saveContext,
		exportSavedContextsJson,
		importSavedContextsJson,
		applySavedContext,
		applyPageContext,
		clearForm
	};
}
//#endregion
//#region src/services/openai-inline-assistant-client.ts
var OpenAIInlineAssistantClient = class {
	baseUrl = "https://api.openai.com/v1/responses";
	logPrefix = "[InlineAssistant:API]";
	apiKey;
	constructor(apiKey) {
		this.apiKey = apiKey;
	}
	setApiKey(apiKey) {
		this.apiKey = apiKey;
	}
	async run(request, signal) {
		if (!this.apiKey.trim()) throw new Error("OpenAI API key is not configured");
		const userPrompt = buildUserPrompt(request);
		const startedAt = Date.now();
		const body = {
			model: request.model,
			input: [{
				role: "system",
				content: [{
					type: "input_text",
					text: request.systemPrompt
				}]
			}, {
				role: "user",
				content: [{
					type: "input_text",
					text: userPrompt
				}]
			}]
		};
		body.tools = [{ type: "web_search_preview" }];
		console.log(this.logPrefix, "request-start", {
			model: request.model,
			systemPromptLength: request.systemPrompt.length,
			userPromptLength: userPrompt.length
		});
		const response = await fetch(this.baseUrl, {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${this.apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body),
			signal: signal ?? null
		});
		if (!response.ok) {
			const errorText = await response.text().catch(() => "Unknown error");
			console.error(this.logPrefix, "request-error", {
				status: response.status,
				elapsedMs: Date.now() - startedAt,
				bodySnippet: errorText.slice(0, 300)
			});
			throw new InlineAssistantApiError(response.status, errorText);
		}
		const output = extractOutputText(await response.json()).trim();
		if (!output) {
			console.warn(this.logPrefix, "empty-response", { elapsedMs: Date.now() - startedAt });
			throw new Error("OpenAI assistant returned an empty response");
		}
		console.log(this.logPrefix, "request-success", {
			elapsedMs: Date.now() - startedAt,
			outputLength: output.length
		});
		return output;
	}
};
function buildUserPrompt(request) {
	const parts = [];
	if (request.focusOriginal) {
		parts.push("Focus line (original):");
		parts.push(request.focusOriginal);
		parts.push("");
	}
	if (request.focusTranslation) {
		parts.push("Focus line (translated):");
		parts.push(request.focusTranslation);
		parts.push("");
	}
	parts.push("Full transcript context:");
	parts.push(request.transcriptContext || "(empty)");
	parts.push("");
	parts.push("User message:");
	parts.push(request.userMessage || "(empty)");
	return parts.join("\n");
}
function extractOutputText(payload) {
	if (typeof payload.output_text === "string" && payload.output_text.trim()) return payload.output_text;
	const textParts = [];
	for (const item of payload.output ?? []) for (const content of item.content ?? []) {
		if (typeof content.text === "string" && content.text.trim()) {
			textParts.push(content.text);
			continue;
		}
		if (content.text && typeof content.text === "object" && typeof content.text.value === "string" && content.text.value.trim()) textParts.push(content.text.value);
	}
	return textParts.join("\n\n");
}
var InlineAssistantApiError = class extends Error {
	constructor(status, body) {
		super(resolveApiErrorMessage(status, body));
		this.status = status;
		this.body = body;
		this.name = "InlineAssistantApiError";
	}
};
function resolveApiErrorMessage(status, body) {
	if (status === 401) return "Invalid OpenAI API key. Please check your key and try again.";
	if (status === 429) return "OpenAI rate limit reached. Please wait a moment and try again.";
	if (status >= 500) return "OpenAI service error. Please try again later.";
	try {
		return JSON.parse(body).error?.message ?? `OpenAI assistant error (${status})`;
	} catch {
		return `OpenAI assistant error (${status})`;
	}
}
//#endregion
//#region src/services/extension-update-api-client.ts
var API_BASE_URL = "https://translate-api.ezitech.io";
async function checkExtensionUpdate() {
	const response = await fetch(`${API_BASE_URL}/api/extension/check-update`, {
		method: "GET",
		headers: { Accept: "application/json" }
	});
	if (!response.ok) throw new Error(`Failed to check extension update (${response.status})`);
	return response.json();
}
//#endregion
//#region src/pages/TranslatorPage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "title-brand" };
var _hoisted_2 = { class: "title-brand__text" };
var _hoisted_3 = {
	key: 0,
	class: "title-brand__version"
};
var _hoisted_4 = ["title"];
var _hoisted_5 = { class: "title-actions" };
var _hoisted_6 = {
	key: 1,
	class: "license-verify-panel"
};
var _hoisted_7 = { class: "license-verify-panel__text" };
var _hoisted_8 = {
	key: 2,
	class: "license-verify-panel license-verify-panel--error"
};
var _hoisted_9 = { class: "license-verify-panel__message" };
var _hoisted_10 = { class: "license-verify-panel__actions" };
var _hoisted_11 = { class: "gc-btn__label" };
var _hoisted_12 = { class: "gc-btn__label" };
var DEFAULT_EXTENSION_INSTALL_URL = "https://translate.ezitech.io/#whats-new";
var INLINE_ASSISTANT_LOG_PREFIX = "[InlineAssistant:Page]";
var ASSISTANT_CHANNEL_NAME = "live-translator-assistant";
var INTERPRETER_CHAT_WARNING_COOLDOWN_MS = 6e3;
//#endregion
//#region src/pages/TranslatorPage.vue
var TranslatorPage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorPage",
	setup(__props) {
		const settingsStore = useSettingsStore();
		const translatorStore = useTranslatorStore();
		const authStore = useAuthStore();
		const { apiKey, targetLanguage, theirLanguage, microphoneEnabled, speakerNames, translationFontSize, narrationEnabled, narrateMyVoice, narrateAllSpeakers, sendMyTranslationViaChat, openaiApiKey, openaiAssistantModel, openaiAssistantChatPrompt, ttsVoice, voiceSpeed, voiceVolume, originalVolume, autoSyncSpeed, ttsProvider, googleVoiceId, browserVoiceId, narrateMyVoiceTtsVoice, narrateMyVoiceTtsProvider, narrateMyVoiceGoogleVoiceId } = storeToRefs(settingsStore);
		const { entries, currentSpeakerId, currentOriginal, currentTranslation, recordingState, isActive, error } = storeToRefs(translatorStore);
		const { start, pause, resume, end, setMicEnabled, configureTTS, setNarrationEnabled, applyNarrationSettings, startNarration, testNarrationVoice, stopNarration, ttsState, isInterpreterActive, isNarrationInjecting, isNarrateMyVoiceActive, onMyVoiceTranslation, onMyVoiceFlush, startInterpreterMode, stopInterpreterMode, setNarrateAllSpeakers, setSonioxNarrationSuppressed, enqueueTTSText } = useTranslation();
		const narrateMyVoice_ = useNarrateMyVoice();
		narrateMyVoice_.onInjectionStart.value = () => {
			isNarrationInjecting.value = true;
		};
		narrateMyVoice_.onInjectionEnd.value = () => {
			isNarrationInjecting.value = false;
		};
		onMyVoiceTranslation.value = (text) => {
			narrateMyVoice_.pushText(text);
		};
		onMyVoiceFlush.value = () => {
			narrateMyVoice_.flushText();
		};
		const captionNarration = useCaptionNarration();
		const isYouTubePage = ref(false);
		const captionNarrationEnabled = ref(false);
		const hostPageUrl = ref("");
		const sonioxPausedForCaptionNarration = ref(false);
		const isVideoCallPageSupported = computed(() => isVideoCallHost(hostPageUrl.value));
		const { downloadTxt, downloadJson, downloadSrtOriginal, downloadSrtTranslated, downloadMeetingSummary, downloadMeetingTaskBreakdown } = useDownloadTranscript();
		const { publish: publishSubtitle } = useSubtitlePublisher();
		const { t } = useI18n();
		const $q = useQuasar();
		const isSpeakerSettingsOpen = ref(false);
		const isDownloadDialogOpen = ref(false);
		const isSummaryDownloadLoading = ref(false);
		const isTaskBreakdownDownloadLoading = ref(false);
		const isNarrationSettingsOpen = ref(false);
		const isContextSettingsOpen = ref(false);
		const isProFeatureDialogOpen = ref(false);
		const isVerifyingLicense = ref(false);
		const licenseVerificationFailed = ref(false);
		const narrationTestError = ref(null);
		const isTestingVoice = ref(false);
		const isAssistantOpen = ref(false);
		const assistantMessages = ref([]);
		const assistantFocusLine = ref("");
		const assistantInitialInput = ref("");
		const assistantInputPrefillKey = ref(0);
		const isAssistantLoading = ref(false);
		const assistantFocusEntry = ref(null);
		let assistantAbortController = null;
		let downloadInsightAbortController = null;
		let inlineAssistantClient = null;
		let assistantMsgCounter = 0;
		let assistantChannel = null;
		const contextSettings = useContextSettings();
		let youtubeAutoApplied = false;
		const { isPro, requirePro, openLearnMore } = useProFeature({ onLocked: () => {
			isProFeatureDialogOpen.value = true;
		} });
		const showSaveTranscript = computed(() => recordingState.value === "stopped" && entries.value.length > 0);
		const sendMyTranslationViaChatAvailable = computed(() => isActive.value && theirLanguage.value !== "none" && theirLanguage.value !== targetLanguage.value && microphoneEnabled.value);
		const showNarrateAllSpeakersToggle = NARRATION_FEATURE_FLAGS.narrateAllSpeakersToggle;
		const extensionVersion = computed(() => {
			try {
				return chrome?.runtime?.getManifest?.()?.version || "";
			} catch {
				return "";
			}
		});
		const hasExtensionUpdate = ref(false);
		const latestExtensionVersion = ref("");
		const extensionInstallUrl = ref(DEFAULT_EXTENSION_INSTALL_URL);
		const extensionUpdateBadgeTitle = computed(() => latestExtensionVersion.value ? t("translator.updateAvailableWithVersion", { version: latestExtensionVersion.value }) : t("translator.updateAvailable"));
		let isDraggingPanel = false;
		let lastInterpreterChatWarningAt = 0;
		function buildTheirVoiceSelectionFromStore() {
			return {
				ttsVoice: ttsVoice.value,
				ttsProvider: ttsProvider.value,
				googleVoiceId: googleVoiceId.value,
				browserVoiceId: browserVoiceId.value
			};
		}
		function buildMyVoiceSelectionFromStore() {
			return {
				ttsVoice: narrateMyVoiceTtsVoice.value,
				ttsProvider: narrateMyVoiceTtsProvider.value,
				googleVoiceId: narrateMyVoiceGoogleVoiceId.value,
				browserVoiceId: browserVoiceId.value
			};
		}
		function buildNarrationSettings(voiceSelection = buildTheirVoiceSelectionFromStore()) {
			return {
				apiKey: openaiApiKey.value,
				voice: voiceSelection.ttsVoice,
				voiceSpeed: voiceSpeed.value,
				voiceVolume: voiceVolume.value,
				originalVolume: originalVolume.value,
				autoSyncSpeed: autoSyncSpeed.value,
				ttsProvider: voiceSelection.ttsProvider,
				googleVoiceId: voiceSelection.googleVoiceId,
				browserVoiceId: voiceSelection.browserVoiceId
			};
		}
		function resolveHintPrompt(template) {
			return (template?.trim() || "").trim().replaceAll("{{targetLanguage}}", targetLanguage.value);
		}
		function broadcastAssistantState() {
			try {
				assistantChannel?.postMessage({
					type: "state",
					messages: JSON.parse(JSON.stringify(assistantMessages.value)),
					loading: isAssistantLoading.value,
					focusLine: assistantFocusLine.value,
					initialInput: assistantInitialInput.value,
					inputPrefillKey: assistantInputPrefillKey.value,
					hintExplainPrompt: resolveHintPrompt(DEFAULT_SETTINGS.openaiAssistantExplainPrompt ?? ""),
					hintAnswerPrompt: resolveHintPrompt(DEFAULT_SETTINGS.openaiAssistantQAPrompt ?? "")
				});
			} catch {}
		}
		function setupAssistantChannel() {
			assistantChannel = new BroadcastChannel(ASSISTANT_CHANNEL_NAME);
			assistantChannel.onmessage = (event) => {
				const data = event.data;
				if (!data?.type) return;
				switch (data.type) {
					case "send":
						if (data.payload) handleAssistantSend(data.payload);
						break;
					case "close":
						closeAssistant();
						break;
					case "clear":
						clearAssistantChat();
						broadcastAssistantState();
						break;
					case "request-state":
						broadcastAssistantState();
						break;
				}
			};
		}
		function handlePageContextResult(event) {
			const data = event.data;
			if (data?.type !== "PAGE_CONTEXT_RESULT") return;
			isYouTubePage.value = data.pageType === "youtube";
			hostPageUrl.value = data.pageUrl ?? "";
			if (data.pageType === "youtube" && !youtubeAutoApplied) {
				youtubeAutoApplied = true;
				contextSettings.applyPageContext(data.title ?? "", data.description ?? "");
				console.info("[Context] Auto-applied YouTube context:", { title: data.title });
			}
		}
		function requestPageContext() {
			sendPanelMessage({ type: "REQUEST_PAGE_CONTEXT" });
		}
		onMounted(async () => {
			await settingsStore.loadSettings();
			await authStore.loadAuth();
			contextSettings.loadSavedContexts();
			handleMicToggle(false);
			syncTTSConfig();
			if (!showNarrateAllSpeakersToggle && narrateAllSpeakers.value) settingsStore.narrateAllSpeakers = false;
			setNarrateAllSpeakers(showNarrateAllSpeakersToggle ? narrateAllSpeakers.value : false);
			setupAssistantChannel();
			window.addEventListener("message", handleChatSendResult);
			window.addEventListener("message", handlePageContextResult);
			narrateMyVoice_.checkPlatformSupport();
			checkExtensionUpdateOnce();
			requestPageContext();
			if (authStore.hasActiveLicense) {
				isVerifyingLicense.value = true;
				const result = await authStore.verifyWithServer();
				isVerifyingLicense.value = false;
				if (!result.valid) licenseVerificationFailed.value = true;
			}
		});
		async function checkExtensionUpdateOnce() {
			if (!extensionVersion.value) return;
			try {
				const response = await checkExtensionUpdate();
				const currentVersion = normalizeVersion(extensionVersion.value);
				const latestVersion = normalizeVersion(response.latest_version ?? "");
				latestExtensionVersion.value = latestVersion;
				hasExtensionUpdate.value = compareNormalizedVersions(latestVersion, currentVersion) > 0;
				extensionInstallUrl.value = response.install_url || DEFAULT_EXTENSION_INSTALL_URL;
			} catch {
				hasExtensionUpdate.value = false;
				latestExtensionVersion.value = "";
				extensionInstallUrl.value = DEFAULT_EXTENSION_INSTALL_URL;
			}
		}
		function normalizeVersion(version) {
			return version.trim().replace(/^[vV]/, "");
		}
		function compareNormalizedVersions(left, right) {
			const leftParts = left.split(".").map((part) => Number.parseInt(part, 10) || 0);
			const rightParts = right.split(".").map((part) => Number.parseInt(part, 10) || 0);
			const maxParts = Math.max(leftParts.length, rightParts.length);
			for (let index = 0; index < maxParts; index += 1) {
				const leftValue = leftParts[index] ?? 0;
				const rightValue = rightParts[index] ?? 0;
				if (leftValue > rightValue) return 1;
				if (leftValue < rightValue) return -1;
			}
			return 0;
		}
		function isVideoCallHost(pageUrl) {
			if (!pageUrl.trim()) return false;
			try {
				const hostname = new URL(pageUrl).hostname.toLowerCase();
				return hostname.includes("facebook.com") || hostname.includes("meet.google.com") || hostname.includes("zoom.us") || hostname.includes("teams.microsoft.com") || hostname.includes("teams.live.com") || hostname.includes("web.whatsapp.com");
			} catch {
				return false;
			}
		}
		function syncTTSConfig() {
			const needsKey = ttsProvider.value === "openai";
			if (!needsKey || openaiApiKey.value) configureTTS(buildNarrationSettings());
			setNarrationEnabled(narrationEnabled.value && (!needsKey || !!openaiApiKey.value));
		}
		watch([
			openaiApiKey,
			ttsVoice,
			ttsProvider,
			googleVoiceId
		], () => {
			syncTTSConfig();
		});
		watch(narrationEnabled, () => {
			syncTTSConfig();
		});
		watch(narrateAllSpeakers, (val) => {
			setNarrateAllSpeakers(showNarrateAllSpeakersToggle ? val : false);
		});
		watch([
			assistantMessages,
			isAssistantLoading,
			assistantFocusLine,
			assistantInitialInput,
			assistantInputPrefillKey,
			targetLanguage
		], () => {
			if (isAssistantOpen.value) broadcastAssistantState();
		}, { deep: true });
		watch([
			currentTranslation,
			currentOriginal,
			isActive
		], () => {
			publishSubtitle({
				currentTranslation: currentTranslation.value,
				currentOriginal: currentOriginal.value,
				isActive: isActive.value
			});
		});
		watch([sendMyTranslationViaChat, sendMyTranslationViaChatAvailable], ([enabled, available]) => {
			if (enabled && available && !isInterpreterActive.value) {
				startInterpreterMode(handleInterpreterTextReady);
				return;
			}
			if ((!enabled || !available) && isInterpreterActive.value) stopInterpreterMode();
		}, { immediate: true });
		function handleStart() {
			if (!apiKey.value) return;
			warnMissingOpenAiFeaturesOnStart();
			start(apiKey.value, targetLanguage.value, microphoneEnabled.value, theirLanguage.value, contextSettings.activeContext.value);
		}
		function handlePause() {
			pause();
		}
		function handleResume() {
			if (captionNarration.isActive.value) {
				console.info("[CaptionNarration] Soniox resume ignored while caption narration is active");
				return;
			}
			resume();
		}
		function suppressSonioxForCaptionNarration() {
			setSonioxNarrationSuppressed(true);
			if (!isActive.value || sonioxPausedForCaptionNarration.value) return;
			if (recordingState.value === "recording") {
				pause();
				sonioxPausedForCaptionNarration.value = true;
				console.info("[CaptionNarration] Soniox paused while caption narration is active");
			}
		}
		function releaseSonioxAfterCaptionNarration() {
			setSonioxNarrationSuppressed(false);
			if (!sonioxPausedForCaptionNarration.value) return;
			sonioxPausedForCaptionNarration.value = false;
			if (isActive.value) {
				resume();
				console.info("[CaptionNarration] Soniox resumed after caption narration");
			}
		}
		async function handleEnd() {
			setSonioxNarrationSuppressed(false);
			sonioxPausedForCaptionNarration.value = false;
			if (captionNarration.isActive.value) captionNarration.stop();
			releaseSonioxAfterCaptionNarration();
			if (narrationEnabled.value || ttsState.isSpeaking.value || captionNarration.isActive.value) {
				settingsStore.narrationEnabled = false;
				stopNarration();
			}
			if (narrateMyVoice.value || narrateMyVoice_.isEnabled.value) {
				settingsStore.narrateMyVoice = false;
				isNarrateMyVoiceActive.value = false;
				narrateMyVoice_.disable();
			}
			if (sendMyTranslationViaChat.value || isInterpreterActive.value) {
				settingsStore.sendMyTranslationViaChat = false;
				stopInterpreterMode();
			}
			settingsStore.microphoneEnabled = false;
			if (isActive.value) {
				await setMicEnabled(false);
				await end();
			}
			clearAssistantChat();
			if (isAssistantOpen.value) broadcastAssistantState();
		}
		async function handleEndFromControls() {
			const hasTranscript = entries.value.length > 0;
			await handleEnd();
			if (hasTranscript) isDownloadDialogOpen.value = true;
		}
		function notifyOpenAiFeatureWarning(featureName) {
			$q.notify({
				icon: "warning",
				color: "warning",
				textColor: "black",
				message: t("translator.openaiFeatureWarning", { feature: featureName }),
				position: "top",
				timeout: 2500
			});
		}
		function warnMissingOpenAiFeaturesOnStart() {
			if (openaiApiKey.value.trim()) return;
			const features = /* @__PURE__ */ new Set();
			const usesOpenAiTheirVoice = ttsProvider.value === "openai";
			const usesOpenAiMyVoice = narrateMyVoiceTtsProvider.value === "openai";
			if (isPro.value) features.add(t("translator.assistantOpen"));
			if (usesOpenAiTheirVoice && isPro.value) features.add(t("translator.narrateTheirVoice"));
			if (usesOpenAiMyVoice && isPro.value) features.add(t("translator.narrateMyVoice"));
			features.forEach((featureName) => {
				notifyOpenAiFeatureWarning(featureName);
			});
		}
		function handleMicToggle(enabled) {
			if (enabled && !isVideoCallPageSupported.value) return;
			settingsStore.microphoneEnabled = enabled;
			if (!enabled && (isInterpreterActive.value || sendMyTranslationViaChat.value)) {
				settingsStore.sendMyTranslationViaChat = false;
				stopInterpreterMode();
			}
			if (isActive.value) setMicEnabled(enabled);
		}
		function handleOpenNarrationSettings() {
			narrationTestError.value = null;
			isNarrationSettingsOpen.value = true;
		}
		function saveDialogSettings(settings) {
			settingsStore.ttsVoice = settings.ttsVoice;
			settingsStore.narrateMyVoiceTtsVoice = settings.myTtsVoice;
			settingsStore.voiceSpeed = settings.voiceSpeed;
			settingsStore.voiceVolume = settings.voiceVolume;
			settingsStore.originalVolume = settings.originalVolume;
			settingsStore.autoSyncSpeed = settings.autoSyncSpeed;
			if (settings.ttsProvider !== void 0) settingsStore.ttsProvider = settings.ttsProvider;
			if (settings.myTtsProvider !== void 0) settingsStore.narrateMyVoiceTtsProvider = settings.myTtsProvider;
			if (settings.googleVoiceId !== void 0) settingsStore.googleVoiceId = settings.googleVoiceId;
			if (settings.browserVoiceId !== void 0) settingsStore.browserVoiceId = settings.browserVoiceId;
			if (settings.myGoogleVoiceId !== void 0) settingsStore.narrateMyVoiceGoogleVoiceId = settings.myGoogleVoiceId;
		}
		async function handleStartNarrateTheirVoice(settings) {
			if (!isActive.value) return;
			narrationTestError.value = null;
			saveDialogSettings(settings);
			applyNarrationSettings(buildNarrationSettings({
				ttsVoice: settings.ttsVoice,
				ttsProvider: settings.ttsProvider,
				googleVoiceId: settings.googleVoiceId,
				browserVoiceId: settings.browserVoiceId
			}));
			if (!await requirePro("narration")) {
				settingsStore.narrationEnabled = false;
				return;
			}
			if (settings.ttsProvider === "openai" && !openaiApiKey.value.trim()) {
				narrationTestError.value = t("errors.openaiApiKeyRequired");
				settingsStore.narrationEnabled = false;
				return;
			}
			if (narrateMyVoice_.isEnabled.value) {
				isNarrateMyVoiceActive.value = false;
				settingsStore.narrateMyVoice = false;
				narrateMyVoice_.disable();
			}
			if (captionNarration.isActive.value) captionNarration.stop();
			releaseSonioxAfterCaptionNarration();
			const narrationSettings = buildNarrationSettings({
				ttsVoice: settings.ttsVoice,
				ttsProvider: settings.ttsProvider,
				googleVoiceId: settings.googleVoiceId,
				browserVoiceId: settings.browserVoiceId
			});
			let narrationPipelineStarted = false;
			if (captionNarrationEnabled.value && isYouTubePage.value && NARRATION_FEATURE_FLAGS.captionNarration) {
				settingsStore.narrationEnabled = true;
				startNarration(narrationSettings);
				narrationPipelineStarted = true;
				suppressSonioxForCaptionNarration();
				if (await captionNarration.start(hostPageUrl.value, targetLanguage.value, {
					onSegmentReady: (text, language, targetDurationMs) => {
						enqueueTTSText(text, language, targetDurationMs);
					},
					onWarning: (message) => {
						console.warn("[CaptionNarration]", message);
						$q.notify({
							type: "warning",
							message,
							timeout: 5e3
						});
					},
					onFallbackToSoniox: () => {
						releaseSonioxAfterCaptionNarration();
						console.info("[CaptionNarration] Caption load failed — falling back to Soniox narration pipeline");
						$q.notify({
							type: "info",
							message: t("translator.captionFallbackToSoniox"),
							timeout: 4e3
						});
					},
					onStarted: () => {
						suppressSonioxForCaptionNarration();
						console.info("[CaptionNarration] Caption narration active — bypassing Soniox");
						$q.notify({
							type: "positive",
							message: t("translator.captionNarrationActive"),
							timeout: 3e3
						});
					},
					onStopped: () => {
						releaseSonioxAfterCaptionNarration();
						console.info("[CaptionNarration] Caption narration stopped");
					}
				}, settings.ttsProvider)) return;
				releaseSonioxAfterCaptionNarration();
			}
			if (!narrationPipelineStarted) {
				settingsStore.narrationEnabled = true;
				startNarration(narrationSettings);
			}
		}
		async function handleStartNarrateMyVoice(settings) {
			if (!isActive.value) return;
			narrationTestError.value = null;
			saveDialogSettings(settings);
			applyNarrationSettings(buildNarrationSettings());
			if (narrateMyVoice_.isEnabled.value) narrateMyVoice_.switchProvider(settings.myTtsProvider, openaiApiKey.value, settings.myTtsVoice, settings.myGoogleVoiceId);
			await handleToggleNarrateMyVoice(true);
		}
		function handleStopNarrationMode() {
			if (captionNarration.isActive.value) captionNarration.stop();
			releaseSonioxAfterCaptionNarration();
			if (narrationEnabled.value) {
				settingsStore.narrationEnabled = false;
				stopNarration();
			}
			if (narrateMyVoice.value || narrateMyVoice_.isEnabled.value) {
				settingsStore.narrateMyVoice = false;
				isNarrateMyVoiceActive.value = false;
				narrateMyVoice_.disable();
			}
		}
		function handleToggleCaptionNarration(enabled) {
			captionNarrationEnabled.value = enabled;
		}
		async function handleNarrationTest(settings) {
			narrationTestError.value = null;
			const provider = settings.ttsProvider ?? ttsProvider.value;
			if (provider === "openai" && !openaiApiKey.value.trim()) {
				narrationTestError.value = t("errors.openaiApiKeyRequired");
				return;
			}
			isTestingVoice.value = true;
			try {
				await testNarrationVoice({
					apiKey: openaiApiKey.value,
					voice: settings.ttsVoice,
					voiceSpeed: settings.voiceSpeed,
					voiceVolume: settings.voiceVolume,
					originalVolume: settings.originalVolume,
					autoSyncSpeed: settings.autoSyncSpeed,
					ttsProvider: provider,
					googleVoiceId: settings.googleVoiceId,
					browserVoiceId: settings.browserVoiceId
				});
			} catch (err) {
				narrationTestError.value = err instanceof Error ? err.message : "Voice test failed";
			} finally {
				isTestingVoice.value = false;
			}
		}
		function handleToggleNarrateAllSpeakers(enabled) {
			if (!showNarrateAllSpeakersToggle) return;
			settingsStore.narrateAllSpeakers = enabled;
		}
		async function handleToggleNarrateMyVoice(enabled) {
			if (enabled && !isVideoCallPageSupported.value) {
				settingsStore.narrateMyVoice = false;
				return;
			}
			settingsStore.narrateMyVoice = enabled;
			if (enabled) {
				if (!await requirePro("narrate-my-voice")) {
					settingsStore.narrateMyVoice = false;
					return;
				}
				const myVoiceSelection = buildMyVoiceSelectionFromStore();
				const provider = myVoiceSelection.ttsProvider;
				if (provider === "openai" && !openaiApiKey.value.trim() || !isActive.value || theirLanguage.value === "none") {
					settingsStore.narrateMyVoice = false;
					return;
				}
				if (narrationEnabled.value) {
					if (captionNarration.isActive.value) captionNarration.stop();
					releaseSonioxAfterCaptionNarration();
					settingsStore.narrationEnabled = false;
					stopNarration();
				}
				isNarrateMyVoiceActive.value = true;
				narrateMyVoice_.enable(openaiApiKey.value, myVoiceSelection.ttsVoice, targetLanguage.value, theirLanguage.value, 1, provider, myVoiceSelection.googleVoiceId);
			} else {
				isNarrateMyVoiceActive.value = false;
				narrateMyVoice_.disable();
			}
		}
		async function handleToggleSendMyTranslationViaChat(enabled) {
			if (enabled && !isVideoCallPageSupported.value) {
				settingsStore.sendMyTranslationViaChat = false;
				return;
			}
			if (enabled) {
				if (!await requirePro("interpreter-mode")) return;
				settingsStore.sendMyTranslationViaChat = true;
				return;
			}
			settingsStore.sendMyTranslationViaChat = false;
		}
		function handleOpenContextSettings() {
			isContextSettingsOpen.value = true;
		}
		function downloadTextFile(content, filename, mimeType) {
			const blob = new Blob([content], { type: mimeType });
			const url = URL.createObjectURL(blob);
			const anchor = document.createElement("a");
			anchor.href = url;
			anchor.download = filename;
			document.body.appendChild(anchor);
			anchor.click();
			document.body.removeChild(anchor);
			URL.revokeObjectURL(url);
		}
		async function handleContextSave() {
			if (await contextSettings.saveContext()) {
				$q.notify({
					icon: "check_circle",
					color: "positive",
					message: t("context.saved"),
					position: "top",
					timeout: 1500
				});
				return;
			}
			$q.notify({
				icon: "error",
				color: "negative",
				message: "Failed to save context",
				position: "top",
				timeout: 1800
			});
		}
		function handleContextExport() {
			const exported = contextSettings.exportSavedContextsJson();
			if (!exported) {
				$q.notify({
					icon: "warning",
					color: "warning",
					textColor: "black",
					message: t("context.noDataToExport"),
					position: "top",
					timeout: 1600
				});
				return;
			}
			downloadTextFile(exported.content, exported.filename, "application/json;charset=utf-8");
			$q.notify({
				icon: "file_download_done",
				color: "positive",
				message: t("context.exported"),
				position: "top",
				timeout: 1500
			});
		}
		async function handleContextImport(file) {
			await handleContextImportRaw(await file.text());
		}
		async function handleContextImportRaw(raw) {
			try {
				const result = await contextSettings.importSavedContextsJson(raw);
				if (result.imported === 0 && result.updated === 0) {
					$q.notify({
						icon: "warning",
						color: "warning",
						textColor: "black",
						message: t("context.importedNone"),
						position: "top",
						timeout: 1800
					});
					return;
				}
				$q.notify({
					icon: "check_circle",
					color: "positive",
					message: t("context.importedSummary", {
						imported: result.imported,
						updated: result.updated
					}),
					position: "top",
					timeout: 2e3
				});
			} catch {
				$q.notify({
					icon: "error",
					color: "negative",
					message: t("context.importFailed"),
					position: "top",
					timeout: 1800
				});
			}
		}
		async function handleContextApply() {
			if (isActive.value) {
				await end();
				start(apiKey.value, targetLanguage.value, microphoneEnabled.value, theirLanguage.value, contextSettings.activeContext.value);
			}
			$q.notify({
				icon: "check_circle",
				color: "positive",
				message: t("context.applied"),
				position: "top",
				timeout: 1500
			});
			isContextSettingsOpen.value = false;
		}
		function handleApplySavedContext(ctx) {
			contextSettings.applySavedContext(ctx);
		}
		function handleLockedAction() {
			isProFeatureDialogOpen.value = true;
		}
		function handleLearnMore() {
			openLearnMore();
			isProFeatureDialogOpen.value = false;
		}
		function handleEnterLicense() {
			isProFeatureDialogOpen.value = false;
			licenseVerificationFailed.value = false;
			try {
				const settingsUrl = chrome.runtime.getURL("www/index.html#/settings?tab=license");
				window.open(settingsUrl, "_blank", "noopener");
			} catch {
				openSettingsPage();
			}
		}
		function handleVerificationClose() {
			licenseVerificationFailed.value = false;
		}
		function getAssistantClient() {
			if (!inlineAssistantClient) {
				inlineAssistantClient = new OpenAIInlineAssistantClient(openaiApiKey.value);
				console.log(INLINE_ASSISTANT_LOG_PREFIX, "client-created");
				return inlineAssistantClient;
			}
			inlineAssistantClient.setApiKey(openaiApiKey.value);
			return inlineAssistantClient;
		}
		function buildAssistantContext(allEntries, focusedEntryId, includeTranslated = false) {
			return allEntries.map((entry, index) => {
				const speaker = entry.audioSource === "mic" ? t("translator.you") : resolveSpeakerLabel(entry.speakerId, speakerNames.value, t("translator.speaker"), t("translator.speakerUnknown"));
				const marker = entry.id === focusedEntryId ? " <FOCUS>" : "";
				const originalText = entry.originalText || "(empty)";
				const translatedText = entry.translatedText || "(empty)";
				const translatedLine = includeTranslated ? `\n   Translated(${entry.targetLanguage}): ${translatedText}` : "";
				return `${index + 1}. [${speaker}] Original: ${originalText}${translatedLine}${marker}`;
			}).join("\n");
		}
		function buildAssistantSystemPrompt() {
			return (openaiAssistantChatPrompt.value?.trim() || (DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "")).trim().replaceAll("{{targetLanguage}}", targetLanguage.value);
		}
		function genMsgId() {
			assistantMsgCounter++;
			return `msg-${Date.now()}-${assistantMsgCounter}`;
		}
		async function handleOpenAssistantFromRow(payload) {
			if (!await requirePro("inline-assistant")) return;
			const entry = payload.entry;
			assistantFocusEntry.value = entry;
			assistantFocusLine.value = entry.translatedText || entry.originalText;
			assistantInitialInput.value = assistantFocusLine.value;
			assistantInputPrefillKey.value += 1;
			isAssistantOpen.value = true;
			sendPanelMessage({ type: "ASSISTANT_OPEN" });
			nextTick(() => broadcastAssistantState());
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "popup-opened-from-row", { entryId: entry.id });
		}
		async function handleOpenAssistantFromControls() {
			if (!await requirePro("inline-assistant")) return;
			assistantFocusEntry.value = null;
			assistantFocusLine.value = "";
			assistantInitialInput.value = "";
			assistantInputPrefillKey.value += 1;
			isAssistantOpen.value = true;
			sendPanelMessage({ type: "ASSISTANT_OPEN" });
			nextTick(() => broadcastAssistantState());
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "popup-opened-from-controls");
		}
		async function handleAssistantSend(message) {
			const userMsg = {
				id: genMsgId(),
				role: "user",
				content: message,
				timestamp: Date.now()
			};
			assistantMessages.value.push(userMsg);
			assistantInitialInput.value = "";
			broadcastAssistantState();
			await runAssistantRequest(message);
		}
		async function runAssistantRequest(userMessage) {
			const startedAt = Date.now();
			isAssistantLoading.value = true;
			if (!openaiApiKey.value.trim()) {
				assistantMessages.value.push({
					id: genMsgId(),
					role: "assistant",
					content: t("errors.openaiApiKeyRequiredAssistant"),
					timestamp: Date.now()
				});
				isAssistantLoading.value = false;
				return;
			}
			assistantAbortController?.abort();
			assistantAbortController = new AbortController();
			const model = openaiAssistantModel.value?.trim() || "gpt-4.1-mini";
			const systemPrompt = buildAssistantSystemPrompt();
			const focusEntry = assistantFocusEntry.value;
			const transcriptContext = buildAssistantContext(entries.value, focusEntry?.id ?? "", false);
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "request-prepared", {
				model,
				hasFocusEntry: Boolean(focusEntry),
				transcriptContextLength: transcriptContext.length
			});
			try {
				const result = await getAssistantClient().run({
					model,
					systemPrompt,
					transcriptContext,
					userMessage,
					focusOriginal: focusEntry?.originalText ?? "",
					focusTranslation: focusEntry?.translatedText ?? ""
				}, assistantAbortController.signal);
				assistantMessages.value.push({
					id: genMsgId(),
					role: "assistant",
					content: result,
					timestamp: Date.now()
				});
				console.log(INLINE_ASSISTANT_LOG_PREFIX, "request-success", {
					resultLength: result.length,
					elapsedMs: Date.now() - startedAt
				});
			} catch (err) {
				if (err.name === "AbortError") return;
				const errorMsg = err instanceof Error ? err.message : t("errors.serviceError");
				assistantMessages.value.push({
					id: genMsgId(),
					role: "assistant",
					content: `⚠ ${errorMsg}`,
					timestamp: Date.now()
				});
				console.error(INLINE_ASSISTANT_LOG_PREFIX, "request-failed", {
					elapsedMs: Date.now() - startedAt,
					error: err
				});
			} finally {
				isAssistantLoading.value = false;
				assistantAbortController = null;
			}
		}
		function closeAssistant() {
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "popup-closed", { hadPendingRequest: Boolean(assistantAbortController) });
			assistantAbortController?.abort();
			assistantAbortController = null;
			isAssistantLoading.value = false;
			isAssistantOpen.value = false;
			sendPanelMessage({ type: "ASSISTANT_CLOSE" });
		}
		function clearAssistantChat() {
			assistantMessages.value = [];
			assistantFocusLine.value = "";
			assistantFocusEntry.value = null;
			assistantInitialInput.value = "";
			assistantInputPrefillKey.value += 1;
		}
		async function handleLanguageChange(lang) {
			settingsStore.targetLanguage = lang;
			if (isActive.value) {
				if (isInterpreterActive.value) stopInterpreterMode();
				await end();
				start(apiKey.value, lang, microphoneEnabled.value, theirLanguage.value, contextSettings.activeContext.value);
			}
		}
		async function handleTheirLanguageChange(lang) {
			settingsStore.theirLanguage = lang;
			if (isActive.value) {
				if (isInterpreterActive.value) stopInterpreterMode();
				await end();
				start(apiKey.value, targetLanguage.value, microphoneEnabled.value, lang, contextSettings.activeContext.value);
			}
		}
		function handleInterpreterTextReady(text) {
			console.info("[Interpreter] sending to chat:", text.substring(0, 80));
			sendPanelMessage({
				type: "SEND_CHAT_MESSAGE",
				text
			});
		}
		function handleChatSendResult(event) {
			const data = event.data;
			if (data?.type !== "CHAT_SEND_RESULT") return;
			if (!data.success && data.error) {
				const now = Date.now();
				if (now - lastInterpreterChatWarningAt >= INTERPRETER_CHAT_WARNING_COOLDOWN_MS) {
					const isChatPanelClosed = data.error.toLowerCase().includes("chat input not found");
					$q.notify({
						icon: "warning",
						color: "warning",
						textColor: "black",
						message: isChatPanelClosed ? t("translator.chatNotFound") : t("translator.chatSendError"),
						position: "top",
						timeout: 3500
					});
					lastInterpreterChatWarningAt = now;
				}
				console.warn("[Interpreter] Chat send failed:", data.error);
			}
		}
		async function handleSpeakerSettingsSave(updatedNames) {
			if (!await requirePro("speaker-names")) return;
			settingsStore.setSpeakerNames(updatedNames);
			await settingsStore.saveSettings();
		}
		async function handleSaveTranscript() {
			if (!await requirePro("download-srt")) return;
			isDownloadDialogOpen.value = true;
		}
		function handleTranslationFontSizeChange(size) {
			settingsStore.translationFontSize = size;
		}
		function handleDownloadSrtOriginal() {
			downloadSrtOriginal(entries.value);
		}
		function handleDownloadSrtTranslated() {
			downloadSrtTranslated(entries.value);
		}
		function handleDownloadTxt() {
			downloadTxt(entries.value);
		}
		function handleDownloadJson() {
			downloadJson(entries.value);
		}
		function resetDownloadInsightLoading() {
			isSummaryDownloadLoading.value = false;
			isTaskBreakdownDownloadLoading.value = false;
		}
		async function handleDownloadSummary() {
			if (isSummaryDownloadLoading.value || isTaskBreakdownDownloadLoading.value) return;
			downloadInsightAbortController?.abort();
			const abortController = new AbortController();
			downloadInsightAbortController = abortController;
			isSummaryDownloadLoading.value = true;
			$q.notify({
				icon: "hourglass_top",
				color: "info",
				message: t("translator.downloadSummaryGenerating"),
				position: "top",
				timeout: 1200
			});
			try {
				await downloadMeetingSummary(entries.value, abortController.signal);
				isDownloadDialogOpen.value = false;
				$q.notify({
					icon: "file_download_done",
					color: "positive",
					message: t("translator.downloadSummaryReady"),
					position: "top",
					timeout: 1800
				});
			} catch (err) {
				if (err instanceof Error && err.name === "AbortError") return;
				const message = err instanceof Error ? err.message : t("errors.serviceError");
				$q.notify({
					icon: "error",
					color: "negative",
					message,
					position: "top",
					timeout: 2200
				});
			} finally {
				if (downloadInsightAbortController === abortController) downloadInsightAbortController = null;
				isSummaryDownloadLoading.value = false;
			}
		}
		async function handleDownloadTaskBreakdown() {
			if (isTaskBreakdownDownloadLoading.value || isSummaryDownloadLoading.value) return;
			downloadInsightAbortController?.abort();
			const abortController = new AbortController();
			downloadInsightAbortController = abortController;
			isTaskBreakdownDownloadLoading.value = true;
			$q.notify({
				icon: "hourglass_top",
				color: "info",
				message: t("translator.downloadTaskBreakdownGenerating"),
				position: "top",
				timeout: 1200
			});
			try {
				await downloadMeetingTaskBreakdown(entries.value, abortController.signal);
				isDownloadDialogOpen.value = false;
				$q.notify({
					icon: "file_download_done",
					color: "positive",
					message: t("translator.downloadTaskBreakdownReady"),
					position: "top",
					timeout: 1800
				});
			} catch (err) {
				if (err instanceof Error && err.name === "AbortError") return;
				const message = err instanceof Error ? err.message : t("errors.serviceError");
				$q.notify({
					icon: "error",
					color: "negative",
					message,
					position: "top",
					timeout: 2200
				});
			} finally {
				if (downloadInsightAbortController === abortController) downloadInsightAbortController = null;
				isTaskBreakdownDownloadLoading.value = false;
			}
		}
		function sendPanelMessage(message) {
			try {
				window.parent.postMessage(message, "*");
			} catch {}
		}
		function stopPanelDrag(shouldNotifyParent = true) {
			if (!isDraggingPanel) return;
			isDraggingPanel = false;
			window.removeEventListener("mousemove", handleWindowMouseMove);
			window.removeEventListener("mouseup", handleWindowMouseUp);
			if (shouldNotifyParent) sendPanelMessage({ type: "PANEL_DRAG_END" });
		}
		function handleWindowMouseMove(event) {
			if (!isDraggingPanel) return;
			sendPanelMessage({
				type: "PANEL_DRAG_MOVE",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
		}
		function handleWindowMouseUp() {
			stopPanelDrag(true);
		}
		function isInteractiveTitleBarTarget(target) {
			if (!(target instanceof HTMLElement)) return false;
			return Boolean(target.closest("button, [role=\"button\"], a, input, textarea, select, [contenteditable=\"true\"], [data-no-panel-drag]"));
		}
		function handleTitleBarMouseDown(event) {
			if (event.button !== 0) return;
			if (isInteractiveTitleBarTarget(event.target)) return;
			event.preventDefault();
			isDraggingPanel = true;
			sendPanelMessage({
				type: "PANEL_DRAG_START",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
			window.addEventListener("mousemove", handleWindowMouseMove);
			window.addEventListener("mouseup", handleWindowMouseUp);
		}
		function openSettingsPage() {
			try {
				if (typeof chrome !== "undefined" && chrome.runtime?.openOptionsPage) {
					chrome.runtime.openOptionsPage();
					return;
				}
			} catch {}
			try {
				if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
					window.open(chrome.runtime.getURL("www/index.html#/settings"), "_blank", "noopener");
					return;
				}
			} catch {}
			window.open(`${window.location.origin}/www/index.html#/settings`, "_blank", "noopener");
		}
		function openSonioxSettingsPage() {
			try {
				if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
					const settingsUrl = chrome.runtime.getURL("www/index.html#/settings?tab=soniox");
					window.open(settingsUrl, "_blank", "noopener");
					return;
				}
			} catch {}
			window.open(`${window.location.origin}/www/index.html#/settings?tab=soniox`, "_blank", "noopener");
		}
		function openExtensionInstallPage() {
			window.open(extensionInstallUrl.value, "_blank", "noopener");
		}
		function handleSubtitleMode() {
			stopPanelDrag(false);
			sendPanelMessage({ type: "SUBTITLE_MODE_ON" });
		}
		async function handleClose() {
			stopPanelDrag(false);
			await handleEnd();
			sendPanelMessage({ type: "CLOSE_PANEL" });
		}
		function handleMinimize() {
			stopPanelDrag(false);
			sendPanelMessage({ type: "MINIMIZE_PANEL" });
		}
		onBeforeUnmount(() => {
			stopPanelDrag(true);
			assistantAbortController?.abort();
			assistantAbortController = null;
			downloadInsightAbortController?.abort();
			downloadInsightAbortController = null;
			resetDownloadInsightLoading();
			assistantChannel?.close();
			assistantChannel = null;
			window.removeEventListener("message", handleChatSendResult);
			window.removeEventListener("message", handlePageContextResult);
			if (isInterpreterActive.value) stopInterpreterMode();
			releaseSonioxAfterCaptionNarration();
			isNarrateMyVoiceActive.value = false;
			narrateMyVoice_.dispose();
			captionNarration.dispose();
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QPage_default, { class: "translator-page" }, {
				default: withCtx(() => [
					createBaseVNode("div", {
						class: "title-bar",
						onMousedown: handleTitleBarMouseDown
					}, [createBaseVNode("div", _hoisted_1, [
						createVNode(QIcon_default, {
							name: "translate",
							size: "18px",
							class: "title-brand__icon"
						}),
						createBaseVNode("span", _hoisted_2, toDisplayString(_ctx.$t("translator.title")), 1),
						extensionVersion.value ? (openBlock(), createElementBlock("span", _hoisted_3, "v" + toDisplayString(extensionVersion.value), 1)) : createCommentVNode("", true),
						hasExtensionUpdate.value ? (openBlock(), createElementBlock("button", {
							key: 1,
							type: "button",
							class: "title-brand__update-badge",
							"data-no-panel-drag": "",
							title: extensionUpdateBadgeTitle.value,
							onClick: openExtensionInstallPage
						}, toDisplayString(_ctx.$t("translator.updateAvailable")), 9, _hoisted_4)) : createCommentVNode("", true)
					]), createBaseVNode("div", _hoisted_5, [
						createBaseVNode("button", {
							class: "title-action-btn",
							"data-no-panel-drag": "",
							onClick: openSettingsPage
						}, [createVNode(QIcon_default, {
							name: "settings",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("settings.settingsTooltip")), 1)]),
							_: 1
						})]),
						createBaseVNode("button", {
							class: "title-action-btn",
							"data-no-panel-drag": "",
							onClick: handleSubtitleMode
						}, [createVNode(QIcon_default, {
							name: "subtitles",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.subtitleMode")), 1)]),
							_: 1
						})]),
						createBaseVNode("button", {
							class: "title-action-btn",
							"data-no-panel-drag": "",
							onClick: handleMinimize
						}, [createVNode(QIcon_default, {
							name: "remove",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.minimize")), 1)]),
							_: 1
						})]),
						createBaseVNode("button", {
							class: "title-action-btn title-action-btn--danger",
							"data-no-panel-drag": "",
							onClick: handleClose
						}, [createVNode(QIcon_default, {
							name: "close",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.close")), 1)]),
							_: 1
						})])
					])], 32),
					createVNode(TranslatorHeader_default, {
						"target-language": unref(targetLanguage),
						"their-language": unref(theirLanguage),
						disabled: unref(isActive),
						"onUpdate:targetLanguage": handleLanguageChange,
						"onUpdate:theirLanguage": handleTheirLanguageChange
					}, null, 8, [
						"target-language",
						"their-language",
						"disabled"
					]),
					unref(error) ? (openBlock(), createBlock(QBanner_default, {
						key: 0,
						dense: "",
						class: "bg-negative text-white q-mx-sm q-mt-xs",
						rounded: ""
					}, {
						avatar: withCtx(() => [createVNode(QIcon_default, {
							name: "error",
							color: "white"
						})]),
						default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(error)), 1)]),
						_: 1
					})) : createCommentVNode("", true),
					isVerifyingLicense.value ? (openBlock(), createElementBlock("div", _hoisted_6, [createVNode(QSpinnerDots_default, {
						color: "primary",
						size: "28px"
					}), createBaseVNode("span", _hoisted_7, toDisplayString(_ctx.$t("pro.verifying")), 1)])) : createCommentVNode("", true),
					licenseVerificationFailed.value ? (openBlock(), createElementBlock("div", _hoisted_8, [createBaseVNode("div", _hoisted_9, [createVNode(QIcon_default, {
						name: "warning",
						color: "warning",
						size: "20px"
					}), createBaseVNode("span", null, toDisplayString(_ctx.$t("pro.verificationFailed")), 1)]), createBaseVNode("div", _hoisted_10, [createBaseVNode("button", {
						class: "gc-btn gc-btn--pill",
						onClick: handleVerificationClose
					}, [createBaseVNode("span", _hoisted_11, toDisplayString(_ctx.$t("translator.close")), 1)]), createBaseVNode("button", {
						class: "gc-btn gc-btn--pill gc-btn--enabled",
						onClick: handleEnterLicense
					}, [createBaseVNode("span", _hoisted_12, toDisplayString(_ctx.$t("pro.enterLicense")), 1)])])])) : createCommentVNode("", true),
					createVNode(TranslatorDisplay_default, {
						entries: unref(entries),
						"current-speaker-id": unref(currentSpeakerId),
						"current-original": unref(currentOriginal),
						"current-translation": unref(currentTranslation),
						"is-active": unref(isActive),
						"translation-font-size": unref(translationFontSize),
						onOpenAssistant: handleOpenAssistantFromRow,
						onOpenSettings: openSonioxSettingsPage
					}, null, 8, [
						"entries",
						"current-speaker-id",
						"current-original",
						"current-translation",
						"is-active",
						"translation-font-size"
					]),
					createVNode(TranslatorControls_default, {
						"recording-state": unref(recordingState),
						"has-api-key": unref(apiKey).length > 0,
						"microphone-enabled": unref(microphoneEnabled),
						"send-my-translation-via-chat": unref(sendMyTranslationViaChat),
						"narration-enabled": unref(narrationEnabled),
						"tts-speaking": unref(ttsState).isSpeaking.value,
						"show-save-transcript": showSaveTranscript.value,
						"translation-font-size": unref(translationFontSize),
						"is-pro": unref(isPro),
						"narrate-my-voice": unref(narrateMyVoice),
						"is-realtime-listening": unref(narrateMyVoice_).isEnabled.value,
						"is-narrating": unref(narrateMyVoice_).isInjecting.value,
						"has-active-context": unref(contextSettings).hasContextData.value,
						"call-features-available": isVideoCallPageSupported.value,
						onStart: handleStart,
						onPause: handlePause,
						onResume: handleResume,
						onEnd: handleEndFromControls,
						onToggleMicrophone: handleMicToggle,
						onToggleSendMyTranslationViaChat: handleToggleSendMyTranslationViaChat,
						onOpenNarrationSettings: handleOpenNarrationSettings,
						onOpenAssistant: handleOpenAssistantFromControls,
						onOpenSpeakerSettings: _cache[0] || (_cache[0] = ($event) => isSpeakerSettingsOpen.value = true),
						onOpenContextSettings: handleOpenContextSettings,
						onSaveTranscript: handleSaveTranscript,
						onUpdateTranslationFontSize: handleTranslationFontSizeChange,
						onLockedAction: handleLockedAction
					}, null, 8, [
						"recording-state",
						"has-api-key",
						"microphone-enabled",
						"send-my-translation-via-chat",
						"narration-enabled",
						"tts-speaking",
						"show-save-transcript",
						"translation-font-size",
						"is-pro",
						"narrate-my-voice",
						"is-realtime-listening",
						"is-narrating",
						"has-active-context",
						"call-features-available"
					]),
					createVNode(SpeakerSettingsDialog_default, {
						modelValue: isSpeakerSettingsOpen.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isSpeakerSettingsOpen.value = $event),
						"speaker-names": unref(speakerNames),
						"is-pro": unref(isPro),
						onSave: handleSpeakerSettingsSave,
						onLockedAction: handleLockedAction
					}, null, 8, [
						"modelValue",
						"speaker-names",
						"is-pro"
					]),
					createVNode(DownloadTranscriptDialog_default, {
						modelValue: isDownloadDialogOpen.value,
						"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isDownloadDialogOpen.value = $event),
						"is-summary-loading": isSummaryDownloadLoading.value,
						"is-task-breakdown-loading": isTaskBreakdownDownloadLoading.value,
						onDownloadTxt: handleDownloadTxt,
						onDownloadJson: handleDownloadJson,
						onDownloadSummary: handleDownloadSummary,
						onDownloadTaskBreakdown: handleDownloadTaskBreakdown,
						onDownloadSrtOriginal: handleDownloadSrtOriginal,
						onDownloadSrtTranslated: handleDownloadSrtTranslated
					}, null, 8, [
						"modelValue",
						"is-summary-loading",
						"is-task-breakdown-loading"
					]),
					createVNode(NarrationSettingsDialog_default, {
						modelValue: isNarrationSettingsOpen.value,
						"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isNarrationSettingsOpen.value = $event),
						"tts-voice": unref(ttsVoice),
						"voice-speed": unref(voiceSpeed),
						"voice-volume": unref(voiceVolume),
						"original-volume": unref(originalVolume),
						"auto-sync-speed": unref(autoSyncSpeed),
						"narration-enabled": unref(narrationEnabled),
						"tts-queue-length": unref(ttsState).queueLength.value,
						"tts-effective-speed": unref(ttsState).effectiveSpeed.value,
						"is-testing-voice": isTestingVoice.value,
						"test-voice-error": narrationTestError.value,
						"is-pro": unref(isPro),
						"narrate-my-voice": unref(narrateMyVoice),
						"narrate-my-voice-available": isVideoCallPageSupported.value && unref(narrateMyVoice_).isPlatformSupported.value && unref(theirLanguage) !== "none",
						"is-call-page-supported": isVideoCallPageSupported.value,
						"narrate-all-speakers": unref(narrateAllSpeakers),
						"is-interpreter-active": unref(isInterpreterActive),
						"is-realtime-connecting": false,
						"is-narrating": unref(narrateMyVoice_).isInjecting.value,
						"is-translation-started": unref(isActive),
						"tts-provider": unref(ttsProvider),
						"google-voice-id": unref(googleVoiceId),
						"browser-voice-id": unref(browserVoiceId),
						"my-tts-voice": unref(narrateMyVoiceTtsVoice),
						"my-tts-provider": unref(narrateMyVoiceTtsProvider),
						"my-google-voice-id": unref(narrateMyVoiceGoogleVoiceId),
						"is-you-tube-page": isYouTubePage.value,
						"caption-narration-enabled": captionNarrationEnabled.value,
						onStartNarrateMyVoice: handleStartNarrateMyVoice,
						onStartNarrateTheirVoice: handleStartNarrateTheirVoice,
						onStopMode: handleStopNarrationMode,
						onTest: handleNarrationTest,
						onLockedAction: handleLockedAction,
						onToggleNarrateAllSpeakers: handleToggleNarrateAllSpeakers,
						onToggleCaptionNarration: handleToggleCaptionNarration
					}, null, 8, [
						"modelValue",
						"tts-voice",
						"voice-speed",
						"voice-volume",
						"original-volume",
						"auto-sync-speed",
						"narration-enabled",
						"tts-queue-length",
						"tts-effective-speed",
						"is-testing-voice",
						"test-voice-error",
						"is-pro",
						"narrate-my-voice",
						"narrate-my-voice-available",
						"is-call-page-supported",
						"narrate-all-speakers",
						"is-interpreter-active",
						"is-narrating",
						"is-translation-started",
						"tts-provider",
						"google-voice-id",
						"browser-voice-id",
						"my-tts-voice",
						"my-tts-provider",
						"my-google-voice-id",
						"is-you-tube-page",
						"caption-narration-enabled"
					]),
					createVNode(ProFeatureDialog_default, {
						modelValue: isProFeatureDialogOpen.value,
						"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isProFeatureDialogOpen.value = $event),
						onEnterLicense: handleEnterLicense,
						onLearnMore: handleLearnMore
					}, null, 8, ["modelValue"]),
					createVNode(ContextSettingDialog_default, {
						modelValue: isContextSettingsOpen.value,
						"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isContextSettingsOpen.value = $event),
						"context-name": unref(contextSettings).contextName.value,
						domain: unref(contextSettings).domain.value,
						topic: unref(contextSettings).topic.value,
						terms: unref(contextSettings).terms.value,
						speakers: unref(contextSettings).speakers.value,
						"saved-contexts": unref(contextSettings).savedContexts.value,
						"onUpdate:contextName": _cache[6] || (_cache[6] = ($event) => unref(contextSettings).contextName.value = $event),
						"onUpdate:domain": _cache[7] || (_cache[7] = ($event) => unref(contextSettings).domain.value = $event),
						"onUpdate:topic": _cache[8] || (_cache[8] = ($event) => unref(contextSettings).topic.value = $event),
						"onUpdate:terms": _cache[9] || (_cache[9] = ($event) => unref(contextSettings).terms.value = $event),
						"onUpdate:speakers": _cache[10] || (_cache[10] = ($event) => unref(contextSettings).speakers.value = $event),
						onSave: handleContextSave,
						onApply: handleContextApply,
						onApplySaved: handleApplySavedContext,
						onExportContexts: handleContextExport,
						onImportContexts: handleContextImport
					}, null, 8, [
						"modelValue",
						"context-name",
						"domain",
						"topic",
						"terms",
						"speakers",
						"saved-contexts"
					])
				]),
				_: 1
			});
		};
	}
}), [["__scopeId", "data-v-38a2c6d4"]]);
//#endregion
export { TranslatorPage_default as default };
