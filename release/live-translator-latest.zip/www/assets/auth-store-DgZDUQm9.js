import { A as onUpdated, C as onActivated, D as onDeactivated, E as onBeforeUpdate, F as watch, G as ref, O as onMounted, S as nextTick, T as onBeforeUnmount, n as Transition, u as computed, v as getCurrentInstance, w as onBeforeMount, x as inject, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { C as injectProp, a as hMergeSlot, b as createComponent, c as hUniqueSlot, d as getEventPath, g as prevent, h as position, i as hDir, m as noop, o as hMergeSlotSafely, p as listenOpts, s as hSlot, t as childHasFocus, v as stop, y as stopAndPrevent } from "./dom-ClQ5j7De.js";
import { c as isRuntimeSsrPreHydration, r as formKey, s as client } from "./symbols-C_cusQ0r.js";
import { c as isKeyCode, i as QIcon_default, o as useSizeProps, s as use_size_default, u as shouldIgnoreKey } from "./vm-BBDykFtW.js";
import { a as use_router_link_default, b as debounce_default, c as Ripple_default, g as isDeepEqual, i as useRouterLinkProps, l as QSpinner_default, o as useAlignProps, p as defineStore, s as use_align_default, y as History_default } from "./index-Cs5Ri5yo.js";
import { a as getVerticalScrollPosition, n as getHorizontalScrollPosition, o as hasScrollbar, r as getScrollTarget, s as scrollTargetProp } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import { _ as use_model_toggle_default, a as addClickOutside, c as use_tick_default, d as use_portal_default, f as closePortalMenus, g as useModelToggleProps, h as useModelToggleEmits, i as validatePosition, l as useTransitionProps, m as removeFocusFn, n as setPosition, o as removeClickOutside, p as addFocusFn, r as validateOffset, s as use_timeout_default, t as parsePosition, u as use_transition_default, v as use_scroll_target_default, x as use_anchor_default, y as useAnchorProps } from "./position-engine-BF19SPWE.js";
//#region node_modules/quasar/src/components/item/QItemSection.js
var QItemSection_default = createComponent({
	name: "QItemSection",
	props: {
		avatar: Boolean,
		thumbnail: Boolean,
		side: Boolean,
		top: Boolean,
		noWrap: Boolean
	},
	setup(props, { slots }) {
		const classes = computed(() => `q-item__section column q-item__section--${props.avatar === true || props.side === true || props.thumbnail === true ? "side" : "main"}` + (props.top === true ? " q-item__section--top justify-start" : " justify-center") + (props.avatar === true ? " q-item__section--avatar" : "") + (props.thumbnail === true ? " q-item__section--thumbnail" : "") + (props.noWrap === true ? " q-item__section--nowrap" : ""));
		return () => h("div", { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/item/QItemLabel.js
var QItemLabel_default = createComponent({
	name: "QItemLabel",
	props: {
		overline: Boolean,
		caption: Boolean,
		header: Boolean,
		lines: [Number, String]
	},
	setup(props, { slots }) {
		const parsedLines = computed(() => parseInt(props.lines, 10));
		const classes = computed(() => "q-item__label" + (props.overline === true ? " q-item__label--overline text-overline" : "") + (props.caption === true ? " q-item__label--caption text-caption" : "") + (props.header === true ? " q-item__label--header" : "") + (parsedLines.value === 1 ? " ellipsis" : ""));
		const style = computed(() => {
			return props.lines !== void 0 && parsedLines.value > 1 ? {
				overflow: "hidden",
				display: "-webkit-box",
				"-webkit-box-orient": "vertical",
				"-webkit-line-clamp": parsedLines.value
			} : null;
		});
		return () => h("div", {
			style: style.value,
			class: classes.value
		}, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/badge/QBadge.js
var alignValues = [
	"top",
	"middle",
	"bottom"
];
var QBadge_default = createComponent({
	name: "QBadge",
	props: {
		color: String,
		textColor: String,
		floating: Boolean,
		transparent: Boolean,
		multiLine: Boolean,
		outline: Boolean,
		rounded: Boolean,
		label: [Number, String],
		align: {
			type: String,
			validator: (v) => alignValues.includes(v)
		}
	},
	setup(props, { slots }) {
		const style = computed(() => {
			return props.align !== void 0 ? { verticalAlign: props.align } : null;
		});
		const classes = computed(() => {
			const text = props.outline === true ? props.color || props.textColor : props.textColor;
			return `q-badge flex inline items-center no-wrap q-badge--${props.multiLine === true ? "multi" : "single"}-line` + (props.outline === true ? " q-badge--outline" : props.color !== void 0 ? ` bg-${props.color}` : "") + (text !== void 0 ? ` text-${text}` : "") + (props.floating === true ? " q-badge--floating" : "") + (props.rounded === true ? " q-badge--rounded" : "") + (props.transparent === true ? " q-badge--transparent" : "");
		});
		return () => h("div", {
			class: classes.value,
			style: style.value,
			role: "status",
			"aria-label": props.label
		}, hMergeSlot(slots.default, props.label !== void 0 ? [props.label] : []));
	}
});
//#endregion
//#region node_modules/quasar/src/composables/private.use-dark/use-dark.js
var useDarkProps = { dark: {
	type: Boolean,
	default: null
} };
function use_dark_default(props, $q) {
	return computed(() => props.dark === null ? $q.dark.isActive : props.dark);
}
//#endregion
//#region node_modules/quasar/src/components/item/QItem.js
var QItem_default = createComponent({
	name: "QItem",
	props: {
		...useDarkProps,
		...useRouterLinkProps,
		tag: {
			type: String,
			default: "div"
		},
		active: {
			type: Boolean,
			default: null
		},
		clickable: Boolean,
		dense: Boolean,
		insetLevel: Number,
		tabindex: [String, Number],
		focused: Boolean,
		manualFocus: Boolean
	},
	emits: ["click", "keyup"],
	setup(props, { slots, emit }) {
		const { proxy: { $q } } = getCurrentInstance();
		const isDark = use_dark_default(props, $q);
		const { hasLink, linkAttrs, linkClass, linkTag, navigateOnClick } = use_router_link_default();
		const rootRef = ref(null);
		const blurTargetRef = ref(null);
		const isActionable = computed(() => props.clickable === true || hasLink.value === true || props.tag === "label");
		const isClickable = computed(() => props.disable !== true && isActionable.value === true);
		const classes = computed(() => "q-item q-item-type row no-wrap" + (props.dense === true ? " q-item--dense" : "") + (isDark.value === true ? " q-item--dark" : "") + (hasLink.value === true && props.active === null ? linkClass.value : props.active === true ? ` q-item--active${props.activeClass !== void 0 ? ` ${props.activeClass}` : ""}` : "") + (props.disable === true ? " disabled" : "") + (isClickable.value === true ? " q-item--clickable q-link cursor-pointer " + (props.manualFocus === true ? "q-manual-focusable" : "q-focusable q-hoverable") + (props.focused === true ? " q-manual-focusable--focused" : "") : ""));
		const style = computed(() => {
			if (props.insetLevel === void 0) return null;
			return { ["padding" + ($q.lang.rtl === true ? "Right" : "Left")]: 16 + props.insetLevel * 56 + "px" };
		});
		function onClick(e) {
			if (isClickable.value === true) {
				if (blurTargetRef.value !== null && e.qAvoidFocus !== true) {
					if (e.qKeyEvent !== true && document.activeElement === rootRef.value) blurTargetRef.value.focus();
					else if (document.activeElement === blurTargetRef.value) rootRef.value.focus();
				}
				navigateOnClick(e);
			}
		}
		function onKeyup(e) {
			if (isClickable.value === true && isKeyCode(e, [13, 32]) === true) {
				stopAndPrevent(e);
				e.qKeyEvent = true;
				const evt = new MouseEvent("click", e);
				evt.qKeyEvent = true;
				rootRef.value.dispatchEvent(evt);
			}
			emit("keyup", e);
		}
		function getContent() {
			const child = hUniqueSlot(slots.default, []);
			isClickable.value === true && child.unshift(h("div", {
				class: "q-focus-helper",
				tabindex: -1,
				ref: blurTargetRef
			}));
			return child;
		}
		return () => {
			const data = {
				ref: rootRef,
				class: classes.value,
				style: style.value,
				role: "listitem",
				onClick,
				onKeyup
			};
			if (isClickable.value === true) {
				data.tabindex = props.tabindex || "0";
				Object.assign(data, linkAttrs.value);
			} else if (isActionable.value === true) data["aria-disabled"] = "true";
			return h(linkTag.value, data, getContent());
		};
	}
});
//#endregion
//#region node_modules/quasar/src/components/separator/QSeparator.js
var insetMap = {
	true: "inset",
	item: "item-inset",
	"item-thumbnail": "item-thumbnail-inset"
};
var margins = {
	xs: 2,
	sm: 4,
	md: 8,
	lg: 16,
	xl: 24
};
var QSeparator_default = createComponent({
	name: "QSeparator",
	props: {
		...useDarkProps,
		spaced: [Boolean, String],
		inset: [Boolean, String],
		vertical: Boolean,
		color: String,
		size: String
	},
	setup(props) {
		const isDark = use_dark_default(props, getCurrentInstance().proxy.$q);
		const orientation = computed(() => props.vertical === true ? "vertical" : "horizontal");
		const orientClass = computed(() => ` q-separator--${orientation.value}`);
		const insetClass = computed(() => props.inset !== false ? `${orientClass.value}-${insetMap[props.inset]}` : "");
		const classes = computed(() => `q-separator${orientClass.value}${insetClass.value}` + (props.color !== void 0 ? ` bg-${props.color}` : "") + (isDark.value === true ? " q-separator--dark" : ""));
		const style = computed(() => {
			const acc = {};
			if (props.size !== void 0) acc[props.vertical === true ? "width" : "height"] = props.size;
			if (props.spaced !== false) {
				const size = props.spaced === true ? `${margins.md}px` : props.spaced in margins ? `${margins[props.spaced]}px` : props.spaced;
				const dir = props.vertical === true ? ["Left", "Right"] : ["Top", "Bottom"];
				acc[`margin${dir[0]}`] = acc[`margin${dir[1]}`] = size;
			}
			return acc;
		});
		return () => h("hr", {
			class: classes.value,
			style: style.value,
			"aria-orientation": orientation.value
		});
	}
});
//#endregion
//#region node_modules/quasar/src/components/banner/QBanner.js
var QBanner_default = createComponent({
	name: "QBanner",
	props: {
		...useDarkProps,
		inlineActions: Boolean,
		dense: Boolean,
		rounded: Boolean
	},
	setup(props, { slots }) {
		const { proxy: { $q } } = getCurrentInstance();
		const isDark = use_dark_default(props, $q);
		const classes = computed(() => "q-banner row items-center" + (props.dense === true ? " q-banner--dense" : "") + (isDark.value === true ? " q-banner--dark q-dark" : "") + (props.rounded === true ? " rounded-borders" : ""));
		const actionClass = computed(() => `q-banner__actions row items-center justify-end col-${props.inlineActions === true ? "auto" : "all"}`);
		return () => {
			const child = [h("div", { class: "q-banner__avatar col-auto row items-center self-start" }, hSlot(slots.avatar)), h("div", { class: "q-banner__content col text-body2" }, hSlot(slots.default))];
			const actions = hSlot(slots.action);
			actions !== void 0 && child.push(h("div", { class: actionClass.value }, actions));
			return h("div", {
				class: classes.value + (props.inlineActions === false && actions !== void 0 ? " q-banner--top-padding" : ""),
				role: "alert"
			}, child);
		};
	}
});
//#endregion
//#region node_modules/quasar/src/utils/uid/uid.js
/**
* Based on the work of https://github.com/jchook/uuid-random
*/
var buf, bufIdx = 0;
var hexBytes = new Array(256);
for (let i = 0; i < 256; i++) hexBytes[i] = (i + 256).toString(16).substring(1);
var randomBytes = (() => {
	const lib = typeof crypto !== "undefined" ? crypto : typeof window !== "undefined" ? window.crypto || window.msCrypto : void 0;
	if (lib !== void 0) {
		if (lib.randomBytes !== void 0) return lib.randomBytes;
		if (lib.getRandomValues !== void 0) return (n) => {
			const bytes = new Uint8Array(n);
			lib.getRandomValues(bytes);
			return bytes;
		};
	}
	return (n) => {
		const r = [];
		for (let i = n; i > 0; i--) r.push(Math.floor(Math.random() * 256));
		return r;
	};
})();
var BUFFER_SIZE = 4096;
function uid_default() {
	if (buf === void 0 || bufIdx + 16 > BUFFER_SIZE) {
		bufIdx = 0;
		buf = randomBytes(BUFFER_SIZE);
	}
	const b = Array.prototype.slice.call(buf, bufIdx, bufIdx += 16);
	b[6] = b[6] & 15 | 64;
	b[8] = b[8] & 63 | 128;
	return hexBytes[b[0]] + hexBytes[b[1]] + hexBytes[b[2]] + hexBytes[b[3]] + "-" + hexBytes[b[4]] + hexBytes[b[5]] + "-" + hexBytes[b[6]] + hexBytes[b[7]] + "-" + hexBytes[b[8]] + hexBytes[b[9]] + "-" + hexBytes[b[10]] + hexBytes[b[11]] + hexBytes[b[12]] + hexBytes[b[13]] + hexBytes[b[14]] + hexBytes[b[15]];
}
//#endregion
//#region node_modules/quasar/src/composables/use-id/use-id.js
function parseValue(val) {
	return val === void 0 || val === null ? null : val;
}
function getId(val, required) {
	return val === void 0 || val === null ? required === true ? `f_${uid_default()}` : null : val;
}
/**
* Returns an "id" which is a ref() that can be used as
* a unique identifier to apply to a DOM node attribute.
*
* On SSR, it takes care of generating the id on the client side (only) to
* avoid hydration errors.
*/
function use_id_default({ getValue, required = true } = {}) {
	if (isRuntimeSsrPreHydration.value === true) {
		const id = getValue !== void 0 ? ref(parseValue(getValue())) : ref(null);
		if (required === true && id.value === null) onMounted(() => {
			id.value = `f_${uid_default()}`;
		});
		if (getValue !== void 0) watch(getValue, (newId) => {
			id.value = getId(newId, required);
		});
		return id;
	}
	return getValue !== void 0 ? computed(() => getId(getValue(), required)) : ref(`f_${uid_default()}`);
}
//#endregion
//#region node_modules/quasar/src/composables/use-split-attrs/use-split-attrs.js
var listenerRE = /^on[A-Z]/;
function use_split_attrs_default() {
	const { attrs, vnode } = getCurrentInstance();
	const acc = {
		listeners: ref({}),
		attributes: ref({})
	};
	function update() {
		const attributes = {};
		const listeners = {};
		for (const key in attrs) if (key !== "class" && key !== "style" && listenerRE.test(key) === false) attributes[key] = attrs[key];
		for (const key in vnode.props) if (listenerRE.test(key) === true) listeners[key] = vnode.props[key];
		acc.attributes.value = attributes;
		acc.listeners.value = listeners;
	}
	onBeforeUpdate(update);
	update();
	return acc;
}
//#endregion
//#region node_modules/quasar/src/composables/use-form/use-form-child.js
function use_form_child_default({ validate, resetValidation, requiresQForm }) {
	const $form = inject(formKey, false);
	if ($form !== false) {
		const { props, proxy } = getCurrentInstance();
		Object.assign(proxy, {
			validate,
			resetValidation
		});
		watch(() => props.disable, (val) => {
			if (val === true) {
				typeof resetValidation === "function" && resetValidation();
				$form.unbindComponent(proxy);
			} else $form.bindComponent(proxy);
		});
		onMounted(() => {
			props.disable !== true && $form.bindComponent(proxy);
		});
		onBeforeUnmount(() => {
			props.disable !== true && $form.unbindComponent(proxy);
		});
	} else if (requiresQForm === true) console.error("Parent QForm not found on useFormChild()!");
}
//#endregion
//#region node_modules/quasar/src/utils/patterns/patterns.js
var hex = /^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/, hexa = /^#[0-9a-fA-F]{4}([0-9a-fA-F]{4})?$/, hexOrHexa = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/, rgb = /^rgb\(((0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),){2}(0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5])\)$/, rgba = /^rgba\(((0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),){2}(0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),(0|0\.[0-9]+[1-9]|0\.[1-9]+|1)\)$/;
var testPattern = {
	date: (v) => /^-?[\d]+\/[0-1]\d\/[0-3]\d$/.test(v),
	time: (v) => /^([0-1]?\d|2[0-3]):[0-5]\d$/.test(v),
	fulltime: (v) => /^([0-1]?\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(v),
	timeOrFulltime: (v) => /^([0-1]?\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(v),
	email: (v) => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(v),
	hexColor: (v) => hex.test(v),
	hexaColor: (v) => hexa.test(v),
	hexOrHexaColor: (v) => hexOrHexa.test(v),
	rgbColor: (v) => rgb.test(v),
	rgbaColor: (v) => rgba.test(v),
	rgbOrRgbaColor: (v) => rgb.test(v) || rgba.test(v),
	hexOrRgbColor: (v) => hex.test(v) || rgb.test(v),
	hexaOrRgbaColor: (v) => hexa.test(v) || rgba.test(v),
	anyColor: (v) => hexOrHexa.test(v) || rgb.test(v) || rgba.test(v)
};
//#endregion
//#region node_modules/quasar/src/composables/private.use-validate/use-validate.js
var lazyRulesValues = [
	true,
	false,
	"ondemand"
];
var useValidateProps = {
	modelValue: {},
	error: {
		type: Boolean,
		default: null
	},
	errorMessage: String,
	noErrorIcon: Boolean,
	rules: Array,
	reactiveRules: Boolean,
	lazyRules: {
		type: [Boolean, String],
		default: false,
		validator: (v) => lazyRulesValues.includes(v)
	}
};
function use_validate_default(focused, innerLoading) {
	const { props, proxy } = getCurrentInstance();
	const innerError = ref(false);
	const innerErrorMessage = ref(null);
	const isDirtyModel = ref(false);
	use_form_child_default({
		validate,
		resetValidation
	});
	let validateIndex = 0, unwatchRules;
	const hasRules = computed(() => props.rules !== void 0 && props.rules !== null && props.rules.length !== 0);
	const canDebounceValidate = computed(() => props.disable !== true && hasRules.value === true && innerLoading.value === false);
	const hasError = computed(() => props.error === true || innerError.value === true);
	const errorMessage = computed(() => typeof props.errorMessage === "string" && props.errorMessage.length !== 0 ? props.errorMessage : innerErrorMessage.value);
	watch(() => props.modelValue, () => {
		isDirtyModel.value = true;
		if (canDebounceValidate.value === true && props.lazyRules === false) debouncedValidate();
	});
	function onRulesChange() {
		if (props.lazyRules !== "ondemand" && canDebounceValidate.value === true && isDirtyModel.value === true) debouncedValidate();
	}
	watch(() => props.reactiveRules, (val) => {
		if (val === true) {
			if (unwatchRules === void 0) unwatchRules = watch(() => props.rules, onRulesChange, {
				immediate: true,
				deep: true
			});
		} else if (unwatchRules !== void 0) {
			unwatchRules();
			unwatchRules = void 0;
		}
	}, { immediate: true });
	watch(() => props.lazyRules, onRulesChange);
	watch(focused, (val) => {
		if (val === true) isDirtyModel.value = true;
		else if (canDebounceValidate.value === true && props.lazyRules !== "ondemand") debouncedValidate();
	});
	function resetValidation() {
		validateIndex++;
		innerLoading.value = false;
		isDirtyModel.value = false;
		innerError.value = false;
		innerErrorMessage.value = null;
		debouncedValidate.cancel();
	}
	function validate(val = props.modelValue) {
		if (props.disable === true || hasRules.value === false) return true;
		const index = ++validateIndex;
		const setDirty = innerLoading.value !== true ? () => {
			isDirtyModel.value = true;
		} : () => {};
		const update = (err, msg) => {
			err === true && setDirty();
			innerError.value = err;
			innerErrorMessage.value = msg || null;
			innerLoading.value = false;
		};
		const promises = [];
		for (let i = 0; i < props.rules.length; i++) {
			const rule = props.rules[i];
			let res;
			if (typeof rule === "function") res = rule(val, testPattern);
			else if (typeof rule === "string" && testPattern[rule] !== void 0) res = testPattern[rule](val);
			if (res === false || typeof res === "string") {
				update(true, res);
				return false;
			} else if (res !== true && res !== void 0) promises.push(res);
		}
		if (promises.length === 0) {
			update(false);
			return true;
		}
		innerLoading.value = true;
		return Promise.all(promises).then((res) => {
			if (res === void 0 || Array.isArray(res) === false || res.length === 0) {
				index === validateIndex && update(false);
				return true;
			}
			const msg = res.find((r) => r === false || typeof r === "string");
			index === validateIndex && update(msg !== void 0, msg);
			return msg === void 0;
		}, (e) => {
			if (index === validateIndex) {
				console.error(e);
				update(true);
			}
			return false;
		});
	}
	const debouncedValidate = debounce_default(validate, 0);
	onBeforeUnmount(() => {
		unwatchRules?.();
		debouncedValidate.cancel();
	});
	Object.assign(proxy, {
		resetValidation,
		validate
	});
	injectProp(proxy, "hasError", () => hasError.value);
	return {
		isDirtyModel,
		hasRules,
		hasError,
		errorMessage,
		validate,
		resetValidation
	};
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-field/use-field.js
function fieldValueIsFilled(val) {
	return val !== void 0 && val !== null && ("" + val).length !== 0;
}
var useFieldProps = {
	...useDarkProps,
	...useValidateProps,
	label: String,
	stackLabel: Boolean,
	hint: String,
	hideHint: Boolean,
	prefix: String,
	suffix: String,
	labelColor: String,
	color: String,
	bgColor: String,
	filled: Boolean,
	outlined: Boolean,
	borderless: Boolean,
	standout: [Boolean, String],
	square: Boolean,
	loading: Boolean,
	labelSlot: Boolean,
	bottomSlots: Boolean,
	hideBottomSpace: Boolean,
	rounded: Boolean,
	dense: Boolean,
	itemAligned: Boolean,
	counter: Boolean,
	clearable: Boolean,
	clearIcon: String,
	disable: Boolean,
	readonly: Boolean,
	autofocus: Boolean,
	for: String,
	maxlength: [Number, String]
};
var useFieldEmits = [
	"update:modelValue",
	"clear",
	"focus",
	"blur"
];
function useFieldState({ requiredForAttr = true, tagProp, changeEvent = false } = {}) {
	const { props, proxy } = getCurrentInstance();
	const isDark = use_dark_default(props, proxy.$q);
	const targetUid = use_id_default({
		required: requiredForAttr,
		getValue: () => props.for
	});
	return {
		requiredForAttr,
		changeEvent,
		tag: tagProp === true ? computed(() => props.tag) : { value: "label" },
		isDark,
		editable: computed(() => props.disable !== true && props.readonly !== true),
		innerLoading: ref(false),
		focused: ref(false),
		hasPopupOpen: false,
		splitAttrs: use_split_attrs_default(),
		targetUid,
		rootRef: ref(null),
		targetRef: ref(null),
		controlRef: ref(null)
	};
}
function use_field_default(state) {
	const { props, emit, slots, attrs, proxy } = getCurrentInstance();
	const { $q } = proxy;
	let focusoutTimer = null;
	if (state.hasValue === void 0) state.hasValue = computed(() => fieldValueIsFilled(props.modelValue));
	if (state.emitValue === void 0) state.emitValue = (value) => {
		emit("update:modelValue", value);
	};
	if (state.controlEvents === void 0) state.controlEvents = {
		onFocusin: onControlFocusin,
		onFocusout: onControlFocusout
	};
	Object.assign(state, {
		clearValue,
		onControlFocusin,
		onControlFocusout,
		focus
	});
	if (state.computedCounter === void 0) state.computedCounter = computed(() => {
		if (props.counter !== false) {
			const len = typeof props.modelValue === "string" || typeof props.modelValue === "number" ? ("" + props.modelValue).length : Array.isArray(props.modelValue) === true ? props.modelValue.length : 0;
			const max = props.maxlength !== void 0 ? props.maxlength : props.maxValues;
			return len + (max !== void 0 ? " / " + max : "");
		}
	});
	const { isDirtyModel, hasRules, hasError, errorMessage, resetValidation } = use_validate_default(state.focused, state.innerLoading);
	const floatingLabel = state.floatingLabel !== void 0 ? computed(() => props.stackLabel === true || state.focused.value === true || state.floatingLabel.value === true) : computed(() => props.stackLabel === true || state.focused.value === true || state.hasValue.value === true);
	const shouldRenderBottom = computed(() => props.bottomSlots === true || props.hint !== void 0 || hasRules.value === true || props.counter === true || props.error !== null);
	const styleType = computed(() => {
		if (props.filled === true) return "filled";
		if (props.outlined === true) return "outlined";
		if (props.borderless === true) return "borderless";
		if (props.standout) return "standout";
		return "standard";
	});
	const classes = computed(() => `q-field row no-wrap items-start q-field--${styleType.value}` + (state.fieldClass !== void 0 ? ` ${state.fieldClass.value}` : "") + (props.rounded === true ? " q-field--rounded" : "") + (props.square === true ? " q-field--square" : "") + (floatingLabel.value === true ? " q-field--float" : "") + (hasLabel.value === true ? " q-field--labeled" : "") + (props.dense === true ? " q-field--dense" : "") + (props.itemAligned === true ? " q-field--item-aligned q-item-type" : "") + (state.isDark.value === true ? " q-field--dark" : "") + (state.getControl === void 0 ? " q-field--auto-height" : "") + (state.focused.value === true ? " q-field--focused" : "") + (hasError.value === true ? " q-field--error" : "") + (hasError.value === true || state.focused.value === true ? " q-field--highlighted" : "") + (props.hideBottomSpace !== true && shouldRenderBottom.value === true ? " q-field--with-bottom" : "") + (props.disable === true ? " q-field--disabled" : props.readonly === true ? " q-field--readonly" : ""));
	const contentClass = computed(() => "q-field__control relative-position row no-wrap" + (props.bgColor !== void 0 ? ` bg-${props.bgColor}` : "") + (hasError.value === true ? " text-negative" : typeof props.standout === "string" && props.standout.length !== 0 && state.focused.value === true ? ` ${props.standout}` : props.color !== void 0 ? ` text-${props.color}` : ""));
	const hasLabel = computed(() => props.labelSlot === true || props.label !== void 0);
	const labelClass = computed(() => "q-field__label no-pointer-events absolute ellipsis" + (props.labelColor !== void 0 && hasError.value !== true ? ` text-${props.labelColor}` : ""));
	const controlSlotScope = computed(() => ({
		id: state.targetUid.value,
		editable: state.editable.value,
		focused: state.focused.value,
		floatingLabel: floatingLabel.value,
		modelValue: props.modelValue,
		emitValue: state.emitValue
	}));
	const attributes = computed(() => {
		const acc = {};
		if (state.targetUid.value) acc.for = state.targetUid.value;
		if (props.disable === true) acc["aria-disabled"] = "true";
		return acc;
	});
	function focusHandler() {
		const el = document.activeElement;
		let target = state.targetRef?.value;
		if (target && (el === null || el.id !== state.targetUid.value)) {
			target.hasAttribute("tabindex") === true || (target = target.querySelector("[tabindex]"));
			if (target !== el) target?.focus({ preventScroll: true });
		}
	}
	function focus() {
		addFocusFn(focusHandler);
	}
	function blur() {
		removeFocusFn(focusHandler);
		const el = document.activeElement;
		if (el !== null && state.rootRef.value.contains(el)) el.blur();
	}
	function onControlFocusin(e) {
		if (focusoutTimer !== null) {
			clearTimeout(focusoutTimer);
			focusoutTimer = null;
		}
		if (state.editable.value === true && state.focused.value === false) {
			state.focused.value = true;
			emit("focus", e);
		}
	}
	function onControlFocusout(e, then) {
		focusoutTimer !== null && clearTimeout(focusoutTimer);
		focusoutTimer = setTimeout(() => {
			focusoutTimer = null;
			if (document.hasFocus() === true && (state.hasPopupOpen === true || state.controlRef === void 0 || state.controlRef.value === null || state.controlRef.value.contains(document.activeElement) !== false)) return;
			if (state.focused.value === true) {
				state.focused.value = false;
				emit("blur", e);
			}
			then?.();
		});
	}
	function clearValue(e) {
		stopAndPrevent(e);
		if ($q.platform.is.mobile !== true) (state.targetRef?.value || state.rootRef.value).focus();
		else if (state.rootRef.value.contains(document.activeElement) === true) document.activeElement.blur();
		if (props.type === "file") state.inputRef.value.value = null;
		emit("update:modelValue", null);
		state.changeEvent === true && emit("change", null);
		emit("clear", props.modelValue);
		nextTick(() => {
			const isDirty = isDirtyModel.value;
			resetValidation();
			isDirtyModel.value = isDirty;
		});
	}
	function onClearableKeyup(evt) {
		[13, 32].includes(evt.keyCode) && clearValue(evt);
	}
	function getContent() {
		const node = [];
		slots.prepend !== void 0 && node.push(h("div", {
			class: "q-field__prepend q-field__marginal row no-wrap items-center",
			key: "prepend",
			onClick: prevent
		}, slots.prepend()));
		node.push(h("div", { class: "q-field__control-container col relative-position row no-wrap q-anchor--skip" }, getControlContainer()));
		hasError.value === true && props.noErrorIcon === false && node.push(getInnerAppendNode("error", [h(QIcon_default, {
			name: $q.iconSet.field.error,
			color: "negative"
		})]));
		if (props.loading === true || state.innerLoading.value === true) node.push(getInnerAppendNode("inner-loading-append", slots.loading !== void 0 ? slots.loading() : [h(QSpinner_default, { color: props.color })]));
		else if (props.clearable === true && state.hasValue.value === true && state.editable.value === true) node.push(getInnerAppendNode("inner-clearable-append", [h(QIcon_default, {
			class: "q-field__focusable-action",
			name: props.clearIcon || $q.iconSet.field.clear,
			tabindex: 0,
			role: "button",
			"aria-hidden": "false",
			"aria-label": $q.lang.label.clear,
			onKeyup: onClearableKeyup,
			onClick: clearValue
		})]));
		slots.append !== void 0 && node.push(h("div", {
			class: "q-field__append q-field__marginal row no-wrap items-center",
			key: "append",
			onClick: prevent
		}, slots.append()));
		state.getInnerAppend !== void 0 && node.push(getInnerAppendNode("inner-append", state.getInnerAppend()));
		state.getControlChild !== void 0 && node.push(state.getControlChild());
		return node;
	}
	function getControlContainer() {
		const node = [];
		props.prefix !== void 0 && props.prefix !== null && node.push(h("div", { class: "q-field__prefix no-pointer-events row items-center" }, props.prefix));
		if (state.getShadowControl !== void 0 && state.hasShadow.value === true) node.push(state.getShadowControl());
		hasLabel.value === true && node.push(h("div", { class: labelClass.value }, hSlot(slots.label, props.label)));
		if (state.getControl !== void 0) node.push(state.getControl());
		else if (slots.rawControl !== void 0) node.push(slots.rawControl());
		else if (slots.control !== void 0) node.push(h("div", {
			ref: state.targetRef,
			class: "q-field__native row",
			tabindex: -1,
			...state.splitAttrs.attributes.value,
			"data-autofocus": props.autofocus === true || void 0
		}, slots.control(controlSlotScope.value)));
		props.suffix !== void 0 && props.suffix !== null && node.push(h("div", { class: "q-field__suffix no-pointer-events row items-center" }, props.suffix));
		return node.concat(hSlot(slots.default));
	}
	function getBottom() {
		let msg, key;
		if (hasError.value === true) if (errorMessage.value !== null) {
			msg = [h("div", { role: "alert" }, errorMessage.value)];
			key = `q--slot-error-${errorMessage.value}`;
		} else {
			msg = hSlot(slots.error);
			key = "q--slot-error";
		}
		else if (props.hideHint !== true || state.focused.value === true) if (props.hint !== void 0) {
			msg = [h("div", props.hint)];
			key = `q--slot-hint-${props.hint}`;
		} else {
			msg = hSlot(slots.hint);
			key = "q--slot-hint";
		}
		const hasCounter = props.counter === true || slots.counter !== void 0;
		if (props.hideBottomSpace === true && hasCounter === false && msg === void 0) return;
		const main = h("div", {
			key,
			class: "q-field__messages col"
		}, msg);
		return h("div", {
			class: "q-field__bottom row items-start q-field__bottom--" + (props.hideBottomSpace !== true ? "animated" : "stale"),
			onClick: prevent
		}, [props.hideBottomSpace === true ? main : h(Transition, { name: "q-transition--field-message" }, () => main), hasCounter === true ? h("div", { class: "q-field__counter" }, slots.counter !== void 0 ? slots.counter() : state.computedCounter.value) : null]);
	}
	function getInnerAppendNode(key, content) {
		return content === null ? null : h("div", {
			key,
			class: "q-field__append q-field__marginal row no-wrap items-center q-anchor--skip"
		}, content);
	}
	let shouldActivate = false;
	onDeactivated(() => {
		shouldActivate = true;
	});
	onActivated(() => {
		shouldActivate === true && props.autofocus === true && proxy.focus();
	});
	props.autofocus === true && onMounted(() => {
		proxy.focus();
	});
	onBeforeUnmount(() => {
		focusoutTimer !== null && clearTimeout(focusoutTimer);
	});
	Object.assign(proxy, {
		focus,
		blur
	});
	return function renderField() {
		const labelAttrs = state.getControl === void 0 && slots.control === void 0 ? {
			...state.splitAttrs.attributes.value,
			"data-autofocus": props.autofocus === true || void 0,
			...attributes.value
		} : attributes.value;
		return h(state.tag.value, {
			ref: state.rootRef,
			class: [classes.value, attrs.class],
			style: attrs.style,
			...labelAttrs
		}, [
			slots.before !== void 0 ? h("div", {
				class: "q-field__before q-field__marginal row no-wrap items-center",
				onClick: prevent
			}, slots.before()) : null,
			h("div", { class: "q-field__inner relative-position col self-stretch" }, [h("div", {
				ref: state.controlRef,
				class: contentClass.value,
				tabindex: -1,
				...state.controlEvents
			}, getContent()), shouldRenderBottom.value === true ? getBottom() : null]),
			slots.after !== void 0 ? h("div", {
				class: "q-field__after q-field__marginal row no-wrap items-center",
				onClick: prevent
			}, slots.after()) : null
		]);
	};
}
//#endregion
//#region node_modules/quasar/src/components/input/use-mask.js
var NAMED_MASKS = {
	date: "####/##/##",
	datetime: "####/##/## ##:##",
	time: "##:##",
	fulltime: "##:##:##",
	phone: "(###) ### - ####",
	card: "#### #### #### ####"
};
var { tokenMap: DEFAULT_TOKEN_MAP, tokenKeys: DEFAULT_TOKEN_MAP_KEYS } = getTokenMap({
	"#": {
		pattern: "[\\d]",
		negate: "[^\\d]"
	},
	S: {
		pattern: "[a-zA-Z]",
		negate: "[^a-zA-Z]"
	},
	N: {
		pattern: "[0-9a-zA-Z]",
		negate: "[^0-9a-zA-Z]"
	},
	A: {
		pattern: "[a-zA-Z]",
		negate: "[^a-zA-Z]",
		transform: (v) => v.toLocaleUpperCase()
	},
	a: {
		pattern: "[a-zA-Z]",
		negate: "[^a-zA-Z]",
		transform: (v) => v.toLocaleLowerCase()
	},
	X: {
		pattern: "[0-9a-zA-Z]",
		negate: "[^0-9a-zA-Z]",
		transform: (v) => v.toLocaleUpperCase()
	},
	x: {
		pattern: "[0-9a-zA-Z]",
		negate: "[^0-9a-zA-Z]",
		transform: (v) => v.toLocaleLowerCase()
	}
});
function getTokenMap(tokens) {
	const tokenKeys = Object.keys(tokens);
	const tokenMap = {};
	tokenKeys.forEach((key) => {
		const entry = tokens[key];
		tokenMap[key] = {
			...entry,
			regex: new RegExp(entry.pattern)
		};
	});
	return {
		tokenMap,
		tokenKeys
	};
}
function getTokenRegexMask(keys) {
	return new RegExp("\\\\([^.*+?^${}()|([\\]])|([.*+?^${}()|[\\]])|([" + keys.join("") + "])|(.)", "g");
}
var escRegex = /[.*+?^${}()|[\]\\]/g;
var DEFAULT_TOKEN_REGEX_MASK = getTokenRegexMask(DEFAULT_TOKEN_MAP_KEYS);
var MARKER = String.fromCharCode(1);
var useMaskProps = {
	mask: String,
	reverseFillMask: Boolean,
	fillMask: [Boolean, String],
	unmaskedValue: Boolean,
	maskTokens: Object
};
function use_mask_default(props, emit, emitValue, inputRef) {
	let maskMarked, maskReplaced, computedMask, computedUnmask, pastedTextStart, selectionAnchor;
	const tokens = computed(() => {
		if (props.maskTokens === void 0 || props.maskTokens === null) return {
			tokenMap: DEFAULT_TOKEN_MAP,
			tokenRegexMask: DEFAULT_TOKEN_REGEX_MASK
		};
		const { tokenMap: customTokens } = getTokenMap(props.maskTokens);
		const tokenMap = {
			...DEFAULT_TOKEN_MAP,
			...customTokens
		};
		return {
			tokenMap,
			tokenRegexMask: getTokenRegexMask(Object.keys(tokenMap))
		};
	});
	const hasMask = ref(null);
	const innerValue = ref(getInitialMaskedValue());
	function getIsTypeText() {
		return props.autogrow === true || [
			"textarea",
			"text",
			"search",
			"url",
			"tel",
			"password"
		].includes(props.type);
	}
	watch(() => props.type + props.autogrow, updateMaskInternals);
	watch(() => props.mask, (v) => {
		if (v !== void 0) updateMaskValue(innerValue.value, true);
		else {
			const val = unmaskValue(innerValue.value);
			updateMaskInternals();
			props.modelValue !== val && emit("update:modelValue", val);
		}
	});
	watch(() => props.fillMask + props.reverseFillMask, () => {
		hasMask.value === true && updateMaskValue(innerValue.value, true);
	});
	watch(() => props.unmaskedValue, () => {
		hasMask.value === true && updateMaskValue(innerValue.value);
	});
	function getInitialMaskedValue() {
		updateMaskInternals();
		if (hasMask.value === true) {
			const masked = maskValue(unmaskValue(props.modelValue));
			return props.fillMask !== false ? fillWithMask(masked) : masked;
		}
		return props.modelValue;
	}
	function getPaddedMaskMarked(size) {
		if (size < maskMarked.length) return maskMarked.slice(-size);
		let pad = "", localMaskMarked = maskMarked;
		const padPos = localMaskMarked.indexOf(MARKER);
		if (padPos !== -1) {
			for (let i = size - localMaskMarked.length; i > 0; i--) pad += MARKER;
			localMaskMarked = localMaskMarked.slice(0, padPos) + pad + localMaskMarked.slice(padPos);
		}
		return localMaskMarked;
	}
	function updateMaskInternals() {
		hasMask.value = props.mask !== void 0 && props.mask.length !== 0 && getIsTypeText();
		if (hasMask.value === false) {
			computedUnmask = void 0;
			maskMarked = "";
			maskReplaced = "";
			return;
		}
		const localComputedMask = NAMED_MASKS[props.mask] === void 0 ? props.mask : NAMED_MASKS[props.mask], fillChar = typeof props.fillMask === "string" && props.fillMask.length !== 0 ? props.fillMask.slice(0, 1) : "_", fillCharEscaped = fillChar.replace(escRegex, "\\$&"), unmask = [], extract = [], mask = [];
		let firstMatch = props.reverseFillMask === true, unmaskChar = "", negateChar = "";
		localComputedMask.replace(tokens.value.tokenRegexMask, (_, char1, esc, token, char2) => {
			if (token !== void 0) {
				const c = tokens.value.tokenMap[token];
				mask.push(c);
				negateChar = c.negate;
				if (firstMatch === true) {
					extract.push("(?:" + negateChar + "+)?(" + c.pattern + "+)?(?:" + negateChar + "+)?(" + c.pattern + "+)?");
					firstMatch = false;
				}
				extract.push("(?:" + negateChar + "+)?(" + c.pattern + ")?");
			} else if (esc !== void 0) {
				unmaskChar = "\\" + (esc === "\\" ? "" : esc);
				mask.push(esc);
				unmask.push("([^" + unmaskChar + "]+)?" + unmaskChar + "?");
			} else {
				const c = char1 !== void 0 ? char1 : char2;
				unmaskChar = c === "\\" ? "\\\\\\\\" : c.replace(escRegex, "\\\\$&");
				mask.push(c);
				unmask.push("([^" + unmaskChar + "]+)?" + unmaskChar + "?");
			}
		});
		const unmaskMatcher = new RegExp("^" + unmask.join("") + "(" + (unmaskChar === "" ? "." : "[^" + unmaskChar + "]") + "+)?" + (unmaskChar === "" ? "" : "[" + unmaskChar + "]*") + "$"), extractLast = extract.length - 1, extractMatcher = extract.map((re, index) => {
			if (index === 0 && props.reverseFillMask === true) return new RegExp("^" + fillCharEscaped + "*" + re);
			else if (index === extractLast) return new RegExp("^" + re + "(" + (negateChar === "" ? "." : negateChar) + "+)?" + (props.reverseFillMask === true ? "$" : fillCharEscaped + "*"));
			return new RegExp("^" + re);
		});
		computedMask = mask;
		computedUnmask = (val) => {
			const unmaskMatch = unmaskMatcher.exec(props.reverseFillMask === true ? val : val.slice(0, mask.length + 1));
			if (unmaskMatch !== null) val = unmaskMatch.slice(1).join("");
			const extractMatch = [], extractMatcherLength = extractMatcher.length;
			for (let i = 0, str = val; i < extractMatcherLength; i++) {
				const m = extractMatcher[i].exec(str);
				if (m === null) break;
				str = str.slice(m.shift().length);
				extractMatch.push(...m);
			}
			if (extractMatch.length !== 0) return extractMatch.join("");
			return val;
		};
		maskMarked = mask.map((v) => typeof v === "string" ? v : MARKER).join("");
		maskReplaced = maskMarked.split(MARKER).join(fillChar);
	}
	function updateMaskValue(rawVal, updateMaskInternalsFlag, inputType) {
		const inp = inputRef.value, end = inp.selectionEnd, endReverse = inp.value.length - end, unmasked = unmaskValue(rawVal);
		updateMaskInternalsFlag === true && updateMaskInternals();
		const preMasked = maskValue(unmasked, updateMaskInternalsFlag), masked = props.fillMask !== false ? fillWithMask(preMasked) : preMasked, changed = innerValue.value !== masked;
		inp.value !== masked && (inp.value = masked);
		changed === true && (innerValue.value = masked);
		document.activeElement === inp && nextTick(() => {
			if (masked === maskReplaced) {
				const cursor = props.reverseFillMask === true ? maskReplaced.length : 0;
				inp.setSelectionRange(cursor, cursor, "forward");
				return;
			}
			if (inputType === "insertFromPaste" && props.reverseFillMask !== true) {
				const maxEnd = inp.selectionEnd;
				let cursor = end - 1;
				for (let i = pastedTextStart; i <= cursor && i < maxEnd; i++) if (maskMarked[i] !== MARKER) cursor++;
				moveCursor.right(inp, cursor);
				return;
			}
			if (["deleteContentBackward", "deleteContentForward"].indexOf(inputType) !== -1) {
				const cursor = props.reverseFillMask === true ? end === 0 ? masked.length > preMasked.length ? 1 : 0 : Math.max(0, masked.length - (masked === maskReplaced ? 0 : Math.min(preMasked.length, endReverse) + 1)) + 1 : end;
				inp.setSelectionRange(cursor, cursor, "forward");
				return;
			}
			if (props.reverseFillMask === true) if (changed === true) {
				const cursor = Math.max(0, masked.length - (masked === maskReplaced ? 0 : Math.min(preMasked.length, endReverse + 1)));
				if (cursor === 1 && end === 1) inp.setSelectionRange(cursor, cursor, "forward");
				else moveCursor.rightReverse(inp, cursor);
			} else {
				const cursor = masked.length - endReverse;
				inp.setSelectionRange(cursor, cursor, "backward");
			}
			else if (changed === true) {
				const cursor = Math.max(0, maskMarked.indexOf(MARKER), Math.min(preMasked.length, end) - 1);
				moveCursor.right(inp, cursor);
			} else {
				const cursor = end - 1;
				moveCursor.right(inp, cursor);
			}
		});
		const val = props.unmaskedValue === true ? unmaskValue(masked) : masked;
		if (String(props.modelValue) !== val && (props.modelValue !== null || val !== "")) emitValue(val, true);
	}
	function moveCursorForPaste(inp, start, end) {
		const preMasked = maskValue(unmaskValue(inp.value));
		start = Math.max(0, maskMarked.indexOf(MARKER), Math.min(preMasked.length, start));
		pastedTextStart = start;
		inp.setSelectionRange(start, end, "forward");
	}
	const moveCursor = {
		left(inp, cursor) {
			const noMarkBefore = maskMarked.slice(cursor - 1).indexOf(MARKER) === -1;
			let i = Math.max(0, cursor - 1);
			for (; i >= 0; i--) if (maskMarked[i] === MARKER) {
				cursor = i;
				noMarkBefore === true && cursor++;
				break;
			}
			if (i < 0 && maskMarked[cursor] !== void 0 && maskMarked[cursor] !== MARKER) return moveCursor.right(inp, 0);
			cursor >= 0 && inp.setSelectionRange(cursor, cursor, "backward");
		},
		right(inp, cursor) {
			const limit = inp.value.length;
			let i = Math.min(limit, cursor + 1);
			for (; i <= limit; i++) if (maskMarked[i] === MARKER) {
				cursor = i;
				break;
			} else if (maskMarked[i - 1] === MARKER) cursor = i;
			if (i > limit && maskMarked[cursor - 1] !== void 0 && maskMarked[cursor - 1] !== MARKER) return moveCursor.left(inp, limit);
			inp.setSelectionRange(cursor, cursor, "forward");
		},
		leftReverse(inp, cursor) {
			const localMaskMarked = getPaddedMaskMarked(inp.value.length);
			let i = Math.max(0, cursor - 1);
			for (; i >= 0; i--) if (localMaskMarked[i - 1] === MARKER) {
				cursor = i;
				break;
			} else if (localMaskMarked[i] === MARKER) {
				cursor = i;
				if (i === 0) break;
			}
			if (i < 0 && localMaskMarked[cursor] !== void 0 && localMaskMarked[cursor] !== MARKER) return moveCursor.rightReverse(inp, 0);
			cursor >= 0 && inp.setSelectionRange(cursor, cursor, "backward");
		},
		rightReverse(inp, cursor) {
			const limit = inp.value.length, localMaskMarked = getPaddedMaskMarked(limit), noMarkBefore = localMaskMarked.slice(0, cursor + 1).indexOf(MARKER) === -1;
			let i = Math.min(limit, cursor + 1);
			for (; i <= limit; i++) if (localMaskMarked[i - 1] === MARKER) {
				cursor = i;
				cursor > 0 && noMarkBefore === true && cursor--;
				break;
			}
			if (i > limit && localMaskMarked[cursor - 1] !== void 0 && localMaskMarked[cursor - 1] !== MARKER) return moveCursor.leftReverse(inp, limit);
			inp.setSelectionRange(cursor, cursor, "forward");
		}
	};
	function onMaskedClick(e) {
		emit("click", e);
		selectionAnchor = void 0;
	}
	function onMaskedKeydown(e) {
		emit("keydown", e);
		if (shouldIgnoreKey(e) === true || e.altKey === true) return;
		const inp = inputRef.value, start = inp.selectionStart, end = inp.selectionEnd;
		if (!e.shiftKey) selectionAnchor = void 0;
		if (e.keyCode === 37 || e.keyCode === 39) {
			if (e.shiftKey && selectionAnchor === void 0) selectionAnchor = inp.selectionDirection === "forward" ? start : end;
			const fn = moveCursor[(e.keyCode === 39 ? "right" : "left") + (props.reverseFillMask === true ? "Reverse" : "")];
			e.preventDefault();
			fn(inp, selectionAnchor === start ? end : start);
			if (e.shiftKey) {
				const cursor = inp.selectionStart;
				inp.setSelectionRange(Math.min(selectionAnchor, cursor), Math.max(selectionAnchor, cursor), "forward");
			}
		} else if (e.keyCode === 8 && props.reverseFillMask !== true && start === end) {
			moveCursor.left(inp, start);
			inp.setSelectionRange(inp.selectionStart, end, "backward");
		} else if (e.keyCode === 46 && props.reverseFillMask === true && start === end) {
			moveCursor.rightReverse(inp, end);
			inp.setSelectionRange(start, inp.selectionEnd, "forward");
		}
	}
	function maskValue(val, updateMaskInternalsFlag) {
		if (val === void 0 || val === null || val === "") return "";
		if (props.reverseFillMask === true) return maskValueReverse(val, updateMaskInternalsFlag);
		const mask = computedMask;
		let valIndex = 0, output = "";
		for (let maskIndex = 0; maskIndex < mask.length; maskIndex++) {
			const valChar = val[valIndex], maskDef = mask[maskIndex];
			if (typeof maskDef === "string") {
				output += maskDef;
				if (updateMaskInternalsFlag === true && valChar === maskDef) valIndex++;
			} else if (valChar !== void 0 && maskDef.regex.test(valChar)) {
				output += maskDef.transform !== void 0 ? maskDef.transform(valChar) : valChar;
				valIndex++;
			} else return output;
		}
		return output;
	}
	function maskValueReverse(val, updateMaskInternalsFlag) {
		const mask = computedMask, firstTokenIndex = maskMarked.indexOf(MARKER);
		let valIndex = val.length - 1, output = "";
		for (let maskIndex = mask.length - 1; maskIndex >= 0 && valIndex !== -1; maskIndex--) {
			const maskDef = mask[maskIndex];
			let valChar = val[valIndex];
			if (typeof maskDef === "string") {
				output = maskDef + output;
				if (updateMaskInternalsFlag === true && valChar === maskDef) valIndex--;
			} else if (valChar !== void 0 && maskDef.regex.test(valChar)) do {
				output = (maskDef.transform !== void 0 ? maskDef.transform(valChar) : valChar) + output;
				valIndex--;
				valChar = val[valIndex];
			} while (firstTokenIndex === maskIndex && valChar !== void 0 && maskDef.regex.test(valChar));
			else return output;
		}
		return output;
	}
	function unmaskValue(val) {
		return typeof val !== "string" || computedUnmask === void 0 ? typeof val === "number" ? computedUnmask("" + val) : val : computedUnmask(val);
	}
	function fillWithMask(val) {
		if (maskReplaced.length - val.length <= 0) return val;
		return props.reverseFillMask === true && val.length !== 0 ? maskReplaced.slice(0, -val.length) + val : val + maskReplaced.slice(val.length);
	}
	return {
		innerValue,
		hasMask,
		moveCursorForPaste,
		updateMaskValue,
		onMaskedKeydown,
		onMaskedClick
	};
}
//#endregion
//#region node_modules/quasar/src/composables/use-form/private.use-form.js
var useFormProps = { name: String };
function useFormAttrs(props) {
	return computed(() => ({
		type: "hidden",
		name: props.name,
		value: props.modelValue
	}));
}
function useFormInject(formAttrs = {}) {
	return (child, action, className) => {
		child[action](h("input", {
			class: "hidden" + (className || ""),
			...formAttrs.value
		}));
	};
}
function useFormInputNameAttr(props) {
	return computed(() => props.name || props.for);
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-file/use-file-dom-props.js
function use_file_dom_props_default(props, typeGuard) {
	function getFormDomProps() {
		const model = props.modelValue;
		try {
			const dt = "DataTransfer" in window ? new DataTransfer() : "ClipboardEvent" in window ? new ClipboardEvent("").clipboardData : void 0;
			if (Object(model) === model) ("length" in model ? Array.from(model) : [model]).forEach((file) => {
				dt.items.add(file);
			});
			return { files: dt.files };
		} catch (e) {
			return { files: void 0 };
		}
	}
	return typeGuard === true ? computed(() => {
		if (props.type !== "file") return;
		return getFormDomProps();
	}) : computed(getFormDomProps);
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-key-composition/use-key-composition.js
var isJapanese = /[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]/;
var isChinese = /[\u4e00-\u9fff\u3400-\u4dbf\u{20000}-\u{2a6df}\u{2a700}-\u{2b73f}\u{2b740}-\u{2b81f}\u{2b820}-\u{2ceaf}\uf900-\ufaff\u3300-\u33ff\ufe30-\ufe4f\uf900-\ufaff\u{2f800}-\u{2fa1f}]/u;
var isKorean = /[\u3131-\u314e\u314f-\u3163\uac00-\ud7a3]/;
var isPlainText = /[a-z0-9_ -]$/i;
function use_key_composition_default(onInput) {
	return function onComposition(e) {
		if (e.type === "compositionend" || e.type === "change") {
			if (e.target.qComposing !== true) return;
			e.target.qComposing = false;
			onInput(e);
		} else if (e.type === "compositionupdate" && e.target.qComposing !== true && typeof e.data === "string") {
			if ((client.is.firefox === true ? isPlainText.test(e.data) === false : isJapanese.test(e.data) === true || isChinese.test(e.data) === true || isKorean.test(e.data) === true) === true) e.target.qComposing = true;
		}
	};
}
//#endregion
//#region node_modules/quasar/src/components/input/QInput.js
var QInput_default = createComponent({
	name: "QInput",
	inheritAttrs: false,
	props: {
		...useFieldProps,
		...useMaskProps,
		...useFormProps,
		modelValue: [
			String,
			Number,
			FileList
		],
		shadowText: String,
		type: {
			type: String,
			default: "text"
		},
		debounce: [String, Number],
		autogrow: Boolean,
		inputClass: [
			Array,
			String,
			Object
		],
		inputStyle: [
			Array,
			String,
			Object
		]
	},
	emits: [
		...useFieldEmits,
		"paste",
		"change",
		"keydown",
		"click",
		"animationend"
	],
	setup(props, { emit, attrs }) {
		const { proxy } = getCurrentInstance();
		const { $q } = proxy;
		const temp = {};
		let emitCachedValue = NaN, typedNumber, stopValueWatcher, emitTimer = null, emitValueFn;
		const inputRef = ref(null);
		const nameProp = useFormInputNameAttr(props);
		const { innerValue, hasMask, moveCursorForPaste, updateMaskValue, onMaskedKeydown, onMaskedClick } = use_mask_default(props, emit, emitValue, inputRef);
		const formDomProps = use_file_dom_props_default(props, true);
		const hasValue = computed(() => fieldValueIsFilled(innerValue.value));
		const onComposition = use_key_composition_default(onInput);
		const state = useFieldState({ changeEvent: true });
		const isTextarea = computed(() => props.type === "textarea" || props.autogrow === true);
		const isTypeText = computed(() => isTextarea.value === true || [
			"text",
			"search",
			"url",
			"tel",
			"password"
		].includes(props.type));
		const onEvents = computed(() => {
			const evt = {
				...state.splitAttrs.listeners.value,
				onInput,
				onPaste,
				onChange,
				onBlur: onFinishEditing,
				onFocus: stop
			};
			evt.onCompositionstart = evt.onCompositionupdate = evt.onCompositionend = onComposition;
			if (hasMask.value === true) {
				evt.onKeydown = onMaskedKeydown;
				evt.onClick = onMaskedClick;
			}
			if (props.autogrow === true) evt.onAnimationend = onAnimationend;
			return evt;
		});
		const inputAttrs = computed(() => {
			const attrs = {
				tabindex: 0,
				"data-autofocus": props.autofocus === true || void 0,
				rows: props.type === "textarea" ? 6 : void 0,
				"aria-label": props.label,
				name: nameProp.value,
				...state.splitAttrs.attributes.value,
				id: state.targetUid.value,
				maxlength: props.maxlength,
				disabled: props.disable === true,
				readonly: props.readonly === true
			};
			if (isTextarea.value === false) attrs.type = props.type;
			if (props.autogrow === true) attrs.rows = 1;
			return attrs;
		});
		watch(() => props.type, () => {
			if (inputRef.value) inputRef.value.value = props.modelValue;
		});
		watch(() => props.modelValue, (v) => {
			if (hasMask.value === true) {
				if (stopValueWatcher === true) {
					stopValueWatcher = false;
					if (String(v) === emitCachedValue) return;
				}
				updateMaskValue(v);
			} else if (innerValue.value !== v) {
				innerValue.value = v;
				if (props.type === "number" && temp.hasOwnProperty("value") === true) if (typedNumber === true) typedNumber = false;
				else delete temp.value;
			}
			props.autogrow === true && nextTick(adjustHeight);
		});
		watch(() => props.autogrow, (val) => {
			if (val === true) nextTick(adjustHeight);
			else if (inputRef.value !== null && attrs.rows > 0) inputRef.value.style.height = "auto";
		});
		watch(() => props.dense, () => {
			props.autogrow === true && nextTick(adjustHeight);
		});
		function focus() {
			addFocusFn(() => {
				const el = document.activeElement;
				if (inputRef.value !== null && inputRef.value !== el && (el === null || el.id !== state.targetUid.value)) inputRef.value.focus({ preventScroll: true });
			});
		}
		function select() {
			inputRef.value?.select();
		}
		function onPaste(e) {
			if (hasMask.value === true && props.reverseFillMask !== true) {
				const inp = e.target;
				moveCursorForPaste(inp, inp.selectionStart, inp.selectionEnd);
			}
			emit("paste", e);
		}
		function onInput(e) {
			if (!e || !e.target) return;
			if (props.type === "file") {
				emit("update:modelValue", e.target.files);
				return;
			}
			const val = e.target.value;
			if (e.target.qComposing === true) {
				temp.value = val;
				return;
			}
			if (hasMask.value === true) updateMaskValue(val, false, e.inputType);
			else {
				emitValue(val);
				if (isTypeText.value === true && e.target === document.activeElement) {
					const { selectionStart, selectionEnd } = e.target;
					if (selectionStart !== void 0 && selectionEnd !== void 0) nextTick(() => {
						if (e.target === document.activeElement && val.indexOf(e.target.value) === 0) e.target.setSelectionRange(selectionStart, selectionEnd);
					});
				}
			}
			props.autogrow === true && adjustHeight();
		}
		function onAnimationend(e) {
			emit("animationend", e);
			adjustHeight();
		}
		function emitValue(val, stopWatcher) {
			emitValueFn = () => {
				emitTimer = null;
				if (props.type !== "number" && temp.hasOwnProperty("value") === true) delete temp.value;
				if (props.modelValue !== val && emitCachedValue !== val) {
					emitCachedValue = val;
					stopWatcher === true && (stopValueWatcher = true);
					emit("update:modelValue", val);
					nextTick(() => {
						emitCachedValue === val && (emitCachedValue = NaN);
					});
				}
				emitValueFn = void 0;
			};
			if (props.type === "number") {
				typedNumber = true;
				temp.value = val;
			}
			if (props.debounce !== void 0) {
				emitTimer !== null && clearTimeout(emitTimer);
				temp.value = val;
				emitTimer = setTimeout(emitValueFn, props.debounce);
			} else emitValueFn();
		}
		function adjustHeight() {
			requestAnimationFrame(() => {
				const inp = inputRef.value;
				if (inp !== null) {
					const parentStyle = inp.parentNode.style;
					const { scrollTop } = inp;
					const { overflowY, maxHeight } = $q.platform.is.firefox === true ? {} : window.getComputedStyle(inp);
					const changeOverflow = overflowY !== void 0 && overflowY !== "scroll";
					changeOverflow === true && (inp.style.overflowY = "hidden");
					parentStyle.marginBottom = inp.scrollHeight - 1 + "px";
					inp.style.height = "1px";
					inp.style.height = inp.scrollHeight + "px";
					changeOverflow === true && (inp.style.overflowY = parseInt(maxHeight, 10) < inp.scrollHeight ? "auto" : "hidden");
					parentStyle.marginBottom = "";
					inp.scrollTop = scrollTop;
				}
			});
		}
		function onChange(e) {
			onComposition(e);
			if (emitTimer !== null) {
				clearTimeout(emitTimer);
				emitTimer = null;
			}
			emitValueFn?.();
			emit("change", e.target.value);
		}
		function onFinishEditing(e) {
			e !== void 0 && stop(e);
			if (emitTimer !== null) {
				clearTimeout(emitTimer);
				emitTimer = null;
			}
			emitValueFn?.();
			typedNumber = false;
			stopValueWatcher = false;
			delete temp.value;
			props.type !== "file" && setTimeout(() => {
				if (inputRef.value !== null) inputRef.value.value = innerValue.value !== void 0 ? innerValue.value : "";
			});
		}
		function getCurValue() {
			return temp.hasOwnProperty("value") === true ? temp.value : innerValue.value !== void 0 ? innerValue.value : "";
		}
		onBeforeUnmount(() => {
			onFinishEditing();
		});
		onMounted(() => {
			props.autogrow === true && adjustHeight();
		});
		Object.assign(state, {
			innerValue,
			fieldClass: computed(() => `q-${isTextarea.value === true ? "textarea" : "input"}` + (props.autogrow === true ? " q-textarea--autogrow" : "")),
			hasShadow: computed(() => props.type !== "file" && typeof props.shadowText === "string" && props.shadowText.length !== 0),
			inputRef,
			emitValue,
			hasValue,
			floatingLabel: computed(() => hasValue.value === true && (props.type !== "number" || isNaN(innerValue.value) === false) || fieldValueIsFilled(props.displayValue)),
			getControl: () => {
				return h(isTextarea.value === true ? "textarea" : "input", {
					ref: inputRef,
					class: ["q-field__native q-placeholder", props.inputClass],
					style: props.inputStyle,
					...inputAttrs.value,
					...onEvents.value,
					...props.type !== "file" ? { value: getCurValue() } : formDomProps.value
				});
			},
			getShadowControl: () => {
				return h("div", { class: "q-field__native q-field__shadow absolute-bottom no-pointer-events" + (isTextarea.value === true ? "" : " text-no-wrap") }, [h("span", { class: "invisible" }, getCurValue()), h("span", props.shadowText)]);
			}
		});
		const renderFn = use_field_default(state);
		Object.assign(proxy, {
			focus,
			select,
			getNativeElement: () => inputRef.value
		});
		injectProp(proxy, "nativeEl", () => inputRef.value);
		return renderFn;
	}
});
//#endregion
//#region node_modules/quasar/src/components/card/QCardSection.js
var QCardSection_default = createComponent({
	name: "QCardSection",
	props: {
		tag: {
			type: String,
			default: "div"
		},
		horizontal: Boolean
	},
	setup(props, { slots }) {
		const classes = computed(() => `q-card__section q-card__section--${props.horizontal === true ? "horiz row no-wrap" : "vert"}`);
		return () => h(props.tag, { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/card/QCardActions.js
var QCardActions_default = createComponent({
	name: "QCardActions",
	props: {
		...useAlignProps,
		vertical: Boolean
	},
	setup(props, { slots }) {
		const alignClass = use_align_default(props);
		const classes = computed(() => `q-card__actions ${alignClass.value} q-card__actions--${props.vertical === true ? "vert column" : "horiz row"}`);
		return () => h("div", { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/card/QCard.js
var QCard_default = createComponent({
	name: "QCard",
	props: {
		...useDarkProps,
		tag: {
			type: String,
			default: "div"
		},
		square: Boolean,
		flat: Boolean,
		bordered: Boolean
	},
	setup(props, { slots }) {
		const { proxy: { $q } } = getCurrentInstance();
		const isDark = use_dark_default(props, $q);
		const classes = computed(() => "q-card" + (isDark.value === true ? " q-card--dark q-dark" : "") + (props.bordered === true ? " q-card--bordered" : "") + (props.square === true ? " q-card--square no-border-radius" : "") + (props.flat === true ? " q-card--flat no-shadow" : ""));
		return () => h(props.tag, { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/composables/private.use-history/use-history.js
function use_history_default(showing, hide, hideOnRouteChange) {
	let historyEntry;
	function removeFromHistory() {
		if (historyEntry !== void 0) {
			History_default.remove(historyEntry);
			historyEntry = void 0;
		}
	}
	onBeforeUnmount(() => {
		showing.value === true && removeFromHistory();
	});
	return {
		removeFromHistory,
		addToHistory() {
			historyEntry = {
				condition: () => hideOnRouteChange.value === true,
				handler: hide
			};
			History_default.add(historyEntry);
		}
	};
}
//#endregion
//#region node_modules/quasar/src/utils/scroll/prevent-scroll.js
var registered = 0, scrollPositionX, scrollPositionY, maxScrollTop, vpPendingUpdate = false, bodyLeft, bodyTop, href, closeTimer = null;
function onWheel(e) {
	if (shouldPreventScroll(e)) stopAndPrevent(e);
}
function shouldPreventScroll(e) {
	if (e.target === document.body || e.target.classList.contains("q-layout__backdrop")) return true;
	const path = getEventPath(e), shift = e.shiftKey && !e.deltaX, scrollY = !shift && Math.abs(e.deltaX) <= Math.abs(e.deltaY), delta = shift || scrollY ? e.deltaY : e.deltaX;
	for (let index = 0; index < path.length; index++) {
		const el = path[index];
		if (hasScrollbar(el, scrollY)) return scrollY ? delta < 0 && el.scrollTop === 0 ? true : delta > 0 && el.scrollTop + el.clientHeight === el.scrollHeight : delta < 0 && el.scrollLeft === 0 ? true : delta > 0 && el.scrollLeft + el.clientWidth === el.scrollWidth;
	}
	return true;
}
function onAppleScroll(e) {
	if (e.target === document) document.scrollingElement.scrollTop = document.scrollingElement.scrollTop;
}
function onAppleResize(evt) {
	if (vpPendingUpdate === true) return;
	vpPendingUpdate = true;
	requestAnimationFrame(() => {
		vpPendingUpdate = false;
		const { height } = evt.target, { clientHeight, scrollTop } = document.scrollingElement;
		if (maxScrollTop === void 0 || height !== window.innerHeight) {
			maxScrollTop = clientHeight - height;
			document.scrollingElement.scrollTop = scrollTop;
		}
		if (scrollTop > maxScrollTop) document.scrollingElement.scrollTop -= Math.ceil((scrollTop - maxScrollTop) / 8);
	});
}
function apply(action) {
	const body = document.body, hasViewport = window.visualViewport !== void 0;
	if (action === "add") {
		const { overflowY, overflowX } = window.getComputedStyle(body);
		scrollPositionX = getHorizontalScrollPosition(window);
		scrollPositionY = getVerticalScrollPosition(window);
		bodyLeft = body.style.left;
		bodyTop = body.style.top;
		href = window.location.href;
		body.style.left = `-${scrollPositionX}px`;
		body.style.top = `-${scrollPositionY}px`;
		if (overflowX !== "hidden" && (overflowX === "scroll" || body.scrollWidth > window.innerWidth)) body.classList.add("q-body--force-scrollbar-x");
		if (overflowY !== "hidden" && (overflowY === "scroll" || body.scrollHeight > window.innerHeight)) body.classList.add("q-body--force-scrollbar-y");
		body.classList.add("q-body--prevent-scroll");
		document.qScrollPrevented = true;
		if (client.is.ios === true) if (hasViewport === true) {
			window.scrollTo(0, 0);
			window.visualViewport.addEventListener("resize", onAppleResize, listenOpts.passiveCapture);
			window.visualViewport.addEventListener("scroll", onAppleResize, listenOpts.passiveCapture);
			window.scrollTo(0, 0);
		} else window.addEventListener("scroll", onAppleScroll, listenOpts.passiveCapture);
	}
	if (client.is.desktop === true && client.is.mac === true) window[`${action}EventListener`]("wheel", onWheel, listenOpts.notPassive);
	if (action === "remove") {
		if (client.is.ios === true) if (hasViewport === true) {
			window.visualViewport.removeEventListener("resize", onAppleResize, listenOpts.passiveCapture);
			window.visualViewport.removeEventListener("scroll", onAppleResize, listenOpts.passiveCapture);
		} else window.removeEventListener("scroll", onAppleScroll, listenOpts.passiveCapture);
		body.classList.remove("q-body--prevent-scroll");
		body.classList.remove("q-body--force-scrollbar-x");
		body.classList.remove("q-body--force-scrollbar-y");
		document.qScrollPrevented = false;
		body.style.left = bodyLeft;
		body.style.top = bodyTop;
		if (window.location.href === href) window.scrollTo(scrollPositionX, scrollPositionY);
		maxScrollTop = void 0;
	}
}
function prevent_scroll_default(state) {
	let action = "add";
	if (state === true) {
		registered++;
		if (closeTimer !== null) {
			clearTimeout(closeTimer);
			closeTimer = null;
			return;
		}
		if (registered > 1) return;
	} else {
		if (registered === 0) return;
		registered--;
		if (registered > 0) return;
		action = "remove";
		if (client.is.ios === true && client.is.nativeMobile === true) {
			closeTimer !== null && clearTimeout(closeTimer);
			closeTimer = setTimeout(() => {
				apply(action);
				closeTimer = null;
			}, 100);
			return;
		}
	}
	apply(action);
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-prevent-scroll/use-prevent-scroll.js
function use_prevent_scroll_default() {
	let currentState;
	return { preventBodyScroll(state) {
		if (state !== currentState && (currentState !== void 0 || state === true)) {
			currentState = state;
			prevent_scroll_default(state);
		}
	} };
}
//#endregion
//#region node_modules/quasar/src/utils/private.keyboard/escape-key.js
var handlers$1 = [];
var escDown;
function onKeydown(evt) {
	escDown = evt.keyCode === 27;
}
function onBlur() {
	if (escDown === true) escDown = false;
}
function onKeyup(evt) {
	if (escDown === true) {
		escDown = false;
		if (isKeyCode(evt, 27) === true) handlers$1[handlers$1.length - 1](evt);
	}
}
function update(action) {
	window[action]("keydown", onKeydown);
	window[action]("blur", onBlur);
	window[action]("keyup", onKeyup);
	escDown = false;
}
function addEscapeKey(fn) {
	if (client.is.desktop === true) {
		handlers$1.push(fn);
		if (handlers$1.length === 1) update("addEventListener");
	}
}
function removeEscapeKey(fn) {
	const index = handlers$1.indexOf(fn);
	if (index !== -1) {
		handlers$1.splice(index, 1);
		if (handlers$1.length === 0) update("removeEventListener");
	}
}
//#endregion
//#region node_modules/quasar/src/utils/private.focus/focusout.js
var handlers = [];
function trigger(e) {
	handlers[handlers.length - 1](e);
}
function addFocusout(fn) {
	if (client.is.desktop === true) {
		handlers.push(fn);
		if (handlers.length === 1) document.body.addEventListener("focusin", trigger);
	}
}
function removeFocusout(fn) {
	const index = handlers.indexOf(fn);
	if (index !== -1) {
		handlers.splice(index, 1);
		if (handlers.length === 0) document.body.removeEventListener("focusin", trigger);
	}
}
//#endregion
//#region node_modules/quasar/src/components/dialog/QDialog.js
var maximizedModals = 0;
var positionClass = {
	standard: "fixed-full flex-center",
	top: "fixed-top justify-center",
	bottom: "fixed-bottom justify-center",
	right: "fixed-right items-center",
	left: "fixed-left items-center"
};
var defaultTransitions = {
	standard: ["scale", "scale"],
	top: ["slide-down", "slide-up"],
	bottom: ["slide-up", "slide-down"],
	right: ["slide-left", "slide-right"],
	left: ["slide-right", "slide-left"]
};
var QDialog_default = createComponent({
	name: "QDialog",
	inheritAttrs: false,
	props: {
		...useModelToggleProps,
		...useTransitionProps,
		transitionShow: String,
		transitionHide: String,
		persistent: Boolean,
		autoClose: Boolean,
		allowFocusOutside: Boolean,
		noEscDismiss: Boolean,
		noBackdropDismiss: Boolean,
		noRouteDismiss: Boolean,
		noRefocus: Boolean,
		noFocus: Boolean,
		noShake: Boolean,
		seamless: Boolean,
		maximized: Boolean,
		fullWidth: Boolean,
		fullHeight: Boolean,
		square: Boolean,
		backdropFilter: String,
		position: {
			type: String,
			default: "standard",
			validator: (val) => [
				"standard",
				"top",
				"bottom",
				"left",
				"right"
			].includes(val)
		}
	},
	emits: [
		...useModelToggleEmits,
		"shake",
		"click",
		"escapeKey"
	],
	setup(props, { slots, emit, attrs }) {
		const vm = getCurrentInstance();
		const innerRef = ref(null);
		const showing = ref(false);
		const animating = ref(false);
		let shakeTimeout = null, refocusTarget = null, isMaximized, avoidAutoClose;
		const hideOnRouteChange = computed(() => props.persistent !== true && props.noRouteDismiss !== true && props.seamless !== true);
		const { preventBodyScroll } = use_prevent_scroll_default();
		const { registerTimeout } = use_timeout_default();
		const { registerTick, removeTick } = use_tick_default();
		const { transitionProps, transitionStyle } = use_transition_default(props, () => defaultTransitions[props.position][0], () => defaultTransitions[props.position][1]);
		const backdropStyle = computed(() => transitionStyle.value + (props.backdropFilter !== void 0 ? `;backdrop-filter:${props.backdropFilter};-webkit-backdrop-filter:${props.backdropFilter}` : ""));
		const { showPortal, hidePortal, portalIsAccessible, renderPortal } = use_portal_default(vm, innerRef, renderPortalContent, "dialog");
		const { hide } = use_model_toggle_default({
			showing,
			hideOnRouteChange,
			handleShow,
			handleHide,
			processOnMount: true
		});
		const { addToHistory, removeFromHistory } = use_history_default(showing, hide, hideOnRouteChange);
		const classes = computed(() => `q-dialog__inner flex no-pointer-events q-dialog__inner--${props.maximized === true ? "maximized" : "minimized"} q-dialog__inner--${props.position} ${positionClass[props.position]}` + (animating.value === true ? " q-dialog__inner--animating" : "") + (props.fullWidth === true ? " q-dialog__inner--fullwidth" : "") + (props.fullHeight === true ? " q-dialog__inner--fullheight" : "") + (props.square === true ? " q-dialog__inner--square" : ""));
		const useBackdrop = computed(() => showing.value === true && props.seamless !== true);
		const onEvents = computed(() => props.autoClose === true ? { onClick: onAutoClose } : {});
		const rootClasses = computed(() => [`q-dialog fullscreen no-pointer-events q-dialog--${useBackdrop.value === true ? "modal" : "seamless"}`, attrs.class]);
		watch(() => props.maximized, (state) => {
			showing.value === true && updateMaximized(state);
		});
		watch(useBackdrop, (val) => {
			preventBodyScroll(val);
			if (val === true) {
				addFocusout(onFocusChange);
				addEscapeKey(onEscapeKey);
			} else {
				removeFocusout(onFocusChange);
				removeEscapeKey(onEscapeKey);
			}
		});
		function handleShow(evt) {
			addToHistory();
			refocusTarget = props.noRefocus === false && document.activeElement !== null ? document.activeElement : null;
			updateMaximized(props.maximized);
			showPortal();
			animating.value = true;
			if (props.noFocus !== true) {
				document.activeElement?.blur();
				registerTick(focus);
			} else removeTick();
			registerTimeout(() => {
				if (vm.proxy.$q.platform.is.ios === true) {
					if (props.seamless !== true && document.activeElement) {
						const { top, bottom } = document.activeElement.getBoundingClientRect(), { innerHeight } = window, height = window.visualViewport !== void 0 ? window.visualViewport.height : innerHeight;
						if (top > 0 && bottom > height / 2) document.scrollingElement.scrollTop = Math.min(document.scrollingElement.scrollHeight - height, bottom >= innerHeight ? Infinity : Math.ceil(document.scrollingElement.scrollTop + bottom - height / 2));
						document.activeElement.scrollIntoView();
					}
					avoidAutoClose = true;
					innerRef.value.click();
					avoidAutoClose = false;
				}
				showPortal(true);
				animating.value = false;
				emit("show", evt);
			}, props.transitionDuration);
		}
		function handleHide(evt) {
			removeTick();
			removeFromHistory();
			cleanup(true);
			animating.value = true;
			hidePortal();
			if (refocusTarget !== null) {
				((evt?.type.indexOf("key") === 0 ? refocusTarget.closest("[tabindex]:not([tabindex^=\"-\"])") : void 0) || refocusTarget).focus();
				refocusTarget = null;
			}
			registerTimeout(() => {
				hidePortal(true);
				animating.value = false;
				emit("hide", evt);
			}, props.transitionDuration);
		}
		function focus(selector) {
			addFocusFn(() => {
				let node = innerRef.value;
				if (node === null) return;
				if (selector !== void 0) {
					const target = node.querySelector(selector);
					if (target !== null) {
						target.focus({ preventScroll: true });
						return;
					}
				}
				if (node.contains(document.activeElement) !== true) {
					node = node.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]") || node.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]") || node.querySelector("[autofocus], [data-autofocus]") || node;
					node.focus({ preventScroll: true });
				}
			});
		}
		function shake(focusTarget) {
			if (focusTarget && typeof focusTarget.focus === "function") focusTarget.focus({ preventScroll: true });
			else focus();
			emit("shake");
			const node = innerRef.value;
			if (node !== null) {
				node.classList.remove("q-animate--scale");
				node.classList.add("q-animate--scale");
				shakeTimeout !== null && clearTimeout(shakeTimeout);
				shakeTimeout = setTimeout(() => {
					shakeTimeout = null;
					if (innerRef.value !== null) {
						node.classList.remove("q-animate--scale");
						focus();
					}
				}, 170);
			}
		}
		function onEscapeKey() {
			if (props.seamless !== true) if (props.persistent === true || props.noEscDismiss === true) props.maximized !== true && props.noShake !== true && shake();
			else {
				emit("escapeKey");
				hide();
			}
		}
		function cleanup(hiding) {
			if (shakeTimeout !== null) {
				clearTimeout(shakeTimeout);
				shakeTimeout = null;
			}
			if (hiding === true || showing.value === true) {
				updateMaximized(false);
				if (props.seamless !== true) {
					preventBodyScroll(false);
					removeFocusout(onFocusChange);
					removeEscapeKey(onEscapeKey);
				}
			}
			if (hiding !== true) refocusTarget = null;
		}
		function updateMaximized(active) {
			if (active === true) {
				if (isMaximized !== true) {
					maximizedModals < 1 && document.body.classList.add("q-body--dialog");
					maximizedModals++;
					isMaximized = true;
				}
			} else if (isMaximized === true) {
				if (maximizedModals < 2) document.body.classList.remove("q-body--dialog");
				maximizedModals--;
				isMaximized = false;
			}
		}
		function onAutoClose(e) {
			if (avoidAutoClose !== true) {
				hide(e);
				emit("click", e);
			}
		}
		function onBackdropClick(e) {
			if (props.persistent !== true && props.noBackdropDismiss !== true) hide(e);
			else if (props.noShake !== true) shake();
		}
		function onFocusChange(evt) {
			if (props.allowFocusOutside !== true && portalIsAccessible.value === true && childHasFocus(innerRef.value, evt.target) !== true) focus("[tabindex]:not([tabindex=\"-1\"])");
		}
		Object.assign(vm.proxy, {
			focus,
			shake,
			__updateRefocusTarget(target) {
				refocusTarget = target || null;
			}
		});
		onBeforeUnmount(cleanup);
		function renderPortalContent() {
			return h("div", {
				role: "dialog",
				"aria-modal": useBackdrop.value === true ? "true" : "false",
				...attrs,
				class: rootClasses.value
			}, [h(Transition, {
				name: "q-transition--fade",
				appear: true
			}, () => useBackdrop.value === true ? h("div", {
				class: "q-dialog__backdrop fixed-full",
				style: backdropStyle.value,
				"aria-hidden": "true",
				tabindex: -1,
				onClick: onBackdropClick
			}) : null), h(Transition, transitionProps.value, () => showing.value === true ? h("div", {
				ref: innerRef,
				class: classes.value,
				style: transitionStyle.value,
				tabindex: -1,
				...onEvents.value
			}, hSlot(slots.default)) : null)]);
		}
		return renderPortal;
	}
});
//#endregion
//#region node_modules/quasar/src/components/field/QField.js
var QField_default = createComponent({
	name: "QField",
	inheritAttrs: false,
	props: {
		...useFieldProps,
		tag: {
			type: String,
			default: "label"
		}
	},
	emits: useFieldEmits,
	setup() {
		return use_field_default(useFieldState({ tagProp: true }));
	}
});
//#endregion
//#region node_modules/quasar/src/components/chip/QChip.js
var defaultSizes = {
	xs: 8,
	sm: 10,
	md: 14,
	lg: 20,
	xl: 24
};
var QChip_default = createComponent({
	name: "QChip",
	props: {
		...useDarkProps,
		...useSizeProps,
		dense: Boolean,
		icon: String,
		iconRight: String,
		iconRemove: String,
		iconSelected: String,
		label: [String, Number],
		color: String,
		textColor: String,
		modelValue: {
			type: Boolean,
			default: true
		},
		selected: {
			type: Boolean,
			default: null
		},
		square: Boolean,
		outline: Boolean,
		clickable: Boolean,
		removable: Boolean,
		removeAriaLabel: String,
		tabindex: [String, Number],
		disable: Boolean,
		ripple: {
			type: [Boolean, Object],
			default: true
		}
	},
	emits: [
		"update:modelValue",
		"update:selected",
		"remove",
		"click"
	],
	setup(props, { slots, emit }) {
		const { proxy: { $q } } = getCurrentInstance();
		const isDark = use_dark_default(props, $q);
		const sizeStyle = use_size_default(props, defaultSizes);
		const hasLeftIcon = computed(() => props.selected === true || props.icon !== void 0);
		const leftIcon = computed(() => props.selected === true ? props.iconSelected || $q.iconSet.chip.selected : props.icon);
		const removeIcon = computed(() => props.iconRemove || $q.iconSet.chip.remove);
		const isClickable = computed(() => props.disable === false && (props.clickable === true || props.selected !== null));
		const classes = computed(() => {
			const text = props.outline === true ? props.color || props.textColor : props.textColor;
			return "q-chip row inline no-wrap items-center" + (props.outline === false && props.color !== void 0 ? ` bg-${props.color}` : "") + (text ? ` text-${text} q-chip--colored` : "") + (props.disable === true ? " disabled" : "") + (props.dense === true ? " q-chip--dense" : "") + (props.outline === true ? " q-chip--outline" : "") + (props.selected === true ? " q-chip--selected" : "") + (isClickable.value === true ? " q-chip--clickable cursor-pointer non-selectable q-hoverable" : "") + (props.square === true ? " q-chip--square" : "") + (isDark.value === true ? " q-chip--dark q-dark" : "");
		});
		const attributes = computed(() => {
			const chip = props.disable === true ? {
				tabindex: -1,
				"aria-disabled": "true"
			} : { tabindex: props.tabindex || 0 };
			return {
				chip,
				remove: {
					...chip,
					role: "button",
					"aria-hidden": "false",
					"aria-label": props.removeAriaLabel || $q.lang.label.remove
				}
			};
		});
		function onKeyup(e) {
			e.keyCode === 13 && onClick(e);
		}
		function onClick(e) {
			if (!props.disable) {
				emit("update:selected", !props.selected);
				emit("click", e);
			}
		}
		function onRemove(e) {
			if (e.keyCode === void 0 || e.keyCode === 13) {
				stopAndPrevent(e);
				if (props.disable === false) {
					emit("update:modelValue", false);
					emit("remove");
				}
			}
		}
		function getContent() {
			const child = [];
			isClickable.value === true && child.push(h("div", { class: "q-focus-helper" }));
			hasLeftIcon.value === true && child.push(h(QIcon_default, {
				class: "q-chip__icon q-chip__icon--left",
				name: leftIcon.value
			}));
			const label = props.label !== void 0 ? [h("div", { class: "ellipsis" }, [props.label])] : void 0;
			child.push(h("div", { class: "q-chip__content col row no-wrap items-center q-anchor--skip" }, hMergeSlotSafely(slots.default, label)));
			props.iconRight && child.push(h(QIcon_default, {
				class: "q-chip__icon q-chip__icon--right",
				name: props.iconRight
			}));
			props.removable === true && child.push(h(QIcon_default, {
				class: "q-chip__icon q-chip__icon--remove cursor-pointer",
				name: removeIcon.value,
				...attributes.value.remove,
				onClick: onRemove,
				onKeyup: onRemove
			}));
			return child;
		}
		return () => {
			if (props.modelValue === false) return;
			const data = {
				class: classes.value,
				style: sizeStyle.value
			};
			isClickable.value === true && Object.assign(data, attributes.value.chip, {
				onClick,
				onKeyup
			});
			return hDir("div", data, getContent(), "ripple", props.ripple !== false && props.disable !== true, () => [[Ripple_default, props.ripple]]);
		};
	}
});
//#endregion
//#region node_modules/quasar/src/components/menu/QMenu.js
var QMenu_default = createComponent({
	name: "QMenu",
	inheritAttrs: false,
	props: {
		...useAnchorProps,
		...useModelToggleProps,
		...useDarkProps,
		...useTransitionProps,
		persistent: Boolean,
		autoClose: Boolean,
		separateClosePopup: Boolean,
		noEscDismiss: Boolean,
		noRouteDismiss: Boolean,
		noRefocus: Boolean,
		noFocus: Boolean,
		fit: Boolean,
		cover: Boolean,
		square: Boolean,
		anchor: {
			type: String,
			validator: validatePosition
		},
		self: {
			type: String,
			validator: validatePosition
		},
		offset: {
			type: Array,
			validator: validateOffset
		},
		scrollTarget: scrollTargetProp,
		touchPosition: Boolean,
		maxHeight: {
			type: String,
			default: null
		},
		maxWidth: {
			type: String,
			default: null
		}
	},
	emits: [
		...useModelToggleEmits,
		"click",
		"escapeKey"
	],
	setup(props, { slots, emit, attrs }) {
		let refocusTarget = null, absoluteOffset, unwatchPosition, avoidAutoClose;
		const vm = getCurrentInstance();
		const { proxy } = vm;
		const { $q } = proxy;
		const innerRef = ref(null);
		const showing = ref(false);
		const hideOnRouteChange = computed(() => props.persistent !== true && props.noRouteDismiss !== true);
		const isDark = use_dark_default(props, $q);
		const { registerTick, removeTick } = use_tick_default();
		const { registerTimeout } = use_timeout_default();
		const { transitionProps, transitionStyle } = use_transition_default(props);
		const { localScrollTarget, changeScrollEvent, unconfigureScrollTarget } = use_scroll_target_default(props, configureScrollTarget);
		const { anchorEl, canShow } = use_anchor_default({ showing });
		const { hide } = use_model_toggle_default({
			showing,
			canShow,
			handleShow,
			handleHide,
			hideOnRouteChange,
			processOnMount: true
		});
		const { showPortal, hidePortal, renderPortal } = use_portal_default(vm, innerRef, renderPortalContent, "menu");
		const clickOutsideProps = {
			anchorEl,
			innerRef,
			onClickOutside(e) {
				if (props.persistent !== true && showing.value === true) {
					hide(e);
					if (e.type === "touchstart" || e.target.classList.contains("q-dialog__backdrop")) stopAndPrevent(e);
					return true;
				}
			}
		};
		const anchorOrigin = computed(() => parsePosition(props.anchor || (props.cover === true ? "center middle" : "bottom start"), $q.lang.rtl));
		const selfOrigin = computed(() => props.cover === true ? anchorOrigin.value : parsePosition(props.self || "top start", $q.lang.rtl));
		const menuClass = computed(() => (props.square === true ? " q-menu--square" : "") + (isDark.value === true ? " q-menu--dark q-dark" : ""));
		const onEvents = computed(() => props.autoClose === true ? { onClick: onAutoClose } : {});
		const handlesFocus = computed(() => showing.value === true && props.persistent !== true);
		watch(handlesFocus, (val) => {
			if (val === true) {
				addEscapeKey(onEscapeKey);
				addClickOutside(clickOutsideProps);
			} else {
				removeEscapeKey(onEscapeKey);
				removeClickOutside(clickOutsideProps);
			}
		});
		function focus() {
			addFocusFn(() => {
				let node = innerRef.value;
				if (node && node.contains(document.activeElement) !== true) {
					node = node.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]") || node.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]") || node.querySelector("[autofocus], [data-autofocus]") || node;
					node.focus({ preventScroll: true });
				}
			});
		}
		function handleShow(evt) {
			refocusTarget = props.noRefocus === false ? document.activeElement : null;
			addFocusout(onFocusout);
			showPortal();
			configureScrollTarget();
			absoluteOffset = void 0;
			if (evt !== void 0 && (props.touchPosition || props.contextMenu)) {
				const pos = position(evt);
				if (pos.left !== void 0) {
					const { top, left } = anchorEl.value.getBoundingClientRect();
					absoluteOffset = {
						left: pos.left - left,
						top: pos.top - top
					};
				}
			}
			if (unwatchPosition === void 0) unwatchPosition = watch(() => $q.screen.width + "|" + $q.screen.height + "|" + props.self + "|" + props.anchor + "|" + $q.lang.rtl, updatePosition);
			if (props.noFocus !== true) document.activeElement.blur();
			registerTick(() => {
				updatePosition();
				props.noFocus !== true && focus();
			});
			registerTimeout(() => {
				if ($q.platform.is.ios === true) {
					avoidAutoClose = props.autoClose;
					innerRef.value.click();
				}
				updatePosition();
				showPortal(true);
				emit("show", evt);
			}, props.transitionDuration);
		}
		function handleHide(evt) {
			removeTick();
			hidePortal();
			anchorCleanup(true);
			if (refocusTarget !== null && (evt === void 0 || evt.qClickOutside !== true)) {
				((evt?.type.indexOf("key") === 0 ? refocusTarget.closest("[tabindex]:not([tabindex^=\"-\"])") : void 0) || refocusTarget).focus();
				refocusTarget = null;
			}
			registerTimeout(() => {
				hidePortal(true);
				emit("hide", evt);
			}, props.transitionDuration);
		}
		function anchorCleanup(hiding) {
			absoluteOffset = void 0;
			if (unwatchPosition !== void 0) {
				unwatchPosition();
				unwatchPosition = void 0;
			}
			if (hiding === true || showing.value === true) {
				removeFocusout(onFocusout);
				unconfigureScrollTarget();
				removeClickOutside(clickOutsideProps);
				removeEscapeKey(onEscapeKey);
			}
			if (hiding !== true) refocusTarget = null;
		}
		function configureScrollTarget() {
			if (anchorEl.value !== null || props.scrollTarget !== void 0) {
				localScrollTarget.value = getScrollTarget(anchorEl.value, props.scrollTarget);
				changeScrollEvent(localScrollTarget.value, updatePosition);
			}
		}
		function onAutoClose(e) {
			if (avoidAutoClose !== true) {
				closePortalMenus(proxy, e);
				emit("click", e);
			} else avoidAutoClose = false;
		}
		function onFocusout(evt) {
			if (handlesFocus.value === true && props.noFocus !== true && childHasFocus(innerRef.value, evt.target) !== true) focus();
		}
		function onEscapeKey(evt) {
			if (props.noEscDismiss !== true) {
				emit("escapeKey");
				hide(evt);
			}
		}
		function updatePosition() {
			setPosition({
				targetEl: innerRef.value,
				offset: props.offset,
				anchorEl: anchorEl.value,
				anchorOrigin: anchorOrigin.value,
				selfOrigin: selfOrigin.value,
				absoluteOffset,
				fit: props.fit,
				cover: props.cover,
				maxHeight: props.maxHeight,
				maxWidth: props.maxWidth
			});
		}
		function renderPortalContent() {
			return h(Transition, transitionProps.value, () => showing.value === true ? h("div", {
				role: "menu",
				...attrs,
				ref: innerRef,
				tabindex: -1,
				class: ["q-menu q-position-engine scroll" + menuClass.value, attrs.class],
				style: [attrs.style, transitionStyle.value],
				...onEvents.value
			}, hSlot(slots.default)) : null);
		}
		onBeforeUnmount(anchorCleanup);
		Object.assign(proxy, {
			focus,
			updatePosition
		});
		return renderPortal;
	}
});
//#endregion
//#region node_modules/quasar/src/utils/private.rtl/rtl.js
var rtlHasScrollBug = false;
{
	const scroller = document.createElement("div");
	scroller.setAttribute("dir", "rtl");
	Object.assign(scroller.style, {
		width: "1px",
		height: "1px",
		overflow: "auto"
	});
	const spacer = document.createElement("div");
	Object.assign(spacer.style, {
		width: "1000px",
		height: "1px"
	});
	document.body.appendChild(scroller);
	scroller.appendChild(spacer);
	scroller.scrollLeft = -1e3;
	rtlHasScrollBug = scroller.scrollLeft >= 0;
	scroller.remove();
}
//#endregion
//#region node_modules/quasar/src/components/virtual-scroll/use-virtual-scroll.js
var aggBucketSize = 1e3;
var scrollToEdges = [
	"start",
	"center",
	"end",
	"start-force",
	"center-force",
	"end-force"
];
var filterProto = Array.prototype.filter;
var setOverflowAnchor = window.getComputedStyle(document.body).overflowAnchor === void 0 ? noop : function(contentEl, index) {
	if (contentEl === null) return;
	if (contentEl._qOverflowAnimationFrame !== void 0) cancelAnimationFrame(contentEl._qOverflowAnimationFrame);
	contentEl._qOverflowAnimationFrame = requestAnimationFrame(() => {
		if (contentEl === null) return;
		contentEl._qOverflowAnimationFrame = void 0;
		const children = contentEl.children || [];
		filterProto.call(children, (el) => el.dataset && el.dataset.qVsAnchor !== void 0).forEach((el) => {
			delete el.dataset.qVsAnchor;
		});
		const el = children[index];
		if (el?.dataset) el.dataset.qVsAnchor = "";
	});
};
function sumFn(acc, h) {
	return acc + h;
}
function getScrollDetails(parent, child, beforeRef, afterRef, horizontal, rtl, stickyStart, stickyEnd) {
	const parentCalc = parent === window ? document.scrollingElement || document.documentElement : parent, propElSize = horizontal === true ? "offsetWidth" : "offsetHeight", details = {
		scrollStart: 0,
		scrollViewSize: -stickyStart - stickyEnd,
		scrollMaxSize: 0,
		offsetStart: -stickyStart,
		offsetEnd: -stickyEnd
	};
	if (horizontal === true) {
		if (parent === window) {
			details.scrollStart = window.pageXOffset || window.scrollX || document.body.scrollLeft || 0;
			details.scrollViewSize += document.documentElement.clientWidth;
		} else {
			details.scrollStart = parentCalc.scrollLeft;
			details.scrollViewSize += parentCalc.clientWidth;
		}
		details.scrollMaxSize = parentCalc.scrollWidth;
		if (rtl === true) details.scrollStart = (rtlHasScrollBug === true ? details.scrollMaxSize - details.scrollViewSize : 0) - details.scrollStart;
	} else {
		if (parent === window) {
			details.scrollStart = window.pageYOffset || window.scrollY || document.body.scrollTop || 0;
			details.scrollViewSize += document.documentElement.clientHeight;
		} else {
			details.scrollStart = parentCalc.scrollTop;
			details.scrollViewSize += parentCalc.clientHeight;
		}
		details.scrollMaxSize = parentCalc.scrollHeight;
	}
	if (beforeRef !== null) {
		for (let el = beforeRef.previousElementSibling; el !== null; el = el.previousElementSibling) if (el.classList.contains("q-virtual-scroll--skip") === false) details.offsetStart += el[propElSize];
	}
	if (afterRef !== null) {
		for (let el = afterRef.nextElementSibling; el !== null; el = el.nextElementSibling) if (el.classList.contains("q-virtual-scroll--skip") === false) details.offsetEnd += el[propElSize];
	}
	if (child !== parent) {
		const parentRect = parentCalc.getBoundingClientRect(), childRect = child.getBoundingClientRect();
		if (horizontal === true) {
			details.offsetStart += childRect.left - parentRect.left;
			details.offsetEnd -= childRect.width;
		} else {
			details.offsetStart += childRect.top - parentRect.top;
			details.offsetEnd -= childRect.height;
		}
		if (parent !== window) details.offsetStart += details.scrollStart;
		details.offsetEnd += details.scrollMaxSize - details.offsetStart;
	}
	return details;
}
function setScroll(parent, scroll, horizontal, rtl) {
	if (scroll === "end") scroll = (parent === window ? document.body : parent)[horizontal === true ? "scrollWidth" : "scrollHeight"];
	if (parent === window) if (horizontal === true) {
		if (rtl === true) scroll = (rtlHasScrollBug === true ? document.body.scrollWidth - document.documentElement.clientWidth : 0) - scroll;
		window.scrollTo(scroll, window.pageYOffset || window.scrollY || document.body.scrollTop || 0);
	} else window.scrollTo(window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, scroll);
	else if (horizontal === true) {
		if (rtl === true) scroll = (rtlHasScrollBug === true ? parent.scrollWidth - parent.offsetWidth : 0) - scroll;
		parent.scrollLeft = scroll;
	} else parent.scrollTop = scroll;
}
function sumSize(sizeAgg, size, from, to) {
	if (from >= to) return 0;
	const lastTo = size.length, fromAgg = Math.floor(from / aggBucketSize), toAgg = Math.floor((to - 1) / aggBucketSize) + 1;
	let total = sizeAgg.slice(fromAgg, toAgg).reduce(sumFn, 0);
	if (from % aggBucketSize !== 0) total -= size.slice(fromAgg * aggBucketSize, from).reduce(sumFn, 0);
	if (to % aggBucketSize !== 0 && to !== lastTo) total -= size.slice(to, toAgg * aggBucketSize).reduce(sumFn, 0);
	return total;
}
var commonVirtScrollProps = {
	virtualScrollSliceSize: {
		type: [Number, String],
		default: 10
	},
	virtualScrollSliceRatioBefore: {
		type: [Number, String],
		default: 1
	},
	virtualScrollSliceRatioAfter: {
		type: [Number, String],
		default: 1
	},
	virtualScrollItemSize: {
		type: [Number, String],
		default: 24
	},
	virtualScrollStickySizeStart: {
		type: [Number, String],
		default: 0
	},
	virtualScrollStickySizeEnd: {
		type: [Number, String],
		default: 0
	},
	tableColspan: [Number, String]
};
var useVirtualScrollProps = {
	virtualScrollHorizontal: Boolean,
	onVirtualScroll: Function,
	...commonVirtScrollProps
};
function useVirtualScroll({ virtualScrollLength, getVirtualScrollTarget, getVirtualScrollEl, virtualScrollItemSizeComputed }) {
	const { props, emit, proxy } = getCurrentInstance();
	const { $q } = proxy;
	let prevScrollStart, prevToIndex, localScrollViewSize, virtualScrollSizesAgg = [], virtualScrollSizes;
	const virtualScrollPaddingBefore = ref(0);
	const virtualScrollPaddingAfter = ref(0);
	const virtualScrollSliceSizeComputed = ref({});
	const beforeRef = ref(null);
	const afterRef = ref(null);
	const contentRef = ref(null);
	const virtualScrollSliceRange = ref({
		from: 0,
		to: 0
	});
	const colspanAttr = computed(() => props.tableColspan !== void 0 ? props.tableColspan : 100);
	if (virtualScrollItemSizeComputed === void 0) virtualScrollItemSizeComputed = computed(() => props.virtualScrollItemSize);
	const needsReset = computed(() => virtualScrollItemSizeComputed.value + ";" + props.virtualScrollHorizontal);
	watch(computed(() => needsReset.value + ";" + props.virtualScrollSliceRatioBefore + ";" + props.virtualScrollSliceRatioAfter), () => {
		setVirtualScrollSize();
	});
	watch(needsReset, reset);
	function reset() {
		localResetVirtualScroll(prevToIndex, true);
	}
	function refresh(toIndex) {
		localResetVirtualScroll(toIndex === void 0 ? prevToIndex : toIndex);
	}
	function scrollTo(toIndex, edge) {
		const scrollEl = getVirtualScrollTarget();
		if (scrollEl === void 0 || scrollEl === null || scrollEl.nodeType === 8) return;
		const scrollDetails = getScrollDetails(scrollEl, getVirtualScrollEl(), beforeRef.value, afterRef.value, props.virtualScrollHorizontal, $q.lang.rtl, props.virtualScrollStickySizeStart, props.virtualScrollStickySizeEnd);
		localScrollViewSize !== scrollDetails.scrollViewSize && setVirtualScrollSize(scrollDetails.scrollViewSize);
		setVirtualScrollSliceRange(scrollEl, scrollDetails, Math.min(virtualScrollLength.value - 1, Math.max(0, parseInt(toIndex, 10) || 0)), 0, scrollToEdges.indexOf(edge) !== -1 ? edge : prevToIndex !== -1 && toIndex > prevToIndex ? "end" : "start");
	}
	function localOnVirtualScrollEvt() {
		const scrollEl = getVirtualScrollTarget();
		if (scrollEl === void 0 || scrollEl === null || scrollEl.nodeType === 8) return;
		const scrollDetails = getScrollDetails(scrollEl, getVirtualScrollEl(), beforeRef.value, afterRef.value, props.virtualScrollHorizontal, $q.lang.rtl, props.virtualScrollStickySizeStart, props.virtualScrollStickySizeEnd), listLastIndex = virtualScrollLength.value - 1, listEndOffset = scrollDetails.scrollMaxSize - scrollDetails.offsetStart - scrollDetails.offsetEnd - virtualScrollPaddingAfter.value;
		if (prevScrollStart === scrollDetails.scrollStart) return;
		if (scrollDetails.scrollMaxSize <= 0) {
			setVirtualScrollSliceRange(scrollEl, scrollDetails, 0, 0);
			return;
		}
		localScrollViewSize !== scrollDetails.scrollViewSize && setVirtualScrollSize(scrollDetails.scrollViewSize);
		updateVirtualScrollSizes(virtualScrollSliceRange.value.from);
		const scrollMaxStart = Math.floor(scrollDetails.scrollMaxSize - Math.max(scrollDetails.scrollViewSize, scrollDetails.offsetEnd) - Math.min(virtualScrollSizes[listLastIndex], scrollDetails.scrollViewSize / 2));
		if (scrollMaxStart > 0 && Math.ceil(scrollDetails.scrollStart) >= scrollMaxStart) {
			setVirtualScrollSliceRange(scrollEl, scrollDetails, listLastIndex, scrollDetails.scrollMaxSize - scrollDetails.offsetEnd - virtualScrollSizesAgg.reduce(sumFn, 0));
			return;
		}
		let toIndex = 0, listOffset = scrollDetails.scrollStart - scrollDetails.offsetStart, offset = listOffset;
		if (listOffset <= listEndOffset && listOffset + scrollDetails.scrollViewSize >= virtualScrollPaddingBefore.value) {
			listOffset -= virtualScrollPaddingBefore.value;
			toIndex = virtualScrollSliceRange.value.from;
			offset = listOffset;
		} else for (let j = 0; listOffset >= virtualScrollSizesAgg[j] && toIndex < listLastIndex; j++) {
			listOffset -= virtualScrollSizesAgg[j];
			toIndex += aggBucketSize;
		}
		while (listOffset > 0 && toIndex < listLastIndex) {
			listOffset -= virtualScrollSizes[toIndex];
			if (listOffset > -scrollDetails.scrollViewSize) {
				toIndex++;
				offset = listOffset;
			} else offset = virtualScrollSizes[toIndex] + listOffset;
		}
		setVirtualScrollSliceRange(scrollEl, scrollDetails, toIndex, offset);
	}
	function setVirtualScrollSliceRange(scrollEl, scrollDetails, toIndex, offset, align) {
		const alignForce = typeof align === "string" && align.indexOf("-force") !== -1;
		const alignEnd = alignForce === true ? align.replace("-force", "") : align;
		const alignRange = alignEnd !== void 0 ? alignEnd : "start";
		let from = Math.max(0, toIndex - virtualScrollSliceSizeComputed.value[alignRange]), to = from + virtualScrollSliceSizeComputed.value.total;
		if (to > virtualScrollLength.value) {
			to = virtualScrollLength.value;
			from = Math.max(0, to - virtualScrollSliceSizeComputed.value.total);
		}
		prevScrollStart = scrollDetails.scrollStart;
		const rangeChanged = from !== virtualScrollSliceRange.value.from || to !== virtualScrollSliceRange.value.to;
		if (rangeChanged === false && alignEnd === void 0) {
			emitScroll(toIndex);
			return;
		}
		const { activeElement } = document;
		const contentEl = contentRef.value;
		if (rangeChanged === true && contentEl !== null && contentEl !== activeElement && contentEl.contains(activeElement) === true) {
			contentEl.addEventListener("focusout", onBlurRefocusFn);
			setTimeout(() => {
				contentEl?.removeEventListener("focusout", onBlurRefocusFn);
			});
		}
		setOverflowAnchor(contentEl, toIndex - from);
		const sizeBefore = alignEnd !== void 0 ? virtualScrollSizes.slice(from, toIndex).reduce(sumFn, 0) : 0;
		if (rangeChanged === true) {
			const tempTo = to >= virtualScrollSliceRange.value.from && from <= virtualScrollSliceRange.value.to ? virtualScrollSliceRange.value.to : to;
			virtualScrollSliceRange.value = {
				from,
				to: tempTo
			};
			virtualScrollPaddingBefore.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, 0, from);
			virtualScrollPaddingAfter.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, to, virtualScrollLength.value);
			requestAnimationFrame(() => {
				if (virtualScrollSliceRange.value.to !== to && prevScrollStart === scrollDetails.scrollStart) {
					virtualScrollSliceRange.value = {
						from: virtualScrollSliceRange.value.from,
						to
					};
					virtualScrollPaddingAfter.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, to, virtualScrollLength.value);
				}
			});
		}
		requestAnimationFrame(() => {
			if (prevScrollStart !== scrollDetails.scrollStart) return;
			if (rangeChanged === true) updateVirtualScrollSizes(from);
			const sizeAfter = virtualScrollSizes.slice(from, toIndex).reduce(sumFn, 0), posStart = sizeAfter + scrollDetails.offsetStart + virtualScrollPaddingBefore.value, posEnd = posStart + virtualScrollSizes[toIndex];
			let scrollPosition = posStart + offset;
			if (alignEnd !== void 0) {
				const sizeDiff = sizeAfter - sizeBefore;
				const scrollStart = scrollDetails.scrollStart + sizeDiff;
				scrollPosition = alignForce !== true && scrollStart < posStart && posEnd < scrollStart + scrollDetails.scrollViewSize ? scrollStart : alignEnd === "end" ? posEnd - scrollDetails.scrollViewSize : posStart - (alignEnd === "start" ? 0 : Math.round((scrollDetails.scrollViewSize - virtualScrollSizes[toIndex]) / 2));
			}
			prevScrollStart = scrollPosition;
			setScroll(scrollEl, scrollPosition, props.virtualScrollHorizontal, $q.lang.rtl);
			emitScroll(toIndex);
		});
	}
	function updateVirtualScrollSizes(from) {
		const contentEl = contentRef.value;
		if (contentEl) {
			const children = filterProto.call(contentEl.children, (el) => el.classList && el.classList.contains("q-virtual-scroll--skip") === false), childrenLength = children.length, sizeFn = props.virtualScrollHorizontal === true ? (el) => el.getBoundingClientRect().width : (el) => el.offsetHeight;
			let index = from, size, diff;
			for (let i = 0; i < childrenLength;) {
				size = sizeFn(children[i]);
				i++;
				while (i < childrenLength && children[i].classList.contains("q-virtual-scroll--with-prev") === true) {
					size += sizeFn(children[i]);
					i++;
				}
				diff = size - virtualScrollSizes[index];
				if (diff !== 0) {
					virtualScrollSizes[index] += diff;
					virtualScrollSizesAgg[Math.floor(index / aggBucketSize)] += diff;
				}
				index++;
			}
		}
	}
	function onBlurRefocusFn() {
		contentRef.value?.focus();
	}
	function localResetVirtualScroll(toIndex, fullReset) {
		const defaultSize = 1 * virtualScrollItemSizeComputed.value;
		if (fullReset === true || Array.isArray(virtualScrollSizes) === false) virtualScrollSizes = [];
		const oldVirtualScrollSizesLength = virtualScrollSizes.length;
		virtualScrollSizes.length = virtualScrollLength.value;
		for (let i = virtualScrollLength.value - 1; i >= oldVirtualScrollSizesLength; i--) virtualScrollSizes[i] = defaultSize;
		const jMax = Math.floor((virtualScrollLength.value - 1) / aggBucketSize);
		virtualScrollSizesAgg = [];
		for (let j = 0; j <= jMax; j++) {
			let size = 0;
			const iMax = Math.min((j + 1) * aggBucketSize, virtualScrollLength.value);
			for (let i = j * aggBucketSize; i < iMax; i++) size += virtualScrollSizes[i];
			virtualScrollSizesAgg.push(size);
		}
		prevToIndex = -1;
		prevScrollStart = void 0;
		virtualScrollPaddingBefore.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, 0, virtualScrollSliceRange.value.from);
		virtualScrollPaddingAfter.value = sumSize(virtualScrollSizesAgg, virtualScrollSizes, virtualScrollSliceRange.value.to, virtualScrollLength.value);
		if (toIndex >= 0) {
			updateVirtualScrollSizes(virtualScrollSliceRange.value.from);
			nextTick(() => {
				scrollTo(toIndex);
			});
		} else onVirtualScrollEvt();
	}
	function setVirtualScrollSize(scrollViewSize) {
		if (scrollViewSize === void 0 && typeof window !== "undefined") {
			const scrollEl = getVirtualScrollTarget();
			if (scrollEl !== void 0 && scrollEl !== null && scrollEl.nodeType !== 8) scrollViewSize = getScrollDetails(scrollEl, getVirtualScrollEl(), beforeRef.value, afterRef.value, props.virtualScrollHorizontal, $q.lang.rtl, props.virtualScrollStickySizeStart, props.virtualScrollStickySizeEnd).scrollViewSize;
		}
		localScrollViewSize = scrollViewSize;
		const virtualScrollSliceRatioBefore = parseFloat(props.virtualScrollSliceRatioBefore) || 0;
		const virtualScrollSliceRatioAfter = parseFloat(props.virtualScrollSliceRatioAfter) || 0;
		const multiplier = 1 + virtualScrollSliceRatioBefore + virtualScrollSliceRatioAfter;
		const view = scrollViewSize === void 0 || scrollViewSize <= 0 ? 1 : Math.ceil(scrollViewSize / virtualScrollItemSizeComputed.value);
		const baseSize = Math.max(1, view, Math.ceil((props.virtualScrollSliceSize > 0 ? props.virtualScrollSliceSize : 10) / multiplier));
		virtualScrollSliceSizeComputed.value = {
			total: Math.ceil(baseSize * multiplier),
			start: Math.ceil(baseSize * virtualScrollSliceRatioBefore),
			center: Math.ceil(baseSize * (.5 + virtualScrollSliceRatioBefore)),
			end: Math.ceil(baseSize * (1 + virtualScrollSliceRatioBefore)),
			view
		};
	}
	function padVirtualScroll(tag, content) {
		const paddingSize = props.virtualScrollHorizontal === true ? "width" : "height";
		const style = { ["--q-virtual-scroll-item-" + paddingSize]: virtualScrollItemSizeComputed.value + "px" };
		return [
			tag === "tbody" ? h(tag, {
				class: "q-virtual-scroll__padding",
				key: "before",
				ref: beforeRef
			}, [h("tr", [h("td", {
				style: {
					[paddingSize]: `${virtualScrollPaddingBefore.value}px`,
					...style
				},
				colspan: colspanAttr.value
			})])]) : h(tag, {
				class: "q-virtual-scroll__padding",
				key: "before",
				ref: beforeRef,
				style: {
					[paddingSize]: `${virtualScrollPaddingBefore.value}px`,
					...style
				}
			}),
			h(tag, {
				class: "q-virtual-scroll__content",
				key: "content",
				ref: contentRef,
				tabindex: -1
			}, content.flat()),
			tag === "tbody" ? h(tag, {
				class: "q-virtual-scroll__padding",
				key: "after",
				ref: afterRef
			}, [h("tr", [h("td", {
				style: {
					[paddingSize]: `${virtualScrollPaddingAfter.value}px`,
					...style
				},
				colspan: colspanAttr.value
			})])]) : h(tag, {
				class: "q-virtual-scroll__padding",
				key: "after",
				ref: afterRef,
				style: {
					[paddingSize]: `${virtualScrollPaddingAfter.value}px`,
					...style
				}
			})
		];
	}
	function emitScroll(index) {
		if (prevToIndex !== index) {
			props.onVirtualScroll !== void 0 && emit("virtualScroll", {
				index,
				from: virtualScrollSliceRange.value.from,
				to: virtualScrollSliceRange.value.to - 1,
				direction: index < prevToIndex ? "decrease" : "increase",
				ref: proxy
			});
			prevToIndex = index;
		}
	}
	setVirtualScrollSize();
	const onVirtualScrollEvt = debounce_default(localOnVirtualScrollEvt, $q.platform.is.ios === true ? 120 : 35);
	onBeforeMount(() => {
		setVirtualScrollSize();
	});
	let shouldActivate = false;
	onDeactivated(() => {
		shouldActivate = true;
	});
	onActivated(() => {
		if (shouldActivate !== true) return;
		const scrollEl = getVirtualScrollTarget();
		if (prevScrollStart !== void 0 && scrollEl !== void 0 && scrollEl !== null && scrollEl.nodeType !== 8) setScroll(scrollEl, prevScrollStart, props.virtualScrollHorizontal, $q.lang.rtl);
		else scrollTo(prevToIndex);
	});
	onBeforeUnmount(() => {
		onVirtualScrollEvt.cancel();
	});
	Object.assign(proxy, {
		scrollTo,
		reset,
		refresh
	});
	return {
		virtualScrollSliceRange,
		virtualScrollSliceSizeComputed,
		setVirtualScrollSize,
		onVirtualScrollEvt,
		localResetVirtualScroll,
		padVirtualScroll,
		scrollTo,
		reset,
		refresh
	};
}
//#endregion
//#region node_modules/quasar/src/utils/format/format.js
function between(v, min, max) {
	return max <= min ? min : Math.min(max, Math.max(min, v));
}
function normalizeToInterval(v, min, max) {
	if (max <= min) return min;
	const size = max - min + 1;
	let index = min + (v - min) % size;
	if (index < min) index = size + index;
	return index === 0 ? 0 : index;
}
//#endregion
//#region node_modules/quasar/src/components/select/QSelect.js
var validateNewValueMode = (v) => [
	"add",
	"add-unique",
	"toggle"
].includes(v);
var reEscapeList = ".*+?^${}()|[]\\";
var fieldPropsList = Object.keys(useFieldProps);
function getPropValueFn(userPropName, defaultPropName) {
	if (typeof userPropName === "function") return userPropName;
	const propName = userPropName !== void 0 ? userPropName : defaultPropName;
	return (opt) => opt !== null && typeof opt === "object" && propName in opt ? opt[propName] : opt;
}
var QSelect_default = createComponent({
	name: "QSelect",
	inheritAttrs: false,
	props: {
		...useVirtualScrollProps,
		...useFormProps,
		...useFieldProps,
		modelValue: { required: true },
		multiple: Boolean,
		displayValue: [String, Number],
		displayValueHtml: Boolean,
		dropdownIcon: String,
		options: {
			type: Array,
			default: () => []
		},
		optionValue: [Function, String],
		optionLabel: [Function, String],
		optionDisable: [Function, String],
		hideSelected: Boolean,
		hideDropdownIcon: Boolean,
		fillInput: Boolean,
		maxValues: [Number, String],
		optionsDense: Boolean,
		optionsDark: {
			type: Boolean,
			default: null
		},
		optionsSelectedClass: String,
		optionsHtml: Boolean,
		optionsCover: Boolean,
		menuShrink: Boolean,
		menuAnchor: String,
		menuSelf: String,
		menuOffset: Array,
		popupContentClass: String,
		popupContentStyle: [
			String,
			Array,
			Object
		],
		popupNoRouteDismiss: Boolean,
		useInput: Boolean,
		useChips: Boolean,
		newValueMode: {
			type: String,
			validator: validateNewValueMode
		},
		mapOptions: Boolean,
		emitValue: Boolean,
		disableTabSelection: Boolean,
		inputDebounce: {
			type: [Number, String],
			default: 500
		},
		inputClass: [
			Array,
			String,
			Object
		],
		inputStyle: [
			Array,
			String,
			Object
		],
		tabindex: {
			type: [String, Number],
			default: 0
		},
		autocomplete: String,
		transitionShow: {},
		transitionHide: {},
		transitionDuration: {},
		behavior: {
			type: String,
			validator: (v) => [
				"default",
				"menu",
				"dialog"
			].includes(v),
			default: "default"
		},
		virtualScrollItemSize: useVirtualScrollProps.virtualScrollItemSize.type,
		onNewValue: Function,
		onFilter: Function
	},
	emits: [
		...useFieldEmits,
		"add",
		"remove",
		"inputValue",
		"keyup",
		"keypress",
		"keydown",
		"popupShow",
		"popupHide",
		"filterAbort"
	],
	setup(props, { slots, emit }) {
		const { proxy } = getCurrentInstance();
		const { $q } = proxy;
		const menu = ref(false);
		const dialog = ref(false);
		const optionIndex = ref(-1);
		const inputValue = ref("");
		const dialogFieldFocused = ref(false);
		const innerLoadingIndicator = ref(false);
		let filterTimer = null, inputValueTimer = null, innerValueCache, hasDialog, userInputValue, filterId = null, defaultInputValue, transitionShowComputed, searchBuffer, searchBufferExp;
		const inputRef = ref(null);
		const targetRef = ref(null);
		const menuRef = ref(null);
		const dialogRef = ref(null);
		const menuContentRef = ref(null);
		const nameProp = useFormInputNameAttr(props);
		const onComposition = use_key_composition_default(onInput);
		const virtualScrollLength = computed(() => Array.isArray(props.options) ? props.options.length : 0);
		const { virtualScrollSliceRange, virtualScrollSliceSizeComputed, localResetVirtualScroll, padVirtualScroll, onVirtualScrollEvt, scrollTo, setVirtualScrollSize } = useVirtualScroll({
			virtualScrollLength,
			getVirtualScrollTarget,
			getVirtualScrollEl,
			virtualScrollItemSizeComputed: computed(() => props.virtualScrollItemSize === void 0 ? props.optionsDense === true ? 24 : 48 : props.virtualScrollItemSize)
		});
		const state = useFieldState();
		const innerValue = computed(() => {
			const mapNull = props.mapOptions === true && props.multiple !== true, val = props.modelValue !== void 0 && (props.modelValue !== null || mapNull === true) ? props.multiple === true && Array.isArray(props.modelValue) ? props.modelValue : [props.modelValue] : [];
			if (props.mapOptions === true && Array.isArray(props.options) === true) {
				const cache = props.mapOptions === true && innerValueCache !== void 0 ? innerValueCache : [];
				const values = val.map((v) => getOption(v, cache));
				return props.modelValue === null && mapNull === true ? values.filter((v) => v !== null) : values;
			}
			return val;
		});
		const innerFieldProps = computed(() => {
			const acc = {};
			fieldPropsList.forEach((key) => {
				const val = props[key];
				if (val !== void 0) acc[key] = val;
			});
			return acc;
		});
		const isOptionsDark = computed(() => props.optionsDark === null ? state.isDark.value : props.optionsDark);
		const hasValue = computed(() => fieldValueIsFilled(innerValue.value));
		const computedInputClass = computed(() => {
			let cls = "q-field__input q-placeholder col";
			if (props.hideSelected === true || innerValue.value.length === 0) return [cls, props.inputClass];
			cls += " q-field__input--padding";
			return props.inputClass === void 0 ? cls : [cls, props.inputClass];
		});
		const menuContentClass = computed(() => (props.virtualScrollHorizontal === true ? "q-virtual-scroll--horizontal" : "") + (props.popupContentClass ? " " + props.popupContentClass : ""));
		const noOptions = computed(() => virtualScrollLength.value === 0);
		const selectedString = computed(() => innerValue.value.map((opt) => getOptionLabel.value(opt)).join(", "));
		const ariaCurrentValue = computed(() => props.displayValue !== void 0 ? props.displayValue : selectedString.value);
		const needsHtmlFn = computed(() => props.optionsHtml === true ? () => true : (opt) => opt?.html === true);
		const valueAsHtml = computed(() => props.displayValueHtml === true || props.displayValue === void 0 && (props.optionsHtml === true || innerValue.value.some(needsHtmlFn.value)));
		const tabindex = computed(() => state.focused.value === true ? props.tabindex : -1);
		const comboboxAttrs = computed(() => {
			const attrs = {
				tabindex: props.tabindex,
				role: "combobox",
				"aria-label": props.label,
				"aria-readonly": props.readonly === true ? "true" : "false",
				"aria-autocomplete": props.useInput === true ? "list" : "none",
				"aria-expanded": menu.value === true ? "true" : "false",
				"aria-controls": `${state.targetUid.value}_lb`
			};
			if (optionIndex.value >= 0) attrs["aria-activedescendant"] = `${state.targetUid.value}_${optionIndex.value}`;
			return attrs;
		});
		const listboxAttrs = computed(() => ({
			id: `${state.targetUid.value}_lb`,
			role: "listbox",
			"aria-multiselectable": props.multiple === true ? "true" : "false"
		}));
		const selectedScope = computed(() => {
			return innerValue.value.map((opt, i) => ({
				index: i,
				opt,
				html: needsHtmlFn.value(opt),
				selected: true,
				removeAtIndex: removeAtIndexAndFocus,
				toggleOption,
				tabindex: tabindex.value
			}));
		});
		const optionScope = computed(() => {
			if (virtualScrollLength.value === 0) return [];
			const { from, to } = virtualScrollSliceRange.value;
			return props.options.slice(from, to).map((opt, i) => {
				const disable = isOptionDisabled.value(opt) === true;
				const active = isOptionSelected(opt) === true;
				const index = from + i;
				const itemProps = {
					clickable: true,
					active,
					activeClass: computedOptionsSelectedClass.value,
					manualFocus: true,
					focused: false,
					disable,
					tabindex: -1,
					dense: props.optionsDense,
					dark: isOptionsDark.value,
					role: "option",
					"aria-selected": active === true ? "true" : "false",
					id: `${state.targetUid.value}_${index}`,
					onClick: () => {
						toggleOption(opt);
					}
				};
				if (disable !== true) {
					optionIndex.value === index && (itemProps.focused = true);
					if ($q.platform.is.desktop === true) itemProps.onMousemove = () => {
						menu.value === true && setOptionIndex(index);
					};
				}
				return {
					index,
					opt,
					html: needsHtmlFn.value(opt),
					label: getOptionLabel.value(opt),
					selected: itemProps.active,
					focused: itemProps.focused,
					toggleOption,
					setOptionIndex,
					itemProps
				};
			});
		});
		const dropdownArrowIcon = computed(() => props.dropdownIcon !== void 0 ? props.dropdownIcon : $q.iconSet.arrow.dropdown);
		const squaredMenu = computed(() => props.optionsCover === false && props.outlined !== true && props.standout !== true && props.borderless !== true && props.rounded !== true);
		const computedOptionsSelectedClass = computed(() => props.optionsSelectedClass !== void 0 ? props.optionsSelectedClass : props.color !== void 0 ? `text-${props.color}` : "");
		const getOptionValue = computed(() => getPropValueFn(props.optionValue, "value"));
		const getOptionLabel = computed(() => getPropValueFn(props.optionLabel, "label"));
		const isOptionDisabled = computed(() => getPropValueFn(props.optionDisable, "disable"));
		const innerOptionsValue = computed(() => innerValue.value.map(getOptionValue.value));
		const inputControlEvents = computed(() => {
			const evt = {
				onInput,
				onChange: onComposition,
				onKeydown: onTargetKeydown,
				onKeyup: onTargetAutocomplete,
				onKeypress: onTargetKeypress,
				onFocus: selectInputText,
				onClick(e) {
					hasDialog === true && stop(e);
				}
			};
			evt.onCompositionstart = evt.onCompositionupdate = evt.onCompositionend = onComposition;
			return evt;
		});
		watch(innerValue, (val) => {
			innerValueCache = val;
			if (props.useInput === true && props.fillInput === true && props.multiple !== true && state.innerLoading.value !== true && (dialog.value !== true && menu.value !== true || hasValue.value !== true)) {
				userInputValue !== true && resetInputValue();
				if (dialog.value === true || menu.value === true) filter("");
			}
		}, { immediate: true });
		watch(() => props.fillInput, resetInputValue);
		watch(menu, updateMenu);
		watch(virtualScrollLength, rerenderMenu);
		function getEmittingOptionValue(opt) {
			return props.emitValue === true ? getOptionValue.value(opt) : opt;
		}
		function removeAtIndex(index) {
			if (index !== -1 && index < innerValue.value.length) if (props.multiple === true) {
				const model = props.modelValue.slice();
				emit("remove", {
					index,
					value: model.splice(index, 1)[0]
				});
				emit("update:modelValue", model);
			} else emit("update:modelValue", null);
		}
		function removeAtIndexAndFocus(index) {
			removeAtIndex(index);
			state.focus();
		}
		function add(opt, unique) {
			const val = getEmittingOptionValue(opt);
			if (props.multiple !== true) {
				props.fillInput === true && updateInputValue(getOptionLabel.value(opt), true, true);
				emit("update:modelValue", val);
				return;
			}
			if (innerValue.value.length === 0) {
				emit("add", {
					index: 0,
					value: val
				});
				emit("update:modelValue", props.multiple === true ? [val] : val);
				return;
			}
			if (unique === true && isOptionSelected(opt) === true) return;
			if (props.maxValues !== void 0 && props.modelValue.length >= props.maxValues) return;
			const model = props.modelValue.slice();
			emit("add", {
				index: model.length,
				value: val
			});
			model.push(val);
			emit("update:modelValue", model);
		}
		function toggleOption(opt, keepOpen) {
			if (state.editable.value !== true || opt === void 0 || isOptionDisabled.value(opt) === true) return;
			const optValue = getOptionValue.value(opt);
			if (props.multiple !== true) {
				if (keepOpen !== true) {
					updateInputValue(props.fillInput === true ? getOptionLabel.value(opt) : "", true, true);
					hidePopup();
				}
				targetRef.value?.focus();
				if (innerValue.value.length === 0 || isDeepEqual(getOptionValue.value(innerValue.value[0]), optValue) !== true) emit("update:modelValue", props.emitValue === true ? optValue : opt);
				return;
			}
			if (hasDialog !== true || dialogFieldFocused.value === true) state.focus();
			selectInputText();
			if (innerValue.value.length === 0) {
				const val = props.emitValue === true ? optValue : opt;
				emit("add", {
					index: 0,
					value: val
				});
				emit("update:modelValue", props.multiple === true ? [val] : val);
				return;
			}
			const model = props.modelValue.slice(), index = innerOptionsValue.value.findIndex((v) => isDeepEqual(v, optValue));
			if (index !== -1) emit("remove", {
				index,
				value: model.splice(index, 1)[0]
			});
			else {
				if (props.maxValues !== void 0 && model.length >= props.maxValues) return;
				const val = props.emitValue === true ? optValue : opt;
				emit("add", {
					index: model.length,
					value: val
				});
				model.push(val);
			}
			emit("update:modelValue", model);
		}
		function setOptionIndex(index) {
			if ($q.platform.is.desktop !== true) return;
			const val = index !== -1 && index < virtualScrollLength.value ? index : -1;
			if (optionIndex.value !== val) optionIndex.value = val;
		}
		function moveOptionSelection(offset = 1, skipInputValue) {
			if (menu.value === true) {
				let index = optionIndex.value;
				do
					index = normalizeToInterval(index + offset, -1, virtualScrollLength.value - 1);
				while (index !== -1 && index !== optionIndex.value && isOptionDisabled.value(props.options[index]) === true);
				if (optionIndex.value !== index) {
					setOptionIndex(index);
					scrollTo(index);
					if (skipInputValue !== true && props.useInput === true && props.fillInput === true) setInputValue(index >= 0 ? getOptionLabel.value(props.options[index]) : defaultInputValue, true);
				}
			}
		}
		function getOption(value, valueCache) {
			const fn = (opt) => isDeepEqual(getOptionValue.value(opt), value);
			return props.options.find(fn) || valueCache.find(fn) || value;
		}
		function isOptionSelected(opt) {
			const val = getOptionValue.value(opt);
			return innerOptionsValue.value.find((v) => isDeepEqual(v, val)) !== void 0;
		}
		function selectInputText(e) {
			if (props.useInput === true && targetRef.value !== null && (e === void 0 || targetRef.value === e.target && e.target.value === selectedString.value)) targetRef.value.select();
		}
		function onTargetKeyup(e) {
			if (isKeyCode(e, 27) === true && menu.value === true) {
				stop(e);
				hidePopup();
				resetInputValue();
			}
			emit("keyup", e);
		}
		function onTargetAutocomplete(e) {
			const { value } = e.target;
			if (e.keyCode !== void 0) {
				onTargetKeyup(e);
				return;
			}
			e.target.value = "";
			if (filterTimer !== null) {
				clearTimeout(filterTimer);
				filterTimer = null;
			}
			if (inputValueTimer !== null) {
				clearTimeout(inputValueTimer);
				inputValueTimer = null;
			}
			resetInputValue();
			if (typeof value === "string" && value.length !== 0) {
				const needle = value.toLocaleLowerCase();
				const findFn = (extractFn) => {
					const option = props.options.find((opt) => String(extractFn.value(opt)).toLocaleLowerCase() === needle);
					if (option === void 0) return false;
					if (innerValue.value.indexOf(option) === -1) toggleOption(option);
					else hidePopup();
					return true;
				};
				const fillFn = (afterFilter) => {
					if (findFn(getOptionValue) !== true && afterFilter !== true && findFn(getOptionLabel) !== true) filter(value, true, () => fillFn(true));
				};
				fillFn();
			} else state.clearValue(e);
		}
		function onTargetKeypress(e) {
			emit("keypress", e);
		}
		function onTargetKeydown(e) {
			emit("keydown", e);
			if (shouldIgnoreKey(e) === true) return;
			const newValueModeValid = inputValue.value.length !== 0 && (props.newValueMode !== void 0 || props.onNewValue !== void 0);
			const tabShouldSelect = e.shiftKey !== true && props.disableTabSelection !== true && props.multiple !== true && (optionIndex.value !== -1 || newValueModeValid === true);
			if (e.keyCode === 27) {
				prevent(e);
				return;
			}
			if (e.keyCode === 9 && tabShouldSelect === false) {
				closeMenu();
				return;
			}
			if (e.target === void 0 || e.target.id !== state.targetUid.value || state.editable.value !== true) return;
			if (e.keyCode === 40 && state.innerLoading.value !== true && menu.value === false) {
				stopAndPrevent(e);
				showPopup();
				return;
			}
			if (e.keyCode === 8 && (props.useChips === true || props.clearable === true) && props.hideSelected !== true && inputValue.value.length === 0) {
				if (props.multiple === true && Array.isArray(props.modelValue) === true) removeAtIndex(props.modelValue.length - 1);
				else if (props.multiple !== true && props.modelValue !== null) emit("update:modelValue", null);
				return;
			}
			if ((e.keyCode === 35 || e.keyCode === 36) && (typeof inputValue.value !== "string" || inputValue.value.length === 0)) {
				stopAndPrevent(e);
				optionIndex.value = -1;
				moveOptionSelection(e.keyCode === 36 ? 1 : -1, props.multiple);
			}
			if ((e.keyCode === 33 || e.keyCode === 34) && virtualScrollSliceSizeComputed.value !== void 0) {
				stopAndPrevent(e);
				optionIndex.value = Math.max(-1, Math.min(virtualScrollLength.value, optionIndex.value + (e.keyCode === 33 ? -1 : 1) * virtualScrollSliceSizeComputed.value.view));
				moveOptionSelection(e.keyCode === 33 ? 1 : -1, props.multiple);
			}
			if (e.keyCode === 38 || e.keyCode === 40) {
				stopAndPrevent(e);
				moveOptionSelection(e.keyCode === 38 ? -1 : 1, props.multiple);
			}
			const optionsLength = virtualScrollLength.value;
			if (searchBuffer === void 0 || searchBufferExp < Date.now()) searchBuffer = "";
			if (optionsLength > 0 && props.useInput !== true && e.key !== void 0 && e.key.length === 1 && e.altKey === false && e.ctrlKey === false && e.metaKey === false && (e.keyCode !== 32 || searchBuffer.length !== 0)) {
				menu.value !== true && showPopup(e);
				const char = e.key.toLocaleLowerCase(), keyRepeat = searchBuffer.length === 1 && searchBuffer[0] === char;
				searchBufferExp = Date.now() + 1500;
				if (keyRepeat === false) {
					stopAndPrevent(e);
					searchBuffer += char;
				}
				const searchRe = new RegExp("^" + searchBuffer.split("").map((l) => reEscapeList.indexOf(l) !== -1 ? "\\" + l : l).join(".*"), "i");
				let index = optionIndex.value;
				if (keyRepeat === true || index < 0 || searchRe.test(getOptionLabel.value(props.options[index])) !== true) do
					index = normalizeToInterval(index + 1, -1, optionsLength - 1);
				while (index !== optionIndex.value && (isOptionDisabled.value(props.options[index]) === true || searchRe.test(getOptionLabel.value(props.options[index])) !== true));
				if (optionIndex.value !== index) nextTick(() => {
					setOptionIndex(index);
					scrollTo(index);
					if (index >= 0 && props.useInput === true && props.fillInput === true) setInputValue(getOptionLabel.value(props.options[index]), true);
				});
				return;
			}
			if (e.keyCode !== 13 && (e.keyCode !== 32 || props.useInput === true || searchBuffer !== "") && (e.keyCode !== 9 || tabShouldSelect === false)) return;
			e.keyCode !== 9 && stopAndPrevent(e);
			if (optionIndex.value !== -1 && optionIndex.value < optionsLength) {
				toggleOption(props.options[optionIndex.value]);
				return;
			}
			if (newValueModeValid === true) {
				const done = (val, mode) => {
					if (mode) {
						if (validateNewValueMode(mode) !== true) return;
					} else mode = props.newValueMode;
					updateInputValue("", props.multiple !== true, true);
					if (val === void 0 || val === null) return;
					(mode === "toggle" ? toggleOption : add)(val, mode === "add-unique");
					if (props.multiple !== true) {
						targetRef.value?.focus();
						hidePopup();
					}
				};
				if (props.onNewValue !== void 0) emit("newValue", inputValue.value, done);
				else done(inputValue.value);
				if (props.multiple !== true) return;
			}
			if (menu.value === true) closeMenu();
			else if (state.innerLoading.value !== true) showPopup();
		}
		function getVirtualScrollEl() {
			return hasDialog === true ? menuContentRef.value : menuRef.value !== null && menuRef.value.contentEl !== null ? menuRef.value.contentEl : void 0;
		}
		function getVirtualScrollTarget() {
			return getVirtualScrollEl();
		}
		function getSelection() {
			if (props.hideSelected === true) return [];
			if (slots["selected-item"] !== void 0) return selectedScope.value.map((scope) => slots["selected-item"](scope)).slice();
			if (slots.selected !== void 0) return [].concat(slots.selected());
			if (props.useChips === true) return selectedScope.value.map((scope, i) => h(QChip_default, {
				key: "option-" + i,
				removable: state.editable.value === true && isOptionDisabled.value(scope.opt) !== true,
				dense: true,
				textColor: props.color,
				tabindex: tabindex.value,
				onRemove() {
					scope.removeAtIndex(i);
				}
			}, () => h("span", {
				class: "ellipsis",
				[scope.html === true ? "innerHTML" : "textContent"]: getOptionLabel.value(scope.opt)
			})));
			return [h("span", {
				class: "ellipsis",
				[valueAsHtml.value === true ? "innerHTML" : "textContent"]: ariaCurrentValue.value
			})];
		}
		function getAllOptions() {
			if (noOptions.value === true) return slots["no-option"] !== void 0 ? slots["no-option"]({ inputValue: inputValue.value }) : void 0;
			const fn = slots.option !== void 0 ? slots.option : (scope) => {
				return h(QItem_default, {
					key: scope.index,
					...scope.itemProps
				}, () => {
					return h(QItemSection_default, () => h(QItemLabel_default, () => h("span", { [scope.html === true ? "innerHTML" : "textContent"]: scope.label })));
				});
			};
			let options = padVirtualScroll("div", optionScope.value.map(fn));
			if (slots["before-options"] !== void 0) options = slots["before-options"]().concat(options);
			return hMergeSlot(slots["after-options"], options);
		}
		function getInput(fromDialog, isTarget) {
			const attrs = isTarget === true ? {
				...comboboxAttrs.value,
				...state.splitAttrs.attributes.value
			} : void 0;
			const data = {
				ref: isTarget === true ? targetRef : void 0,
				key: "i_t",
				class: computedInputClass.value,
				style: props.inputStyle,
				value: inputValue.value !== void 0 ? inputValue.value : "",
				type: "search",
				...attrs,
				id: isTarget === true ? state.targetUid.value : void 0,
				maxlength: props.maxlength,
				autocomplete: props.autocomplete,
				"data-autofocus": fromDialog === true || props.autofocus === true || void 0,
				disabled: props.disable === true,
				readonly: props.readonly === true,
				...inputControlEvents.value
			};
			if (fromDialog !== true && hasDialog === true) if (Array.isArray(data.class) === true) data.class = [...data.class, "no-pointer-events"];
			else data.class += " no-pointer-events";
			return h("input", data);
		}
		function onInput(e) {
			if (filterTimer !== null) {
				clearTimeout(filterTimer);
				filterTimer = null;
			}
			if (inputValueTimer !== null) {
				clearTimeout(inputValueTimer);
				inputValueTimer = null;
			}
			if (e && e.target && e.target.qComposing === true) return;
			setInputValue(e.target.value || "");
			userInputValue = true;
			defaultInputValue = inputValue.value;
			if (state.focused.value !== true && (hasDialog !== true || dialogFieldFocused.value === true)) state.focus();
			if (props.onFilter !== void 0) filterTimer = setTimeout(() => {
				filterTimer = null;
				filter(inputValue.value);
			}, props.inputDebounce);
		}
		function setInputValue(val, emitImmediately) {
			if (inputValue.value !== val) {
				inputValue.value = val;
				if (emitImmediately === true || props.inputDebounce === 0 || props.inputDebounce === "0") emit("inputValue", val);
				else inputValueTimer = setTimeout(() => {
					inputValueTimer = null;
					emit("inputValue", val);
				}, props.inputDebounce);
			}
		}
		function updateInputValue(val, noFiltering, internal) {
			userInputValue = internal !== true;
			if (props.useInput === true) {
				setInputValue(val, true);
				if (noFiltering === true || internal !== true) defaultInputValue = val;
				noFiltering !== true && filter(val);
			}
		}
		function filter(val, keepClosed, afterUpdateFn) {
			if (props.onFilter === void 0 || keepClosed !== true && state.focused.value !== true) return;
			if (state.innerLoading.value === true) emit("filterAbort");
			else {
				state.innerLoading.value = true;
				innerLoadingIndicator.value = true;
			}
			if (val !== "" && props.multiple !== true && innerValue.value.length !== 0 && userInputValue !== true && val === getOptionLabel.value(innerValue.value[0])) val = "";
			const localFilterId = setTimeout(() => {
				menu.value === true && (menu.value = false);
			}, 10);
			filterId !== null && clearTimeout(filterId);
			filterId = localFilterId;
			emit("filter", val, (fn, afterFn) => {
				if ((keepClosed === true || state.focused.value === true) && filterId === localFilterId) {
					clearTimeout(filterId);
					typeof fn === "function" && fn();
					innerLoadingIndicator.value = false;
					nextTick(() => {
						state.innerLoading.value = false;
						if (state.editable.value === true) if (keepClosed === true) menu.value === true && hidePopup();
						else if (menu.value === true) updateMenu(true);
						else menu.value = true;
						typeof afterFn === "function" && nextTick(() => {
							afterFn(proxy);
						});
						typeof afterUpdateFn === "function" && nextTick(() => {
							afterUpdateFn(proxy);
						});
					});
				}
			}, () => {
				if (state.focused.value === true && filterId === localFilterId) {
					clearTimeout(filterId);
					state.innerLoading.value = false;
					innerLoadingIndicator.value = false;
				}
				menu.value === true && (menu.value = false);
			});
		}
		function getMenu() {
			return h(QMenu_default, {
				ref: menuRef,
				class: menuContentClass.value,
				style: props.popupContentStyle,
				modelValue: menu.value,
				fit: props.menuShrink !== true,
				cover: props.optionsCover === true && noOptions.value !== true && props.useInput !== true,
				anchor: props.menuAnchor,
				self: props.menuSelf,
				offset: props.menuOffset,
				dark: isOptionsDark.value,
				noParentEvent: true,
				noRefocus: true,
				noFocus: true,
				noRouteDismiss: props.popupNoRouteDismiss,
				square: squaredMenu.value,
				transitionShow: props.transitionShow,
				transitionHide: props.transitionHide,
				transitionDuration: props.transitionDuration,
				separateClosePopup: true,
				...listboxAttrs.value,
				onScrollPassive: onVirtualScrollEvt,
				onBeforeShow: onControlPopupShow,
				onBeforeHide: onMenuBeforeHide,
				onShow: onMenuShow
			}, getAllOptions);
		}
		function onMenuBeforeHide(e) {
			onControlPopupHide(e);
			closeMenu();
		}
		function onMenuShow() {
			setVirtualScrollSize();
		}
		function onDialogFieldFocus(e) {
			stop(e);
			targetRef.value?.focus();
			dialogFieldFocused.value = true;
			window.scrollTo(window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, 0);
		}
		function onDialogFieldBlur(e) {
			stop(e);
			nextTick(() => {
				dialogFieldFocused.value = false;
			});
		}
		function getDialog() {
			const content = [h(QField_default, {
				class: `col-auto ${state.fieldClass.value}`,
				...innerFieldProps.value,
				for: state.targetUid.value,
				dark: isOptionsDark.value,
				square: true,
				loading: innerLoadingIndicator.value,
				itemAligned: false,
				filled: true,
				stackLabel: inputValue.value.length !== 0,
				...state.splitAttrs.listeners.value,
				onFocus: onDialogFieldFocus,
				onBlur: onDialogFieldBlur
			}, {
				...slots,
				rawControl: () => state.getControl(true),
				before: void 0,
				after: void 0
			})];
			menu.value === true && content.push(h("div", {
				ref: menuContentRef,
				class: menuContentClass.value + " scroll",
				style: props.popupContentStyle,
				...listboxAttrs.value,
				onClick: prevent,
				onScrollPassive: onVirtualScrollEvt
			}, getAllOptions()));
			return h(QDialog_default, {
				ref: dialogRef,
				modelValue: dialog.value,
				position: props.useInput === true ? "top" : void 0,
				transitionShow: transitionShowComputed,
				transitionHide: props.transitionHide,
				transitionDuration: props.transitionDuration,
				noRouteDismiss: props.popupNoRouteDismiss,
				onBeforeShow: onControlPopupShow,
				onBeforeHide: onDialogBeforeHide,
				onHide: onDialogHide,
				onShow: onDialogShow
			}, () => h("div", { class: "q-select__dialog" + (isOptionsDark.value === true ? " q-select__dialog--dark q-dark" : "") + (dialogFieldFocused.value === true ? " q-select__dialog--focused" : "") }, content));
		}
		function onDialogBeforeHide(e) {
			onControlPopupHide(e);
			if (dialogRef.value !== null) dialogRef.value.__updateRefocusTarget(state.rootRef.value.querySelector(".q-field__native > [tabindex]:last-child"));
			state.focused.value = false;
		}
		function onDialogHide(e) {
			hidePopup();
			state.focused.value === false && emit("blur", e);
			resetInputValue();
		}
		function onDialogShow() {
			const el = document.activeElement;
			if ((el === null || el.id !== state.targetUid.value) && targetRef.value !== null && targetRef.value !== el) targetRef.value.focus();
			setVirtualScrollSize();
		}
		function closeMenu() {
			if (dialog.value === true) return;
			optionIndex.value = -1;
			if (menu.value === true) menu.value = false;
			if (state.focused.value === false) {
				if (filterId !== null) {
					clearTimeout(filterId);
					filterId = null;
				}
				if (state.innerLoading.value === true) {
					emit("filterAbort");
					state.innerLoading.value = false;
					innerLoadingIndicator.value = false;
				}
			}
		}
		function showPopup(e) {
			if (state.editable.value !== true) return;
			if (hasDialog === true) {
				state.onControlFocusin(e);
				dialog.value = true;
				nextTick(() => {
					state.focus();
				});
			} else state.focus();
			if (props.onFilter !== void 0) filter(inputValue.value);
			else if (noOptions.value !== true || slots["no-option"] !== void 0) menu.value = true;
		}
		function hidePopup() {
			dialog.value = false;
			closeMenu();
		}
		function resetInputValue() {
			props.useInput === true && updateInputValue(props.multiple !== true && props.fillInput === true && innerValue.value.length !== 0 ? getOptionLabel.value(innerValue.value[0]) || "" : "", true, true);
		}
		function updateMenu(show) {
			let optionIndex = -1;
			if (show === true) {
				if (innerValue.value.length !== 0) {
					const val = getOptionValue.value(innerValue.value[0]);
					optionIndex = props.options.findIndex((v) => isDeepEqual(getOptionValue.value(v), val));
				}
				localResetVirtualScroll(optionIndex);
			}
			setOptionIndex(optionIndex);
		}
		function rerenderMenu(newLength, oldLength) {
			if (menu.value === true && state.innerLoading.value === false) {
				localResetVirtualScroll(-1, true);
				nextTick(() => {
					if (menu.value === true && state.innerLoading.value === false) if (newLength > oldLength) localResetVirtualScroll();
					else updateMenu(true);
				});
			}
		}
		function updateMenuPosition() {
			if (dialog.value === false && menuRef.value !== null) menuRef.value.updatePosition();
		}
		function onControlPopupShow(e) {
			e !== void 0 && stop(e);
			emit("popupShow", e);
			state.hasPopupOpen = true;
			state.onControlFocusin(e);
		}
		function onControlPopupHide(e) {
			e !== void 0 && stop(e);
			emit("popupHide", e);
			state.hasPopupOpen = false;
			state.onControlFocusout(e);
		}
		function updatePreState() {
			hasDialog = $q.platform.is.mobile !== true && props.behavior !== "dialog" ? false : props.behavior !== "menu" && (props.useInput === true ? slots["no-option"] !== void 0 || props.onFilter !== void 0 || noOptions.value === false : true);
			transitionShowComputed = $q.platform.is.ios === true && hasDialog === true && props.useInput === true ? "fade" : props.transitionShow;
		}
		onBeforeUpdate(updatePreState);
		onUpdated(updateMenuPosition);
		updatePreState();
		onBeforeUnmount(() => {
			filterTimer !== null && clearTimeout(filterTimer);
			inputValueTimer !== null && clearTimeout(inputValueTimer);
		});
		Object.assign(proxy, {
			showPopup,
			hidePopup,
			removeAtIndex,
			add,
			toggleOption,
			getOptionIndex: () => optionIndex.value,
			setOptionIndex,
			moveOptionSelection,
			filter,
			updateMenuPosition,
			updateInputValue,
			isOptionSelected,
			getEmittingOptionValue,
			isOptionDisabled: (...args) => isOptionDisabled.value.apply(null, args) === true,
			getOptionValue: (...args) => getOptionValue.value.apply(null, args),
			getOptionLabel: (...args) => getOptionLabel.value.apply(null, args)
		});
		Object.assign(state, {
			innerValue,
			fieldClass: computed(() => `q-select q-field--auto-height q-select--with${props.useInput !== true ? "out" : ""}-input q-select--with${props.useChips !== true ? "out" : ""}-chips q-select--${props.multiple === true ? "multiple" : "single"}`),
			inputRef,
			targetRef,
			hasValue,
			showPopup,
			floatingLabel: computed(() => props.hideSelected !== true && hasValue.value === true || typeof inputValue.value === "number" || inputValue.value.length !== 0 || fieldValueIsFilled(props.displayValue)),
			getControlChild: () => {
				if (state.editable.value !== false && (dialog.value === true || noOptions.value !== true || slots["no-option"] !== void 0)) return hasDialog === true ? getDialog() : getMenu();
				else if (state.hasPopupOpen === true) state.hasPopupOpen = false;
			},
			controlEvents: {
				onFocusin(e) {
					state.onControlFocusin(e);
				},
				onFocusout(e) {
					state.onControlFocusout(e, () => {
						resetInputValue();
						closeMenu();
					});
				},
				onClick(e) {
					prevent(e);
					if (hasDialog !== true && menu.value === true) {
						closeMenu();
						targetRef.value?.focus();
						return;
					}
					showPopup(e);
				}
			},
			getControl: (fromDialog) => {
				const child = getSelection();
				const isTarget = fromDialog === true || dialog.value !== true || hasDialog !== true;
				if (props.useInput === true) child.push(getInput(fromDialog, isTarget));
				else if (state.editable.value === true) {
					const attrs = isTarget === true ? comboboxAttrs.value : void 0;
					child.push(h("input", {
						ref: isTarget === true ? targetRef : void 0,
						key: "d_t",
						class: "q-select__focus-target",
						id: isTarget === true ? state.targetUid.value : void 0,
						value: ariaCurrentValue.value,
						readonly: true,
						"data-autofocus": fromDialog === true || props.autofocus === true || void 0,
						...attrs,
						onKeydown: onTargetKeydown,
						onKeyup: onTargetKeyup,
						onKeypress: onTargetKeypress
					}));
					if (isTarget === true && typeof props.autocomplete === "string" && props.autocomplete.length !== 0) child.push(h("input", {
						class: "q-select__autocomplete-input",
						autocomplete: props.autocomplete,
						tabindex: -1,
						onKeyup: onTargetAutocomplete
					}));
				}
				if (nameProp.value !== void 0 && props.disable !== true && innerOptionsValue.value.length !== 0) {
					const opts = innerOptionsValue.value.map((value) => h("option", {
						value,
						selected: true
					}));
					child.push(h("select", {
						class: "hidden",
						name: nameProp.value,
						multiple: props.multiple
					}, opts));
				}
				return h("div", {
					class: "q-field__native row items-center",
					...props.useInput === true || isTarget !== true ? void 0 : state.splitAttrs.attributes.value,
					...state.splitAttrs.listeners.value
				}, child);
			},
			getInnerAppend: () => props.loading !== true && innerLoadingIndicator.value !== true && props.hideDropdownIcon !== true ? [h(QIcon_default, {
				class: "q-select__dropdown-icon" + (menu.value === true ? " rotate-180" : ""),
				name: dropdownArrowIcon.value
			})] : null
		});
		return use_field_default(state);
	}
});
//#endregion
//#region src/types/index.ts
var SUPPORTED_LANGUAGES = [
	{
		value: "af",
		label: "Afrikaans",
		nativeLabel: "Afrikaans"
	},
	{
		value: "sq",
		label: "Albanian",
		nativeLabel: "Shqip"
	},
	{
		value: "ar",
		label: "Arabic",
		nativeLabel: "العربية"
	},
	{
		value: "az",
		label: "Azerbaijani",
		nativeLabel: "Azərbaycan dili"
	},
	{
		value: "eu",
		label: "Basque",
		nativeLabel: "Euskara"
	},
	{
		value: "be",
		label: "Belarusian",
		nativeLabel: "Беларуская"
	},
	{
		value: "bn",
		label: "Bengali",
		nativeLabel: "বাংলা"
	},
	{
		value: "bs",
		label: "Bosnian",
		nativeLabel: "Bosanski"
	},
	{
		value: "bg",
		label: "Bulgarian",
		nativeLabel: "Български"
	},
	{
		value: "ca",
		label: "Catalan",
		nativeLabel: "Català"
	},
	{
		value: "zh",
		label: "Chinese",
		nativeLabel: "中文"
	},
	{
		value: "hr",
		label: "Croatian",
		nativeLabel: "Hrvatski"
	},
	{
		value: "cs",
		label: "Czech",
		nativeLabel: "Čeština"
	},
	{
		value: "da",
		label: "Danish",
		nativeLabel: "Dansk"
	},
	{
		value: "nl",
		label: "Dutch",
		nativeLabel: "Nederlands"
	},
	{
		value: "en",
		label: "English",
		nativeLabel: "English"
	},
	{
		value: "et",
		label: "Estonian",
		nativeLabel: "Eesti"
	},
	{
		value: "fi",
		label: "Finnish",
		nativeLabel: "Suomi"
	},
	{
		value: "fr",
		label: "French",
		nativeLabel: "Français"
	},
	{
		value: "gl",
		label: "Galician",
		nativeLabel: "Galego"
	},
	{
		value: "de",
		label: "German",
		nativeLabel: "Deutsch"
	},
	{
		value: "el",
		label: "Greek",
		nativeLabel: "Ελληνικά"
	},
	{
		value: "gu",
		label: "Gujarati",
		nativeLabel: "ગુજરાતી"
	},
	{
		value: "he",
		label: "Hebrew",
		nativeLabel: "עברית"
	},
	{
		value: "hi",
		label: "Hindi",
		nativeLabel: "हिन्दी"
	},
	{
		value: "hu",
		label: "Hungarian",
		nativeLabel: "Magyar"
	},
	{
		value: "id",
		label: "Indonesian",
		nativeLabel: "Bahasa Indonesia"
	},
	{
		value: "it",
		label: "Italian",
		nativeLabel: "Italiano"
	},
	{
		value: "ja",
		label: "Japanese",
		nativeLabel: "日本語"
	},
	{
		value: "kn",
		label: "Kannada",
		nativeLabel: "ಕನ್ನಡ"
	},
	{
		value: "kk",
		label: "Kazakh",
		nativeLabel: "Қазақ тілі"
	},
	{
		value: "ko",
		label: "Korean",
		nativeLabel: "한국어"
	},
	{
		value: "lv",
		label: "Latvian",
		nativeLabel: "Latviešu"
	},
	{
		value: "lt",
		label: "Lithuanian",
		nativeLabel: "Lietuvių"
	},
	{
		value: "mk",
		label: "Macedonian",
		nativeLabel: "Македонски"
	},
	{
		value: "ms",
		label: "Malay",
		nativeLabel: "Bahasa Melayu"
	},
	{
		value: "ml",
		label: "Malayalam",
		nativeLabel: "മലയാളം"
	},
	{
		value: "mr",
		label: "Marathi",
		nativeLabel: "मराठी"
	},
	{
		value: "no",
		label: "Norwegian",
		nativeLabel: "Norsk"
	},
	{
		value: "fa",
		label: "Persian",
		nativeLabel: "فارسی"
	},
	{
		value: "pl",
		label: "Polish",
		nativeLabel: "Polski"
	},
	{
		value: "pt",
		label: "Portuguese",
		nativeLabel: "Português"
	},
	{
		value: "pa",
		label: "Punjabi",
		nativeLabel: "ਪੰਜਾਬੀ"
	},
	{
		value: "ro",
		label: "Romanian",
		nativeLabel: "Română"
	},
	{
		value: "ru",
		label: "Russian",
		nativeLabel: "Русский"
	},
	{
		value: "sr",
		label: "Serbian",
		nativeLabel: "Српски"
	},
	{
		value: "sk",
		label: "Slovak",
		nativeLabel: "Slovenčina"
	},
	{
		value: "sl",
		label: "Slovenian",
		nativeLabel: "Slovenščina"
	},
	{
		value: "es",
		label: "Spanish",
		nativeLabel: "Español"
	},
	{
		value: "sw",
		label: "Swahili",
		nativeLabel: "Kiswahili"
	},
	{
		value: "sv",
		label: "Swedish",
		nativeLabel: "Svenska"
	},
	{
		value: "tl",
		label: "Tagalog",
		nativeLabel: "Tagalog"
	},
	{
		value: "ta",
		label: "Tamil",
		nativeLabel: "தமிழ்"
	},
	{
		value: "te",
		label: "Telugu",
		nativeLabel: "తెలుగు"
	},
	{
		value: "th",
		label: "Thai",
		nativeLabel: "ไทย"
	},
	{
		value: "tr",
		label: "Turkish",
		nativeLabel: "Türkçe"
	},
	{
		value: "uk",
		label: "Ukrainian",
		nativeLabel: "Українська"
	},
	{
		value: "ur",
		label: "Urdu",
		nativeLabel: "اردو"
	},
	{
		value: "vi",
		label: "Vietnamese",
		nativeLabel: "Tiếng Việt"
	},
	{
		value: "cy",
		label: "Welsh",
		nativeLabel: "Cymraeg"
	}
];
var TRANSLATION_FONT_SIZES = [
	"small",
	"medium",
	"large"
];
var TTS_VOICES = [
	"alloy",
	"ash",
	"ballad",
	"coral",
	"echo",
	"fable",
	"nova",
	"onyx",
	"sage",
	"shimmer",
	"verse",
	"marin",
	"cedar"
];
var TTS_MODELS = [
	"gpt-4o-mini-tts",
	"tts-1",
	"tts-1-hd"
];
function isTheirLanguage(value) {
	return value === "none" || isSupportedLanguage(value);
}
var SUPPORTED_LANGUAGE_VALUES = new Set(SUPPORTED_LANGUAGES.map((language) => language.value));
var TRANSLATION_FONT_SIZE_VALUES = new Set(TRANSLATION_FONT_SIZES);
var TTS_VOICE_VALUES = new Set(TTS_VOICES);
var TTS_MODEL_VALUES = new Set(TTS_MODELS);
function isSupportedLanguage(value) {
	return typeof value === "string" && SUPPORTED_LANGUAGE_VALUES.has(value);
}
function isTranslationFontSize(value) {
	return typeof value === "string" && TRANSLATION_FONT_SIZE_VALUES.has(value);
}
function isTTSVoice(value) {
	return typeof value === "string" && TTS_VOICE_VALUES.has(value);
}
function isTTSModel(value) {
	return typeof value === "string" && TTS_MODEL_VALUES.has(value);
}
var DEFAULT_SETTINGS = {
	apiKey: "",
	targetLanguage: "vi",
	theirLanguage: "en",
	microphoneEnabled: false,
	speakerNames: [],
	translationFontSize: "medium",
	narrationEnabled: false,
	narrateMyVoice: false,
	sendMyTranslationViaChat: false,
	narrateAllSpeakers: false,
	openaiApiKey: "",
	openaiAssistantModel: "gpt-4.1-mini",
	openaiAssistantExplainPrompt: ["Explain the focus sentence."].join(" "),
	openaiAssistantQAPrompt: ["Give me 3 possible answers to the focus question"].join(" "),
	openaiAssistantChatPrompt: [
		"You are my inline conversation assistant for a live translation session.",
		"Answer the user's question based on the full transcript context provided.",
		"Use web search tool when useful for factual, time-sensitive, or domain-specific details.",
		"Be concise and helpful. Respond in \"{{targetLanguage}}\"."
	].join(" "),
	ttsVoice: "coral",
	ttsModel: "gpt-4o-mini-tts",
	voiceSpeed: 100,
	voiceVolume: 100,
	originalVolume: 10,
	autoSyncSpeed: true,
	ttsProvider: "openai",
	googleVoiceId: "en"
};
var EXTENSION_HOMEPAGE = "https://translate.ezitech.io";
function normalizeSpeakerNames(speakerNames, minimumSlots = 10) {
	const safeMinimum = Number.isFinite(minimumSlots) ? Math.max(0, Math.floor(minimumSlots)) : 10;
	const normalized = Array.isArray(speakerNames) ? speakerNames.map((name) => typeof name === "string" ? name.trim() : "") : [];
	while (normalized.length < safeMinimum) normalized.push("");
	return normalized;
}
function extractSpeakerIndex(speakerId) {
	if (!speakerId) return null;
	const trimmed = speakerId.trim();
	if (!trimmed) return null;
	const match = trimmed.match(/(\d+)/);
	if (!match) return null;
	const parsed = Number.parseInt(match[1] ?? "", 10);
	if (!Number.isFinite(parsed) || parsed <= 0) return null;
	return parsed;
}
function resolveSpeakerLabel(speakerId, speakerNames, speakerPrefixLabel, fallbackLabel) {
	const speakerIndex = extractSpeakerIndex(speakerId);
	if (speakerIndex !== null) {
		const customName = speakerNames[speakerIndex - 1]?.trim();
		if (customName) return customName;
		return `${speakerPrefixLabel} ${speakerIndex}`;
	}
	return fallbackLabel;
}
//#endregion
//#region src/stores/settings-store.ts
var STORAGE_KEY = "translatorSettings";
var useSettingsStore = defineStore("settings", () => {
	const apiKey = ref(DEFAULT_SETTINGS.apiKey);
	const targetLanguage = ref(DEFAULT_SETTINGS.targetLanguage);
	const theirLanguage = ref(DEFAULT_SETTINGS.theirLanguage ?? "en");
	const microphoneEnabled = ref(DEFAULT_SETTINGS.microphoneEnabled ?? false);
	const speakerNames = ref(normalizeSpeakerNames(DEFAULT_SETTINGS.speakerNames));
	const translationFontSize = ref(DEFAULT_SETTINGS.translationFontSize ?? "medium");
	const narrationEnabled = ref(DEFAULT_SETTINGS.narrationEnabled ?? false);
	const narrateMyVoice = ref(DEFAULT_SETTINGS.narrateMyVoice ?? false);
	const sendMyTranslationViaChat = ref(DEFAULT_SETTINGS.sendMyTranslationViaChat ?? false);
	const narrateAllSpeakers = ref(DEFAULT_SETTINGS.narrateAllSpeakers ?? false);
	const openaiApiKey = ref(DEFAULT_SETTINGS.openaiApiKey ?? "");
	const openaiAssistantModel = ref(DEFAULT_SETTINGS.openaiAssistantModel ?? "gpt-4.1-mini");
	const openaiAssistantChatPrompt = ref(DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "");
	const ttsVoice = ref(DEFAULT_SETTINGS.ttsVoice ?? "coral");
	const ttsModel = ref(DEFAULT_SETTINGS.ttsModel ?? "gpt-4o-mini-tts");
	const voiceSpeed = ref(DEFAULT_SETTINGS.voiceSpeed ?? 50);
	const voiceVolume = ref(DEFAULT_SETTINGS.voiceVolume ?? 100);
	const originalVolume = ref(DEFAULT_SETTINGS.originalVolume ?? 30);
	const autoSyncSpeed = ref(DEFAULT_SETTINGS.autoSyncSpeed ?? true);
	const ttsProvider = ref(DEFAULT_SETTINGS.ttsProvider ?? "openai");
	const googleVoiceId = ref(DEFAULT_SETTINGS.googleVoiceId ?? "en");
	const isLoaded = ref(false);
	async function loadSettings() {
		try {
			const stored = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
			if (stored) {
				apiKey.value = stored.apiKey ?? DEFAULT_SETTINGS.apiKey;
				targetLanguage.value = isSupportedLanguage(stored.targetLanguage) ? stored.targetLanguage : DEFAULT_SETTINGS.targetLanguage;
				theirLanguage.value = isTheirLanguage(stored.theirLanguage) ? stored.theirLanguage : DEFAULT_SETTINGS.theirLanguage ?? "en";
				microphoneEnabled.value = stored.microphoneEnabled ?? DEFAULT_SETTINGS.microphoneEnabled ?? false;
				speakerNames.value = normalizeSpeakerNames(stored.speakerNames);
				translationFontSize.value = isTranslationFontSize(stored.translationFontSize) ? stored.translationFontSize : DEFAULT_SETTINGS.translationFontSize ?? "medium";
				narrationEnabled.value = stored.narrationEnabled ?? DEFAULT_SETTINGS.narrationEnabled ?? false;
				narrateMyVoice.value = stored.narrateMyVoice ?? DEFAULT_SETTINGS.narrateMyVoice ?? false;
				sendMyTranslationViaChat.value = stored.sendMyTranslationViaChat ?? DEFAULT_SETTINGS.sendMyTranslationViaChat ?? false;
				narrateAllSpeakers.value = stored.narrateAllSpeakers ?? DEFAULT_SETTINGS.narrateAllSpeakers ?? false;
				openaiApiKey.value = stored.openaiApiKey ?? DEFAULT_SETTINGS.openaiApiKey ?? "";
				openaiAssistantModel.value = stored.openaiAssistantModel ?? DEFAULT_SETTINGS.openaiAssistantModel ?? "gpt-4.1-mini";
				openaiAssistantChatPrompt.value = stored.openaiAssistantChatPrompt ?? DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "";
				ttsVoice.value = isTTSVoice(stored.ttsVoice) ? stored.ttsVoice : DEFAULT_SETTINGS.ttsVoice ?? "coral";
				ttsModel.value = isTTSModel(stored.ttsModel) ? stored.ttsModel : DEFAULT_SETTINGS.ttsModel ?? "gpt-4o-mini-tts";
				voiceSpeed.value = typeof stored.voiceSpeed === "number" ? stored.voiceSpeed : DEFAULT_SETTINGS.voiceSpeed ?? 50;
				voiceVolume.value = typeof stored.voiceVolume === "number" ? stored.voiceVolume : DEFAULT_SETTINGS.voiceVolume ?? 100;
				originalVolume.value = typeof stored.originalVolume === "number" ? stored.originalVolume : DEFAULT_SETTINGS.originalVolume ?? 30;
				autoSyncSpeed.value = stored.autoSyncSpeed ?? DEFAULT_SETTINGS.autoSyncSpeed ?? true;
				ttsProvider.value = stored.ttsProvider === "google" ? "google" : "openai";
				googleVoiceId.value = stored.googleVoiceId ?? DEFAULT_SETTINGS.googleVoiceId ?? "en";
			}
		} catch {} finally {
			isLoaded.value = true;
		}
	}
	async function saveSettings() {
		try {
			const settings = {
				apiKey: apiKey.value,
				targetLanguage: targetLanguage.value,
				theirLanguage: theirLanguage.value,
				microphoneEnabled: microphoneEnabled.value,
				speakerNames: [...speakerNames.value],
				translationFontSize: translationFontSize.value,
				narrationEnabled: narrationEnabled.value,
				narrateMyVoice: narrateMyVoice.value,
				sendMyTranslationViaChat: sendMyTranslationViaChat.value,
				narrateAllSpeakers: narrateAllSpeakers.value,
				openaiApiKey: openaiApiKey.value,
				openaiAssistantModel: openaiAssistantModel.value,
				openaiAssistantChatPrompt: openaiAssistantChatPrompt.value,
				ttsVoice: ttsVoice.value,
				ttsModel: ttsModel.value,
				voiceSpeed: voiceSpeed.value,
				voiceVolume: voiceVolume.value,
				originalVolume: originalVolume.value,
				autoSyncSpeed: autoSyncSpeed.value,
				ttsProvider: ttsProvider.value,
				googleVoiceId: googleVoiceId.value
			};
			await chrome.storage.local.set({ [STORAGE_KEY]: settings });
		} catch {}
	}
	let debounceTimer = null;
	function debouncedSave() {
		if (debounceTimer) clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => {
			saveSettings();
		}, 500);
	}
	watch([
		apiKey,
		targetLanguage,
		theirLanguage,
		microphoneEnabled,
		translationFontSize,
		narrationEnabled,
		narrateMyVoice,
		sendMyTranslationViaChat,
		narrateAllSpeakers,
		openaiApiKey,
		openaiAssistantModel,
		openaiAssistantChatPrompt,
		ttsVoice,
		ttsModel,
		voiceSpeed,
		voiceVolume,
		originalVolume,
		autoSyncSpeed,
		ttsProvider,
		googleVoiceId
	], () => {
		if (isLoaded.value) debouncedSave();
	});
	function setSpeakerNames(names) {
		speakerNames.value = normalizeSpeakerNames(names, Math.max(names.length, 10));
	}
	return {
		apiKey,
		targetLanguage,
		theirLanguage,
		microphoneEnabled,
		speakerNames,
		translationFontSize,
		narrationEnabled,
		narrateMyVoice,
		sendMyTranslationViaChat,
		narrateAllSpeakers,
		openaiApiKey,
		openaiAssistantModel,
		openaiAssistantChatPrompt,
		ttsVoice,
		ttsModel,
		voiceSpeed,
		voiceVolume,
		originalVolume,
		autoSyncSpeed,
		ttsProvider,
		googleVoiceId,
		isLoaded,
		setSpeakerNames,
		loadSettings,
		saveSettings
	};
});
//#endregion
//#region src/services/license-api-client.ts
var API_BASE_URL = "https://translate-api.ezitech.io";
var LicenseApiError = class extends Error {
	constructor(errorCode, message, statusCode) {
		super(message);
		this.errorCode = errorCode;
		this.statusCode = statusCode;
		this.name = "LicenseApiError";
	}
};
async function handleResponse(response) {
	if (response.ok) return response.json();
	let errorData;
	try {
		errorData = await response.json();
	} catch {
		throw new LicenseApiError("UNKNOWN_ERROR", `Server error (${response.status})`, response.status);
	}
	throw new LicenseApiError(errorData.error || "UNKNOWN_ERROR", errorData.message || `Server error (${response.status})`, response.status);
}
async function activateLicense(key, deviceLabel) {
	return handleResponse(await fetch(`${API_BASE_URL}/api/license/activate`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"Accept": "application/json"
		},
		body: JSON.stringify({
			key,
			device_label: deviceLabel
		})
	}));
}
async function forceActivateLicense(key, deviceLabel) {
	return handleResponse(await fetch(`${API_BASE_URL}/api/license/force-activate`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"Accept": "application/json"
		},
		body: JSON.stringify({
			key,
			device_label: deviceLabel
		})
	}));
}
async function verifyLicense(accessToken) {
	return handleResponse(await fetch(`${API_BASE_URL}/api/license/verify`, {
		method: "GET",
		headers: {
			"Accept": "application/json",
			"Authorization": `Bearer ${accessToken}`
		}
	}));
}
//#endregion
//#region src/stores/auth-store.ts
var AUTH_STORAGE_KEY = "licenseAuth";
var useAuthStore = defineStore("auth", () => {
	const accessToken = ref("");
	const activationId = ref("");
	const expiresAt = ref("");
	const customerEmail = ref("");
	const customerName = ref("");
	const isLoaded = ref(false);
	const isLicensed = computed(() => accessToken.value.length > 0);
	const isExpired = computed(() => {
		if (!expiresAt.value) return false;
		return new Date(expiresAt.value) < /* @__PURE__ */ new Date();
	});
	const licenseStatus = computed(() => {
		if (!isLicensed.value) return "unlicensed";
		if (isExpired.value) return "expired";
		return "active";
	});
	const hasActiveLicense = computed(() => licenseStatus.value === "active");
	async function loadAuth() {
		try {
			const stored = (await chrome.storage.local.get(AUTH_STORAGE_KEY))[AUTH_STORAGE_KEY];
			if (stored) {
				accessToken.value = stored.accessToken ?? "";
				activationId.value = stored.activationId ?? "";
				expiresAt.value = stored.expiresAt ?? "";
				customerEmail.value = stored.customerEmail ?? "";
				customerName.value = stored.customerName ?? "";
			}
		} catch {} finally {
			isLoaded.value = true;
		}
	}
	async function saveAuth(auth) {
		accessToken.value = auth.accessToken;
		activationId.value = auth.activationId;
		expiresAt.value = auth.expiresAt;
		customerEmail.value = auth.customerEmail;
		customerName.value = auth.customerName;
		try {
			await chrome.storage.local.set({ [AUTH_STORAGE_KEY]: auth });
		} catch {}
	}
	async function clearAuth() {
		accessToken.value = "";
		activationId.value = "";
		expiresAt.value = "";
		customerEmail.value = "";
		customerName.value = "";
		try {
			await chrome.storage.local.remove(AUTH_STORAGE_KEY);
		} catch {}
	}
	async function revalidateFromStorage() {
		try {
			const stored = (await chrome.storage.local.get(AUTH_STORAGE_KEY))[AUTH_STORAGE_KEY];
			if (!stored?.accessToken) return false;
			if (stored.expiresAt && new Date(stored.expiresAt) < /* @__PURE__ */ new Date()) return false;
			accessToken.value = stored.accessToken;
			activationId.value = stored.activationId ?? "";
			expiresAt.value = stored.expiresAt ?? "";
			customerEmail.value = stored.customerEmail ?? "";
			customerName.value = stored.customerName ?? "";
			return true;
		} catch {
			return false;
		}
	}
	async function verifyWithServer() {
		if (!accessToken.value) return {
			valid: false,
			error: "No token stored"
		};
		try {
			await verifyLicense(accessToken.value);
			return { valid: true };
		} catch (err) {
			await clearAuth();
			return {
				valid: false,
				error: err instanceof LicenseApiError ? err.message : "License verification failed"
			};
		}
	}
	async function canAccessPremiumFeature() {
		if (!isLoaded.value) await loadAuth();
		return hasActiveLicense.value;
	}
	return {
		accessToken,
		activationId,
		expiresAt,
		customerEmail,
		customerName,
		isLoaded,
		isLicensed,
		isExpired,
		licenseStatus,
		hasActiveLicense,
		loadAuth,
		saveAuth,
		clearAuth,
		revalidateFromStorage,
		verifyWithServer,
		canAccessPremiumFeature
	};
});
//#endregion
export { QItemSection_default as A, QBanner_default as C, use_dark_default as D, useDarkProps as E, QBadge_default as O, use_id_default as S, QItem_default as T, QCardSection_default as _, useSettingsStore as a, useFormInject as b, DEFAULT_SETTINGS as c, TTS_VOICES as d, QSelect_default as f, QCardActions_default as g, QCard_default as h, forceActivateLicense as i, QItemLabel_default as k, EXTENSION_HOMEPAGE as l, QDialog_default as m, LicenseApiError as n, normalizeSpeakerNames as o, between as p, activateLicense as r, resolveSpeakerLabel as s, useAuthStore as t, SUPPORTED_LANGUAGES as u, QInput_default as v, QSeparator_default as w, useFormProps as x, useFormAttrs as y };
