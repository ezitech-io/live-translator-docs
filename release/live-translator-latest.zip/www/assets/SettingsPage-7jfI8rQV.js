import { $ as toDisplayString, A as openBlock, B as isRef, D as onMounted, F as withCtx, M as renderList, P as watch, W as ref, X as unref, _ as getCurrentInstance, b as inject, d as createBlock, f as createCommentVNode, g as defineComponent, h as createVNode, l as computed, m as createTextVNode, n as Transition, o as Fragment, p as createElementBlock, u as createBaseVNode, v as h } from "./vue.runtime.esm-bundler-Da8D7169.js";
import { b as createComponent, s as hSlot } from "./dom-DvzD_91u.js";
import "./symbols-dSu0xIJX.js";
import { i as QIcon_default } from "./vm-BOuecwlZ.js";
import { d as storeToRefs, r as QBtn_default } from "./index-DRZOEVCp.js";
import { n as useI18n } from "./vue-i18n.runtime-9cAkLvsS.js";
import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Ca_i4E4D.js";
import { C as QPage_default } from "./position-engine-DsV-rayo.js";
import { S as QItemSection_default, _ as QItem_default, b as QBadge_default, d as QInput_default, g as QSeparator_default, i as DEFAULT_SETTINGS, s as QSelect_default, t as useSettingsStore, u as QBanner_default, v as useDarkProps, x as QItemLabel_default, y as use_dark_default } from "./settings-store-CY9p4di7.js";
//#region node_modules/quasar/src/components/item/QList.js
var roleAttrExceptions = ["ul", "ol"];
var QList_default = createComponent({
	name: "QList",
	props: {
		...useDarkProps,
		bordered: Boolean,
		dense: Boolean,
		separator: Boolean,
		padding: Boolean,
		tag: {
			type: String,
			default: "div"
		}
	},
	setup(props, { slots }) {
		const isDark = use_dark_default(props, getCurrentInstance().proxy.$q);
		const role = computed(() => roleAttrExceptions.includes(props.tag) ? null : "list");
		const classes = computed(() => "q-list" + (props.bordered === true ? " q-list--bordered" : "") + (props.dense === true ? " q-list--dense" : "") + (props.separator === true ? " q-list--separator" : "") + (isDark.value === true ? " q-list--dark" : "") + (props.padding === true ? " q-list--padding" : ""));
		return () => h(props.tag, {
			class: classes.value,
			role: role.value
		}, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/composables/use-quasar/use-quasar.js
/**
* Returns the $q instance.
* Equivalent to `this.$q` inside templates.
*/
function useQuasar() {
	return inject("_q_");
}
//#endregion
//#region src/pages/SettingsPage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "settings-shell" };
var _hoisted_2 = { class: "settings-nav" };
var _hoisted_3 = { class: "nav-header" };
var _hoisted_4 = { class: "nav-header__title" };
var _hoisted_5 = { class: "settings-content" };
var _hoisted_6 = {
	key: "soniox",
	class: "section"
};
var _hoisted_7 = { class: "section-header" };
var _hoisted_8 = { class: "section-title" };
var _hoisted_9 = { class: "section-subtitle" };
var _hoisted_10 = { class: "field-group" };
var _hoisted_11 = { class: "field-label" };
var _hoisted_12 = { class: "field-actions q-mt-sm" };
var _hoisted_13 = {
	key: "openai",
	class: "section"
};
var _hoisted_14 = { class: "section-header" };
var _hoisted_15 = { class: "section-title" };
var _hoisted_16 = { class: "section-subtitle" };
var _hoisted_17 = { class: "field-group" };
var _hoisted_18 = { class: "field-label" };
var _hoisted_19 = { class: "field-actions q-mt-sm" };
var _hoisted_20 = { class: "field-group q-mt-lg" };
var _hoisted_21 = { class: "field-label" };
var _hoisted_22 = { class: "field-group field-group--wide q-mt-lg" };
var _hoisted_23 = { class: "field-label-row" };
var _hoisted_24 = { class: "field-label" };
//#endregion
//#region src/pages/SettingsPage.vue
var SettingsPage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "SettingsPage",
	setup(__props) {
		const settingsStore = useSettingsStore();
		const { apiKey, openaiApiKey, openaiAssistantModel, openaiAssistantChatPrompt } = storeToRefs(settingsStore);
		const { t } = useI18n();
		const $q = useQuasar();
		const activeSection = ref("soniox");
		const showSonioxKey = ref(false);
		const showOpenaiKey = ref(false);
		const OPENAI_MODELS = [
			{
				label: "GPT-4.1 Mini",
				value: "gpt-4.1-mini"
			},
			{
				label: "GPT-4.1 Nano",
				value: "gpt-4.1-nano"
			},
			{
				label: "GPT-4.1",
				value: "gpt-4.1"
			},
			{
				label: "GPT-4o Mini",
				value: "gpt-4o-mini"
			},
			{
				label: "GPT-4o",
				value: "gpt-4o"
			}
		];
		const hasSonioxKey = computed(() => apiKey.value.length > 0);
		const hasOpenaiKey = computed(() => openaiApiKey.value.length > 0);
		const navItems = computed(() => [{
			id: "soniox",
			icon: "graphic_eq",
			label: t("settings.soniox.title"),
			caption: t("settings.soniox.description"),
			hasKey: hasSonioxKey.value,
			required: true
		}, {
			id: "openai",
			icon: "smart_toy",
			label: t("settings.openai.title"),
			caption: t("settings.openai.description"),
			hasKey: hasOpenaiKey.value,
			required: false
		}]);
		let saveNotifyTimer = null;
		watch([
			apiKey,
			openaiApiKey,
			openaiAssistantModel,
			openaiAssistantChatPrompt
		], () => {
			if (!settingsStore.isLoaded) return;
			if (saveNotifyTimer) clearTimeout(saveNotifyTimer);
			saveNotifyTimer = setTimeout(() => {
				$q.notify({
					message: t("settings.saved"),
					icon: "check_circle",
					color: "positive",
					position: "top",
					timeout: 1500,
					classes: "settings-save-notify"
				});
			}, 600);
		});
		function openSonioxHelp() {
			window.open("https://soniox.com/docs/stt/get-started#get-api-key", "_blank");
		}
		function openOpenaiHelp() {
			window.open("https://platform.openai.com/api-keys", "_blank");
		}
		function resetChatPrompt() {
			openaiAssistantChatPrompt.value = DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "";
		}
		onMounted(async () => {
			await settingsStore.loadSettings();
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QPage_default, { class: "settings-page" }, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1, [createBaseVNode("nav", _hoisted_2, [
					createBaseVNode("div", _hoisted_3, [createVNode(QIcon_default, {
						name: "settings",
						size: "20px",
						class: "nav-header__icon"
					}), createBaseVNode("span", _hoisted_4, toDisplayString(unref(t)("settings.title")), 1)]),
					createVNode(QList_default, { class: "nav-list" }, {
						default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(navItems.value, (item) => {
							return openBlock(), createBlock(QItem_default, {
								key: item.id,
								clickable: "",
								active: activeSection.value === item.id,
								"active-class": "nav-item--active",
								class: "nav-item",
								onClick: ($event) => activeSection.value = item.id
							}, {
								default: withCtx(() => [
									createVNode(QItemSection_default, { avatar: "" }, {
										default: withCtx(() => [createVNode(QIcon_default, {
											name: item.icon,
											size: "20px"
										}, null, 8, ["name"])]),
										_: 2
									}, 1024),
									createVNode(QItemSection_default, null, {
										default: withCtx(() => [createVNode(QItemLabel_default, { class: "nav-item__label" }, {
											default: withCtx(() => [createTextVNode(toDisplayString(item.label), 1)]),
											_: 2
										}, 1024), createVNode(QItemLabel_default, {
											caption: "",
											class: "nav-item__caption"
										}, {
											default: withCtx(() => [createTextVNode(toDisplayString(item.caption), 1)]),
											_: 2
										}, 1024)]),
										_: 2
									}, 1024),
									createVNode(QItemSection_default, { side: "" }, {
										default: withCtx(() => [item.hasKey ? (openBlock(), createBlock(QBadge_default, {
											key: 0,
											color: "positive",
											rounded: "",
											class: "nav-badge"
										}, {
											default: withCtx(() => [createVNode(QIcon_default, {
												name: "check",
												size: "10px"
											})]),
											_: 1
										})) : item.required ? (openBlock(), createBlock(QBadge_default, {
											key: 1,
											color: "warning",
											rounded: "",
											class: "nav-badge"
										}, {
											default: withCtx(() => [createVNode(QIcon_default, {
												name: "priority_high",
												size: "10px"
											})]),
											_: 1
										})) : createCommentVNode("", true)]),
										_: 2
									}, 1024)
								]),
								_: 2
							}, 1032, ["active", "onClick"]);
						}), 128))]),
						_: 1
					}),
					_cache[6] || (_cache[6] = createBaseVNode("div", { class: "nav-footer" }, [createBaseVNode("span", { class: "text-caption text-grey-6" }, "Live Translator")], -1))
				]), createBaseVNode("main", _hoisted_5, [createVNode(Transition, {
					name: "fade",
					mode: "out-in"
				}, {
					default: withCtx(() => [activeSection.value === "soniox" ? (openBlock(), createElementBlock("div", _hoisted_6, [
						createBaseVNode("div", _hoisted_7, [createVNode(QIcon_default, {
							name: "graphic_eq",
							size: "28px",
							color: "primary"
						}), createBaseVNode("div", null, [createBaseVNode("h2", _hoisted_8, toDisplayString(unref(t)("settings.soniox.title")), 1), createBaseVNode("p", _hoisted_9, toDisplayString(unref(t)("settings.soniox.description")), 1)])]),
						createVNode(QSeparator_default, { class: "q-my-md" }),
						createBaseVNode("div", _hoisted_10, [
							createBaseVNode("label", _hoisted_11, toDisplayString(unref(t)("settings.soniox.apiKey")), 1),
							createVNode(QInput_default, {
								modelValue: unref(apiKey),
								"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(apiKey) ? apiKey.value = $event : null),
								type: showSonioxKey.value ? "text" : "password",
								outlined: "",
								dense: "",
								placeholder: unref(t)("settings.soniox.apiKeyPlaceholder"),
								class: "api-key-input"
							}, {
								prepend: withCtx(() => [createVNode(QIcon_default, {
									name: "key",
									size: "18px"
								})]),
								append: withCtx(() => [createVNode(QIcon_default, {
									name: showSonioxKey.value ? "visibility_off" : "visibility",
									size: "18px",
									class: "cursor-pointer",
									onClick: _cache[0] || (_cache[0] = ($event) => showSonioxKey.value = !showSonioxKey.value)
								}, null, 8, ["name"]), hasSonioxKey.value ? (openBlock(), createBlock(QIcon_default, {
									key: 0,
									name: "check_circle",
									size: "18px",
									color: "positive",
									class: "q-ml-xs"
								})) : createCommentVNode("", true)]),
								_: 1
							}, 8, [
								"modelValue",
								"type",
								"placeholder"
							]),
							createBaseVNode("div", _hoisted_12, [createVNode(QBtn_default, {
								flat: "",
								dense: "",
								"no-caps": "",
								color: "primary",
								icon: "open_in_new",
								label: unref(t)("settings.soniox.getApiKey"),
								class: "link-btn",
								onClick: openSonioxHelp
							}, null, 8, ["label"])]),
							createVNode(QBanner_default, {
								class: "info-banner q-mt-md",
								rounded: ""
							}, {
								avatar: withCtx(() => [createVNode(QIcon_default, {
									name: "info",
									color: "primary"
								})]),
								default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(t)("settings.soniox.required")), 1)]),
								_: 1
							})
						])
					])) : activeSection.value === "openai" ? (openBlock(), createElementBlock("div", _hoisted_13, [
						createBaseVNode("div", _hoisted_14, [createVNode(QIcon_default, {
							name: "smart_toy",
							size: "28px",
							color: "teal"
						}), createBaseVNode("div", null, [createBaseVNode("h2", _hoisted_15, toDisplayString(unref(t)("settings.openai.title")), 1), createBaseVNode("p", _hoisted_16, toDisplayString(unref(t)("settings.openai.description")), 1)])]),
						createVNode(QSeparator_default, { class: "q-my-md" }),
						createBaseVNode("div", _hoisted_17, [
							createBaseVNode("label", _hoisted_18, toDisplayString(unref(t)("settings.openai.apiKey")), 1),
							createVNode(QInput_default, {
								modelValue: unref(openaiApiKey),
								"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(openaiApiKey) ? openaiApiKey.value = $event : null),
								type: showOpenaiKey.value ? "text" : "password",
								outlined: "",
								dense: "",
								placeholder: unref(t)("settings.openai.apiKeyPlaceholder"),
								class: "api-key-input"
							}, {
								prepend: withCtx(() => [createVNode(QIcon_default, {
									name: "key",
									size: "18px"
								})]),
								append: withCtx(() => [createVNode(QIcon_default, {
									name: showOpenaiKey.value ? "visibility_off" : "visibility",
									size: "18px",
									class: "cursor-pointer",
									onClick: _cache[2] || (_cache[2] = ($event) => showOpenaiKey.value = !showOpenaiKey.value)
								}, null, 8, ["name"]), hasOpenaiKey.value ? (openBlock(), createBlock(QIcon_default, {
									key: 0,
									name: "check_circle",
									size: "18px",
									color: "positive",
									class: "q-ml-xs"
								})) : createCommentVNode("", true)]),
								_: 1
							}, 8, [
								"modelValue",
								"type",
								"placeholder"
							]),
							createBaseVNode("div", _hoisted_19, [createVNode(QBtn_default, {
								flat: "",
								dense: "",
								"no-caps": "",
								color: "teal",
								icon: "open_in_new",
								label: unref(t)("settings.openai.getApiKey"),
								class: "link-btn",
								onClick: openOpenaiHelp
							}, null, 8, ["label"])])
						]),
						createBaseVNode("div", _hoisted_20, [createBaseVNode("label", _hoisted_21, toDisplayString(unref(t)("settings.openai.model")), 1), createVNode(QSelect_default, {
							modelValue: unref(openaiAssistantModel),
							"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(openaiAssistantModel) ? openaiAssistantModel.value = $event : null),
							options: OPENAI_MODELS,
							outlined: "",
							dense: "",
							"emit-value": "",
							"map-options": "",
							hint: unref(t)("settings.openai.modelHint"),
							class: "model-select"
						}, {
							prepend: withCtx(() => [createVNode(QIcon_default, {
								name: "model_training",
								size: "18px"
							})]),
							_: 1
						}, 8, ["modelValue", "hint"])]),
						createBaseVNode("div", _hoisted_22, [createBaseVNode("div", _hoisted_23, [createBaseVNode("label", _hoisted_24, toDisplayString(unref(t)("settings.openai.chatPrompt")), 1), createVNode(QBtn_default, {
							flat: "",
							dense: "",
							"no-caps": "",
							size: "xs",
							color: "grey-5",
							icon: "restart_alt",
							label: unref(t)("settings.openai.chatPromptReset"),
							class: "reset-btn",
							onClick: resetChatPrompt
						}, null, 8, ["label"])]), createVNode(QInput_default, {
							modelValue: unref(openaiAssistantChatPrompt),
							"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(openaiAssistantChatPrompt) ? openaiAssistantChatPrompt.value = $event : null),
							type: "textarea",
							outlined: "",
							dense: "",
							autogrow: "",
							hint: unref(t)("settings.openai.chatPromptHint"),
							class: "prompt-textarea"
						}, null, 8, ["modelValue", "hint"])]),
						createVNode(QBanner_default, {
							class: "info-banner q-mt-lg",
							rounded: ""
						}, {
							avatar: withCtx(() => [createVNode(QIcon_default, {
								name: "info",
								color: "teal"
							})]),
							default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(t)("settings.openai.optional")), 1)]),
							_: 1
						})
					])) : createCommentVNode("", true)]),
					_: 1
				})])])]),
				_: 1
			});
		};
	}
}), [["__scopeId", "data-v-9d2f16b3"]]);
//#endregion
export { SettingsPage_default as default };
