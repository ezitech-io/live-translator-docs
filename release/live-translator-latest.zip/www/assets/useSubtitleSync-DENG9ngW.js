import { G as ref, T as onBeforeUnmount } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
//#region src/composables/useSubtitleSync.ts
var CHANNEL_NAME = "live-translator-subtitle";
function useSubtitlePublisher() {
	let channel = null;
	try {
		channel = new BroadcastChannel(CHANNEL_NAME);
	} catch {}
	function publish(data) {
		try {
			channel?.postMessage({
				type: "translation-update",
				...data
			});
		} catch {}
	}
	onBeforeUnmount(() => {
		channel?.close();
		channel = null;
	});
	return { publish };
}
function useSubtitleSubscriber() {
	const lines = ref([]);
	let nextId = 0;
	let lastFullText = "";
	let channel = null;
	try {
		channel = new BroadcastChannel(CHANNEL_NAME);
		channel.onmessage = (event) => {
			const data = event.data;
			if (data?.type !== "translation-update") return;
			const fullText = data.currentTranslation.trim();
			if (!fullText) return;
			if (fullText === lastFullText) return;
			if (fullText.startsWith(lastFullText)) {
				const deltaText = fullText.slice(lastFullText.length).trim();
				lastFullText = fullText;
				if (!deltaText) return;
				lines.value = [...lines.value, {
					id: nextId++,
					text: deltaText
				}];
				return;
			}
			if (lastFullText.startsWith(fullText)) {
				lastFullText = fullText;
				return;
			}
			lastFullText = fullText;
			lines.value = [...lines.value, {
				id: nextId++,
				text: fullText
			}];
		};
	} catch {}
	onBeforeUnmount(() => {
		channel?.close();
		channel = null;
	});
	return { lines };
}
//#endregion
export { useSubtitleSubscriber as n, useSubtitlePublisher as t };
