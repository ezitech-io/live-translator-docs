import { F as watch, G as ref, T as onBeforeUnmount, n as Transition, u as computed, v as getCurrentInstance, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { b as createComponent, l as addEvt, s as hSlot, u as cleanEvt, y as stopAndPrevent } from "./dom-ClQ5j7De.js";
import { r as getScrollTarget, s as scrollTargetProp } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import { S as clearSelection, _ as use_model_toggle_default, a as addClickOutside, b as useAnchorStaticProps, c as use_tick_default, d as use_portal_default, g as useModelToggleProps, h as useModelToggleEmits, i as validatePosition, l as useTransitionProps, n as setPosition, o as removeClickOutside, r as validateOffset, s as use_timeout_default, t as parsePosition, u as use_transition_default, v as use_scroll_target_default, x as use_anchor_default } from "./position-engine-B6rijeNv.js";
//#region node_modules/quasar/src/components/tooltip/QTooltip.js
var QTooltip_default = createComponent({
	name: "QTooltip",
	inheritAttrs: false,
	props: {
		...useAnchorStaticProps,
		...useModelToggleProps,
		...useTransitionProps,
		maxHeight: {
			type: String,
			default: null
		},
		maxWidth: {
			type: String,
			default: null
		},
		transitionShow: {
			...useTransitionProps.transitionShow,
			default: "jump-down"
		},
		transitionHide: {
			...useTransitionProps.transitionHide,
			default: "jump-up"
		},
		anchor: {
			type: String,
			default: "bottom middle",
			validator: validatePosition
		},
		self: {
			type: String,
			default: "top middle",
			validator: validatePosition
		},
		offset: {
			type: Array,
			default: () => [14, 14],
			validator: validateOffset
		},
		scrollTarget: scrollTargetProp,
		delay: {
			type: Number,
			default: 0
		},
		hideDelay: {
			type: Number,
			default: 0
		},
		persistent: Boolean
	},
	emits: [...useModelToggleEmits],
	setup(props, { slots, emit, attrs }) {
		let unwatchPosition, observer;
		const vm = getCurrentInstance();
		const { proxy: { $q } } = vm;
		const innerRef = ref(null);
		const showing = ref(false);
		const anchorOrigin = computed(() => parsePosition(props.anchor, $q.lang.rtl));
		const selfOrigin = computed(() => parsePosition(props.self, $q.lang.rtl));
		const hideOnRouteChange = computed(() => props.persistent !== true);
		const { registerTick, removeTick } = use_tick_default();
		const { registerTimeout } = use_timeout_default();
		const { transitionProps, transitionStyle } = use_transition_default(props);
		const { localScrollTarget, changeScrollEvent, unconfigureScrollTarget } = use_scroll_target_default(props, configureScrollTarget);
		const { anchorEl, canShow, anchorEvents } = use_anchor_default({
			showing,
			configureAnchorEl
		});
		const { show, hide } = use_model_toggle_default({
			showing,
			canShow,
			handleShow,
			handleHide,
			hideOnRouteChange,
			processOnMount: true
		});
		Object.assign(anchorEvents, {
			delayShow,
			delayHide
		});
		const { showPortal, hidePortal, renderPortal } = use_portal_default(vm, innerRef, renderPortalContent, "tooltip");
		if ($q.platform.is.mobile === true) {
			const clickOutsideProps = {
				anchorEl,
				innerRef,
				onClickOutside(e) {
					hide(e);
					if (e.target.classList.contains("q-dialog__backdrop")) stopAndPrevent(e);
					return true;
				}
			};
			watch(computed(() => props.modelValue === null && props.persistent !== true && showing.value === true), (val) => {
				(val === true ? addClickOutside : removeClickOutside)(clickOutsideProps);
			});
			onBeforeUnmount(() => {
				removeClickOutside(clickOutsideProps);
			});
		}
		function handleShow(evt) {
			showPortal();
			registerTick(() => {
				observer = new MutationObserver(() => updatePosition());
				observer.observe(innerRef.value, {
					attributes: false,
					childList: true,
					characterData: true,
					subtree: true
				});
				updatePosition();
				configureScrollTarget();
			});
			if (unwatchPosition === void 0) unwatchPosition = watch(() => $q.screen.width + "|" + $q.screen.height + "|" + props.self + "|" + props.anchor + "|" + $q.lang.rtl, updatePosition);
			registerTimeout(() => {
				showPortal(true);
				emit("show", evt);
			}, props.transitionDuration);
		}
		function handleHide(evt) {
			removeTick();
			hidePortal();
			anchorCleanup();
			registerTimeout(() => {
				hidePortal(true);
				emit("hide", evt);
			}, props.transitionDuration);
		}
		function anchorCleanup() {
			if (observer !== void 0) {
				observer.disconnect();
				observer = void 0;
			}
			if (unwatchPosition !== void 0) {
				unwatchPosition();
				unwatchPosition = void 0;
			}
			unconfigureScrollTarget();
			cleanEvt(anchorEvents, "tooltipTemp");
		}
		function updatePosition() {
			setPosition({
				targetEl: innerRef.value,
				offset: props.offset,
				anchorEl: anchorEl.value,
				anchorOrigin: anchorOrigin.value,
				selfOrigin: selfOrigin.value,
				maxHeight: props.maxHeight,
				maxWidth: props.maxWidth
			});
		}
		function delayShow(evt) {
			if ($q.platform.is.mobile === true) {
				clearSelection();
				document.body.classList.add("non-selectable");
				const target = anchorEl.value;
				addEvt(anchorEvents, "tooltipTemp", [
					"touchmove",
					"touchcancel",
					"touchend",
					"click"
				].map((e) => [
					target,
					e,
					"delayHide",
					"passiveCapture"
				]));
			}
			registerTimeout(() => {
				show(evt);
			}, props.delay);
		}
		function delayHide(evt) {
			if ($q.platform.is.mobile === true) {
				cleanEvt(anchorEvents, "tooltipTemp");
				clearSelection();
				setTimeout(() => {
					document.body.classList.remove("non-selectable");
				}, 10);
			}
			registerTimeout(() => {
				hide(evt);
			}, props.hideDelay);
		}
		function configureAnchorEl() {
			if (props.noParentEvent === true || anchorEl.value === null) return;
			addEvt(anchorEvents, "anchor", $q.platform.is.mobile === true ? [[
				anchorEl.value,
				"touchstart",
				"delayShow",
				"passive"
			]] : [[
				anchorEl.value,
				"mouseenter",
				"delayShow",
				"passive"
			], [
				anchorEl.value,
				"mouseleave",
				"delayHide",
				"passive"
			]]);
		}
		function configureScrollTarget() {
			if (anchorEl.value !== null || props.scrollTarget !== void 0) {
				localScrollTarget.value = getScrollTarget(anchorEl.value, props.scrollTarget);
				const fn = props.noParentEvent === true ? updatePosition : hide;
				changeScrollEvent(localScrollTarget.value, fn);
			}
		}
		function getTooltipContent() {
			return showing.value === true ? h("div", {
				...attrs,
				ref: innerRef,
				class: ["q-tooltip q-tooltip--style q-position-engine no-pointer-events", attrs.class],
				style: [attrs.style, transitionStyle.value],
				role: "tooltip"
			}, hSlot(slots.default)) : null;
		}
		function renderPortalContent() {
			return h(Transition, transitionProps.value, getTooltipContent);
		}
		onBeforeUnmount(anchorCleanup);
		Object.assign(vm.proxy, { updatePosition });
		return renderPortal;
	}
});
//#endregion
export { QTooltip_default as t };
