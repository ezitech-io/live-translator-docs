import { F as watch, G as ref, I as withCtx, N as renderList, O as onMounted, V as isRef, Z as unref, _ as defineComponent, d as createBaseVNode, et as toDisplayString, f as createBlock, g as createVNode, h as createTextVNode, j as openBlock, m as createElementBlock, n as Transition, o as withKeys, p as createCommentVNode, s as Fragment, u as computed, v as getCurrentInstance, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { b as createComponent, s as hSlot } from "./dom-ClQ5j7De.js";
import "./Platform-DVLU8Kjq.js";
import { i as QIcon_default } from "./vm-BBDykFtW.js";
import { f as useRoute, m as storeToRefs, r as QBtn_default } from "./index-SGausFmx.js";
import { n as useI18n } from "./vue-i18n.runtime-0_E2riTW.js";
import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import { t as QPage_default } from "./QPage-CH5UzGwX.js";
import "./position-engine-DEYgZOgR.js";
import { C as QItemLabel_default, S as QBadge_default, _ as QBanner_default, a as forceActivateLicense, b as useDarkProps, c as QDialog_default, d as QCardSection_default, f as QInput_default, i as activateLicense, l as QCard_default, n as useAuthStore, o as QSelect_default, r as LicenseApiError, t as useQuasar, u as QCardActions_default, v as QSeparator_default, w as QItemSection_default, x as use_dark_default, y as QItem_default } from "./use-quasar-DN3XJpGy.js";
import { i as DEFAULT_SETTINGS, t as useSettingsStore } from "./settings-store-DPdKgbIB.js";
//#region node_modules/quasar/src/components/item/QList.js
var roleAttrExceptions = ["ul", "ol"];
var QList_default = createComponent({
	name: "QList",
	props: {
		...useDarkProps,
		bordered: Boolean,
		dense: Boolean,
		separator: Boolean,
		padding: Boolean,
		tag: {
			type: String,
			default: "div"
		}
	},
	setup(props, { slots }) {
		const isDark = use_dark_default(props, getCurrentInstance().proxy.$q);
		const role = computed(() => roleAttrExceptions.includes(props.tag) ? null : "list");
		const classes = computed(() => "q-list" + (props.bordered === true ? " q-list--bordered" : "") + (props.dense === true ? " q-list--dense" : "") + (props.separator === true ? " q-list--separator" : "") + (isDark.value === true ? " q-list--dark" : "") + (props.padding === true ? " q-list--padding" : ""));
		return () => h(props.tag, {
			class: classes.value,
			role: role.value
		}, hSlot(slots.default));
	}
});
//#endregion
//#region src/composables/useLicense.ts
function useLicense() {
	const authStore = useAuthStore();
	const uiState = ref("idle");
	const errorMessage = ref("");
	const errorCode = ref("");
	const showForceActivateDialog = ref(false);
	const pendingKey = ref("");
	const pendingDeviceLabel = ref("");
	const isActivating = computed(() => uiState.value === "activating");
	function getDeviceLabel() {
		const ua = navigator.userAgent;
		if (ua.includes("Chrome")) return `Chrome / ${navigator.platform}`;
		if (ua.includes("Firefox")) return `Firefox / ${navigator.platform}`;
		if (ua.includes("Edge")) return `Edge / ${navigator.platform}`;
		return `Browser / ${navigator.platform}`;
	}
	async function handleActivateSuccess(response) {
		await authStore.saveAuth({
			accessToken: response.access_token,
			activationId: response.activation_id,
			expiresAt: response.expires_at ?? "",
			customerEmail: response.user.email,
			customerName: response.user.name
		});
		uiState.value = "success";
		errorMessage.value = "";
		errorCode.value = "";
	}
	async function activate(key) {
		if (!key.trim()) {
			errorMessage.value = "Please enter a license key.";
			errorCode.value = "EMPTY_KEY";
			uiState.value = "error";
			return;
		}
		uiState.value = "activating";
		errorMessage.value = "";
		errorCode.value = "";
		const deviceLabel = getDeviceLabel();
		try {
			await handleActivateSuccess(await activateLicense(key, deviceLabel));
		} catch (err) {
			if (err instanceof LicenseApiError) {
				if (err.errorCode === "KEY_ALREADY_ACTIVATED") {
					pendingKey.value = key;
					pendingDeviceLabel.value = deviceLabel;
					showForceActivateDialog.value = true;
					uiState.value = "idle";
					return;
				}
				errorMessage.value = err.message;
				errorCode.value = err.errorCode;
			} else {
				errorMessage.value = "Network error. Please check your connection.";
				errorCode.value = "NETWORK_ERROR";
			}
			uiState.value = "error";
		}
	}
	async function confirmForceActivate() {
		showForceActivateDialog.value = false;
		uiState.value = "activating";
		try {
			await handleActivateSuccess(await forceActivateLicense(pendingKey.value, pendingDeviceLabel.value));
		} catch (err) {
			if (err instanceof LicenseApiError) {
				errorMessage.value = err.message;
				errorCode.value = err.errorCode;
			} else {
				errorMessage.value = "Network error. Please check your connection.";
				errorCode.value = "NETWORK_ERROR";
			}
			uiState.value = "error";
		} finally {
			pendingKey.value = "";
			pendingDeviceLabel.value = "";
		}
	}
	function cancelForceActivate() {
		showForceActivateDialog.value = false;
		pendingKey.value = "";
		pendingDeviceLabel.value = "";
	}
	function resetError() {
		errorMessage.value = "";
		errorCode.value = "";
		uiState.value = "idle";
	}
	return {
		uiState,
		errorMessage,
		errorCode,
		isActivating,
		showForceActivateDialog,
		activate,
		confirmForceActivate,
		cancelForceActivate,
		resetError
	};
}
//#endregion
//#region src/pages/SettingsPage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "settings-shell" };
var _hoisted_2 = { class: "settings-nav" };
var _hoisted_3 = { class: "nav-header" };
var _hoisted_4 = { class: "nav-header__title" };
var _hoisted_5 = { class: "settings-content" };
var _hoisted_6 = {
	key: "license",
	class: "section"
};
var _hoisted_7 = { class: "section-header" };
var _hoisted_8 = { class: "section-title" };
var _hoisted_9 = { class: "section-subtitle" };
var _hoisted_10 = {
	key: 0,
	class: "license-status"
};
var _hoisted_11 = { class: "license-status__badge license-status__badge--active" };
var _hoisted_12 = { class: "license-status__details q-mt-md" };
var _hoisted_13 = { class: "license-detail" };
var _hoisted_14 = { class: "license-detail__label" };
var _hoisted_15 = { class: "license-detail__value" };
var _hoisted_16 = {
	key: 0,
	class: "license-detail"
};
var _hoisted_17 = { class: "license-detail__value" };
var _hoisted_18 = {
	key: 1,
	class: "license-detail"
};
var _hoisted_19 = { class: "license-detail__label" };
var _hoisted_20 = { class: "license-detail__value" };
var _hoisted_21 = {
	key: 1,
	class: "license-status"
};
var _hoisted_22 = { class: "license-status__badge license-status__badge--expired" };
var _hoisted_23 = { class: "field-group q-mt-lg" };
var _hoisted_24 = { class: "field-label" };
var _hoisted_25 = {
	key: 2,
	class: "field-group"
};
var _hoisted_26 = { class: "field-label" };
var _hoisted_27 = {
	href: "https://buy.polar.sh/polar_cl_ACENb7X8r4vhnoa0DXmuJIpjs1cmnJK2C8Geh2KEn4S",
	target: "_blank",
	class: "text-amber"
};
var _hoisted_28 = { class: "text-h6" };
var _hoisted_29 = {
	key: "soniox",
	class: "section"
};
var _hoisted_30 = { class: "section-header" };
var _hoisted_31 = { class: "section-title" };
var _hoisted_32 = { class: "section-subtitle" };
var _hoisted_33 = { class: "field-group" };
var _hoisted_34 = { class: "field-label" };
var _hoisted_35 = { class: "field-actions q-mt-sm" };
var _hoisted_36 = {
	key: "openai",
	class: "section"
};
var _hoisted_37 = { class: "section-header" };
var _hoisted_38 = { class: "section-title" };
var _hoisted_39 = { class: "section-subtitle" };
var _hoisted_40 = { class: "field-group" };
var _hoisted_41 = { class: "field-label" };
var _hoisted_42 = { class: "field-actions q-mt-sm" };
var _hoisted_43 = { class: "field-group q-mt-lg" };
var _hoisted_44 = { class: "field-label" };
var _hoisted_45 = { class: "field-group field-group--wide q-mt-lg" };
var _hoisted_46 = { class: "field-label-row" };
var _hoisted_47 = { class: "field-label" };
//#endregion
//#region src/pages/SettingsPage.vue
var SettingsPage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "SettingsPage",
	setup(__props) {
		const settingsStore = useSettingsStore();
		const authStore = useAuthStore();
		const { apiKey, openaiApiKey, openaiAssistantModel, openaiAssistantChatPrompt } = storeToRefs(settingsStore);
		const { licenseStatus, customerEmail, customerName, expiresAt } = storeToRefs(authStore);
		const { t } = useI18n();
		const $q = useQuasar();
		const route = useRoute();
		const license = useLicense();
		const licenseKeyInput = ref("");
		const showLicenseKey = ref(false);
		const activeSection = ref("license");
		const showSonioxKey = ref(false);
		const showOpenaiKey = ref(false);
		function isSettingsSection(value) {
			return value === "license" || value === "soniox" || value === "openai";
		}
		const OPENAI_MODELS = [
			{
				label: "GPT-4.1 Mini",
				value: "gpt-4.1-mini"
			},
			{
				label: "GPT-4.1 Nano",
				value: "gpt-4.1-nano"
			},
			{
				label: "GPT-4.1",
				value: "gpt-4.1"
			},
			{
				label: "GPT-4o Mini",
				value: "gpt-4o-mini"
			},
			{
				label: "GPT-4o",
				value: "gpt-4o"
			}
		];
		const hasSonioxKey = computed(() => apiKey.value.length > 0);
		const hasOpenaiKey = computed(() => openaiApiKey.value.length > 0);
		const formattedExpiresAt = computed(() => {
			if (!expiresAt.value) return "";
			return new Date(expiresAt.value).toLocaleDateString(void 0, {
				year: "numeric",
				month: "long",
				day: "numeric"
			});
		});
		const navItems = computed(() => [
			{
				id: "license",
				icon: "verified_user",
				label: t("settings.license.title"),
				caption: t("settings.license.description"),
				hasKey: licenseStatus.value === "active",
				required: true,
				badgeColor: licenseStatus.value === "active" ? "positive" : licenseStatus.value === "expired" ? "warning" : void 0
			},
			{
				id: "soniox",
				icon: "graphic_eq",
				label: t("settings.soniox.title"),
				caption: t("settings.soniox.description"),
				hasKey: hasSonioxKey.value,
				required: true
			},
			{
				id: "openai",
				icon: "smart_toy",
				label: t("settings.openai.title"),
				caption: t("settings.openai.description"),
				hasKey: hasOpenaiKey.value,
				required: false
			}
		]);
		let saveNotifyTimer = null;
		watch([
			apiKey,
			openaiApiKey,
			openaiAssistantModel,
			openaiAssistantChatPrompt
		], () => {
			if (!settingsStore.isLoaded) return;
			if (saveNotifyTimer) clearTimeout(saveNotifyTimer);
			saveNotifyTimer = setTimeout(() => {
				$q.notify({
					message: t("settings.saved"),
					icon: "check_circle",
					color: "positive",
					position: "top",
					timeout: 1500,
					classes: "settings-save-notify"
				});
			}, 600);
		});
		watch(() => {
			const tab = route.query.tab;
			const section = route.query.section;
			if (typeof tab === "string") return tab;
			if (typeof section === "string") return section;
		}, (value) => {
			if (value && isSettingsSection(value)) activeSection.value = value;
		}, { immediate: true });
		function openSonioxHelp() {
			window.open("https://soniox.com/docs/stt/get-started#get-api-key", "_blank");
		}
		function openOpenaiHelp() {
			window.open("https://platform.openai.com/api-keys", "_blank");
		}
		function resetChatPrompt() {
			openaiAssistantChatPrompt.value = DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "";
		}
		async function handleActivate() {
			await license.activate(licenseKeyInput.value);
			if (license.uiState.value === "success") {
				licenseKeyInput.value = "";
				$q.notify({
					message: "License activated successfully!",
					icon: "check_circle",
					color: "positive",
					position: "top",
					timeout: 3e3
				});
			}
		}
		onMounted(async () => {
			await Promise.all([settingsStore.loadSettings(), authStore.loadAuth()]);
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QPage_default, { class: "settings-page" }, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1, [createBaseVNode("nav", _hoisted_2, [
					createBaseVNode("div", _hoisted_3, [createVNode(QIcon_default, {
						name: "settings",
						size: "20px",
						class: "nav-header__icon"
					}), createBaseVNode("span", _hoisted_4, toDisplayString(unref(t)("settings.title")), 1)]),
					createVNode(QList_default, { class: "nav-list" }, {
						default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(navItems.value, (item) => {
							return openBlock(), createBlock(QItem_default, {
								key: item.id,
								clickable: "",
								active: activeSection.value === item.id,
								"active-class": "nav-item--active",
								class: "nav-item",
								onClick: ($event) => activeSection.value = item.id
							}, {
								default: withCtx(() => [
									createVNode(QItemSection_default, { avatar: "" }, {
										default: withCtx(() => [createVNode(QIcon_default, {
											name: item.icon,
											size: "20px"
										}, null, 8, ["name"])]),
										_: 2
									}, 1024),
									createVNode(QItemSection_default, null, {
										default: withCtx(() => [createVNode(QItemLabel_default, { class: "nav-item__label" }, {
											default: withCtx(() => [createTextVNode(toDisplayString(item.label), 1)]),
											_: 2
										}, 1024), createVNode(QItemLabel_default, {
											caption: "",
											class: "nav-item__caption"
										}, {
											default: withCtx(() => [createTextVNode(toDisplayString(item.caption), 1)]),
											_: 2
										}, 1024)]),
										_: 2
									}, 1024),
									createVNode(QItemSection_default, { side: "" }, {
										default: withCtx(() => [item.hasKey ? (openBlock(), createBlock(QBadge_default, {
											key: 0,
											color: item.badgeColor ?? "positive",
											rounded: "",
											class: "nav-badge"
										}, {
											default: withCtx(() => [createVNode(QIcon_default, {
												name: "check",
												size: "10px"
											})]),
											_: 1
										}, 8, ["color"])) : item.required ? (openBlock(), createBlock(QBadge_default, {
											key: 1,
											color: "warning",
											rounded: "",
											class: "nav-badge"
										}, {
											default: withCtx(() => [createVNode(QIcon_default, {
												name: "priority_high",
												size: "10px"
											})]),
											_: 1
										})) : createCommentVNode("", true)]),
										_: 2
									}, 1024)
								]),
								_: 2
							}, 1032, ["active", "onClick"]);
						}), 128))]),
						_: 1
					}),
					_cache[14] || (_cache[14] = createBaseVNode("div", { class: "nav-footer" }, [createBaseVNode("span", { class: "text-caption text-grey-6" }, "Live Translator")], -1))
				]), createBaseVNode("main", _hoisted_5, [createVNode(Transition, {
					name: "fade",
					mode: "out-in"
				}, {
					default: withCtx(() => [activeSection.value === "license" ? (openBlock(), createElementBlock("div", _hoisted_6, [
						createBaseVNode("div", _hoisted_7, [createVNode(QIcon_default, {
							name: "verified_user",
							size: "28px",
							color: "amber"
						}), createBaseVNode("div", null, [createBaseVNode("h2", _hoisted_8, toDisplayString(unref(t)("settings.license.title")), 1), createBaseVNode("p", _hoisted_9, toDisplayString(unref(t)("settings.license.description")), 1)])]),
						createVNode(QSeparator_default, { class: "q-my-md" }),
						unref(licenseStatus) === "active" ? (openBlock(), createElementBlock("div", _hoisted_10, [createBaseVNode("div", _hoisted_11, [createVNode(QIcon_default, {
							name: "check_circle",
							size: "24px"
						}), createBaseVNode("span", null, toDisplayString(unref(t)("settings.license.active")), 1)]), createBaseVNode("div", _hoisted_12, [
							createBaseVNode("div", _hoisted_13, [createBaseVNode("span", _hoisted_14, toDisplayString(unref(t)("settings.license.licensedTo")), 1), createBaseVNode("span", _hoisted_15, toDisplayString(unref(customerName) || unref(customerEmail)), 1)]),
							unref(customerEmail) ? (openBlock(), createElementBlock("div", _hoisted_16, [_cache[15] || (_cache[15] = createBaseVNode("span", { class: "license-detail__label" }, "Email", -1)), createBaseVNode("span", _hoisted_17, toDisplayString(unref(customerEmail)), 1)])) : createCommentVNode("", true),
							formattedExpiresAt.value ? (openBlock(), createElementBlock("div", _hoisted_18, [createBaseVNode("span", _hoisted_19, toDisplayString(unref(t)("settings.license.validUntil", { date: "" })), 1), createBaseVNode("span", _hoisted_20, toDisplayString(formattedExpiresAt.value), 1)])) : createCommentVNode("", true)
						])])) : unref(licenseStatus) === "expired" ? (openBlock(), createElementBlock("div", _hoisted_21, [
							createBaseVNode("div", _hoisted_22, [createVNode(QIcon_default, {
								name: "warning",
								size: "24px"
							}), createBaseVNode("span", null, toDisplayString(unref(t)("settings.license.expired")), 1)]),
							createVNode(QBanner_default, {
								class: "info-banner info-banner--warning q-mt-md",
								rounded: ""
							}, {
								avatar: withCtx(() => [createVNode(QIcon_default, {
									name: "info",
									color: "warning"
								})]),
								default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(t)("settings.license.expiredMessage", { date: formattedExpiresAt.value })), 1)]),
								_: 1
							}),
							createBaseVNode("div", _hoisted_23, [
								createBaseVNode("label", _hoisted_24, toDisplayString(unref(t)("settings.license.keyLabel")), 1),
								createVNode(QInput_default, {
									modelValue: licenseKeyInput.value,
									"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => licenseKeyInput.value = $event),
									type: showLicenseKey.value ? "text" : "password",
									outlined: "",
									dense: "",
									placeholder: unref(t)("settings.license.keyPlaceholder"),
									disable: unref(license).isActivating.value,
									class: "api-key-input",
									onKeyup: withKeys(handleActivate, ["enter"])
								}, {
									prepend: withCtx(() => [createVNode(QIcon_default, {
										name: "vpn_key",
										size: "18px"
									})]),
									append: withCtx(() => [createVNode(QIcon_default, {
										name: showLicenseKey.value ? "visibility_off" : "visibility",
										size: "18px",
										class: "cursor-pointer",
										onClick: _cache[0] || (_cache[0] = ($event) => showLicenseKey.value = !showLicenseKey.value)
									}, null, 8, ["name"])]),
									_: 1
								}, 8, [
									"modelValue",
									"type",
									"placeholder",
									"disable"
								]),
								createVNode(QBtn_default, {
									label: unref(license).isActivating.value ? unref(t)("settings.license.activating") : unref(t)("settings.license.activate"),
									loading: unref(license).isActivating.value,
									color: "amber",
									"text-color": "dark",
									"no-caps": "",
									class: "q-mt-sm",
									disable: !licenseKeyInput.value.trim(),
									onClick: handleActivate
								}, null, 8, [
									"label",
									"loading",
									"disable"
								])
							])
						])) : (openBlock(), createElementBlock("div", _hoisted_25, [
							createBaseVNode("label", _hoisted_26, toDisplayString(unref(t)("settings.license.keyLabel")), 1),
							createVNode(QInput_default, {
								modelValue: licenseKeyInput.value,
								"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => licenseKeyInput.value = $event),
								type: showLicenseKey.value ? "text" : "password",
								outlined: "",
								dense: "",
								placeholder: unref(t)("settings.license.keyPlaceholder"),
								disable: unref(license).isActivating.value,
								class: "api-key-input",
								onKeyup: withKeys(handleActivate, ["enter"])
							}, {
								prepend: withCtx(() => [createVNode(QIcon_default, {
									name: "vpn_key",
									size: "18px"
								})]),
								append: withCtx(() => [createVNode(QIcon_default, {
									name: showLicenseKey.value ? "visibility_off" : "visibility",
									size: "18px",
									class: "cursor-pointer",
									onClick: _cache[2] || (_cache[2] = ($event) => showLicenseKey.value = !showLicenseKey.value)
								}, null, 8, ["name"])]),
								_: 1
							}, 8, [
								"modelValue",
								"type",
								"placeholder",
								"disable"
							]),
							unref(license).errorMessage.value ? (openBlock(), createBlock(QBanner_default, {
								key: 0,
								class: "info-banner info-banner--error q-mt-sm",
								rounded: ""
							}, {
								avatar: withCtx(() => [createVNode(QIcon_default, {
									name: "error",
									color: "negative"
								})]),
								action: withCtx(() => [createVNode(QBtn_default, {
									flat: "",
									dense: "",
									"no-caps": "",
									size: "sm",
									label: "Dismiss",
									onClick: _cache[4] || (_cache[4] = ($event) => unref(license).resetError())
								})]),
								default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(license).errorMessage.value) + " ", 1)]),
								_: 1
							})) : createCommentVNode("", true),
							createVNode(QBtn_default, {
								label: unref(license).isActivating.value ? unref(t)("settings.license.activating") : unref(t)("settings.license.activate"),
								loading: unref(license).isActivating.value,
								color: "amber",
								"text-color": "dark",
								"no-caps": "",
								class: "q-mt-sm",
								disable: !licenseKeyInput.value.trim(),
								onClick: handleActivate
							}, null, 8, [
								"label",
								"loading",
								"disable"
							]),
							createVNode(QBanner_default, {
								class: "info-banner q-mt-lg",
								rounded: ""
							}, {
								avatar: withCtx(() => [createVNode(QIcon_default, {
									name: "info",
									color: "amber"
								})]),
								default: withCtx(() => [_cache[16] || (_cache[16] = createTextVNode(" Enter your license key to activate premium features. Don't have one? ", -1)), createBaseVNode("a", _hoisted_27, toDisplayString(unref(t)("settings.license.getPurchase")), 1)]),
								_: 1
							})
						])),
						createVNode(QDialog_default, {
							modelValue: unref(license).showForceActivateDialog.value,
							"onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => unref(license).showForceActivateDialog.value = $event),
							persistent: ""
						}, {
							default: withCtx(() => [createVNode(QCard_default, { class: "force-activate-dialog" }, {
								default: withCtx(() => [
									createVNode(QCardSection_default, { class: "row items-center" }, {
										default: withCtx(() => [createVNode(QIcon_default, {
											name: "devices",
											size: "28px",
											color: "warning",
											class: "q-mr-md"
										}), createBaseVNode("div", _hoisted_28, toDisplayString(unref(t)("settings.license.forceActivateTitle")), 1)]),
										_: 1
									}),
									createVNode(QCardSection_default, null, {
										default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("settings.license.forceActivateMessage")), 1)]),
										_: 1
									}),
									createVNode(QCardActions_default, { align: "right" }, {
										default: withCtx(() => [createVNode(QBtn_default, {
											flat: "",
											"no-caps": "",
											label: unref(t)("settings.license.forceActivateCancel"),
											onClick: _cache[5] || (_cache[5] = ($event) => unref(license).cancelForceActivate())
										}, null, 8, ["label"]), createVNode(QBtn_default, {
											flat: "",
											"no-caps": "",
											color: "warning",
											label: unref(t)("settings.license.forceActivateConfirm"),
											onClick: _cache[6] || (_cache[6] = ($event) => unref(license).confirmForceActivate())
										}, null, 8, ["label"])]),
										_: 1
									})
								]),
								_: 1
							})]),
							_: 1
						}, 8, ["modelValue"])
					])) : activeSection.value === "soniox" ? (openBlock(), createElementBlock("div", _hoisted_29, [
						createBaseVNode("div", _hoisted_30, [createVNode(QIcon_default, {
							name: "graphic_eq",
							size: "28px",
							color: "primary"
						}), createBaseVNode("div", null, [createBaseVNode("h2", _hoisted_31, toDisplayString(unref(t)("settings.soniox.title")), 1), createBaseVNode("p", _hoisted_32, toDisplayString(unref(t)("settings.soniox.description")), 1)])]),
						createVNode(QSeparator_default, { class: "q-my-md" }),
						createBaseVNode("div", _hoisted_33, [
							createBaseVNode("label", _hoisted_34, toDisplayString(unref(t)("settings.soniox.apiKey")), 1),
							createVNode(QInput_default, {
								modelValue: unref(apiKey),
								"onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => isRef(apiKey) ? apiKey.value = $event : null),
								type: showSonioxKey.value ? "text" : "password",
								outlined: "",
								dense: "",
								placeholder: unref(t)("settings.soniox.apiKeyPlaceholder"),
								class: "api-key-input"
							}, {
								prepend: withCtx(() => [createVNode(QIcon_default, {
									name: "key",
									size: "18px"
								})]),
								append: withCtx(() => [createVNode(QIcon_default, {
									name: showSonioxKey.value ? "visibility_off" : "visibility",
									size: "18px",
									class: "cursor-pointer",
									onClick: _cache[8] || (_cache[8] = ($event) => showSonioxKey.value = !showSonioxKey.value)
								}, null, 8, ["name"]), hasSonioxKey.value ? (openBlock(), createBlock(QIcon_default, {
									key: 0,
									name: "check_circle",
									size: "18px",
									color: "positive",
									class: "q-ml-xs"
								})) : createCommentVNode("", true)]),
								_: 1
							}, 8, [
								"modelValue",
								"type",
								"placeholder"
							]),
							createBaseVNode("div", _hoisted_35, [createVNode(QBtn_default, {
								flat: "",
								dense: "",
								"no-caps": "",
								color: "primary",
								icon: "open_in_new",
								label: unref(t)("settings.soniox.getApiKey"),
								class: "link-btn",
								onClick: openSonioxHelp
							}, null, 8, ["label"])]),
							createVNode(QBanner_default, {
								class: "info-banner q-mt-md",
								rounded: ""
							}, {
								avatar: withCtx(() => [createVNode(QIcon_default, {
									name: "info",
									color: "primary"
								})]),
								default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(t)("settings.soniox.required")), 1)]),
								_: 1
							})
						])
					])) : activeSection.value === "openai" ? (openBlock(), createElementBlock("div", _hoisted_36, [
						createBaseVNode("div", _hoisted_37, [createVNode(QIcon_default, {
							name: "smart_toy",
							size: "28px",
							color: "teal"
						}), createBaseVNode("div", null, [createBaseVNode("h2", _hoisted_38, toDisplayString(unref(t)("settings.openai.title")), 1), createBaseVNode("p", _hoisted_39, toDisplayString(unref(t)("settings.openai.description")), 1)])]),
						createVNode(QSeparator_default, { class: "q-my-md" }),
						createBaseVNode("div", _hoisted_40, [
							createBaseVNode("label", _hoisted_41, toDisplayString(unref(t)("settings.openai.apiKey")), 1),
							createVNode(QInput_default, {
								modelValue: unref(openaiApiKey),
								"onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => isRef(openaiApiKey) ? openaiApiKey.value = $event : null),
								type: showOpenaiKey.value ? "text" : "password",
								outlined: "",
								dense: "",
								placeholder: unref(t)("settings.openai.apiKeyPlaceholder"),
								class: "api-key-input"
							}, {
								prepend: withCtx(() => [createVNode(QIcon_default, {
									name: "key",
									size: "18px"
								})]),
								append: withCtx(() => [createVNode(QIcon_default, {
									name: showOpenaiKey.value ? "visibility_off" : "visibility",
									size: "18px",
									class: "cursor-pointer",
									onClick: _cache[10] || (_cache[10] = ($event) => showOpenaiKey.value = !showOpenaiKey.value)
								}, null, 8, ["name"]), hasOpenaiKey.value ? (openBlock(), createBlock(QIcon_default, {
									key: 0,
									name: "check_circle",
									size: "18px",
									color: "positive",
									class: "q-ml-xs"
								})) : createCommentVNode("", true)]),
								_: 1
							}, 8, [
								"modelValue",
								"type",
								"placeholder"
							]),
							createBaseVNode("div", _hoisted_42, [createVNode(QBtn_default, {
								flat: "",
								dense: "",
								"no-caps": "",
								color: "teal",
								icon: "open_in_new",
								label: unref(t)("settings.openai.getApiKey"),
								class: "link-btn",
								onClick: openOpenaiHelp
							}, null, 8, ["label"])])
						]),
						createBaseVNode("div", _hoisted_43, [createBaseVNode("label", _hoisted_44, toDisplayString(unref(t)("settings.openai.model")), 1), createVNode(QSelect_default, {
							modelValue: unref(openaiAssistantModel),
							"onUpdate:modelValue": _cache[12] || (_cache[12] = ($event) => isRef(openaiAssistantModel) ? openaiAssistantModel.value = $event : null),
							options: OPENAI_MODELS,
							outlined: "",
							dense: "",
							"emit-value": "",
							"map-options": "",
							hint: unref(t)("settings.openai.modelHint"),
							class: "model-select"
						}, {
							prepend: withCtx(() => [createVNode(QIcon_default, {
								name: "model_training",
								size: "18px"
							})]),
							_: 1
						}, 8, ["modelValue", "hint"])]),
						createBaseVNode("div", _hoisted_45, [createBaseVNode("div", _hoisted_46, [createBaseVNode("label", _hoisted_47, toDisplayString(unref(t)("settings.openai.chatPrompt")), 1), createVNode(QBtn_default, {
							flat: "",
							dense: "",
							"no-caps": "",
							size: "xs",
							color: "grey-5",
							icon: "restart_alt",
							label: unref(t)("settings.openai.chatPromptReset"),
							class: "reset-btn",
							onClick: resetChatPrompt
						}, null, 8, ["label"])]), createVNode(QInput_default, {
							modelValue: unref(openaiAssistantChatPrompt),
							"onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => isRef(openaiAssistantChatPrompt) ? openaiAssistantChatPrompt.value = $event : null),
							type: "textarea",
							outlined: "",
							dense: "",
							autogrow: "",
							hint: unref(t)("settings.openai.chatPromptHint"),
							class: "prompt-textarea"
						}, null, 8, ["modelValue", "hint"])]),
						createVNode(QBanner_default, {
							class: "info-banner q-mt-lg",
							rounded: ""
						}, {
							avatar: withCtx(() => [createVNode(QIcon_default, {
								name: "info",
								color: "teal"
							})]),
							default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(t)("settings.openai.optional")), 1)]),
							_: 1
						})
					])) : createCommentVNode("", true)]),
					_: 1
				})])])]),
				_: 1
			});
		};
	}
}), [["__scopeId", "data-v-6b95718c"]]);
//#endregion
export { SettingsPage_default as default };
