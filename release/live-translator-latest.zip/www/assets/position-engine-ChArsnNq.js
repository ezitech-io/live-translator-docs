import { D as onDeactivated, F as watch, G as ref, O as onMounted, S as nextTick, T as onBeforeUnmount, c as Teleport, k as onUnmounted, u as computed, v as getCurrentInstance, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { C as injectProp, b as createComponent, g as prevent, l as addEvt, p as listenOpts, u as cleanEvt } from "./dom-ClQ5j7De.js";
import { n as client, t as Platform } from "./Platform-DVLU8Kjq.js";
import { c as isKeyCode, n as vmHasRouter, r as vmIsDestroyed, t as getParentProxy } from "./vm-BBDykFtW.js";
import { n as removeGlobalNode, t as createGlobalNode } from "./index-CA7V2kmT.js";
import { i as getScrollbarWidth } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
//#region node_modules/quasar/src/utils/private.selection/selection.js
function clearSelection() {
	if (window.getSelection !== void 0) {
		const selection = window.getSelection();
		if (selection.empty !== void 0) selection.empty();
		else if (selection.removeAllRanges !== void 0) {
			selection.removeAllRanges();
			Platform.is.mobile !== true && selection.addRange(document.createRange());
		}
	} else if (document.selection !== void 0) document.selection.empty();
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-anchor/use-anchor.js
var useAnchorStaticProps = {
	target: {
		type: [
			Boolean,
			String,
			Element
		],
		default: true
	},
	noParentEvent: Boolean
};
var useAnchorProps = {
	...useAnchorStaticProps,
	contextMenu: Boolean
};
function use_anchor_default({ showing, avoidEmit, configureAnchorEl }) {
	const { props, proxy, emit } = getCurrentInstance();
	const anchorEl = ref(null);
	let touchTimer = null;
	function canShow(evt) {
		return anchorEl.value === null ? false : evt === void 0 || evt.touches === void 0 || evt.touches.length <= 1;
	}
	const anchorEvents = {};
	if (configureAnchorEl === void 0) {
		Object.assign(anchorEvents, {
			hide(evt) {
				proxy.hide(evt);
			},
			toggle(evt) {
				proxy.toggle(evt);
				evt.qAnchorHandled = true;
			},
			toggleKey(evt) {
				isKeyCode(evt, 13) === true && anchorEvents.toggle(evt);
			},
			contextClick(evt) {
				proxy.hide(evt);
				prevent(evt);
				nextTick(() => {
					proxy.show(evt);
					evt.qAnchorHandled = true;
				});
			},
			prevent,
			mobileTouch(evt) {
				anchorEvents.mobileCleanup(evt);
				if (canShow(evt) !== true) return;
				proxy.hide(evt);
				anchorEl.value.classList.add("non-selectable");
				const target = evt.target;
				addEvt(anchorEvents, "anchor", [
					[
						target,
						"touchmove",
						"mobileCleanup",
						"passive"
					],
					[
						target,
						"touchend",
						"mobileCleanup",
						"passive"
					],
					[
						target,
						"touchcancel",
						"mobileCleanup",
						"passive"
					],
					[
						anchorEl.value,
						"contextmenu",
						"prevent",
						"notPassive"
					]
				]);
				touchTimer = setTimeout(() => {
					touchTimer = null;
					proxy.show(evt);
					evt.qAnchorHandled = true;
				}, 300);
			},
			mobileCleanup(evt) {
				anchorEl.value.classList.remove("non-selectable");
				if (touchTimer !== null) {
					clearTimeout(touchTimer);
					touchTimer = null;
				}
				if (showing.value === true && evt !== void 0) clearSelection();
			}
		});
		configureAnchorEl = function(context = props.contextMenu) {
			if (props.noParentEvent === true || anchorEl.value === null) return;
			let evts;
			if (context === true) if (proxy.$q.platform.is.mobile === true) evts = [[
				anchorEl.value,
				"touchstart",
				"mobileTouch",
				"passive"
			]];
			else evts = [[
				anchorEl.value,
				"mousedown",
				"hide",
				"passive"
			], [
				anchorEl.value,
				"contextmenu",
				"contextClick",
				"notPassive"
			]];
			else evts = [[
				anchorEl.value,
				"click",
				"toggle",
				"passive"
			], [
				anchorEl.value,
				"keyup",
				"toggleKey",
				"passive"
			]];
			addEvt(anchorEvents, "anchor", evts);
		};
	}
	function unconfigureAnchorEl() {
		cleanEvt(anchorEvents, "anchor");
	}
	function setAnchorEl(el) {
		anchorEl.value = el;
		while (anchorEl.value.classList.contains("q-anchor--skip")) anchorEl.value = anchorEl.value.parentNode;
		configureAnchorEl();
	}
	function pickAnchorEl() {
		if (props.target === false || props.target === "" || proxy.$el.parentNode === null) anchorEl.value = null;
		else if (props.target === true) setAnchorEl(proxy.$el.parentNode);
		else {
			let el = props.target;
			if (typeof props.target === "string") try {
				el = document.querySelector(props.target);
			} catch (err) {
				el = void 0;
			}
			if (el !== void 0 && el !== null) {
				anchorEl.value = el.$el || el;
				configureAnchorEl();
			} else {
				anchorEl.value = null;
				console.error(`Anchor: target "${props.target}" not found`);
			}
		}
	}
	watch(() => props.contextMenu, (val) => {
		if (anchorEl.value !== null) {
			unconfigureAnchorEl();
			configureAnchorEl(val);
		}
	});
	watch(() => props.target, () => {
		if (anchorEl.value !== null) unconfigureAnchorEl();
		pickAnchorEl();
	});
	watch(() => props.noParentEvent, (val) => {
		if (anchorEl.value !== null) if (val === true) unconfigureAnchorEl();
		else configureAnchorEl();
	});
	onMounted(() => {
		pickAnchorEl();
		if (avoidEmit !== true && props.modelValue === true && anchorEl.value === null) emit("update:modelValue", false);
	});
	onBeforeUnmount(() => {
		touchTimer !== null && clearTimeout(touchTimer);
		unconfigureAnchorEl();
	});
	return {
		anchorEl,
		canShow,
		anchorEvents
	};
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-scroll-target/use-scroll-target.js
function use_scroll_target_default(props, configureScrollTarget) {
	const localScrollTarget = ref(null);
	let scrollFn;
	function changeScrollEvent(scrollTarget, fn) {
		const fnProp = `${fn !== void 0 ? "add" : "remove"}EventListener`;
		const fnHandler = fn !== void 0 ? fn : scrollFn;
		if (scrollTarget !== window) scrollTarget[fnProp]("scroll", fnHandler, listenOpts.passive);
		window[fnProp]("scroll", fnHandler, listenOpts.passive);
		scrollFn = fn;
	}
	function unconfigureScrollTarget() {
		if (localScrollTarget.value !== null) {
			changeScrollEvent(localScrollTarget.value);
			localScrollTarget.value = null;
		}
	}
	onBeforeUnmount(watch(() => props.noParentEvent, () => {
		if (localScrollTarget.value !== null) {
			unconfigureScrollTarget();
			configureScrollTarget();
		}
	}));
	return {
		localScrollTarget,
		unconfigureScrollTarget,
		changeScrollEvent
	};
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-model-toggle/use-model-toggle.js
var useModelToggleProps = {
	modelValue: {
		type: Boolean,
		default: null
	},
	"onUpdate:modelValue": [Function, Array]
};
var useModelToggleEmits = [
	"beforeShow",
	"show",
	"beforeHide",
	"hide"
];
function use_model_toggle_default({ showing, canShow, hideOnRouteChange, handleShow, handleHide, processOnMount }) {
	const vm = getCurrentInstance();
	const { props, emit, proxy } = vm;
	let payload;
	function toggle(evt) {
		if (showing.value === true) hide(evt);
		else show(evt);
	}
	function show(evt) {
		if (props.disable === true || evt?.qAnchorHandled === true || canShow !== void 0 && canShow(evt) !== true) return;
		const listener = props["onUpdate:modelValue"] !== void 0;
		if (listener === true && true) {
			emit("update:modelValue", true);
			payload = evt;
			nextTick(() => {
				if (payload === evt) payload = void 0;
			});
		}
		if (props.modelValue === null || listener === false || false) processShow(evt);
	}
	function processShow(evt) {
		if (showing.value === true) return;
		showing.value = true;
		emit("beforeShow", evt);
		if (handleShow !== void 0) handleShow(evt);
		else emit("show", evt);
	}
	function hide(evt) {
		if (props.disable === true) return;
		const listener = props["onUpdate:modelValue"] !== void 0;
		if (listener === true && true) {
			emit("update:modelValue", false);
			payload = evt;
			nextTick(() => {
				if (payload === evt) payload = void 0;
			});
		}
		if (props.modelValue === null || listener === false || false) processHide(evt);
	}
	function processHide(evt) {
		if (showing.value === false) return;
		showing.value = false;
		emit("beforeHide", evt);
		if (handleHide !== void 0) handleHide(evt);
		else emit("hide", evt);
	}
	function processModelChange(val) {
		if (props.disable === true && val === true) {
			if (props["onUpdate:modelValue"] !== void 0) emit("update:modelValue", false);
		} else if (val === true !== showing.value) (val === true ? processShow : processHide)(payload);
	}
	watch(() => props.modelValue, processModelChange);
	if (hideOnRouteChange !== void 0 && vmHasRouter(vm) === true) watch(() => proxy.$route.fullPath, () => {
		if (hideOnRouteChange.value === true && showing.value === true) hide();
	});
	processOnMount === true && onMounted(() => {
		processModelChange(props.modelValue);
	});
	const publicMethods = {
		show,
		hide,
		toggle
	};
	Object.assign(proxy, publicMethods);
	return publicMethods;
}
//#endregion
//#region node_modules/quasar/src/utils/private.focus/focus-manager.js
var queue = [];
var waitFlags = [];
function clearFlag(flag) {
	waitFlags = waitFlags.filter((entry) => entry !== flag);
}
function addFocusWaitFlag(flag) {
	clearFlag(flag);
	waitFlags.push(flag);
}
function removeFocusWaitFlag(flag) {
	clearFlag(flag);
	if (waitFlags.length === 0 && queue.length !== 0) {
		queue[queue.length - 1]();
		queue = [];
	}
}
function addFocusFn(fn) {
	if (waitFlags.length === 0) fn();
	else queue.push(fn);
}
function removeFocusFn(fn) {
	queue = queue.filter((entry) => entry !== fn);
}
//#endregion
//#region node_modules/quasar/src/utils/private.portal/portal.js
var portalProxyList = [];
function closePortalMenus(proxy, evt) {
	do {
		if (proxy.$options.name === "QMenu") {
			proxy.hide(evt);
			if (proxy.$props.separateClosePopup === true) return getParentProxy(proxy);
		} else if (proxy.__qPortal === true) {
			const parent = getParentProxy(proxy);
			if (parent?.$options.name === "QPopupProxy") {
				proxy.hide(evt);
				return parent;
			} else return proxy;
		}
		proxy = getParentProxy(proxy);
	} while (proxy !== void 0 && proxy !== null);
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-portal/use-portal.js
/**
* Noop internal component to ease testing
* of the teleported content.
*
* const wrapper = mount(QDialog, { ... })
* const teleportedWrapper = wrapper.findComponent({ name: 'QPortal' })
*/
var QPortal = createComponent({
	name: "QPortal",
	setup(_, { slots }) {
		return () => slots.default();
	}
});
function isOnGlobalDialog(vm) {
	vm = vm.parent;
	while (vm !== void 0 && vm !== null) {
		if (vm.type.name === "QGlobalDialog") return true;
		if (vm.type.name === "QDialog" || vm.type.name === "QMenu") return false;
		vm = vm.parent;
	}
	return false;
}
function use_portal_default(vm, innerRef, renderPortalContent, type) {
	const portalIsActive = ref(false);
	const portalIsAccessible = ref(false);
	let portalEl = null;
	const focusObj = {};
	const onGlobalDialog = type === "dialog" && isOnGlobalDialog(vm);
	function showPortal(isReady) {
		if (isReady === true) {
			removeFocusWaitFlag(focusObj);
			portalIsAccessible.value = true;
			return;
		}
		portalIsAccessible.value = false;
		if (portalIsActive.value === false) {
			if (onGlobalDialog === false && portalEl === null) portalEl = createGlobalNode(false, type);
			portalIsActive.value = true;
			portalProxyList.push(vm.proxy);
			addFocusWaitFlag(focusObj);
		}
	}
	function hidePortal(isReady) {
		portalIsAccessible.value = false;
		if (isReady !== true) return;
		removeFocusWaitFlag(focusObj);
		portalIsActive.value = false;
		const index = portalProxyList.indexOf(vm.proxy);
		if (index !== -1) portalProxyList.splice(index, 1);
		if (portalEl !== null) {
			removeGlobalNode(portalEl);
			portalEl = null;
		}
	}
	onUnmounted(() => {
		hidePortal(true);
	});
	vm.proxy.__qPortal = true;
	injectProp(vm.proxy, "contentEl", () => innerRef.value);
	return {
		showPortal,
		hidePortal,
		portalIsActive,
		portalIsAccessible,
		renderPortal: () => onGlobalDialog === true ? renderPortalContent() : portalIsActive.value === true ? [h(Teleport, { to: portalEl }, h(QPortal, renderPortalContent))] : void 0
	};
}
//#endregion
//#region node_modules/quasar/src/composables/private.use-transition/use-transition.js
var useTransitionProps = {
	transitionShow: {
		type: String,
		default: "fade"
	},
	transitionHide: {
		type: String,
		default: "fade"
	},
	transitionDuration: {
		type: [String, Number],
		default: 300
	}
};
function use_transition_default(props, defaultShowFn = () => {}, defaultHideFn = () => {}) {
	return {
		transitionProps: computed(() => {
			const show = `q-transition--${props.transitionShow || defaultShowFn()}`;
			const hide = `q-transition--${props.transitionHide || defaultHideFn()}`;
			return {
				appear: true,
				enterFromClass: `${show}-enter-from`,
				enterActiveClass: `${show}-enter-active`,
				enterToClass: `${show}-enter-to`,
				leaveFromClass: `${hide}-leave-from`,
				leaveActiveClass: `${hide}-leave-active`,
				leaveToClass: `${hide}-leave-to`
			};
		}),
		transitionStyle: computed(() => `--q-transition-duration: ${props.transitionDuration}ms`)
	};
}
//#endregion
//#region node_modules/quasar/src/composables/use-tick/use-tick.js
function use_tick_default() {
	let tickFn;
	const vm = getCurrentInstance();
	function removeTick() {
		tickFn = void 0;
	}
	onDeactivated(removeTick);
	onBeforeUnmount(removeTick);
	return {
		removeTick,
		registerTick(fn) {
			tickFn = fn;
			nextTick(() => {
				if (tickFn === fn) {
					vmIsDestroyed(vm) === false && tickFn();
					tickFn = void 0;
				}
			});
		}
	};
}
//#endregion
//#region node_modules/quasar/src/composables/use-timeout/use-timeout.js
function use_timeout_default() {
	let timer = null;
	const vm = getCurrentInstance();
	function removeTimeout() {
		if (timer !== null) {
			clearTimeout(timer);
			timer = null;
		}
	}
	onDeactivated(removeTimeout);
	onBeforeUnmount(removeTimeout);
	return {
		removeTimeout,
		registerTimeout(fn, delay) {
			removeTimeout();
			if (vmIsDestroyed(vm) === false) timer = setTimeout(() => {
				timer = null;
				fn();
			}, delay);
		}
	};
}
//#endregion
//#region node_modules/quasar/src/utils/private.click-outside/click-outside.js
var timer = null;
var { notPassiveCapture } = listenOpts, registeredList = [];
function globalHandler(evt) {
	if (timer !== null) {
		clearTimeout(timer);
		timer = null;
	}
	const target = evt.target;
	if (target === void 0 || target.nodeType === 8 || target.classList.contains("no-pointer-events") === true) return;
	let portalIndex = portalProxyList.length - 1;
	while (portalIndex >= 0) {
		const proxy = portalProxyList[portalIndex].$;
		if (proxy.type.name === "QTooltip") {
			portalIndex--;
			continue;
		}
		if (proxy.type.name !== "QDialog") break;
		if (proxy.props.seamless !== true) return;
		portalIndex--;
	}
	for (let i = registeredList.length - 1; i >= 0; i--) {
		const state = registeredList[i];
		if ((state.anchorEl.value === null || state.anchorEl.value.contains(target) === false) && (target === document.body || state.innerRef.value !== null && state.innerRef.value.contains(target) === false)) {
			evt.qClickOutside = true;
			state.onClickOutside(evt);
		} else return;
	}
}
function addClickOutside(clickOutsideProps) {
	registeredList.push(clickOutsideProps);
	if (registeredList.length === 1) {
		document.addEventListener("mousedown", globalHandler, notPassiveCapture);
		document.addEventListener("touchstart", globalHandler, notPassiveCapture);
	}
}
function removeClickOutside(clickOutsideProps) {
	const index = registeredList.findIndex((h) => h === clickOutsideProps);
	if (index !== -1) {
		registeredList.splice(index, 1);
		if (registeredList.length === 0) {
			if (timer !== null) {
				clearTimeout(timer);
				timer = null;
			}
			document.removeEventListener("mousedown", globalHandler, notPassiveCapture);
			document.removeEventListener("touchstart", globalHandler, notPassiveCapture);
		}
	}
}
//#endregion
//#region node_modules/quasar/src/utils/private.position-engine/position-engine.js
var vpLeft, vpTop;
function validatePosition(pos) {
	const parts = pos.split(" ");
	if (parts.length !== 2) return false;
	if ([
		"top",
		"center",
		"bottom"
	].includes(parts[0]) !== true) {
		console.error("Anchor/Self position must start with one of top/center/bottom");
		return false;
	}
	if ([
		"left",
		"middle",
		"right",
		"start",
		"end"
	].includes(parts[1]) !== true) {
		console.error("Anchor/Self position must end with one of left/middle/right/start/end");
		return false;
	}
	return true;
}
function validateOffset(val) {
	if (!val) return true;
	if (val.length !== 2) return false;
	if (typeof val[0] !== "number" || typeof val[1] !== "number") return false;
	return true;
}
var horizontalPos = {
	"start#ltr": "left",
	"start#rtl": "right",
	"end#ltr": "right",
	"end#rtl": "left"
};
[
	"left",
	"middle",
	"right"
].forEach((pos) => {
	horizontalPos[`${pos}#ltr`] = pos;
	horizontalPos[`${pos}#rtl`] = pos;
});
function parsePosition(pos, rtl) {
	const parts = pos.split(" ");
	return {
		vertical: parts[0],
		horizontal: horizontalPos[`${parts[1]}#${rtl === true ? "rtl" : "ltr"}`]
	};
}
function getAnchorProps(el, offset) {
	let { top, left, right, bottom, width, height } = el.getBoundingClientRect();
	if (offset !== void 0) {
		top -= offset[1];
		left -= offset[0];
		bottom += offset[1];
		right += offset[0];
		width += offset[0];
		height += offset[1];
	}
	return {
		top,
		bottom,
		height,
		left,
		right,
		width,
		middle: left + (right - left) / 2,
		center: top + (bottom - top) / 2
	};
}
function getAbsoluteAnchorProps(el, absoluteOffset, offset) {
	let { top, left } = el.getBoundingClientRect();
	top += absoluteOffset.top;
	left += absoluteOffset.left;
	if (offset !== void 0) {
		top += offset[1];
		left += offset[0];
	}
	return {
		top,
		bottom: top + 1,
		height: 1,
		left,
		right: left + 1,
		width: 1,
		middle: left,
		center: top
	};
}
function getTargetProps(width, height) {
	return {
		top: 0,
		center: height / 2,
		bottom: height,
		left: 0,
		middle: width / 2,
		right: width
	};
}
function getTopLeftProps(anchorProps, targetProps, anchorOrigin, selfOrigin) {
	return {
		top: anchorProps[anchorOrigin.vertical] - targetProps[selfOrigin.vertical],
		left: anchorProps[anchorOrigin.horizontal] - targetProps[selfOrigin.horizontal]
	};
}
function setPosition(cfg, retryNumber = 0) {
	if (cfg.targetEl === null || cfg.anchorEl === null || retryNumber > 5) return;
	if (cfg.targetEl.offsetHeight === 0 || cfg.targetEl.offsetWidth === 0) {
		setTimeout(() => {
			setPosition(cfg, retryNumber + 1);
		}, 10);
		return;
	}
	const { targetEl, offset, anchorEl, anchorOrigin, selfOrigin, absoluteOffset, fit, cover, maxHeight, maxWidth } = cfg;
	if (client.is.ios === true && window.visualViewport !== void 0) {
		const el = document.body.style;
		const { offsetLeft: left, offsetTop: top } = window.visualViewport;
		if (left !== vpLeft) {
			el.setProperty("--q-pe-left", left + "px");
			vpLeft = left;
		}
		if (top !== vpTop) {
			el.setProperty("--q-pe-top", top + "px");
			vpTop = top;
		}
	}
	const { scrollLeft, scrollTop } = targetEl;
	const anchorProps = absoluteOffset === void 0 ? getAnchorProps(anchorEl, cover === true ? [0, 0] : offset) : getAbsoluteAnchorProps(anchorEl, absoluteOffset, offset);
	/**
	* We "reset" the critical CSS properties
	* so we can take an accurate measurement.
	*
	* Ensure that targetEl has a max-width & max-height
	* set in CSS and that the value does NOT exceeds 100vw/vh.
	* All users of the position-engine (currently QMenu & QTooltip)
	* have CSS for this.
	*/
	Object.assign(targetEl.style, {
		top: 0,
		left: 0,
		minWidth: null,
		minHeight: null,
		maxWidth,
		maxHeight,
		visibility: "visible"
	});
	const { offsetWidth: origElWidth, offsetHeight: origElHeight } = targetEl;
	const { elWidth, elHeight } = fit === true || cover === true ? {
		elWidth: Math.max(anchorProps.width, origElWidth),
		elHeight: cover === true ? Math.max(anchorProps.height, origElHeight) : origElHeight
	} : {
		elWidth: origElWidth,
		elHeight: origElHeight
	};
	let elStyle = {
		maxWidth,
		maxHeight
	};
	if (fit === true || cover === true) {
		elStyle.minWidth = anchorProps.width + "px";
		if (cover === true) elStyle.minHeight = anchorProps.height + "px";
	}
	Object.assign(targetEl.style, elStyle);
	const targetProps = getTargetProps(elWidth, elHeight);
	let props = getTopLeftProps(anchorProps, targetProps, anchorOrigin, selfOrigin);
	if (absoluteOffset === void 0 || offset === void 0) applyBoundaries(props, anchorProps, targetProps, anchorOrigin, selfOrigin);
	else {
		const { top, left } = props;
		applyBoundaries(props, anchorProps, targetProps, anchorOrigin, selfOrigin);
		let hasChanged = false;
		if (props.top !== top) {
			hasChanged = true;
			const offsetY = 2 * offset[1];
			anchorProps.center = anchorProps.top -= offsetY;
			anchorProps.bottom -= offsetY + 2;
		}
		if (props.left !== left) {
			hasChanged = true;
			const offsetX = 2 * offset[0];
			anchorProps.middle = anchorProps.left -= offsetX;
			anchorProps.right -= offsetX + 2;
		}
		if (hasChanged === true) {
			props = getTopLeftProps(anchorProps, targetProps, anchorOrigin, selfOrigin);
			applyBoundaries(props, anchorProps, targetProps, anchorOrigin, selfOrigin);
		}
	}
	elStyle = {
		top: props.top + "px",
		left: props.left + "px"
	};
	if (props.maxHeight !== void 0) {
		elStyle.maxHeight = props.maxHeight + "px";
		if (anchorProps.height > props.maxHeight) elStyle.minHeight = elStyle.maxHeight;
	}
	if (props.maxWidth !== void 0) {
		elStyle.maxWidth = props.maxWidth + "px";
		if (anchorProps.width > props.maxWidth) elStyle.minWidth = elStyle.maxWidth;
	}
	Object.assign(targetEl.style, elStyle);
	if (targetEl.scrollTop !== scrollTop) targetEl.scrollTop = scrollTop;
	if (targetEl.scrollLeft !== scrollLeft) targetEl.scrollLeft = scrollLeft;
}
function applyBoundaries(props, anchorProps, targetProps, anchorOrigin, selfOrigin) {
	const currentHeight = targetProps.bottom, currentWidth = targetProps.right, margin = getScrollbarWidth(), innerHeight = window.innerHeight - margin, innerWidth = document.body.clientWidth;
	if (props.top < 0 || props.top + currentHeight > innerHeight) if (selfOrigin.vertical === "center") {
		props.top = anchorProps[anchorOrigin.vertical] > innerHeight / 2 ? Math.max(0, innerHeight - currentHeight) : 0;
		props.maxHeight = Math.min(currentHeight, innerHeight);
	} else if (anchorProps[anchorOrigin.vertical] > innerHeight / 2) {
		const anchorY = Math.min(innerHeight, anchorOrigin.vertical === "center" ? anchorProps.center : anchorOrigin.vertical === selfOrigin.vertical ? anchorProps.bottom : anchorProps.top);
		props.maxHeight = Math.min(currentHeight, anchorY);
		props.top = Math.max(0, anchorY - currentHeight);
	} else {
		props.top = Math.max(0, anchorOrigin.vertical === "center" ? anchorProps.center : anchorOrigin.vertical === selfOrigin.vertical ? anchorProps.top : anchorProps.bottom);
		props.maxHeight = Math.min(currentHeight, innerHeight - props.top);
	}
	if (props.left < 0 || props.left + currentWidth > innerWidth) {
		props.maxWidth = Math.min(currentWidth, innerWidth);
		if (selfOrigin.horizontal === "middle") props.left = anchorProps[anchorOrigin.horizontal] > innerWidth / 2 ? Math.max(0, innerWidth - currentWidth) : 0;
		else if (anchorProps[anchorOrigin.horizontal] > innerWidth / 2) {
			const anchorX = Math.min(innerWidth, anchorOrigin.horizontal === "middle" ? anchorProps.middle : anchorOrigin.horizontal === selfOrigin.horizontal ? anchorProps.right : anchorProps.left);
			props.maxWidth = Math.min(currentWidth, anchorX);
			props.left = Math.max(0, anchorX - props.maxWidth);
		} else {
			props.left = Math.max(0, anchorOrigin.horizontal === "middle" ? anchorProps.middle : anchorOrigin.horizontal === selfOrigin.horizontal ? anchorProps.left : anchorProps.right);
			props.maxWidth = Math.min(currentWidth, innerWidth - props.left);
		}
	}
}
//#endregion
export { clearSelection as S, use_model_toggle_default as _, addClickOutside as a, useAnchorStaticProps as b, use_tick_default as c, use_portal_default as d, closePortalMenus as f, useModelToggleProps as g, useModelToggleEmits as h, validatePosition as i, useTransitionProps as l, removeFocusFn as m, setPosition as n, removeClickOutside as o, addFocusFn as p, validateOffset as r, use_timeout_default as s, parsePosition as t, use_transition_default as u, use_scroll_target_default as v, use_anchor_default as x, useAnchorProps as y };
