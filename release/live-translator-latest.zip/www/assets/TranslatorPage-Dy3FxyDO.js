import { $ as toDisplayString, A as openBlock, D as onMounted, E as onDeactivated, F as withCtx, I as withDirectives, M as renderList, O as onUnmounted, P as watch, Q as normalizeStyle, S as onActivated, W as ref, X as unref, Z as normalizeClass, _ as getCurrentInstance, b as inject, d as createBlock, f as createCommentVNode, g as defineComponent, h as createVNode, j as provide, l as computed, m as createTextVNode, o as Fragment, p as createElementBlock, q as toRaw, u as createBaseVNode, v as h, w as onBeforeUnmount, x as nextTick } from "./vue.runtime.esm-bundler-Da8D7169.js";
import { _ as preventDraggable, a as hMergeSlot, b as createComponent, f as leftClick, g as prevent, h as position, i as hDir, l as addEvt, m as noop, s as hSlot, u as cleanEvt, v as stop, x as createDirective, y as stopAndPrevent } from "./dom-DvzD_91u.js";
import { n as fabKey, s as client } from "./symbols-dSu0xIJX.js";
import { i as QIcon_default, o as useSizeProps, s as use_size_default } from "./vm-BOuecwlZ.js";
import { _ as debounce_default, d as storeToRefs, h as isObject, l as QSpinner_default, m as isNumber, o as useAlignProps, r as QBtn_default, s as use_align_default, u as defineStore } from "./index-DRZOEVCp.js";
import { n as useI18n } from "./vue-i18n.runtime-9cAkLvsS.js";
import { c as setHorizontalScrollPosition, l as setVerticalScrollPosition, t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Ca_i4E4D.js";
import { n as QScrollObserver_default, t as QResizeObserver_default } from "./QResizeObserver-B_cyRWeX.js";
import { C as QPage_default, S as clearSelection, _ as use_model_toggle_default, g as useModelToggleProps, h as useModelToggleEmits } from "./position-engine-DsV-rayo.js";
import { t as QTooltip_default } from "./QTooltip-D-Ofb-TG.js";
import { a as SUPPORTED_LANGUAGES, b as QBadge_default, c as between, d as QInput_default, f as useFormAttrs, g as QSeparator_default, h as use_id_default, i as DEFAULT_SETTINGS, l as QDialog_default, m as useFormProps, n as normalizeSpeakerNames, o as TTS_VOICES, p as useFormInject, r as resolveSpeakerLabel, s as QSelect_default, t as useSettingsStore, u as QBanner_default, v as useDarkProps, y as use_dark_default } from "./settings-store-CY9p4di7.js";
//#region src/stores/translator-store.ts
var useTranslatorStore = defineStore("translator", () => {
	const isActive = ref(false);
	const recordingState = ref("idle");
	const entries = ref([]);
	const activeTargetLanguage = ref(DEFAULT_SETTINGS.targetLanguage);
	const error = ref(null);
	const currentTab = ref({
		speakerId: null,
		original: "",
		translation: "",
		audioSource: "tab"
	});
	const currentMic = ref({
		speakerId: null,
		original: "",
		translation: "",
		audioSource: "mic"
	});
	const currentSpeakerId = computed(() => currentTab.value.speakerId ?? currentMic.value.speakerId);
	const currentOriginal = computed(() => currentTab.value.original || currentMic.value.original);
	const currentTranslation = computed(() => currentTab.value.translation || currentMic.value.translation);
	const isRecording = computed(() => recordingState.value === "recording");
	const isConnecting = computed(() => recordingState.value === "starting" || recordingState.value === "connecting");
	const hasError = computed(() => recordingState.value === "error");
	const canStart = computed(() => recordingState.value === "idle" || recordingState.value === "stopped" || recordingState.value === "error" || recordingState.value === "canceled");
	function addEntry(entry) {
		entries.value.push(entry);
	}
	function updateCurrentTokens(speakerId, original, translation, audioSource = "tab") {
		const target = audioSource === "mic" ? currentMic : currentTab;
		target.value = {
			speakerId,
			original,
			translation,
			audioSource
		};
	}
	function finalizeCurrent(speakerId, audioSource = "tab") {
		const target = audioSource === "mic" ? currentMic : currentTab;
		const current = target.value;
		const resolvedSpeakerId = speakerId ?? current.speakerId;
		if (!current.original && !current.translation || !resolvedSpeakerId) return;
		const entry = {
			id: crypto.randomUUID(),
			timestamp: Date.now(),
			speakerId: resolvedSpeakerId,
			originalText: current.original,
			translatedText: current.translation,
			sourceLanguage: "",
			targetLanguage: activeTargetLanguage.value,
			isFinal: true,
			audioSource
		};
		entries.value.push(entry);
		target.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource
		};
	}
	function clearEntries() {
		entries.value = [];
		currentTab.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "tab"
		};
		currentMic.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "mic"
		};
	}
	function setRecordingState(state) {
		recordingState.value = state;
		isActive.value = state === "recording" || state === "starting" || state === "connecting" || state === "paused";
	}
	function setError(message) {
		error.value = message;
		if (message) recordingState.value = "error";
	}
	function setTargetLanguage(targetLanguage) {
		activeTargetLanguage.value = targetLanguage;
	}
	function reset() {
		isActive.value = false;
		recordingState.value = "idle";
		entries.value = [];
		currentTab.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "tab"
		};
		currentMic.value = {
			speakerId: null,
			original: "",
			translation: "",
			audioSource: "mic"
		};
		activeTargetLanguage.value = DEFAULT_SETTINGS.targetLanguage;
		error.value = null;
	}
	return {
		isActive,
		recordingState,
		entries,
		currentSpeakerId,
		currentOriginal,
		currentTranslation,
		currentTab,
		currentMic,
		error,
		isRecording,
		isConnecting,
		hasError,
		canStart,
		addEntry,
		updateCurrentTokens,
		finalizeCurrent,
		setTargetLanguage,
		clearEntries,
		setRecordingState,
		setError,
		reset
	};
});
//#endregion
//#region node_modules/@soniox/client/dist/index.mjs
var SonioxError = class extends Error {
	/**
	* Error code describing the type of error.
	* Typed as `string` at the base level to allow subclasses (e.g. HTTP errors)
	* to use their own error code unions.
	*/
	code;
	/**
	* HTTP status code when applicable (e.g., 401 for auth errors, 500 for server errors).
	*/
	statusCode;
	/**
	* The underlying error that caused this error, if any.
	*/
	cause;
	constructor(message, code = "soniox_error", statusCode, cause) {
		super(message);
		this.name = "SonioxError";
		this.code = code;
		this.statusCode = statusCode;
		this.cause = cause;
		if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
		Object.setPrototypeOf(this, new.target.prototype);
	}
	/**
	* Creates a human-readable string representation
	*/
	toString() {
		const parts = [`${this.name} [${this.code}]: ${this.message}`];
		if (this.statusCode !== void 0) parts.push(`  Status: ${this.statusCode}`);
		return parts.join("\n");
	}
	/**
	* Converts to a plain object for logging/serialization
	*/
	toJSON() {
		return {
			name: this.name,
			code: this.code,
			message: this.message,
			...this.statusCode !== void 0 && { statusCode: this.statusCode }
		};
	}
};
/**
* Generic async event queue that supports iteration with proper error propagation.
*
* This utility enables `for await...of` consumption of events while properly
* surfacing errors to consumers instead of silently ending iteration.
*/
var AsyncEventQueue = class {
	queue = [];
	waiters = [];
	done = false;
	error = null;
	/**
	* Push an event to the queue.
	* If there are waiting consumers, delivers immediately.
	*/
	push(event) {
		if (this.done) return;
		const waiter = this.waiters.shift();
		if (waiter) waiter.resolve({
			value: event,
			done: false
		});
		else this.queue.push(event);
	}
	/**
	* End the queue normally.
	* Waiting consumers will receive `{ done: true }`.
	*/
	end() {
		if (this.done) return;
		this.done = true;
		this.flushWaiters();
	}
	/**
	* End the queue with an error.
	* Waiting consumers will have their promises rejected.
	* Future `next()` calls will also reject with this error.
	* Any queued events are discarded.
	*/
	abort(error) {
		if (this.done) return;
		this.done = true;
		this.error = error;
		this.queue = [];
		this.flushWaiters();
	}
	/**
	* Whether the queue has ended (normally or with error).
	*/
	get isDone() {
		return this.done;
	}
	/**
	* Async iterator implementation.
	*/
	[Symbol.asyncIterator]() {
		return { next: () => this.next() };
	}
	/**
	* Get the next event from the queue.
	*/
	next() {
		const error = this.error;
		if (error) return Promise.reject(error);
		const event = this.queue.shift();
		if (event !== void 0) return Promise.resolve({
			value: event,
			done: false
		});
		if (this.done) return Promise.resolve({
			value: void 0,
			done: true
		});
		return new Promise((resolve, reject) => {
			this.waiters.push({
				resolve,
				reject
			});
		});
	}
	/**
	* Flush all waiting consumers when queue ends.
	*/
	flushWaiters() {
		for (const { resolve, reject } of this.waiters) if (this.error) reject(this.error);
		else resolve({
			value: void 0,
			done: true
		});
		this.waiters = [];
	}
};
/**
* A minimal, runtime-agnostic typed event emitter.
* Does not depend on Node.js EventEmitter.
*/
var TypedEmitter = class {
	listeners = /* @__PURE__ */ new Map();
	errorEvent = "error";
	/**
	* Register an event handler.
	*/
	on(event, handler) {
		let handlers = this.listeners.get(event);
		if (!handlers) {
			handlers = /* @__PURE__ */ new Set();
			this.listeners.set(event, handlers);
		}
		handlers.add(handler);
		return this;
	}
	/**
	* Register a one-time event handler.
	*/
	once(event, handler) {
		const wrapper = ((...args) => {
			this.off(event, wrapper);
			handler(...args);
		});
		return this.on(event, wrapper);
	}
	/**
	* Remove an event handler.
	*/
	off(event, handler) {
		const handlers = this.listeners.get(event);
		if (handlers) {
			handlers.delete(handler);
			if (handlers.size === 0) this.listeners.delete(event);
		}
		return this;
	}
	/**
	* Emit an event to all registered handlers.
	* Handler errors do not prevent other handlers from running.
	* Errors are reported to an `error` event if present, otherwise rethrown async.
	*/
	emit(event, ...args) {
		const handlers = this.listeners.get(event);
		if (handlers) for (const handler of [...handlers]) try {
			handler(...args);
		} catch (error) {
			if (event === this.errorEvent) this.scheduleThrow(this.normalizeError(error));
			else this.reportListenerError(error);
		}
	}
	/**
	* Remove all event handlers.
	*/
	removeAllListeners(event) {
		if (event !== void 0) this.listeners.delete(event);
		else this.listeners.clear();
	}
	reportListenerError(error) {
		const normalizedError = this.normalizeError(error);
		const handlers = this.listeners.get(this.errorEvent);
		if (!handlers || handlers.size === 0) {
			this.scheduleThrow(normalizedError);
			return;
		}
		for (const handler of [...handlers]) try {
			handler(normalizedError);
		} catch (handlerError) {
			this.scheduleThrow(this.normalizeError(handlerError));
		}
	}
	normalizeError(error) {
		if (error instanceof Error) return error;
		return new Error(String(error));
	}
	scheduleThrow(error) {
		setTimeout(() => {
			throw error;
		}, 0);
	}
};
/**
* Real-time (WebSocket) API error classes for the Soniox SDK
* All real-time errors extend SonioxError
*/
/**
* Base error class for all real-time (WebSocket) SDK errors
*/
var RealtimeError = class extends SonioxError {
	/**
	* Original response payload for debugging.
	* Contains the raw WebSocket message that caused the error.
	*/
	raw;
	constructor(message, code = "realtime_error", statusCode, raw) {
		super(message, code, statusCode);
		this.name = "RealtimeError";
		this.raw = raw;
	}
	/**
	* Creates a human-readable string representation
	*/
	toString() {
		const parts = [`${this.name} [${this.code}]: ${this.message}`];
		if (this.statusCode !== void 0) parts.push(`  Status: ${this.statusCode}`);
		return parts.join("\n");
	}
	/**
	* Converts to a plain object for logging/serialization
	*/
	toJSON() {
		return {
			name: this.name,
			code: this.code,
			message: this.message,
			...this.statusCode !== void 0 && { statusCode: this.statusCode },
			...this.raw !== void 0 && { raw: this.raw }
		};
	}
};
/**
* Authentication error (401).
* Thrown when the API key is invalid or expired.
*/
var AuthError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "auth_error", statusCode, raw);
		this.name = "AuthError";
	}
};
/**
* Bad request error (400).
* Thrown for invalid configuration or parameters.
*/
var BadRequestError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "bad_request", statusCode, raw);
		this.name = "BadRequestError";
	}
};
/**
* Quota error (402, 429).
* Thrown when rate limits are exceeded or quota is exhausted.
*/
var QuotaError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "quota_exceeded", statusCode, raw);
		this.name = "QuotaError";
	}
};
/**
* Connection error.
* Thrown for WebSocket connection failures and transport errors.
*/
var ConnectionError = class extends RealtimeError {
	constructor(message, raw) {
		super(message, "connection_error", void 0, raw);
		this.name = "ConnectionError";
	}
};
/**
* Network error.
* Thrown for server-side network issues (408, 500, 503).
*/
var NetworkError = class extends RealtimeError {
	constructor(message, statusCode, raw) {
		super(message, "network_error", statusCode, raw);
		this.name = "NetworkError";
	}
};
/**
* Abort error.
* Thrown when an operation is cancelled via AbortSignal.
*/
var AbortError = class extends RealtimeError {
	constructor(message = "Operation aborted") {
		super(message, "aborted");
		this.name = "AbortError";
	}
};
/**
* State error.
* Thrown when an operation is attempted in an invalid state.
*/
var StateError = class extends RealtimeError {
	constructor(message) {
		super(message, "state_error");
		this.name = "StateError";
	}
};
/**
* Map a Soniox error response to a typed error class.
*
* @param response - Error response from the WebSocket
* @returns Appropriate error subclass
*/
function mapErrorResponse(response) {
	const { error_code, error_message } = response;
	const message = error_message ?? "Unknown error";
	switch (error_code) {
		case 401: return new AuthError(message, error_code, response);
		case 400: return new BadRequestError(message, error_code, response);
		case 402:
		case 429: return new QuotaError(message, error_code, response);
		case 408:
		case 500:
		case 503: return new NetworkError(message, error_code, response);
		default: return new RealtimeError(message, "realtime_error", error_code, response);
	}
}
var DEFAULT_KEEPALIVE_INTERVAL_MS = 5e3;
var MIN_KEEPALIVE_INTERVAL_MS = 1e3;
/**
* Convert audio data to Uint8Array
* Handles Uint8Array and ArrayBuffer
*/
function toUint8Array(data) {
	if (data instanceof ArrayBuffer) return new Uint8Array(data);
	return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
}
/**
* Build the configuration message to send after WebSocket connection
*/
function buildConfigMessage(config, apiKey) {
	return {
		api_key: apiKey,
		model: config.model,
		audio_format: config.audio_format ?? "auto",
		sample_rate: config.sample_rate,
		num_channels: config.num_channels,
		language_hints: config.language_hints,
		language_hints_strict: config.language_hints_strict,
		enable_speaker_diarization: config.enable_speaker_diarization,
		enable_language_identification: config.enable_language_identification,
		enable_endpoint_detection: config.enable_endpoint_detection,
		client_reference_id: config.client_reference_id,
		max_endpoint_delay_ms: config.max_endpoint_delay_ms,
		context: config.context,
		translation: config.translation
	};
}
/**
* Parse a result message from the WebSocket
*/
function parseResultMessage(data) {
	const raw = JSON.parse(data);
	if ("error_code" in raw || "error_message" in raw) throw mapErrorResponse(raw);
	return {
		tokens: (raw.tokens ?? []).map((t) => ({
			text: typeof t.text === "string" ? t.text : "",
			start_ms: typeof t.start_ms === "number" ? t.start_ms : void 0,
			end_ms: typeof t.end_ms === "number" ? t.end_ms : void 0,
			confidence: typeof t.confidence === "number" ? t.confidence : 0,
			is_final: Boolean(t.is_final),
			speaker: typeof t.speaker === "string" ? t.speaker : void 0,
			language: typeof t.language === "string" ? t.language : void 0,
			translation_status: t.translation_status === "none" || t.translation_status === "original" || t.translation_status === "translation" ? t.translation_status : void 0,
			source_language: typeof t.source_language === "string" ? t.source_language : void 0
		})),
		final_audio_proc_ms: typeof raw.final_audio_proc_ms === "number" ? raw.final_audio_proc_ms : 0,
		total_audio_proc_ms: typeof raw.total_audio_proc_ms === "number" ? raw.total_audio_proc_ms : 0,
		finished: raw.finished === true,
		raw
	};
}
/**
* Check if a token is a special control token
*/
function isSpecialToken(text) {
	return text === "<end>" || text === "<fin>";
}
/**
* Filter out special control tokens from tokens array
*/
function filterSpecialTokens(tokens) {
	return tokens.filter((t) => !isSpecialToken(t.text));
}
/**
* Real-time Speech-to-Text session
*
* Provides WebSocket-based streaming transcription with support for:
* - Event-based and async iterator consumption
* - Pause/resume with automatic keepalive while paused
* - AbortSignal cancellation
*
* @example
* ```typescript
* const session = new RealtimeSttSession(apiKey, wsUrl, { model: 'stt-rt-v4' });
*
* session.on('result', (result) => {
*   console.log(result.tokens.map(t => t.text).join(''));
* });
*
* await session.connect();
* session.sendAudio(audioChunk);
* await session.finish();
* ```
*/
var RealtimeSttSession = class {
	emitter = new TypedEmitter();
	eventQueue = new AsyncEventQueue();
	apiKey;
	wsBaseUrl;
	config;
	keepaliveIntervalMs;
	signal;
	ws = null;
	_state = "idle";
	_paused = false;
	_pauseWarned = false;
	keepaliveInterval = null;
	finishResolver = null;
	finishRejecter = null;
	abortHandler = null;
	constructor(apiKey, wsBaseUrl, config, options) {
		this.apiKey = apiKey;
		this.wsBaseUrl = wsBaseUrl;
		this.config = config;
		const keepaliveMs = options?.keepalive_interval_ms ?? DEFAULT_KEEPALIVE_INTERVAL_MS;
		this.keepaliveIntervalMs = Number.isFinite(keepaliveMs) && keepaliveMs > 0 ? Math.max(keepaliveMs, MIN_KEEPALIVE_INTERVAL_MS) : DEFAULT_KEEPALIVE_INTERVAL_MS;
		this.signal = options?.signal;
		if (this.signal) {
			this.abortHandler = () => this.handleAbort();
			this.signal.addEventListener("abort", this.abortHandler);
		}
	}
	/**
	* Current session state.
	*/
	get state() {
		return this._state;
	}
	/**
	* Whether the session is currently paused.
	*/
	get paused() {
		return this._paused;
	}
	/**
	* Connect to the Soniox WebSocket API.
	*
	* @throws {@link AbortError} If aborted
	* @throws {@link ConnectionError} If connection fails
	* @throws {@link StateError} If already connected
	*/
	async connect() {
		if (this._state !== "idle") throw new StateError(`Cannot connect: session is in "${this._state}" state`);
		this.checkAborted();
		this.setState("connecting");
		try {
			await this.createWebSocket();
			this.setState("connected");
			this.emitter.emit("connected");
			this.updateKeepalive();
		} catch (error) {
			if (!this.isTerminalState(this._state)) {
				const err = error instanceof Error ? error : new ConnectionError("Connection failed", error);
				this.cleanup("error", err);
			}
			throw error;
		}
	}
	/**
	* Send audio data to the server
	*
	* @param data - Audio data as Uint8Array or ArrayBuffer
	* @throws {@link AbortError} If aborted
	* @throws {@link StateError} If not connected
	*/
	sendAudio(data) {
		this.checkAborted();
		if (this._state !== "connected") throw new StateError(`Cannot send audio: session is in "${this._state}" state`);
		if (this._paused) return;
		const chunk = toUint8Array(data);
		this.sendMessage(chunk, true);
	}
	/**
	* Stream audio data from an async iterable source.
	*
	* @param stream - Async iterable yielding audio chunks
	* @param options - Optional pacing and auto-finish settings
	* @throws {@link AbortError} If aborted during streaming
	* @throws {@link StateError} If not connected
	*/
	async sendStream(stream, options) {
		for await (const chunk of stream) {
			this.sendAudio(chunk);
			if (options?.pace_ms) await new Promise((resolve) => setTimeout(resolve, options.pace_ms));
		}
		if (options?.finish) await this.finish();
	}
	/**
	* Pause audio transmission and starts automatic keepalive messages
	*/
	pause() {
		if (this._paused) return;
		this._paused = true;
		this.finalize();
		if (!this._pauseWarned && typeof process !== "undefined" && false);
		this.updateKeepalive();
	}
	/**
	* Resume audio transmission
	*/
	resume() {
		if (!this._paused) return;
		this._paused = false;
		this.updateKeepalive();
	}
	/**
	* Requests the server to finalize current transcription
	*/
	finalize(options) {
		if (this._state !== "connected" && this._state !== "finishing") return;
		const message = { type: "finalize" };
		if (options?.trailing_silence_ms !== void 0) message.trailing_silence_ms = options.trailing_silence_ms;
		this.sendMessage(JSON.stringify(message), false);
	}
	/**
	* Send a keepalive message
	*/
	keepAlive() {
		if (this._state !== "connected" && this._state !== "finishing") return;
		this.sendMessage(JSON.stringify({ type: "keepalive" }), false);
	}
	/**
	* Gracefully finish the session
	*/
	async finish() {
		this.checkAborted();
		if (this._state !== "connected") throw new StateError(`Cannot finish: session is in "${this._state}" state`);
		if (this._paused) this.resume();
		this.setState("finishing");
		this.updateKeepalive();
		const finishPromise = new Promise((resolve, reject) => {
			this.finishResolver = resolve;
			this.finishRejecter = reject;
		});
		this.sendMessage("", false);
		return finishPromise;
	}
	/**
	* Close (cancel) the session immediately without waiting
	*/
	close() {
		if (this.isTerminalState(this._state)) return;
		this.emitter.emit("disconnected", "client_closed");
		this.settleFinish(new StateError("Session canceled"));
		this.cleanup("canceled");
	}
	/**
	* Register an event handler
	*/
	on(event, handler) {
		this.emitter.on(event, handler);
		return this;
	}
	/**
	* Register a one-time event handler
	*/
	once(event, handler) {
		this.emitter.once(event, handler);
		return this;
	}
	/**
	* Remove an event handler
	*/
	off(event, handler) {
		this.emitter.off(event, handler);
		return this;
	}
	/**
	* Async iterator for consuming events.
	*/
	[Symbol.asyncIterator]() {
		return this.eventQueue[Symbol.asyncIterator]();
	}
	async createWebSocket() {
		return new Promise((resolve, reject) => {
			try {
				const ws = new WebSocket(this.wsBaseUrl);
				this.ws = ws;
				ws.binaryType = "arraybuffer";
				const cleanup = () => {
					ws.removeEventListener("open", onOpen);
					ws.removeEventListener("error", onError);
				};
				const onOpen = () => {
					cleanup();
					const configMessage = buildConfigMessage(this.config, this.apiKey);
					ws.send(JSON.stringify(configMessage));
					ws.addEventListener("message", this.handleMessage.bind(this));
					ws.addEventListener("close", this.handleClose.bind(this));
					ws.addEventListener("error", this.handleError.bind(this));
					resolve();
				};
				const onError = (event) => {
					cleanup();
					reject(new ConnectionError("WebSocket connection failed", event));
				};
				ws.addEventListener("open", onOpen);
				ws.addEventListener("error", onError);
				if (this.signal) this.signal.addEventListener("abort", () => {
					cleanup();
					ws.close();
					reject(new AbortError());
				}, { once: true });
			} catch (error) {
				reject(new ConnectionError("Failed to create WebSocket", error));
			}
		});
	}
	handleMessage(event) {
		if (typeof event.data !== "string") return;
		const data = event.data;
		try {
			const result = parseResultMessage(data);
			const hasEndpoint = result.tokens.some((t) => t.text === "<end>");
			const hasFinalized = result.tokens.some((t) => t.text === "<fin>");
			const userTokens = filterSpecialTokens(result.tokens);
			for (const token of userTokens) this.emitter.emit("token", token);
			const filteredResult = {
				...result,
				tokens: userTokens
			};
			this.emitter.emit("result", filteredResult);
			this.eventQueue.push({
				kind: "result",
				data: filteredResult
			});
			if (hasEndpoint) {
				this.emitter.emit("endpoint");
				this.eventQueue.push({ kind: "endpoint" });
			}
			if (hasFinalized) {
				this.emitter.emit("finalized");
				this.eventQueue.push({ kind: "finalized" });
			}
			if (result.finished) {
				this.emitter.emit("finished");
				this.eventQueue.push({ kind: "finished" });
				this.settleFinish();
				this.cleanup("finished");
			}
		} catch (error) {
			const err = error;
			this.emitter.emit("error", err);
			this.settleFinish(err);
			this.cleanup("error", err);
		}
	}
	handleClose(event) {
		if (this.isTerminalState(this._state)) return;
		this.emitter.emit("disconnected", event.reason || void 0);
		if (this._state === "finishing") {
			const error = new ConnectionError("WebSocket closed before finished response", event);
			this.emitter.emit("error", error);
			this.settleFinish(error);
			this.cleanup("error", error);
			return;
		}
		this.cleanup("closed");
	}
	handleError(event) {
		const error = new ConnectionError("WebSocket error", event);
		this.emitter.emit("error", error);
		this.settleFinish(error);
		this.cleanup("error", error);
	}
	handleAbort() {
		const error = new AbortError();
		this.emitter.emit("error", error);
		this.settleFinish(error);
		this.cleanup("canceled", error);
	}
	setState(newState) {
		if (this._state === newState) return;
		const oldState = this._state;
		this._state = newState;
		this.emitter.emit("state_change", {
			old_state: oldState,
			new_state: newState
		});
	}
	cleanup(finalState, error) {
		this.setState(finalState);
		this.stopKeepalive();
		if (this.signal && this.abortHandler) {
			this.signal.removeEventListener("abort", this.abortHandler);
			this.abortHandler = null;
		}
		if (this.ws) {
			this.ws.close();
			this.ws = null;
		}
		if (error) this.eventQueue.abort(error);
		else this.eventQueue.end();
		this.emitter.removeAllListeners();
	}
	isTerminalState(state) {
		return state === "closed" || state === "error" || state === "finished" || state === "canceled";
	}
	checkAborted() {
		if (this.signal?.aborted) throw new AbortError();
	}
	settleFinish(error) {
		if (!this.finishResolver && !this.finishRejecter) return;
		const resolve = this.finishResolver;
		const reject = this.finishRejecter;
		this.finishResolver = null;
		this.finishRejecter = null;
		if (error) reject?.(error);
		else resolve?.();
	}
	sendMessage(data, shouldThrow) {
		if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
			const error = new ConnectionError("WebSocket is not open");
			this.emitter.emit("error", error);
			this.settleFinish(error);
			this.cleanup("error", error);
			if (shouldThrow) throw error;
			return;
		}
		try {
			this.ws.send(data);
		} catch (err) {
			const error = new ConnectionError("WebSocket send failed", err);
			this.emitter.emit("error", error);
			this.settleFinish(error);
			this.cleanup("error", error);
			if (shouldThrow) throw error;
		}
	}
	startKeepalive() {
		if (this.keepaliveInterval) return;
		this.keepaliveInterval = setInterval(() => {
			this.keepAlive();
		}, this.keepaliveIntervalMs);
	}
	stopKeepalive() {
		if (this.keepaliveInterval) {
			clearInterval(this.keepaliveInterval);
			this.keepaliveInterval = null;
		}
	}
	updateKeepalive() {
		if ((this._state === "connected" || this._state === "finishing") && this._paused) this.startKeepalive();
		else this.stopKeepalive();
	}
};
/**
* Audio-specific error classes for the client SDK
* These errors are thrown by AudioSource implementations when capture cannot begin
*/
/**
* Thrown when microphone access is denied by the user or blocked by the browser.
*
* Maps to `getUserMedia` `NotAllowedError` DOMException.
*/
var AudioPermissionError = class extends SonioxError {
	constructor(message = "Microphone access denied", cause) {
		super(message, "permission_denied", void 0, cause);
		this.name = "AudioPermissionError";
	}
};
/**
* Thrown when no audio input device is found
*
* Maps to `getUserMedia` `NotFoundError` DOMException.
*/
var AudioDeviceError = class extends SonioxError {
	constructor(message = "No audio input device found", cause) {
		super(message, "device_not_found", void 0, cause);
		this.name = "AudioDeviceError";
	}
};
/**
* Thrown when audio capture is not supported in the current environment
*
* For example, when `getUserMedia` or `MediaRecorder` is not available.
*/
var AudioUnavailableError = class extends SonioxError {
	constructor(message = "Audio capture is not supported in this environment", cause) {
		super(message, "audio_unavailable", void 0, cause);
		this.name = "AudioUnavailableError";
	}
};
/**
* Browser microphone audio source using getUserMedia + MediaRecorder
*/
var DEFAULT_TIMESLICE_MS = 60;
var DEFAULT_AUDIO_CONSTRAINTS = {
	echoCancellation: false,
	noiseSuppression: false,
	autoGainControl: false,
	channelCount: 1,
	sampleRate: 16e3
};
/**
* Browser microphone audio source
*
* Uses `navigator.mediaDevices.getUserMedia` to capture audio from the microphone
* and `MediaRecorder` to encode it into chunks.
*
* @example
* ```typescript
* const source = new MicrophoneSource();
* await source.start({
*   onData: (chunk) => session.sendAudio(chunk),
*   onError: (err) => console.error(err),
* });
* // Later:
* source.stop();
* ```
*/
var MicrophoneSource = class {
	constraints;
	recorderOptions;
	timesliceMs;
	mediaRecorder = null;
	stream = null;
	boundOnData = null;
	boundOnError = null;
	boundOnMute = null;
	boundOnUnmute = null;
	startGeneration = 0;
	constructor(options = {}) {
		this.constraints = options.constraints ?? DEFAULT_AUDIO_CONSTRAINTS;
		this.recorderOptions = options.recorderOptions ?? {};
		this.timesliceMs = options.timesliceMs ?? DEFAULT_TIMESLICE_MS;
	}
	/**
	* Request microphone access and start recording
	*
	* @throws AudioUnavailableError if getUserMedia or MediaRecorder is not supported
	* @throws AudioPermissionError if microphone access is denied
	* @throws AudioDeviceError if no microphone is found
	*/
	async start(handlers) {
		this.stop();
		const generation = ++this.startGeneration;
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) throw new AudioUnavailableError("navigator.mediaDevices.getUserMedia is not available");
		if (typeof MediaRecorder === "undefined") throw new AudioUnavailableError("MediaRecorder is not available");
		let stream;
		try {
			stream = await navigator.mediaDevices.getUserMedia({ audio: this.constraints });
		} catch (err) {
			if (err instanceof DOMException) {
				if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") throw new AudioPermissionError("Microphone access denied by user", err);
				if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") throw new AudioDeviceError("No microphone found", err);
				if (err.name === "NotReadableError" || err.name === "TrackStartError") throw new AudioDeviceError("Microphone is already in use or not readable", err);
			}
			throw new AudioUnavailableError(err instanceof Error ? err.message : "Failed to access microphone", err);
		}
		if (generation !== this.startGeneration) {
			stream.getTracks().forEach((track$1) => track$1.stop());
			return;
		}
		this.stream = stream;
		const track = stream.getAudioTracks()[0];
		if (track) {
			const { onMuted, onUnmuted } = handlers;
			this.boundOnMute = onMuted ? () => {
				onMuted();
			} : null;
			this.boundOnUnmute = onUnmuted ? () => {
				onUnmuted();
			} : null;
			if (this.boundOnMute) track.addEventListener("mute", this.boundOnMute);
			if (this.boundOnUnmute) track.addEventListener("unmute", this.boundOnUnmute);
		}
		try {
			const recorder = new MediaRecorder(stream, this.recorderOptions);
			this.mediaRecorder = recorder;
			this.boundOnData = (event) => {
				if (event.data.size > 0) event.data.arrayBuffer().then((buffer) => handlers.onData(buffer), (err) => handlers.onError(err instanceof Error ? err : new Error(String(err))));
			};
			this.boundOnError = (event) => {
				const errorEvent = event;
				const error = new Error(errorEvent.message || "MediaRecorder error");
				handlers.onError(error);
			};
			recorder.addEventListener("dataavailable", this.boundOnData);
			recorder.addEventListener("error", this.boundOnError);
			recorder.start(this.timesliceMs);
		} catch (err) {
			stream.getTracks().forEach((track$1) => track$1.stop());
			this.stream = null;
			this.mediaRecorder = null;
			this.boundOnMute = null;
			this.boundOnUnmute = null;
			throw new AudioUnavailableError(err instanceof Error ? err.message : "Failed to start MediaRecorder", err);
		}
	}
	/**
	* Stop recording and release all resources
	*/
	stop() {
		if (this.mediaRecorder) {
			if (this.mediaRecorder.state !== "inactive") {
				const recorder = this.mediaRecorder;
				const onData = this.boundOnData;
				const onError = this.boundOnError;
				recorder.addEventListener("stop", () => {
					if (onData) recorder.removeEventListener("dataavailable", onData);
					if (onError) recorder.removeEventListener("error", onError);
				}, { once: true });
				recorder.stop();
			} else {
				if (this.boundOnData) this.mediaRecorder.removeEventListener("dataavailable", this.boundOnData);
				if (this.boundOnError) this.mediaRecorder.removeEventListener("error", this.boundOnError);
			}
			this.boundOnData = null;
			this.boundOnError = null;
			this.mediaRecorder = null;
		}
		if (this.stream) {
			if (this.boundOnMute || this.boundOnUnmute) {
				const track = this.stream.getAudioTracks()[0];
				if (track) {
					if (this.boundOnMute) track.removeEventListener("mute", this.boundOnMute);
					if (this.boundOnUnmute) track.removeEventListener("unmute", this.boundOnUnmute);
				}
				this.boundOnMute = null;
				this.boundOnUnmute = null;
			}
			this.stream.getTracks().forEach((track) => track.stop());
			this.stream = null;
		}
	}
	/**
	* Pause audio capture
	*/
	pause() {
		if (this.mediaRecorder && this.mediaRecorder.state === "recording") this.mediaRecorder.pause();
	}
	/**
	* Resume audio capture
	*/
	resume() {
		if (this.mediaRecorder && this.mediaRecorder.state === "paused") this.mediaRecorder.resume();
	}
};
/**
* Resolves an ApiKeyConfig to a plain API key string.
* @param config - The API key configuration
* @returns The resolved API key string
* @throws If the function rejects or returns a non-string value
*/
async function resolveApiKey(config) {
	if (typeof config === "function") {
		const key = await config();
		if (typeof key !== "string" || key.length === 0) throw new Error("api_key function must return a non-empty string");
		return key;
	}
	if (typeof config !== "string" || config.length === 0) throw new Error("api_key must be a non-empty string");
	return config;
}
/**
* Recording - high-level orchestrator for real-time speech-to-text.
*
* Returned by `client.realtime.record()`. Manages the lifecycle of an AudioSource
* and a RealtimeSttSession, including audio buffering during key fetch/connection.
*/
var TERMINAL_STATES = [
	"stopped",
	"canceled",
	"error"
];
var DEFAULT_BUFFER_QUEUE_SIZE = 1e3;
/**
* High-level recording orchestrator
*
* Manages the lifecycle of audio capture and real-time transcription:
* 1. Starts audio source immediately (buffers chunks)
* 2. Resolves the API key (from string or async function)
* 3. Connects to the Soniox WebSocket API
* 4. Drains buffered audio, then pipes live audio to the session
*
* @example
* ```typescript
* const recording = client.realtime.record({ model: 'stt-rt-v4' });
* recording.on('result', (r) => console.log(r.tokens));
* recording.on('error', (e) => console.error(e));
*
* // Later:
* await recording.stop();
* ```
*/
var Recording = class {
	emitter = new TypedEmitter();
	apiKeyConfig;
	wsBaseUrl;
	sttConfig;
	sessionOptions;
	source;
	maxBufferSize;
	signal;
	session = null;
	audioBuffer = [];
	_state = "idle";
	isBuffering = true;
	_isSourceMuted = false;
	stopResolver = null;
	stopRejecter = null;
	/** @internal */
	constructor(apiKeyConfig, wsBaseUrl, sttConfig, source, options) {
		this.apiKeyConfig = apiKeyConfig;
		this.wsBaseUrl = wsBaseUrl;
		this.sttConfig = sttConfig;
		this.source = source;
		this.maxBufferSize = options?.buffer_queue_size ?? DEFAULT_BUFFER_QUEUE_SIZE;
		this.sessionOptions = options?.session_options;
		this.signal = options?.signal;
		queueMicrotask(() => {
			this.run();
		});
	}
	/**
	* Current recording state
	*/
	get state() {
		return this._state;
	}
	/**
	* Register an event handler
	*/
	on(event, handler) {
		this.emitter.on(event, handler);
		return this;
	}
	/**
	* Register a one-time event handler
	*/
	once(event, handler) {
		this.emitter.once(event, handler);
		return this;
	}
	/**
	* Remove an event handler
	*/
	off(event, handler) {
		this.emitter.off(event, handler);
		return this;
	}
	/**
	* Gracefully stop recording
	*
	* Stops the audio source and waits for the server to process all
	* buffered audio and return final results.
	*
	* @returns Promise that resolves when the server acknowledges completion
	*/
	async stop() {
		if (this._state === "stopped" || this._state === "canceled" || this._state === "error") return;
		if (this._state === "stopping") return new Promise((resolve, reject) => {
			this.once("finished", resolve);
			this.once("error", reject);
		});
		this.setState("stopping");
		this.source.stop();
		if (this.session && this.session.state === "connected") {
			const finishPromise = new Promise((resolve, reject) => {
				this.stopResolver = resolve;
				this.stopRejecter = reject;
			});
			try {
				await this.session.finish();
			} catch (err) {
				const error = err instanceof Error ? err : new Error(String(err));
				this.settleStop(error);
				this.cleanup("error");
				return;
			}
			return finishPromise;
		}
		return new Promise((resolve, reject) => {
			this.stopResolver = resolve;
			this.stopRejecter = reject;
		});
	}
	/**
	* Immediately cancel recording without waiting for final results
	*/
	cancel() {
		if (this._state === "stopped" || this._state === "canceled" || this._state === "error") return;
		this.source.stop();
		this.session?.close();
		this.cleanup("canceled");
	}
	/**
	* Request the server to finalize current non-final tokens.
	*/
	finalize(options) {
		this.session?.finalize(options);
	}
	/**
	* Pause recording.
	*
	* Pauses the audio source (stops microphone capture) and pauses the
	* session (activates automatic keepalive to prevent server disconnect).
	*/
	pause() {
		if (this._state !== "recording") return;
		this.source.pause?.();
		this.session?.pause();
		this.setState("paused");
	}
	/**
	* Resume recording after pause.
	*
	* Resumes the audio source and session. Audio capture and transmission
	* continue from where they left off.
	*/
	resume() {
		if (this._state !== "paused") return;
		this.source.resume?.();
		if (!this._isSourceMuted) this.session?.resume();
		this.setState("recording");
	}
	async run() {
		if (this.signal?.aborted) {
			this.handleAbort();
			return;
		}
		const onAbort = () => this.handleAbort();
		this.signal?.addEventListener("abort", onAbort, { once: true });
		this.setState("starting");
		try {
			await this.source.start({
				onData: (chunk) => this.handleAudioData(chunk),
				onError: (err) => this.handleError(err),
				onMuted: () => this.handleSourceMuted(),
				onUnmuted: () => this.handleSourceUnmuted()
			});
		} catch (error) {
			this.signal?.removeEventListener("abort", onAbort);
			this.handleError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		if (this.isTerminalState()) {
			this.signal?.removeEventListener("abort", onAbort);
			return;
		}
		let apiKey;
		try {
			apiKey = await resolveApiKey(this.apiKeyConfig);
		} catch (error) {
			this.signal?.removeEventListener("abort", onAbort);
			this.source.stop();
			this.handleError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		this.signal?.removeEventListener("abort", onAbort);
		if (this.isTerminalState()) {
			this.source.stop();
			return;
		}
		this.setState("connecting");
		const sessionOptions = { ...this.sessionOptions };
		if (this.signal !== void 0) sessionOptions.signal = this.signal;
		const session = new RealtimeSttSession(apiKey, this.wsBaseUrl, this.sttConfig, sessionOptions);
		this.session = session;
		this.wireSessionEvents(session);
		try {
			await session.connect();
		} catch (error) {
			this.source.stop();
			this.handleError(error instanceof Error ? error : new Error(String(error)));
			return;
		}
		if (this.isTerminalState()) {
			session.close();
			return;
		}
		const stoppingEarly = this._state === "stopping";
		if (!stoppingEarly) {
			this.setState("recording");
			this.emitter.emit("connected");
		}
		this.isBuffering = false;
		for (const chunk of this.audioBuffer) {
			if (this._state !== "recording" && this._state !== "stopping") break;
			session.sendAudio(chunk);
		}
		this.audioBuffer = [];
		if (stoppingEarly) try {
			await session.finish();
		} catch (err) {
			const error = err instanceof Error ? err : new Error(String(err));
			this.settleStop(error);
			this.cleanup("error");
		}
	}
	handleAudioData(chunk) {
		if (this.isBuffering) {
			if (this.audioBuffer.length >= this.maxBufferSize) {
				this.handleError(/* @__PURE__ */ new Error("Audio buffer queue size exceeded before connection was established"));
				return;
			}
			this.audioBuffer.push(chunk);
			return;
		}
		if (this.session && (this._state === "recording" || this._state === "stopping")) try {
			this.session.sendAudio(chunk);
		} catch {}
	}
	handleSourceMuted() {
		if (this._state !== "recording" && this._state !== "paused") return;
		this._isSourceMuted = true;
		if (this._state === "recording") this.session?.pause();
		this.emitter.emit("source_muted");
	}
	handleSourceUnmuted() {
		if (this._state !== "recording" && this._state !== "paused") return;
		this._isSourceMuted = false;
		if (this._state === "recording") this.session?.resume();
		this.emitter.emit("source_unmuted");
	}
	wireSessionEvents(session) {
		session.on("result", (result) => this.emitter.emit("result", result));
		session.on("token", (token) => this.emitter.emit("token", token));
		session.on("endpoint", () => this.emitter.emit("endpoint"));
		session.on("finalized", () => this.emitter.emit("finalized"));
		session.on("finished", () => {
			this.source.stop();
			this.emitter.emit("finished");
			this.settleStop();
			this.cleanup("stopped");
		});
		session.on("error", (error) => {
			this.handleError(error);
		});
	}
	handleAbort() {
		if (this.isTerminalState()) return;
		this.source.stop();
		this.session?.close();
		const error = /* @__PURE__ */ new Error("Recording aborted");
		this.emitter.emit("error", error);
		this.settleStop(error);
		this.cleanup("canceled");
	}
	handleError(error) {
		if (this._state === "error" || this._state === "stopped" || this._state === "canceled") return;
		this.source.stop();
		this.session?.close();
		this.emitter.emit("error", error);
		this.settleStop(error);
		this.cleanup("error");
	}
	cleanup(finalState) {
		this.setState(finalState);
		this.audioBuffer = [];
		this.isBuffering = false;
		this._isSourceMuted = false;
	}
	setState(newState) {
		if (this._state === newState) return;
		const oldState = this._state;
		this._state = newState;
		this.emitter.emit("state_change", {
			old_state: oldState,
			new_state: newState
		});
	}
	isTerminalState() {
		return TERMINAL_STATES.includes(this._state);
	}
	settleStop(error) {
		const resolve = this.stopResolver;
		const reject = this.stopRejecter;
		this.stopResolver = null;
		this.stopRejecter = null;
		if (error) reject?.(error);
		else resolve?.();
	}
};
/**
* SonioxClient - main entry point for the @soniox/client SDK
*
* Provides high-level `record()` for audio capture + transcription,
* and low-level `stt()` for direct WebSocket session access
*/
var SONIOX_WS_URL = "wss://stt-rt.soniox.com/transcribe-websocket";
/**
* Main entry point for the Soniox client SDK.
*
* @example
* ```typescript
* const client = new SonioxClient({
*   api_key: async () => {
*     const res = await fetch('/api/get-temporary-key', { method: 'POST' });
*     return (await res.json()).api_key;
*   },
* });
*
* // High-level: record from microphone
* const recording = client.realtime.record({ model: 'stt-rt-v4' });
* recording.on('result', (r) => console.log(r.tokens));
* await recording.stop();
*
* // Low-level: direct session access
* const session = client.realtime.stt({ model: 'stt-rt-v4' }, { api_key: key });
* await session.connect();
* ```
*/
var SonioxClient = class {
	apiKeyConfig;
	wsBaseUrl;
	permissionResolver;
	defaultBufferQueueSize;
	defaultSessionOptions;
	/**
	* Real-time API namespace
	*/
	realtime;
	constructor(options) {
		this.apiKeyConfig = options.api_key;
		this.wsBaseUrl = options.ws_base_url ?? SONIOX_WS_URL;
		this.permissionResolver = options.permissions;
		this.defaultBufferQueueSize = options.buffer_queue_size ?? 1e3;
		this.defaultSessionOptions = options.default_session_options;
		this.realtime = {
			record: (recordOptions) => this.createRecording(recordOptions),
			stt: (config, sttOptions) => this.createSession(config, sttOptions)
		};
	}
	/**
	* Permission resolver, if configured.
	* Returns `undefined` if no resolver was provided (SSR-safe).
	*
	* @example
	* ```typescript
	* const mic = await client.permissions?.check('microphone');
	* if (mic?.status === 'denied') {
	*   showSettingsMessage();
	* }
	* ```
	*/
	get permissions() {
		return this.permissionResolver;
	}
	createRecording(options) {
		const { source, signal, buffer_queue_size, session_options, ...sttConfig } = options;
		const audioSource = source ?? new MicrophoneSource();
		return new Recording(this.apiKeyConfig, this.wsBaseUrl, sttConfig, audioSource, {
			buffer_queue_size: buffer_queue_size ?? this.defaultBufferQueueSize,
			session_options: {
				...this.defaultSessionOptions,
				...session_options,
				...signal !== void 0 ? { signal } : {}
			},
			...signal !== void 0 ? { signal } : {}
		});
	}
	createSession(config, options) {
		const mergedSessionOptions = {
			...this.defaultSessionOptions,
			...options.session_options
		};
		return new RealtimeSttSession(options.api_key, this.wsBaseUrl, config, mergedSessionOptions);
	}
};
/**
* Browser permission resolver for checking and requesting microphone access.
*
* @example
* ```typescript
* const resolver = new BrowserPermissionResolver();
* const mic = await resolver.check('microphone');
* if (mic.status === 'prompt') {
*   const result = await resolver.request('microphone');
*   if (result.status === 'denied') {
*     showDeniedMessage();
*   }
* }
* ```
*/
var BrowserPermissionResolver = class {
	/**
	* Check current microphone permission status without prompting the user.
	*/
	async check(permission) {
		if (permission === "microphone") return this.checkMicrophone();
		return {
			status: "unavailable",
			can_request: false
		};
	}
	/**
	* Request microphone permission from the user.
	* This may show a browser permission prompt.
	*/
	async request(permission) {
		if (permission === "microphone") return this.requestMicrophone();
		return {
			status: "unavailable",
			can_request: false
		};
	}
	async checkMicrophone() {
		if (typeof navigator !== "undefined" && navigator.permissions?.query) try {
			const result = await navigator.permissions.query({ name: "microphone" });
			return {
				status: result.state === "prompt" ? "prompt" : result.state,
				can_request: result.state !== "denied"
			};
		} catch {}
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) return {
			status: "unavailable",
			can_request: false
		};
		return {
			status: "prompt",
			can_request: true
		};
	}
	async requestMicrophone() {
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) return {
			status: "unavailable",
			can_request: false
		};
		try {
			(await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((track) => track.stop());
			return {
				status: "granted",
				can_request: true
			};
		} catch (err) {
			if (err instanceof DOMException) {
				if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") return {
					status: "denied",
					can_request: false
				};
				if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") return {
					status: "unavailable",
					can_request: false
				};
			}
			return {
				status: "denied",
				can_request: false
			};
		}
	}
};
//#endregion
//#region src/audio/mixed-audio-source.ts
var TIMESLICE_MS = 60;
var MIC_CONSTRAINTS = {
	echoCancellation: true,
	noiseSuppression: true,
	autoGainControl: true,
	channelCount: 1
};
/**
* AudioSource that merges tab audio (getDisplayMedia) and microphone
* (getUserMedia) into a single stream using the Web Audio API.
*
* Tab audio always starts first. Microphone is best-effort: if it
* fails (no hardware, permission denied), only tab audio feeds the
* mixer and no error is surfaced to the caller.
*
* The mic can be added or removed at any time via `setMicEnabled()`
* without restarting the Soniox session or tab capture.
*/
var MixedAudioSource = class {
	audioCtx = null;
	dest = null;
	tabStream = null;
	tabNode = null;
	micStream = null;
	micNode = null;
	recorder = null;
	active = false;
	micEnabled;
	constructor(options) {
		this.micEnabled = options?.includeMic ?? false;
	}
	getAudioContext() {
		return this.audioCtx;
	}
	async start(handlers) {
		this.active = true;
		try {
			await this.ensureTabStream(handlers);
			this.ensureMixer();
			if (this.micEnabled) await this.ensureMic();
			else this.releaseMic();
			const outputStream = this.dest?.stream ?? this.tabStream;
			if (!outputStream) throw new Error("No audio stream available to start recording");
			this.recorder = new MediaRecorder(outputStream);
			this.recorder.ondataavailable = (event) => {
				if (!this.active || event.data.size === 0) return;
				event.data.arrayBuffer().then((buf) => {
					if (this.active) handlers.onData(buf);
				});
			};
			this.recorder.onerror = () => {
				if (this.active) handlers.onError(/* @__PURE__ */ new Error("Mixed audio capture recorder error"));
			};
			this.recorder.start(TIMESLICE_MS);
			console.log("[MixedAudio] Recording started —", this.micStream ? "tab + mic" : "tab only");
		} catch (err) {
			console.error("[MixedAudio] Failed to start:", err);
			this.releaseAll();
			throw err;
		}
	}
	/**
	* Hot-switch microphone on/off while recording continues.
	* Safe to call at any time; no-ops if not currently active.
	*/
	async setMicEnabled(enabled) {
		this.micEnabled = enabled;
		if (enabled) {
			if (this.active && !this.hasLiveAudioTrack(this.micStream)) await this.ensureMic();
		} else this.releaseMic();
		if (this.active) console.log("[MixedAudio] Mic toggled —", this.micStream ? "tab + mic" : "tab only");
	}
	stop() {
		this.active = false;
		this.releaseRecorder();
		this.releaseMic();
	}
	pause() {
		if (this.recorder?.state === "recording") this.recorder.pause();
	}
	resume() {
		if (this.recorder?.state === "paused") this.recorder.resume();
	}
	dispose() {
		this.active = false;
		this.releaseAll();
	}
	async ensureTabStream(handlers) {
		if (this.hasLiveAudioTrack(this.tabStream)) return;
		this.releaseTabStream();
		this.tabStream = await navigator.mediaDevices.getDisplayMedia({
			audio: true,
			video: true,
			preferCurrentTab: true
		});
		for (const vt of this.tabStream.getVideoTracks()) vt.stop();
		if (!this.hasLiveAudioTrack(this.tabStream)) throw new Error("getDisplayMedia returned no audio tracks");
		this.tabStream.getAudioTracks()[0].addEventListener("ended", () => {
			if (this.active) {
				console.warn("[MixedAudio] Tab audio sharing stopped by user");
				handlers.onError(/* @__PURE__ */ new Error("Tab audio sharing was stopped"));
			}
		});
	}
	/**
	* Ensure AudioContext + destination exist so we can always route
	* through the mixer (even tab-only). This lets us hot-add mic later.
	*/
	ensureMixer() {
		if (!this.audioCtx) this.audioCtx = new AudioContext();
		if (!this.dest) this.dest = this.audioCtx.createMediaStreamDestination();
		if (this.tabStream && !this.tabNode) {
			this.tabNode = this.audioCtx.createMediaStreamSource(this.tabStream);
			this.tabNode.connect(this.dest);
		}
	}
	async ensureMic() {
		if (this.hasLiveAudioTrack(this.micStream)) return;
		try {
			this.releaseMic();
			this.micStream = await navigator.mediaDevices.getUserMedia({ audio: MIC_CONSTRAINTS });
			this.ensureMixer();
			if (this.audioCtx && this.dest) {
				this.micNode = this.audioCtx.createMediaStreamSource(this.micStream);
				this.micNode.connect(this.dest);
			}
			console.log("[MixedAudio] Microphone added to mix");
		} catch (micErr) {
			console.warn("[MixedAudio] Microphone unavailable, continuing with tab audio only:", micErr);
			this.micStream = null;
			this.micNode = null;
		}
	}
	releaseMic() {
		if (this.micNode) {
			try {
				this.micNode.disconnect();
			} catch {}
			this.micNode = null;
		}
		if (this.micStream) {
			for (const t of this.micStream.getTracks()) t.stop();
			this.micStream = null;
		}
	}
	releaseTabStream() {
		if (this.tabNode) {
			try {
				this.tabNode.disconnect();
			} catch {}
			this.tabNode = null;
		}
		if (this.tabStream) {
			for (const t of this.tabStream.getTracks()) t.stop();
			this.tabStream = null;
		}
	}
	releaseRecorder() {
		if (this.recorder) {
			try {
				if (this.recorder.state !== "inactive") this.recorder.stop();
			} catch {}
			this.recorder = null;
		}
	}
	hasLiveAudioTrack(stream) {
		if (!stream) return false;
		return stream.getAudioTracks().some((track) => track.readyState === "live");
	}
	releaseAll() {
		this.releaseRecorder();
		this.releaseMic();
		this.releaseTabStream();
		if (this.audioCtx) {
			try {
				this.audioCtx.close();
			} catch {}
			this.audioCtx = null;
		}
		this.dest = null;
	}
};
//#endregion
//#region src/composables/useSoniox.ts
function useSoniox() {
	const state = ref("idle");
	const error = ref(null);
	let client = null;
	let recording = null;
	let audioSource = null;
	let currentApiKey = null;
	function createClient(apiKey) {
		return new SonioxClient({
			api_key: apiKey,
			permissions: new BrowserPermissionResolver()
		});
	}
	function ensureClient(apiKey) {
		if (!client || currentApiKey !== apiKey) {
			client = createClient(apiKey);
			currentApiKey = apiKey;
		}
		return client;
	}
	function ensureAudioSource(useMicrophone) {
		if (!audioSource) audioSource = new MixedAudioSource({ includeMic: useMicrophone });
		return audioSource;
	}
	function buildTranslationConfig(targetLanguage, theirLanguage) {
		if (theirLanguage && theirLanguage !== "none" && theirLanguage !== targetLanguage) return {
			type: "two_way",
			language_a: theirLanguage,
			language_b: targetLanguage
		};
		return {
			type: "one_way",
			target_language: targetLanguage
		};
	}
	function startRecording(apiKey, targetLanguage, callbacks = {}, useMicrophone = false, theirLanguage) {
		if (recording) try {
			recording.cancel();
		} catch {} finally {
			recording = null;
		}
		error.value = null;
		state.value = "starting";
		try {
			const sonioxClient = ensureClient(apiKey);
			const source = ensureAudioSource(useMicrophone);
			source.setMicEnabled(useMicrophone);
			const translation = buildTranslationConfig(targetLanguage, theirLanguage);
			console.info("[Soniox] translation config:", JSON.stringify(translation));
			recording = sonioxClient.realtime.record({
				model: "stt-rt-v4",
				translation,
				enable_speaker_diarization: true,
				enable_endpoint_detection: true,
				max_endpoint_delay_ms: 2e3,
				source
			});
			recording.on("result", (result) => {
				console.debug("[Soniox] result received:", result.tokens.length, "tokens");
				const mapped = { tokens: result.tokens.map((t) => ({
					text: t.text,
					is_final: t.is_final,
					translation_status: t.translation_status,
					source_language: t.source_language,
					language: t.language,
					speaker: t.speaker
				})) };
				callbacks.onResult?.(mapped);
			});
			recording.on("endpoint", () => {
				console.debug("[Soniox] endpoint event");
				callbacks.onEndpoint?.();
			});
			recording.on("finalized", () => {
				console.debug("[Soniox] finalized event");
				callbacks.onFinalized?.();
			});
			recording.on("error", (err) => {
				console.error("[Soniox] error event:", err.message);
				error.value = resolveErrorMessage(err);
				state.value = "error";
				callbacks.onError?.(err);
			});
			recording.on("state_change", ({ old_state, new_state }) => {
				console.debug("[Soniox] state_change:", old_state, "->", new_state);
				state.value = new_state;
				callbacks.onStateChange?.(old_state, new_state);
			});
		} catch (err) {
			error.value = err instanceof Error ? err.message : "Failed to start recording";
			state.value = "error";
		}
	}
	async function stopRecording() {
		if (!recording) return;
		state.value = "stopping";
		try {
			await recording.stop();
		} catch {} finally {
			recording = null;
			state.value = "stopped";
		}
	}
	function cancelRecording() {
		if (!recording) return;
		try {
			recording.cancel();
		} catch {}
		recording = null;
		state.value = "canceled";
	}
	function pauseRecording() {
		if (!recording || !audioSource) return;
		audioSource.pause();
		state.value = "paused";
	}
	function resumeRecording() {
		if (!recording || !audioSource) return;
		audioSource.resume();
		state.value = "recording";
	}
	function cleanup() {
		if (recording) {
			try {
				recording.cancel();
			} catch {}
			recording = null;
		}
		if (audioSource) {
			audioSource.dispose();
			audioSource = null;
		}
		client = null;
		currentApiKey = null;
	}
	async function setMicEnabled(enabled) {
		if (audioSource) await audioSource.setMicEnabled(enabled);
	}
	async function checkPermission() {
		if (!client) return "prompt";
		try {
			return (await client.permissions?.check("microphone"))?.status ?? "prompt";
		} catch {
			return "unavailable";
		}
	}
	async function requestPermission() {
		if (!client) return false;
		try {
			return (await client.permissions?.request("microphone"))?.status === "granted";
		} catch {
			return false;
		}
	}
	function resolveErrorMessage(err) {
		const msg = err.message.toLowerCase();
		if (msg.includes("api_key") || msg.includes("unauthorized") || msg.includes("401")) return "Invalid API key. Please check your API key and try again.";
		if (msg.includes("permission") || msg.includes("notallowed")) return "Microphone access denied. Please allow microphone access in browser settings.";
		if (msg.includes("notfound") || msg.includes("no device")) return "No microphone found. Please connect a microphone and try again.";
		if (msg.includes("no audio received")) return "No audio received from current input device. Please check microphone/input source and restart translation.";
		if (msg.includes("audio device recovery failed")) return "Audio device changed and automatic recovery failed. Please stop and restart translation.";
		if (msg.includes("network") || msg.includes("websocket") || msg.includes("connection")) return "Connection lost. Please check your internet connection.";
		return err.message || "Translation service error. Please try again.";
	}
	onUnmounted(() => {
		cleanup();
	});
	function pauseCapture() {
		audioSource?.pause();
	}
	function resumeCapture() {
		audioSource?.resume();
	}
	return {
		state,
		error,
		startRecording,
		stopRecording,
		cancelRecording,
		pauseRecording,
		resumeRecording,
		setMicEnabled,
		pauseCapture,
		resumeCapture,
		cleanup,
		checkPermission,
		requestPermission
	};
}
//#endregion
//#region src/services/openai-tts-client.ts
var OpenAITTSClient = class {
	baseUrl = "https://api.openai.com/v1/audio/speech";
	apiKey;
	constructor(apiKey) {
		this.apiKey = apiKey;
	}
	setApiKey(apiKey) {
		this.apiKey = apiKey;
	}
	async synthesize(request, signal) {
		if (!this.apiKey) throw new Error("OpenAI API key is not configured");
		const body = {
			model: request.model,
			input: request.input,
			voice: request.voice,
			response_format: request.responseFormat ?? "mp3"
		};
		if (request.speed !== void 0) body.speed = request.speed;
		if (request.instructions) body.instructions = request.instructions;
		console.log("[TTS:API] POST", this.baseUrl, "— model:", request.model, "voice:", request.voice, "input length:", request.input.length);
		const response = await fetch(this.baseUrl, {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${this.apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body),
			signal: signal ?? null
		});
		if (!response.ok) {
			const errorText = await response.text().catch(() => "Unknown error");
			console.error("[TTS:API] Error response:", response.status, errorText);
			throw new TTSApiError(response.status, errorText);
		}
		const blob = await response.blob();
		console.log("[TTS:API] Success — blob size:", blob.size, "type:", blob.type);
		return blob;
	}
};
var TTSApiError = class extends Error {
	constructor(status, body) {
		const message = resolveApiErrorMessage$1(status, body);
		super(message);
		this.status = status;
		this.body = body;
		this.name = "TTSApiError";
	}
};
function resolveApiErrorMessage$1(status, body) {
	if (status === 401) return "Invalid OpenAI API key. Please check your key and try again.";
	if (status === 429) return "OpenAI rate limit reached. Please wait a moment and try again.";
	if (status >= 500) return "OpenAI service error. Please try again later.";
	try {
		return JSON.parse(body).error?.message ?? `OpenAI TTS error (${status})`;
	} catch {
		return `OpenAI TTS error (${status})`;
	}
}
//#endregion
//#region src/audio/tts-audio-player.ts
/**
* Plays TTS audio blobs.
*
* Preferred path: background offscreen document (isolated from current tab
* audio capture, prevents Soniox duplicate capture).
*
* Fallback path: local <audio> playback (used in test/non-extension env).
*/
var TTSAudioPlayer = class {
	audio = null;
	currentBlobUrl = null;
	handlers = /* @__PURE__ */ new Map();
	_isSpeaking = false;
	offscreenPlaybackId = 0;
	_volume = 1;
	get isSpeaking() {
		return this._isSpeaking;
	}
	setVolume(volume) {
		this._volume = Math.max(0, Math.min(1, volume));
		if (this.audio) this.audio.volume = this._volume;
		if (this.canUseRuntimeMessaging()) this.sendRuntimeMessage({
			type: "tts.setVolume",
			volume: this._volume
		}).catch(() => {});
	}
	on(event, handler) {
		if (!this.handlers.has(event)) this.handlers.set(event, /* @__PURE__ */ new Set());
		this.handlers.get(event).add(handler);
	}
	off(event, handler) {
		this.handlers.get(event)?.delete(handler);
	}
	async play(audioBlob) {
		this.stop();
		if (this.canUseRuntimeMessaging()) {
			await this.playViaOffscreen(audioBlob);
			return;
		}
		await this.playLocally(audioBlob);
	}
	stop() {
		this.offscreenPlaybackId += 1;
		if (this.canUseRuntimeMessaging()) this.sendRuntimeMessage({ type: "tts.stop" }).catch((err) => {
			const msg = err instanceof Error ? err.message : String(err);
			console.warn("[TTS:Player] Failed to stop offscreen playback:", msg);
		});
		const audio = this.audio;
		if (audio) {
			audio.onplay = null;
			audio.onended = null;
			audio.onerror = null;
			audio.pause();
			this.audio = null;
		}
		if (this._isSpeaking) {
			this._isSpeaking = false;
			this.emit("end");
		}
		this.revokeBlobUrl();
	}
	dispose() {
		this.stop();
		this.handlers.clear();
	}
	async playViaOffscreen(audioBlob) {
		const playbackId = ++this.offscreenPlaybackId;
		const dataUrl = await this.blobToDataUrl(audioBlob);
		this._isSpeaking = true;
		this.emit("start");
		console.log("[TTS:Player] Playing via offscreen document, bytes:", audioBlob.size, "volume:", this._volume);
		try {
			const response = await this.sendRuntimeMessage({
				type: "tts.play",
				payload: {
					dataUrl,
					volume: this._volume
				}
			});
			if (playbackId !== this.offscreenPlaybackId) return;
			if (!response?.ok) throw new Error(response?.error ?? "Offscreen playback failed");
			this._isSpeaking = false;
			this.emit("end");
		} catch (err) {
			if (playbackId !== this.offscreenPlaybackId) return;
			const error = err instanceof Error ? err : /* @__PURE__ */ new Error("Offscreen TTS playback failed");
			this._isSpeaking = false;
			this.emit("error", error);
			throw error;
		}
	}
	async playLocally(audioBlob) {
		this.currentBlobUrl = URL.createObjectURL(audioBlob);
		this.audio = new Audio(this.currentBlobUrl);
		this.audio.volume = this._volume;
		return new Promise((resolve, reject) => {
			const audio = this.audio;
			audio.onplay = () => {
				this._isSpeaking = true;
				this.emit("start");
			};
			audio.onended = () => {
				this._isSpeaking = false;
				this.cleanup();
				this.emit("end");
				resolve();
			};
			audio.onerror = () => {
				if (!this.audio || this.audio !== audio) return;
				this._isSpeaking = false;
				const err = /* @__PURE__ */ new Error("TTS audio playback failed");
				this.cleanup();
				this.emit("error", err);
				reject(err);
			};
			audio.play().catch((err) => {
				if (!this.audio || this.audio !== audio) return;
				this._isSpeaking = false;
				const error = err instanceof Error ? err : /* @__PURE__ */ new Error("Failed to play TTS audio");
				this.cleanup();
				this.emit("error", error);
				reject(error);
			});
		});
	}
	cleanup() {
		this.audio = null;
		this.revokeBlobUrl();
	}
	revokeBlobUrl() {
		if (this.currentBlobUrl) {
			URL.revokeObjectURL(this.currentBlobUrl);
			this.currentBlobUrl = null;
		}
	}
	canUseRuntimeMessaging() {
		return typeof chrome !== "undefined" && Boolean(chrome.runtime?.id) && typeof chrome.runtime?.sendMessage === "function";
	}
	async sendRuntimeMessage(message) {
		if (!this.canUseRuntimeMessaging()) return null;
		return await new Promise((resolve, reject) => {
			try {
				chrome.runtime.sendMessage(message, (response) => {
					const runtimeErr = chrome.runtime.lastError;
					if (runtimeErr) {
						reject(new Error(runtimeErr.message));
						return;
					}
					resolve(response ?? null);
				});
			} catch (err) {
				reject(err instanceof Error ? err : /* @__PURE__ */ new Error("Runtime messaging failed"));
			}
		});
	}
	async blobToDataUrl(blob) {
		return await new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.onload = () => {
				const result = reader.result;
				if (typeof result === "string") {
					resolve(result);
					return;
				}
				reject(/* @__PURE__ */ new Error("Failed to convert TTS blob to data URL"));
			};
			reader.onerror = () => {
				reject(/* @__PURE__ */ new Error("Failed to read TTS blob"));
			};
			reader.readAsDataURL(blob);
		});
	}
	emit(event, error) {
		const handlers = this.handlers.get(event);
		if (handlers) for (const handler of handlers) try {
			handler(error);
		} catch {}
	}
};
//#endregion
//#region src/composables/useTTS.ts
var MAX_QUEUE_SIZE = 5;
/**
* Auto-sync: if the total backlog (pending synthesis + pending playback)
* exceeds this threshold, speed is boosted to drain the queue faster.
*/
var AUTO_SYNC_THRESHOLD = 3;
var AUTO_SYNC_BOOST_PER_ITEM = .4;
var MAX_API_SPEED = 4;
var langCodeToName = new Map(SUPPORTED_LANGUAGES.map((l) => [l.value, l.label]));
function useTTS() {
	const isSpeaking = ref(false);
	const isEnabled = ref(false);
	const error = ref(null);
	const queueLength = ref(0);
	const effectiveSpeed = ref(1.5);
	let client = null;
	let player = null;
	let queue = [];
	const playbackQueue = [];
	let abortController = null;
	let callbacks = {};
	let playbackRunning = false;
	let currentModel = "gpt-4o-mini-tts";
	let currentVoice = "coral";
	let currentSpeed = 1.5;
	let currentVolume = 1;
	let autoSyncEnabled = true;
	function ensureClient(apiKey) {
		if (!client) client = new OpenAITTSClient(apiKey);
		else client.setApiKey(apiKey);
		return client;
	}
	function ensurePlayer() {
		if (!player) {
			player = new TTSAudioPlayer();
			player.on("start", () => {
				isSpeaking.value = true;
				callbacks.onSpeakStart?.();
			});
			player.on("end", () => {
				isSpeaking.value = false;
				callbacks.onSpeakEnd?.();
			});
			player.on("error", (err) => {
				isSpeaking.value = false;
				if (err) {
					error.value = err.message;
					callbacks.onError?.(err);
				}
			});
		}
		player.setVolume(currentVolume);
		return player;
	}
	/**
	* Compute speed for the next synthesis request.
	* When auto-sync is active, boosts speed proportional to backlog depth
	* so the queue drains faster, keeping latency low.
	*
	* OpenAI speed range: 0.25 – 4.0 (per-request parameter).
	*/
	function computeEffectiveSpeed() {
		if (!autoSyncEnabled) {
			effectiveSpeed.value = currentSpeed;
			return currentSpeed;
		}
		const backlog = queue.length + playbackQueue.length;
		if (backlog <= AUTO_SYNC_THRESHOLD) {
			effectiveSpeed.value = currentSpeed;
			return currentSpeed;
		}
		const boost = (backlog - AUTO_SYNC_THRESHOLD) * AUTO_SYNC_BOOST_PER_ITEM;
		const boosted = Math.min(MAX_API_SPEED, currentSpeed + boost);
		effectiveSpeed.value = boosted;
		return boosted;
	}
	function configure(options) {
		ensureClient(options.apiKey);
		if (options.model) currentModel = options.model;
		if (options.voice) currentVoice = options.voice;
		if (options.speed !== void 0) currentSpeed = options.speed;
		if (options.volume !== void 0) {
			currentVolume = options.volume;
			player?.setVolume(currentVolume);
		}
		if (options.autoSyncSpeed !== void 0) autoSyncEnabled = options.autoSyncSpeed;
		if (options.callbacks) callbacks = options.callbacks;
		effectiveSpeed.value = currentSpeed;
	}
	async function speakOnce(options) {
		const text = options.text.trim();
		if (!text) throw new Error("No text provided for TTS preview");
		const previewClient = ensureClient(options.apiKey);
		const languageName = langCodeToName.get(options.language) ?? options.language;
		const model = options.model ?? currentModel;
		const voice = options.voice ?? currentVoice;
		const speed = options.speed ?? currentSpeed;
		const volume = options.volume ?? currentVolume;
		const blob = await previewClient.synthesize({
			input: text,
			model,
			voice,
			responseFormat: "mp3",
			speed,
			instructions: `Speak naturally in ${languageName}. Match the tone and style of the translated text.`
		});
		const previewPlayer = new TTSAudioPlayer();
		previewPlayer.setVolume(volume);
		try {
			await previewPlayer.play(blob);
		} finally {
			previewPlayer.dispose();
		}
	}
	function enqueue(text, language) {
		if (!isEnabled.value) return;
		if (!text.trim()) return;
		if (!client) return;
		const item = {
			id: crypto.randomUUID(),
			text: text.trim(),
			language,
			timestamp: Date.now()
		};
		queue.push(item);
		while (queue.length > MAX_QUEUE_SIZE) queue.shift();
		queueLength.value = queue.length;
		synthesizeNext();
	}
	function synthesizeNext() {
		if (!client || !isEnabled.value) return;
		const item = queue.shift();
		if (!item) return;
		queueLength.value = queue.length;
		const currentClient = client;
		const ac = new AbortController();
		abortController = ac;
		const languageName = langCodeToName.get(item.language) ?? item.language;
		const speed = computeEffectiveSpeed();
		if (speed !== currentSpeed) console.log("[TTS] Auto-sync boost — backlog:", queue.length + playbackQueue.length, "speed:", speed.toFixed(2));
		currentClient.synthesize({
			input: item.text,
			model: currentModel,
			voice: currentVoice,
			responseFormat: "mp3",
			speed,
			instructions: `Speak naturally in ${languageName}. Match the tone and style of the translated text.`
		}, ac.signal).then((audioBlob) => {
			if (!isEnabled.value) return;
			enqueuePlayback(audioBlob);
		}).catch((err) => {
			if (err instanceof Error && err.name === "AbortError") return;
			const message = err instanceof Error ? err.message : "TTS synthesis failed";
			console.error("[TTS] Synthesis error:", message);
			error.value = message;
			callbacks.onError?.(err instanceof Error ? err : new Error(message));
		}).finally(() => {
			if (abortController === ac) abortController = null;
			synthesizeNext();
		});
	}
	async function enqueuePlayback(blob) {
		playbackQueue.push(blob);
		if (playbackRunning) return;
		playbackRunning = true;
		while (playbackQueue.length > 0 && isEnabled.value) {
			const nextBlob = playbackQueue.shift();
			try {
				await ensurePlayer().play(nextBlob);
			} catch (err) {
				const message = err instanceof Error ? err.message : "Playback failed";
				console.error("[TTS] Playback error in queue:", message);
				error.value = message;
				callbacks.onError?.(err instanceof Error ? err : new Error(message));
			}
		}
		playbackRunning = false;
	}
	function stop() {
		abortController?.abort();
		abortController = null;
		player?.stop();
		queue = [];
		playbackQueue.length = 0;
		queueLength.value = 0;
		playbackRunning = false;
		effectiveSpeed.value = currentSpeed;
	}
	function setEnabled(enabled) {
		isEnabled.value = enabled;
		if (!enabled) stop();
	}
	function cleanup() {
		stop();
		player?.dispose();
		player = null;
		client = null;
		callbacks = {};
	}
	onUnmounted(() => {
		cleanup();
	});
	return {
		isSpeaking,
		isEnabled,
		error,
		queueLength,
		effectiveSpeed,
		configure,
		speakOnce,
		enqueue,
		stop,
		setEnabled,
		cleanup
	};
}
//#endregion
//#region src/composables/useVolumeDucker.ts
/**
* Controls volume ducking on the tab's media elements.
* When TTS is speaking, reduces all <audio>/<video> volumes to the configured level.
* When TTS stops, restores original volumes.
*/
function useVolumeDucker() {
	const isDucked = ref(false);
	let duckLevel = .3;
	function setDuckLevel(level) {
		duckLevel = Math.max(0, Math.min(1, level));
		if (isDucked.value) broadcastVolumeChange(duckLevel);
	}
	function duck() {
		if (isDucked.value) return;
		isDucked.value = true;
		broadcastVolumeChange(duckLevel);
	}
	function restore() {
		if (!isDucked.value) return;
		isDucked.value = false;
		broadcastVolumeChange(1);
	}
	function broadcastVolumeChange(volume) {
		try {
			window.parent.postMessage({
				type: "TTS_DUCK_VOLUME",
				volume
			}, "*");
		} catch {}
	}
	function dispose() {
		if (isDucked.value) restore();
	}
	onUnmounted(() => {
		dispose();
	});
	return {
		isDucked,
		setDuckLevel,
		duck,
		restore,
		dispose
	};
}
//#endregion
//#region src/composables/useTranslation.ts
var SAMPLE_TEST_TEXT = "This is a narration voice test.";
/**
* Convert UI voice speed (-100 to +100) to OpenAI speed (0.25 to 4.0).
* 0% → 1.0x, +100% → 2.0x, -100% → 0.25x
*/
function uiSpeedToApiSpeed(uiSpeed) {
	if (uiSpeed >= 0) return 1 + uiSpeed / 100;
	return Math.max(.25, 1 + uiSpeed / 100 * .75);
}
function useTranslation() {
	const SPEAKER_PAUSE_MS = 2e3;
	const soniox = useSoniox();
	const tts = useTTS();
	const ducker = useVolumeDucker();
	const store = useTranslatorStore();
	let session = createSessionState();
	let activeTargetLanguage = "vi";
	let activeTheirLanguage = "none";
	const isInterpreterActive = ref(false);
	const interpreterBuffer = ref("");
	const onInterpreterText = ref(null);
	function createSessionState() {
		return {
			activeSpeakerId: null,
			originalBuffer: "",
			translationBuffer: "",
			lastSpeakerActivityAt: 0,
			lastTTSCommitAt: 0
		};
	}
	watch(soniox.state, (newState) => {
		store.setRecordingState(newState);
	});
	watch(soniox.error, (newError) => {
		if (newError) store.setError(newError);
	});
	function shouldRouteToInterpreter(token) {
		if (!isInterpreterActive.value) return false;
		if (activeTheirLanguage === "none") return false;
		return token.translation_status === "translation" && token.language === activeTheirLanguage;
	}
	const TWO_WAY_LOG_PREFIX = "[TwoWay]";
	function handleResult(result) {
		const audioSource = "tab";
		const isTwoWay = activeTheirLanguage !== "none";
		const speakerOrder = [];
		const bySpeaker = /* @__PURE__ */ new Map();
		let interpreterFinalChunk = "";
		for (const token of result.tokens) {
			if (token.text === "<end>") continue;
			if (isTwoWay && token.is_final) console.debug(TWO_WAY_LOG_PREFIX, "token", {
				text: token.text.substring(0, 30),
				status: token.translation_status,
				lang: token.language,
				srcLang: token.source_language,
				final: token.is_final,
				speaker: token.speaker
			});
			if (shouldRouteToInterpreter(token) && token.is_final) interpreterFinalChunk += token.text;
			const text = token.text;
			const status = token.translation_status;
			const speakerId = normalizeSpeakerId(token.speaker, session.activeSpeakerId);
			if (!bySpeaker.has(speakerId)) {
				bySpeaker.set(speakerId, {
					speakerId,
					finalOriginal: "",
					finalTranslation: "",
					nonFinalOriginal: "",
					nonFinalTranslation: ""
				});
				speakerOrder.push(speakerId);
			}
			const bucket = bySpeaker.get(speakerId);
			if (status === "original" || status === void 0 || status === "none") if (token.is_final) bucket.finalOriginal += text;
			else bucket.nonFinalOriginal += text;
			if (status === "translation") if (token.is_final) bucket.finalTranslation += text;
			else bucket.nonFinalTranslation += text;
		}
		if (interpreterFinalChunk) {
			interpreterBuffer.value += interpreterFinalChunk;
			console.debug(TWO_WAY_LOG_PREFIX, "interpreter-buffer", interpreterFinalChunk.substring(0, 60));
		}
		for (const speakerId of speakerOrder) {
			const chunk = bySpeaker.get(speakerId);
			if (!chunk) continue;
			processSpeakerChunk(chunk, audioSource);
		}
	}
	function processSpeakerChunk(chunk, audioSource) {
		if (session.activeSpeakerId && chunk.speakerId !== session.activeSpeakerId) commitSessionEntry(audioSource);
		if (!session.activeSpeakerId) session.activeSpeakerId = chunk.speakerId;
		const now = Date.now();
		const hasIncomingText = Boolean(chunk.finalOriginal || chunk.finalTranslation || chunk.nonFinalOriginal || chunk.nonFinalTranslation);
		if (session.activeSpeakerId === chunk.speakerId && hasIncomingText && session.lastSpeakerActivityAt > 0 && now - session.lastSpeakerActivityAt >= SPEAKER_PAUSE_MS && (session.originalBuffer || session.translationBuffer)) {
			commitSessionEntry(audioSource);
			session.activeSpeakerId = chunk.speakerId;
		}
		if (chunk.finalOriginal) session.originalBuffer += chunk.finalOriginal;
		if (chunk.finalTranslation) session.translationBuffer += chunk.finalTranslation;
		const displayOriginal = session.originalBuffer + chunk.nonFinalOriginal;
		const displayTranslation = session.translationBuffer + chunk.nonFinalTranslation;
		if (displayOriginal || displayTranslation) store.updateCurrentTokens(chunk.speakerId, displayOriginal, displayTranslation, audioSource);
		if (hasIncomingText) session.lastSpeakerActivityAt = now;
		maybeFlushForTTS(audioSource);
	}
	function maybeFlushForTTS(audioSource) {
		if (!tts.isEnabled.value) return;
		const translationText = session.translationBuffer;
		if (!translationText.trim()) return;
		const now = Date.now();
		if (now - session.lastTTSCommitAt < SPEAKER_PAUSE_MS) return;
		session.lastTTSCommitAt = now;
		tts.enqueue(translationText, activeTargetLanguage);
		session.translationBuffer = "";
		session.originalBuffer = "";
		store.finalizeCurrent(session.activeSpeakerId ?? "unknown", audioSource);
	}
	function flushInterpreterBuffer() {
		const text = interpreterBuffer.value.trim();
		if (text) {
			console.debug(TWO_WAY_LOG_PREFIX, "flush-buffer", {
				text: text.substring(0, 80),
				interpreterActive: isInterpreterActive.value,
				hasCallback: !!onInterpreterText.value
			});
			if (isInterpreterActive.value && onInterpreterText.value) onInterpreterText.value(text);
		}
		interpreterBuffer.value = "";
	}
	function handleEndpoint() {
		commitSessionEntry("tab");
		flushInterpreterBuffer();
	}
	function handleFinalized() {
		commitSessionEntry("tab");
		flushInterpreterBuffer();
	}
	function commitSessionEntry(audioSource) {
		const currentEntry = audioSource === "mic" ? store.currentMic : store.currentTab;
		const fallbackTranslation = currentEntry.translation ?? "";
		const hasAnyText = Boolean(session.originalBuffer || session.translationBuffer || currentEntry.original || fallbackTranslation);
		if (!session.activeSpeakerId || !hasAnyText) return;
		const translationText = session.translationBuffer || fallbackTranslation;
		store.finalizeCurrent(session.activeSpeakerId, audioSource);
		if (translationText.trim() && tts.isEnabled.value) tts.enqueue(translationText, activeTargetLanguage);
		session.activeSpeakerId = null;
		session.originalBuffer = "";
		session.translationBuffer = "";
		session.lastSpeakerActivityAt = 0;
		session.lastTTSCommitAt = Date.now();
	}
	function normalizeSpeakerId(rawSpeaker, fallbackSpeaker) {
		const normalizedSpeaker = rawSpeaker?.trim();
		if (normalizedSpeaker) return normalizedSpeaker;
		if (fallbackSpeaker) return fallbackSpeaker;
		return "unknown";
	}
	function configureTTS(settings) {
		const apiSpeed = uiSpeedToApiSpeed(settings.voiceSpeed);
		const voiceVol = settings.voiceVolume / 100;
		const duckLevel = settings.originalVolume / 100;
		ducker.setDuckLevel(duckLevel);
		const config = {
			apiKey: settings.apiKey,
			speed: apiSpeed,
			volume: voiceVol,
			autoSyncSpeed: settings.autoSyncSpeed ?? true,
			callbacks: {
				onSpeakStart: () => {
					ducker.duck();
				},
				onSpeakEnd: () => {
					ducker.restore();
				},
				onError: (err) => {
					console.error("[TTS:Translation] TTS pipeline error:", err.message);
					ducker.restore();
				}
			}
		};
		if (settings.model) config.model = settings.model;
		if (settings.voice) config.voice = settings.voice;
		tts.configure(config);
	}
	function setNarrationEnabled(enabled) {
		if (enabled) {
			session.translationBuffer = "";
			session.originalBuffer = "";
			session.lastTTSCommitAt = Date.now();
		}
		tts.setEnabled(enabled);
		if (!enabled) ducker.restore();
	}
	/**
	* Apply narration settings. If TTS is currently running,
	* restart the pipeline to apply new speed/voice/volume.
	*/
	function applyNarrationSettings(settings) {
		configureTTS(settings);
		if (tts.isEnabled.value) {
			tts.stop();
			session.translationBuffer = "";
			session.originalBuffer = "";
			session.lastTTSCommitAt = Date.now();
			tts.setEnabled(true);
		}
	}
	/**
	* Apply settings and start narration (enable TTS).
	*/
	function startNarration(settings) {
		configureTTS(settings);
		setNarrationEnabled(true);
	}
	async function testNarrationVoice(settings) {
		if (!settings.apiKey.trim()) throw new Error("Please configure OpenAI API key to use voice test");
		const apiSpeed = uiSpeedToApiSpeed(settings.voiceSpeed);
		const voiceVol = settings.voiceVolume / 100;
		const duckLevel = settings.originalVolume / 100;
		ducker.setDuckLevel(duckLevel);
		ducker.duck();
		try {
			const previewRequest = {
				apiKey: settings.apiKey,
				text: SAMPLE_TEST_TEXT,
				language: activeTargetLanguage,
				speed: apiSpeed,
				volume: voiceVol
			};
			if (settings.model) previewRequest.model = settings.model;
			if (settings.voice) previewRequest.voice = settings.voice;
			await tts.speakOnce(previewRequest);
		} finally {
			ducker.restore();
		}
	}
	function start(apiKey, targetLanguage, microphoneEnabled = false, theirLanguage) {
		store.reset();
		store.setTargetLanguage(targetLanguage);
		session = createSessionState();
		activeTargetLanguage = targetLanguage;
		activeTheirLanguage = theirLanguage ?? "none";
		interpreterBuffer.value = "";
		const mode = activeTheirLanguage !== "none" && activeTheirLanguage !== targetLanguage ? "two_way" : "one_way";
		console.info(TWO_WAY_LOG_PREFIX, "start", {
			mode,
			targetLanguage,
			theirLanguage: activeTheirLanguage,
			microphoneEnabled
		});
		soniox.startRecording(apiKey, targetLanguage, {
			onResult: handleResult,
			onEndpoint: handleEndpoint,
			onFinalized: handleFinalized
		}, microphoneEnabled, theirLanguage);
	}
	function pause() {
		soniox.pauseRecording();
	}
	function resume() {
		soniox.resumeRecording();
	}
	async function end() {
		await soniox.stopRecording();
		commitSessionEntry("tab");
		tts.stop();
		ducker.restore();
	}
	function cancel() {
		soniox.cancelRecording();
		session = createSessionState();
		tts.stop();
		ducker.restore();
	}
	async function setMicEnabled(enabled) {
		await soniox.setMicEnabled(enabled);
	}
	function clear() {
		store.clearEntries();
		session = createSessionState();
	}
	function stopNarration() {
		tts.stop();
		tts.setEnabled(false);
		ducker.restore();
		session.translationBuffer = "";
		session.originalBuffer = "";
		session.lastTTSCommitAt = 0;
	}
	function startInterpreterMode(callback) {
		isInterpreterActive.value = true;
		interpreterBuffer.value = "";
		onInterpreterText.value = callback;
	}
	function stopInterpreterMode() {
		flushInterpreterBuffer();
		isInterpreterActive.value = false;
		interpreterBuffer.value = "";
		onInterpreterText.value = null;
	}
	return {
		state: soniox.state,
		error: soniox.error,
		ttsState: {
			isSpeaking: tts.isSpeaking,
			isEnabled: tts.isEnabled,
			error: tts.error,
			queueLength: tts.queueLength,
			effectiveSpeed: tts.effectiveSpeed
		},
		start,
		pause,
		resume,
		end,
		cancel,
		clear,
		setMicEnabled,
		configureTTS,
		setNarrationEnabled,
		applyNarrationSettings,
		startNarration,
		testNarrationVoice,
		stopNarration,
		isInterpreterActive,
		startInterpreterMode,
		stopInterpreterMode
	};
}
//#endregion
//#region src/composables/useDownloadTranscript.ts
function formatTimestamp(ms) {
	const totalSeconds = Math.max(0, Math.floor(ms / 1e3));
	const minutes = Math.floor(totalSeconds / 60);
	const seconds = totalSeconds % 60;
	return `${minutes}:${String(seconds).padStart(2, "0")}`;
}
function computeRelativeTimes(entries) {
	if (entries.length === 0) return [];
	const baseTimestamp = entries[0].timestamp;
	return entries.map((entry, index) => {
		const start = entry.timestamp - baseTimestamp;
		const nextEntry = entries[index + 1];
		return {
			start,
			end: nextEntry ? nextEntry.timestamp - baseTimestamp : start + 2e3
		};
	});
}
function formatAsText(entries, speakerNames, speakerPrefix, fallbackLabel) {
	if (entries.length === 0) return "";
	const times = computeRelativeTimes(entries);
	const lines = [];
	entries.forEach((entry, index) => {
		const { start, end } = times[index];
		const startStr = formatTimestamp(start);
		const endStr = formatTimestamp(end);
		const speaker = entry.audioSource === "mic" ? fallbackLabel : resolveSpeakerLabel(entry.speakerId, speakerNames, speakerPrefix, fallbackLabel);
		if (entry.originalText) lines.push(`[${startStr} - ${endStr}] [${speaker}] [${entry.sourceLanguage || "unknown"}]: ${entry.originalText}`);
		if (entry.translatedText) lines.push(`[${startStr} - ${endStr}] [${speaker}] [${entry.targetLanguage}]: ${entry.translatedText}`);
	});
	return lines.join("\n");
}
function formatAsJson(entries, speakerNames, speakerPrefix, fallbackLabel) {
	if (entries.length === 0) return "[]";
	const times = computeRelativeTimes(entries);
	const result = entries.map((entry, index) => {
		const { start, end } = times[index];
		const speaker = entry.audioSource === "mic" ? fallbackLabel : resolveSpeakerLabel(entry.speakerId, speakerNames, speakerPrefix, fallbackLabel);
		const transcript = {};
		if (entry.originalText) transcript[entry.sourceLanguage || "unknown"] = entry.originalText;
		if (entry.translatedText) transcript[entry.targetLanguage] = entry.translatedText;
		return {
			start: formatTimestamp(start),
			end: formatTimestamp(end),
			speaker,
			transcript
		};
	});
	return JSON.stringify(result, null, 2);
}
function downloadFile(content, filename, mimeType) {
	const blob = new Blob([content], { type: mimeType });
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	document.body.appendChild(anchor);
	anchor.click();
	document.body.removeChild(anchor);
	URL.revokeObjectURL(url);
}
function buildFilename(extension) {
	const now = /* @__PURE__ */ new Date();
	return `transcript-${now.toISOString().slice(0, 10)}-${now.toTimeString().slice(0, 5).replace(":", "")}.${extension}`;
}
function useDownloadTranscript() {
	const { t } = useI18n();
	const settingsStore = useSettingsStore();
	function downloadTxt(entries) {
		downloadFile(formatAsText(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown")), buildFilename("txt"), "text/plain;charset=utf-8");
	}
	function downloadJson(entries) {
		downloadFile(formatAsJson(entries, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown")), buildFilename("json"), "application/json;charset=utf-8");
	}
	return {
		downloadTxt,
		downloadJson
	};
}
//#endregion
//#region src/components/translator/TranslatorHeader.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = { class: "translator-header" };
var _hoisted_2$6 = { class: "translator-header__inner" };
//#endregion
//#region src/components/translator/TranslatorHeader.vue
var TranslatorHeader_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorHeader",
	props: {
		targetLanguage: {},
		theirLanguage: {},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	emits: ["update:targetLanguage", "update:theirLanguage"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const languageOptions = SUPPORTED_LANGUAGES.map((lang) => ({
			label: `${lang.nativeLabel} (${lang.label})`,
			value: lang.value
		}));
		const theirLanguageOptions = computed(() => [{
			label: "None",
			value: "none"
		}, ...languageOptions]);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$6, [createBaseVNode("div", _hoisted_2$6, [
				createVNode(QSelect_default, {
					"model-value": __props.targetLanguage,
					options: unref(languageOptions),
					dense: "",
					outlined: "",
					"emit-value": "",
					"map-options": "",
					label: _ctx.$t("translator.myLanguage"),
					disable: __props.disabled,
					"popup-content-class": "translator-language-menu",
					class: "translator-language-select",
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:targetLanguage", $event))
				}, {
					prepend: withCtx(() => [createVNode(QIcon_default, {
						name: "person",
						size: "xs"
					})]),
					_: 1
				}, 8, [
					"model-value",
					"options",
					"label",
					"disable"
				]),
				createVNode(QIcon_default, {
					name: "swap_horiz",
					size: "xs",
					class: "translator-header__swap-icon"
				}),
				createVNode(QSelect_default, {
					"model-value": __props.theirLanguage,
					options: theirLanguageOptions.value,
					dense: "",
					outlined: "",
					"emit-value": "",
					"map-options": "",
					label: _ctx.$t("translator.theirLanguage"),
					disable: __props.disabled,
					"popup-content-class": "translator-language-menu",
					class: "translator-language-select",
					"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => emit("update:theirLanguage", $event))
				}, {
					prepend: withCtx(() => [createVNode(QIcon_default, {
						name: "groups",
						size: "xs"
					})]),
					_: 1
				}, 8, [
					"model-value",
					"options",
					"label",
					"disable"
				])
			])]);
		};
	}
}), [["__scopeId", "data-v-64771b83"]]);
//#endregion
//#region node_modules/quasar/src/components/scroll-area/ScrollAreaControls.js
/**
* We are using a sub-component to avoid unnecessary re-renders
* of the QScrollArea content when the scrollbars are interacted with.
*/
var ScrollAreaControls_default = createComponent({
	props: [
		"store",
		"barStyle",
		"verticalBarStyle",
		"horizontalBarStyle"
	],
	setup(props) {
		return () => [
			h("div", {
				class: props.store.scroll.vertical.barClass.value,
				style: [props.barStyle, props.verticalBarStyle],
				"aria-hidden": "true",
				onMousedown: props.store.onVerticalMousedown
			}),
			h("div", {
				class: props.store.scroll.horizontal.barClass.value,
				style: [props.barStyle, props.horizontalBarStyle],
				"aria-hidden": "true",
				onMousedown: props.store.onHorizontalMousedown
			}),
			withDirectives(h("div", {
				ref: props.store.scroll.vertical.ref,
				class: props.store.scroll.vertical.thumbClass.value,
				style: props.store.scroll.vertical.style.value,
				"aria-hidden": "true"
			}), props.store.thumbVertDir),
			withDirectives(h("div", {
				ref: props.store.scroll.horizontal.ref,
				class: props.store.scroll.horizontal.thumbClass.value,
				style: props.store.scroll.horizontal.style.value,
				"aria-hidden": "true"
			}), props.store.thumbHorizDir)
		];
	}
});
//#endregion
//#region node_modules/quasar/src/utils/private.touch/touch.js
var modifiersAll = {
	left: true,
	right: true,
	up: true,
	down: true,
	horizontal: true,
	vertical: true
};
var directionList = Object.keys(modifiersAll);
modifiersAll.all = true;
function getModifierDirections(mod) {
	const dir = {};
	for (const direction of directionList) if (mod[direction] === true) dir[direction] = true;
	if (Object.keys(dir).length === 0) return modifiersAll;
	if (dir.horizontal === true) dir.left = dir.right = true;
	else if (dir.left === true && dir.right === true) dir.horizontal = true;
	if (dir.vertical === true) dir.up = dir.down = true;
	else if (dir.up === true && dir.down === true) dir.vertical = true;
	if (dir.horizontal === true && dir.vertical === true) dir.all = true;
	return dir;
}
var avoidNodeNamesList = ["INPUT", "TEXTAREA"];
function shouldStart(evt, ctx) {
	return ctx.event === void 0 && evt.target !== void 0 && evt.target.draggable !== true && typeof ctx.handler === "function" && avoidNodeNamesList.includes(evt.target.nodeName.toUpperCase()) === false && (evt.qClonedBy === void 0 || evt.qClonedBy.indexOf(ctx.uid) === -1);
}
//#endregion
//#region node_modules/quasar/src/directives/touch-pan/TouchPan.js
function getChanges(evt, ctx, isFinal) {
	const pos = position(evt);
	let dir, distX = pos.left - ctx.event.x, distY = pos.top - ctx.event.y, absX = Math.abs(distX), absY = Math.abs(distY);
	const direction = ctx.direction;
	if (direction.horizontal === true && direction.vertical !== true) dir = distX < 0 ? "left" : "right";
	else if (direction.horizontal !== true && direction.vertical === true) dir = distY < 0 ? "up" : "down";
	else if (direction.up === true && distY < 0) {
		dir = "up";
		if (absX > absY) {
			if (direction.left === true && distX < 0) dir = "left";
			else if (direction.right === true && distX > 0) dir = "right";
		}
	} else if (direction.down === true && distY > 0) {
		dir = "down";
		if (absX > absY) {
			if (direction.left === true && distX < 0) dir = "left";
			else if (direction.right === true && distX > 0) dir = "right";
		}
	} else if (direction.left === true && distX < 0) {
		dir = "left";
		if (absX < absY) {
			if (direction.up === true && distY < 0) dir = "up";
			else if (direction.down === true && distY > 0) dir = "down";
		}
	} else if (direction.right === true && distX > 0) {
		dir = "right";
		if (absX < absY) {
			if (direction.up === true && distY < 0) dir = "up";
			else if (direction.down === true && distY > 0) dir = "down";
		}
	}
	let synthetic = false;
	if (dir === void 0 && isFinal === false) {
		if (ctx.event.isFirst === true || ctx.event.lastDir === void 0) return {};
		dir = ctx.event.lastDir;
		synthetic = true;
		if (dir === "left" || dir === "right") {
			pos.left -= distX;
			absX = 0;
			distX = 0;
		} else {
			pos.top -= distY;
			absY = 0;
			distY = 0;
		}
	}
	return {
		synthetic,
		payload: {
			evt,
			touch: ctx.event.mouse !== true,
			mouse: ctx.event.mouse === true,
			position: pos,
			direction: dir,
			isFirst: ctx.event.isFirst,
			isFinal: isFinal === true,
			duration: Date.now() - ctx.event.time,
			distance: {
				x: absX,
				y: absY
			},
			offset: {
				x: distX,
				y: distY
			},
			delta: {
				x: pos.left - ctx.event.lastX,
				y: pos.top - ctx.event.lastY
			}
		}
	};
}
var uid = 0;
var TouchPan_default = createDirective({
	name: "touch-pan",
	beforeMount(el, { value, modifiers }) {
		if (modifiers.mouse !== true && client.has.touch !== true) return;
		function handleEvent(evt, mouseEvent) {
			if (modifiers.mouse === true && mouseEvent === true) stopAndPrevent(evt);
			else {
				modifiers.stop === true && stop(evt);
				modifiers.prevent === true && prevent(evt);
			}
		}
		const ctx = {
			uid: "qvtp_" + uid++,
			handler: value,
			modifiers,
			direction: getModifierDirections(modifiers),
			noop,
			mouseStart(evt) {
				if (shouldStart(evt, ctx) && leftClick(evt)) {
					addEvt(ctx, "temp", [[
						document,
						"mousemove",
						"move",
						"notPassiveCapture"
					], [
						document,
						"mouseup",
						"end",
						"passiveCapture"
					]]);
					ctx.start(evt, true);
				}
			},
			touchStart(evt) {
				if (shouldStart(evt, ctx)) {
					const target = evt.target;
					addEvt(ctx, "temp", [
						[
							target,
							"touchmove",
							"move",
							"notPassiveCapture"
						],
						[
							target,
							"touchcancel",
							"end",
							"passiveCapture"
						],
						[
							target,
							"touchend",
							"end",
							"passiveCapture"
						]
					]);
					ctx.start(evt);
				}
			},
			start(evt, mouseEvent) {
				client.is.firefox === true && preventDraggable(el, true);
				ctx.lastEvt = evt;
				if (mouseEvent === true || modifiers.stop === true) {
					if (ctx.direction.all !== true && (mouseEvent !== true || ctx.modifiers.mouseAllDir !== true && ctx.modifiers.mousealldir !== true)) {
						const clone = evt.type.indexOf("mouse") !== -1 ? new MouseEvent(evt.type, evt) : new TouchEvent(evt.type, evt);
						evt.defaultPrevented === true && prevent(clone);
						evt.cancelBubble === true && stop(clone);
						Object.assign(clone, {
							qKeyEvent: evt.qKeyEvent,
							qClickOutside: evt.qClickOutside,
							qAnchorHandled: evt.qAnchorHandled,
							qClonedBy: evt.qClonedBy === void 0 ? [ctx.uid] : evt.qClonedBy.concat(ctx.uid)
						});
						ctx.initialEvent = {
							target: evt.target,
							event: clone
						};
					}
					stop(evt);
				}
				const { left, top } = position(evt);
				ctx.event = {
					x: left,
					y: top,
					time: Date.now(),
					mouse: mouseEvent === true,
					detected: false,
					isFirst: true,
					isFinal: false,
					lastX: left,
					lastY: top
				};
			},
			move(evt) {
				if (ctx.event === void 0) return;
				const pos = position(evt), distX = pos.left - ctx.event.x, distY = pos.top - ctx.event.y;
				if (distX === 0 && distY === 0) return;
				ctx.lastEvt = evt;
				const isMouseEvt = ctx.event.mouse === true;
				const start = () => {
					handleEvent(evt, isMouseEvt);
					let cursor;
					if (modifiers.preserveCursor !== true && modifiers.preservecursor !== true) {
						cursor = document.documentElement.style.cursor || "";
						document.documentElement.style.cursor = "grabbing";
					}
					isMouseEvt === true && document.body.classList.add("no-pointer-events--children");
					document.body.classList.add("non-selectable");
					clearSelection();
					ctx.styleCleanup = (withDelayedFn) => {
						ctx.styleCleanup = void 0;
						if (cursor !== void 0) document.documentElement.style.cursor = cursor;
						document.body.classList.remove("non-selectable");
						if (isMouseEvt === true) {
							const remove = () => {
								document.body.classList.remove("no-pointer-events--children");
							};
							if (withDelayedFn !== void 0) setTimeout(() => {
								remove();
								withDelayedFn();
							}, 50);
							else remove();
						} else if (withDelayedFn !== void 0) withDelayedFn();
					};
				};
				if (ctx.event.detected === true) {
					ctx.event.isFirst !== true && handleEvent(evt, ctx.event.mouse);
					const { payload, synthetic } = getChanges(evt, ctx, false);
					if (payload !== void 0) if (ctx.handler(payload) === false) ctx.end(evt);
					else {
						if (ctx.styleCleanup === void 0 && ctx.event.isFirst === true) start();
						ctx.event.lastX = payload.position.left;
						ctx.event.lastY = payload.position.top;
						ctx.event.lastDir = synthetic === true ? void 0 : payload.direction;
						ctx.event.isFirst = false;
					}
					return;
				}
				if (ctx.direction.all === true || isMouseEvt === true && (ctx.modifiers.mouseAllDir === true || ctx.modifiers.mousealldir === true)) {
					start();
					ctx.event.detected = true;
					ctx.move(evt);
					return;
				}
				const absX = Math.abs(distX), absY = Math.abs(distY);
				if (absX !== absY) if (ctx.direction.horizontal === true && absX > absY || ctx.direction.vertical === true && absX < absY || ctx.direction.up === true && absX < absY && distY < 0 || ctx.direction.down === true && absX < absY && distY > 0 || ctx.direction.left === true && absX > absY && distX < 0 || ctx.direction.right === true && absX > absY && distX > 0) {
					ctx.event.detected = true;
					ctx.move(evt);
				} else ctx.end(evt, true);
			},
			end(evt, abort) {
				if (ctx.event === void 0) return;
				cleanEvt(ctx, "temp");
				client.is.firefox === true && preventDraggable(el, false);
				if (abort === true) {
					ctx.styleCleanup?.();
					if (ctx.event.detected !== true && ctx.initialEvent !== void 0) ctx.initialEvent.target.dispatchEvent(ctx.initialEvent.event);
				} else if (ctx.event.detected === true) {
					ctx.event.isFirst === true && ctx.handler(getChanges(evt === void 0 ? ctx.lastEvt : evt, ctx).payload);
					const { payload } = getChanges(evt === void 0 ? ctx.lastEvt : evt, ctx, true);
					const fn = () => {
						ctx.handler(payload);
					};
					if (ctx.styleCleanup !== void 0) ctx.styleCleanup(fn);
					else fn();
				}
				ctx.event = void 0;
				ctx.initialEvent = void 0;
				ctx.lastEvt = void 0;
			}
		};
		el.__qtouchpan = ctx;
		if (modifiers.mouse === true) addEvt(ctx, "main", [[
			el,
			"mousedown",
			"mouseStart",
			`passive${modifiers.mouseCapture === true || modifiers.mousecapture === true ? "Capture" : ""}`
		]]);
		client.has.touch === true && addEvt(ctx, "main", [[
			el,
			"touchstart",
			"touchStart",
			`passive${modifiers.capture === true ? "Capture" : ""}`
		], [
			el,
			"touchmove",
			"noop",
			"notPassiveCapture"
		]]);
	},
	updated(el, bindings) {
		const ctx = el.__qtouchpan;
		if (ctx !== void 0) {
			if (bindings.oldValue !== bindings.value) {
				typeof value !== "function" && ctx.end();
				ctx.handler = bindings.value;
			}
			ctx.direction = getModifierDirections(bindings.modifiers);
		}
	},
	beforeUnmount(el) {
		const ctx = el.__qtouchpan;
		if (ctx !== void 0) {
			ctx.event !== void 0 && ctx.end();
			cleanEvt(ctx, "main");
			cleanEvt(ctx, "temp");
			client.is.firefox === true && preventDraggable(el, false);
			ctx.styleCleanup?.();
			delete el.__qtouchpan;
		}
	}
});
//#endregion
//#region node_modules/quasar/src/components/scroll-area/QScrollArea.js
var axisList = ["vertical", "horizontal"];
var dirProps = {
	vertical: {
		offset: "offsetY",
		scroll: "scrollTop",
		dir: "down",
		dist: "y"
	},
	horizontal: {
		offset: "offsetX",
		scroll: "scrollLeft",
		dir: "right",
		dist: "x"
	}
};
var panOpts = {
	prevent: true,
	mouse: true,
	mouseAllDir: true
};
var getMinThumbSize = (size) => size >= 250 ? 50 : Math.ceil(size / 5);
var QScrollArea_default = createComponent({
	name: "QScrollArea",
	props: {
		...useDarkProps,
		thumbStyle: Object,
		verticalThumbStyle: Object,
		horizontalThumbStyle: Object,
		barStyle: [
			Array,
			String,
			Object
		],
		verticalBarStyle: [
			Array,
			String,
			Object
		],
		horizontalBarStyle: [
			Array,
			String,
			Object
		],
		verticalOffset: {
			type: Array,
			default: [0, 0]
		},
		horizontalOffset: {
			type: Array,
			default: [0, 0]
		},
		contentStyle: [
			Array,
			String,
			Object
		],
		contentActiveStyle: [
			Array,
			String,
			Object
		],
		delay: {
			type: [String, Number],
			default: 1e3
		},
		visible: {
			type: Boolean,
			default: null
		},
		tabindex: [String, Number],
		onScroll: Function
	},
	setup(props, { slots, emit }) {
		const tempShowing = ref(false);
		const panning = ref(false);
		const hover = ref(false);
		const container = {
			vertical: ref(0),
			horizontal: ref(0)
		};
		const scroll = {
			vertical: {
				ref: ref(null),
				position: ref(0),
				size: ref(0)
			},
			horizontal: {
				ref: ref(null),
				position: ref(0),
				size: ref(0)
			}
		};
		const { proxy } = getCurrentInstance();
		const isDark = use_dark_default(props, proxy.$q);
		let timer = null, panRefPos;
		const targetRef = ref(null);
		const classes = computed(() => "q-scrollarea" + (isDark.value === true ? " q-scrollarea--dark" : ""));
		Object.assign(container, {
			verticalInner: computed(() => container.vertical.value - props.verticalOffset[0] - props.verticalOffset[1]),
			horizontalInner: computed(() => container.horizontal.value - props.horizontalOffset[0] - props.horizontalOffset[1])
		});
		scroll.vertical.percentage = computed(() => {
			const diff = scroll.vertical.size.value - container.vertical.value;
			if (diff <= 0) return 0;
			const p = between(scroll.vertical.position.value / diff, 0, 1);
			return Math.round(p * 1e4) / 1e4;
		});
		scroll.vertical.thumbHidden = computed(() => (props.visible === null ? hover.value : props.visible) !== true && tempShowing.value === false && panning.value === false || scroll.vertical.size.value <= container.vertical.value + 1);
		scroll.vertical.thumbStart = computed(() => props.verticalOffset[0] + scroll.vertical.percentage.value * (container.verticalInner.value - scroll.vertical.thumbSize.value));
		scroll.vertical.thumbSize = computed(() => Math.round(between(container.verticalInner.value * container.verticalInner.value / scroll.vertical.size.value, getMinThumbSize(container.verticalInner.value), container.verticalInner.value)));
		scroll.vertical.style = computed(() => ({
			...props.thumbStyle,
			...props.verticalThumbStyle,
			top: `${scroll.vertical.thumbStart.value}px`,
			height: `${scroll.vertical.thumbSize.value}px`,
			right: `${props.horizontalOffset[1]}px`
		}));
		scroll.vertical.thumbClass = computed(() => "q-scrollarea__thumb q-scrollarea__thumb--v absolute-right" + (scroll.vertical.thumbHidden.value === true ? " q-scrollarea__thumb--invisible" : ""));
		scroll.vertical.barClass = computed(() => "q-scrollarea__bar q-scrollarea__bar--v absolute-right" + (scroll.vertical.thumbHidden.value === true ? " q-scrollarea__bar--invisible" : ""));
		scroll.horizontal.percentage = computed(() => {
			const diff = scroll.horizontal.size.value - container.horizontal.value;
			if (diff <= 0) return 0;
			const p = between(Math.abs(scroll.horizontal.position.value) / diff, 0, 1);
			return Math.round(p * 1e4) / 1e4;
		});
		scroll.horizontal.thumbHidden = computed(() => (props.visible === null ? hover.value : props.visible) !== true && tempShowing.value === false && panning.value === false || scroll.horizontal.size.value <= container.horizontal.value + 1);
		scroll.horizontal.thumbStart = computed(() => props.horizontalOffset[0] + scroll.horizontal.percentage.value * (container.horizontalInner.value - scroll.horizontal.thumbSize.value));
		scroll.horizontal.thumbSize = computed(() => Math.round(between(container.horizontalInner.value * container.horizontalInner.value / scroll.horizontal.size.value, getMinThumbSize(container.horizontalInner.value), container.horizontalInner.value)));
		scroll.horizontal.style = computed(() => ({
			...props.thumbStyle,
			...props.horizontalThumbStyle,
			[proxy.$q.lang.rtl === true ? "right" : "left"]: `${scroll.horizontal.thumbStart.value}px`,
			width: `${scroll.horizontal.thumbSize.value}px`,
			bottom: `${props.verticalOffset[1]}px`
		}));
		scroll.horizontal.thumbClass = computed(() => "q-scrollarea__thumb q-scrollarea__thumb--h absolute-bottom" + (scroll.horizontal.thumbHidden.value === true ? " q-scrollarea__thumb--invisible" : ""));
		scroll.horizontal.barClass = computed(() => "q-scrollarea__bar q-scrollarea__bar--h absolute-bottom" + (scroll.horizontal.thumbHidden.value === true ? " q-scrollarea__bar--invisible" : ""));
		const mainStyle = computed(() => scroll.vertical.thumbHidden.value === true && scroll.horizontal.thumbHidden.value === true ? props.contentStyle : props.contentActiveStyle);
		function getScroll() {
			const info = {};
			axisList.forEach((axis) => {
				const data = scroll[axis];
				Object.assign(info, {
					[axis + "Position"]: data.position.value,
					[axis + "Percentage"]: data.percentage.value,
					[axis + "Size"]: data.size.value,
					[axis + "ContainerSize"]: container[axis].value,
					[axis + "ContainerInnerSize"]: container[axis + "Inner"].value
				});
			});
			return info;
		}
		const emitScroll = debounce_default(() => {
			const info = getScroll();
			info.ref = proxy;
			emit("scroll", info);
		}, 0);
		function localSetScrollPosition(axis, offset, duration) {
			if (axisList.includes(axis) === false) {
				console.error("[QScrollArea]: wrong first param of setScrollPosition (vertical/horizontal)");
				return;
			}
			(axis === "vertical" ? setVerticalScrollPosition : setHorizontalScrollPosition)(targetRef.value, offset, duration);
		}
		function updateContainer({ height, width }) {
			let change = false;
			if (container.vertical.value !== height) {
				container.vertical.value = height;
				change = true;
			}
			if (container.horizontal.value !== width) {
				container.horizontal.value = width;
				change = true;
			}
			change === true && startTimer();
		}
		function updateScroll({ position }) {
			let change = false;
			if (scroll.vertical.position.value !== position.top) {
				scroll.vertical.position.value = position.top;
				change = true;
			}
			if (scroll.horizontal.position.value !== position.left) {
				scroll.horizontal.position.value = position.left;
				change = true;
			}
			change === true && startTimer();
		}
		function updateScrollSize({ height, width }) {
			if (scroll.horizontal.size.value !== width) {
				scroll.horizontal.size.value = width;
				startTimer();
			}
			if (scroll.vertical.size.value !== height) {
				scroll.vertical.size.value = height;
				startTimer();
			}
		}
		function onPanThumb(e, axis) {
			const data = scroll[axis];
			if (e.isFirst === true) {
				if (data.thumbHidden.value === true) return;
				panRefPos = data.position.value;
				panning.value = true;
			} else if (panning.value !== true) return;
			if (e.isFinal === true) panning.value = false;
			const dProp = dirProps[axis];
			const multiplier = (data.size.value - container[axis].value) / (container[axis + "Inner"].value - data.thumbSize.value);
			const distance = e.distance[dProp.dist];
			setScroll(panRefPos + (e.direction === dProp.dir ? 1 : -1) * distance * multiplier, axis);
		}
		function onMousedown(evt, axis) {
			const data = scroll[axis];
			if (data.thumbHidden.value !== true) {
				const startOffset = axis === "vertical" ? props.verticalOffset[0] : props.horizontalOffset[0];
				const offset = evt[dirProps[axis].offset] - startOffset;
				const thumbStart = data.thumbStart.value - startOffset;
				if (offset < thumbStart || offset > thumbStart + data.thumbSize.value) setScroll(between((offset - data.thumbSize.value / 2) / (container[axis + "Inner"].value - data.thumbSize.value), 0, 1) * Math.max(0, data.size.value - container[axis].value), axis);
				if (data.ref.value !== null) data.ref.value.dispatchEvent(new MouseEvent(evt.type, evt));
			}
		}
		function startTimer() {
			tempShowing.value = true;
			timer !== null && clearTimeout(timer);
			timer = setTimeout(() => {
				timer = null;
				tempShowing.value = false;
			}, props.delay);
			props.onScroll !== void 0 && emitScroll();
		}
		function setScroll(offset, axis) {
			targetRef.value[dirProps[axis].scroll] = offset;
		}
		let mouseEventTimer = null;
		function onMouseenter() {
			if (mouseEventTimer !== null) clearTimeout(mouseEventTimer);
			mouseEventTimer = setTimeout(() => {
				mouseEventTimer = null;
				hover.value = true;
			}, proxy.$q.platform.is.ios ? 50 : 0);
		}
		function onMouseleave() {
			if (mouseEventTimer !== null) {
				clearTimeout(mouseEventTimer);
				mouseEventTimer = null;
			}
			hover.value = false;
		}
		let scrollPosition = null;
		watch(() => proxy.$q.lang.rtl, (rtl) => {
			if (targetRef.value !== null) setHorizontalScrollPosition(targetRef.value, Math.abs(scroll.horizontal.position.value) * (rtl === true ? -1 : 1));
		});
		onDeactivated(() => {
			scrollPosition = {
				top: scroll.vertical.position.value,
				left: scroll.horizontal.position.value
			};
		});
		onActivated(() => {
			if (scrollPosition === null) return;
			const scrollTarget = targetRef.value;
			if (scrollTarget !== null) {
				setHorizontalScrollPosition(scrollTarget, scrollPosition.left);
				setVerticalScrollPosition(scrollTarget, scrollPosition.top);
			}
		});
		onBeforeUnmount(emitScroll.cancel);
		Object.assign(proxy, {
			getScrollTarget: () => targetRef.value,
			getScroll,
			getScrollPosition: () => ({
				top: scroll.vertical.position.value,
				left: scroll.horizontal.position.value
			}),
			getScrollPercentage: () => ({
				top: scroll.vertical.percentage.value,
				left: scroll.horizontal.percentage.value
			}),
			setScrollPosition: localSetScrollPosition,
			setScrollPercentage(axis, percentage, duration) {
				localSetScrollPosition(axis, percentage * (scroll[axis].size.value - container[axis].value) * (axis === "horizontal" && proxy.$q.lang.rtl === true ? -1 : 1), duration);
			}
		});
		const store = {
			scroll,
			thumbVertDir: [[
				TouchPan_default,
				(e) => {
					onPanThumb(e, "vertical");
				},
				void 0,
				{
					vertical: true,
					...panOpts
				}
			]],
			thumbHorizDir: [[
				TouchPan_default,
				(e) => {
					onPanThumb(e, "horizontal");
				},
				void 0,
				{
					horizontal: true,
					...panOpts
				}
			]],
			onVerticalMousedown(evt) {
				onMousedown(evt, "vertical");
			},
			onHorizontalMousedown(evt) {
				onMousedown(evt, "horizontal");
			}
		};
		return () => {
			return h("div", {
				class: classes.value,
				onMouseenter,
				onMouseleave
			}, [
				h("div", {
					ref: targetRef,
					class: "q-scrollarea__container scroll relative-position fit hide-scrollbar",
					tabindex: props.tabindex !== void 0 ? props.tabindex : void 0
				}, [h("div", {
					class: "q-scrollarea__content absolute",
					style: mainStyle.value
				}, hMergeSlot(slots.default, [h(QResizeObserver_default, {
					debounce: 0,
					onResize: updateScrollSize
				})])), h(QScrollObserver_default, {
					axis: "both",
					onScroll: updateScroll
				})]),
				h(QResizeObserver_default, {
					debounce: 0,
					onResize: updateContainer
				}),
				h(ScrollAreaControls_default, {
					store,
					barStyle: props.barStyle,
					verticalBarStyle: props.verticalBarStyle,
					horizontalBarStyle: props.horizontalBarStyle
				})
			]);
		};
	}
});
//#endregion
//#region src/components/translator/TranslatorDisplay.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = { class: "translator-display-wrapper" };
var _hoisted_2$5 = { class: "translator-display__inner" };
var _hoisted_3$5 = {
	key: 0,
	class: "empty-state"
};
var _hoisted_4$4 = { class: "empty-state__text" };
var _hoisted_5$4 = ["onMouseenter", "onMouseleave"];
var _hoisted_6$2 = { class: "original-text" };
var _hoisted_7$2 = { class: "translated-row" };
var _hoisted_8$1 = ["onClick"];
var _hoisted_9$1 = { class: "speaker-label" };
var _hoisted_10$1 = { class: "original-text" };
var _hoisted_11$1 = { class: "translated-row" };
var _hoisted_12$1 = { class: "speaker-label speaker-label--mic" };
var _hoisted_13$1 = { class: "original-text" };
var _hoisted_14$1 = { class: "translated-row" };
var _hoisted_15$1 = {
	key: 0,
	class: "scroll-to-latest-wrapper"
};
var pauseThresholdPx = 40;
var INLINE_ASSISTANT_LOG_PREFIX$1 = "[InlineAssistant:UI]";
//#endregion
//#region src/components/translator/TranslatorDisplay.vue
var TranslatorDisplay_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorDisplay",
	props: {
		entries: {},
		currentSpeakerId: {},
		currentOriginal: {},
		currentTranslation: {},
		isActive: { type: Boolean },
		translationFontSize: { default: "medium" }
	},
	emits: ["open-assistant"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const { t } = useI18n();
		const store = useTranslatorStore();
		const settingsStore = useSettingsStore();
		const scrollRef = ref(null);
		const autoScrollEnabled = ref(true);
		const showScrollToLatest = computed(() => !autoScrollEnabled.value);
		const hoveredEntryId = ref(null);
		const scrollThumbStyle = {
			right: "2px",
			width: "6px",
			borderRadius: "999px",
			background: "rgba(138, 180, 248, 0.45)",
			opacity: "0.92"
		};
		const scrollBarStyle = {
			right: "1px",
			width: "8px",
			borderRadius: "999px",
			background: "rgba(255, 255, 255, 0.07)",
			opacity: "0.8"
		};
		const hasTabCurrent = computed(() => Boolean(store.currentTab.original || store.currentTab.translation));
		const hasMicCurrent = computed(() => Boolean(store.currentMic.original || store.currentMic.translation));
		const translatedFontClass = computed(() => `translated-text--${props.translationFontSize}`);
		const assistantBtnSize = computed(() => {
			if (props.translationFontSize === "small") return "24px";
			if (props.translationFontSize === "large") return "32px";
			return "28px";
		});
		const fallbackTargetLanguage = computed(() => props.entries[props.entries.length - 1]?.targetLanguage ?? "vi");
		const currentTabInlineEntry = computed(() => ({
			id: "current-tab-inline",
			timestamp: Date.now(),
			speakerId: store.currentTab.speakerId ?? "unknown",
			originalText: store.currentTab.original,
			translatedText: store.currentTab.translation,
			sourceLanguage: "",
			targetLanguage: fallbackTargetLanguage.value,
			isFinal: false,
			audioSource: "tab"
		}));
		const currentMicInlineEntry = computed(() => ({
			id: "current-mic-inline",
			timestamp: Date.now(),
			speakerId: store.currentMic.speakerId ?? "unknown",
			originalText: store.currentMic.original,
			translatedText: store.currentMic.translation,
			sourceLanguage: "",
			targetLanguage: fallbackTargetLanguage.value,
			isFinal: false,
			audioSource: "mic"
		}));
		function getDistanceFromBottom(el) {
			return Math.max(0, el.scrollHeight - (el.scrollTop + el.clientHeight));
		}
		function isScrollAreaPayload(value) {
			if (!value || typeof value !== "object") return false;
			const payload = value;
			return typeof payload.verticalPosition === "number" && typeof payload.verticalSize === "number" && typeof payload.verticalContainerSize === "number";
		}
		function isScrollableDomElement(value) {
			if (!value || typeof value !== "object") return false;
			const candidate = value;
			return typeof candidate.scrollTop === "number" && typeof candidate.scrollHeight === "number" && typeof candidate.clientHeight === "number";
		}
		function getScrollContainerFromRef() {
			const current = scrollRef.value;
			if (isScrollableDomElement(current)) return current;
			return null;
		}
		function scrollToBottom() {
			nextTick(() => {
				const current = scrollRef.value;
				if (!current) return;
				if ("setScrollPosition" in current && typeof current.setScrollPosition === "function") {
					current.setScrollPosition("vertical", Number.MAX_SAFE_INTEGER, 0);
					return;
				}
				const scrollContainer = getScrollContainerFromRef();
				if (scrollContainer) scrollContainer.scrollTop = scrollContainer.scrollHeight;
			});
		}
		watch(() => [props.entries.length, props.currentTranslation], () => {
			if (autoScrollEnabled.value) scrollToBottom();
		});
		function speakerLabel(entry) {
			if (entry.audioSource === "mic") return t("translator.you");
			return resolveSpeakerLabel(entry.speakerId, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"));
		}
		function currentSpeakerLabel(speakerId, isMic) {
			if (isMic) return t("translator.you");
			return resolveSpeakerLabel(speakerId, settingsStore.speakerNames, t("translator.speaker"), t("translator.speakerUnknown"));
		}
		function handleScroll(payload) {
			let distance = null;
			if (isScrollAreaPayload(payload)) distance = Math.max(0, payload.verticalSize - (payload.verticalPosition + payload.verticalContainerSize));
			else if (payload && "target" in payload) {
				const target = payload.target;
				if (isScrollableDomElement(target)) distance = getDistanceFromBottom(target);
			}
			if (distance === null) {
				const scrollContainer = getScrollContainerFromRef();
				if (scrollContainer) distance = getDistanceFromBottom(scrollContainer);
			}
			if (distance !== null && distance > pauseThresholdPx) autoScrollEnabled.value = false;
		}
		function scrollToLatestAndResume() {
			autoScrollEnabled.value = true;
			scrollToBottom();
		}
		function handleEntryMouseEnter(entryId) {
			hoveredEntryId.value = entryId;
		}
		function handleEntryMouseLeave(entryId) {
			if (hoveredEntryId.value === entryId) hoveredEntryId.value = null;
		}
		function isAssistantVisible(entryId) {
			return hoveredEntryId.value === entryId;
		}
		function openAssistant(entry) {
			console.log(INLINE_ASSISTANT_LOG_PREFIX$1, "assistant-opened", {
				entryId: entry.id,
				isFinal: entry.isFinal,
				audioSource: entry.audioSource ?? "tab"
			});
			emit("open-assistant", { entry });
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$5, [createVNode(QScrollArea_default, {
				ref_key: "scrollRef",
				ref: scrollRef,
				class: "translator-display",
				"thumb-style": scrollThumbStyle,
				"bar-style": scrollBarStyle,
				onScroll: handleScroll
			}, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_2$5, [
					__props.entries.length === 0 && !__props.currentOriginal && !__props.currentTranslation ? (openBlock(), createElementBlock("div", _hoisted_3$5, [createVNode(QIcon_default, {
						name: "subtitles",
						size: "48px",
						class: "empty-state__icon"
					}), createBaseVNode("p", _hoisted_4$4, toDisplayString(_ctx.$t("translator.emptyState")), 1)])) : createCommentVNode("", true),
					(openBlock(true), createElementBlock(Fragment, null, renderList(__props.entries, (entry) => {
						return openBlock(), createElementBlock("div", {
							key: entry.id,
							class: normalizeClass(["translation-entry", { "translation-entry--mic": entry.audioSource === "mic" }]),
							onMouseenter: ($event) => handleEntryMouseEnter(entry.id),
							onMouseleave: ($event) => handleEntryMouseLeave(entry.id)
						}, [
							createBaseVNode("div", { class: normalizeClass(["speaker-label", { "speaker-label--mic": entry.audioSource === "mic" }]) }, toDisplayString(speakerLabel(entry)), 3),
							createBaseVNode("div", _hoisted_6$2, toDisplayString(entry.originalText), 1),
							createBaseVNode("div", _hoisted_7$2, [createBaseVNode("div", { class: normalizeClass(["translated-text", translatedFontClass.value]) }, toDisplayString(entry.translatedText), 3), createBaseVNode("div", { class: normalizeClass(["inline-assistant-wrapper", { "inline-assistant-wrapper--visible": isAssistantVisible(entry.id) }]) }, [createBaseVNode("button", {
								class: "inline-assistant-btn",
								style: normalizeStyle({
									width: assistantBtnSize.value,
									height: assistantBtnSize.value
								}),
								onClick: ($event) => openAssistant(entry)
							}, [createVNode(QIcon_default, {
								name: "smart_toy",
								size: "16px"
							}), createVNode(QTooltip_default, null, {
								default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
								_: 1
							})], 12, _hoisted_8$1)], 2)])
						], 42, _hoisted_5$4);
					}), 128)),
					hasTabCurrent.value ? (openBlock(), createElementBlock("div", {
						key: 1,
						class: "translation-entry translation-entry--active",
						onMouseenter: _cache[1] || (_cache[1] = ($event) => handleEntryMouseEnter("current-tab-inline")),
						onMouseleave: _cache[2] || (_cache[2] = ($event) => handleEntryMouseLeave("current-tab-inline"))
					}, [
						createBaseVNode("div", _hoisted_9$1, toDisplayString(currentSpeakerLabel(unref(store).currentTab.speakerId, false)), 1),
						createBaseVNode("div", _hoisted_10$1, toDisplayString(unref(store).currentTab.original), 1),
						createBaseVNode("div", _hoisted_11$1, [createBaseVNode("div", { class: normalizeClass(["translated-text", translatedFontClass.value]) }, [createTextVNode(toDisplayString(unref(store).currentTab.translation) + " ", 1), _cache[6] || (_cache[6] = createBaseVNode("span", { class: "typing-indicator" }, [
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" })
						], -1))], 2), createBaseVNode("div", { class: normalizeClass(["inline-assistant-wrapper", { "inline-assistant-wrapper--visible": isAssistantVisible("current-tab-inline") }]) }, [createBaseVNode("button", {
							class: "inline-assistant-btn",
							style: normalizeStyle({
								width: assistantBtnSize.value,
								height: assistantBtnSize.value
							}),
							onClick: _cache[0] || (_cache[0] = ($event) => openAssistant(currentTabInlineEntry.value))
						}, [createVNode(QIcon_default, {
							name: "smart_toy",
							size: "16px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
							_: 1
						})], 4)], 2)])
					], 32)) : createCommentVNode("", true),
					hasMicCurrent.value ? (openBlock(), createElementBlock("div", {
						key: 2,
						class: "translation-entry translation-entry--active translation-entry--mic",
						onMouseenter: _cache[4] || (_cache[4] = ($event) => handleEntryMouseEnter("current-mic-inline")),
						onMouseleave: _cache[5] || (_cache[5] = ($event) => handleEntryMouseLeave("current-mic-inline"))
					}, [
						createBaseVNode("div", _hoisted_12$1, toDisplayString(currentSpeakerLabel(unref(store).currentMic.speakerId, true)), 1),
						createBaseVNode("div", _hoisted_13$1, toDisplayString(unref(store).currentMic.original), 1),
						createBaseVNode("div", _hoisted_14$1, [createBaseVNode("div", { class: normalizeClass(["translated-text", translatedFontClass.value]) }, [createTextVNode(toDisplayString(unref(store).currentMic.translation) + " ", 1), _cache[7] || (_cache[7] = createBaseVNode("span", { class: "typing-indicator" }, [
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" }),
							createBaseVNode("span", { class: "dot" })
						], -1))], 2), createBaseVNode("div", { class: normalizeClass(["inline-assistant-wrapper", { "inline-assistant-wrapper--visible": isAssistantVisible("current-mic-inline") }]) }, [createBaseVNode("button", {
							class: "inline-assistant-btn",
							style: normalizeStyle({
								width: assistantBtnSize.value,
								height: assistantBtnSize.value
							}),
							onClick: _cache[3] || (_cache[3] = ($event) => openAssistant(currentMicInlineEntry.value))
						}, [createVNode(QIcon_default, {
							name: "smart_toy",
							size: "16px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
							_: 1
						})], 4)], 2)])
					], 32)) : createCommentVNode("", true)
				])]),
				_: 1
			}, 512), showScrollToLatest.value ? (openBlock(), createElementBlock("div", _hoisted_15$1, [createVNode(QBtn_default, {
				color: "primary",
				unelevated: "",
				"no-caps": "",
				dense: "",
				rounded: "",
				label: _ctx.$t("translator.scrollToLatest"),
				onClick: scrollToLatestAndResume
			}, null, 8, ["label"])])) : createCommentVNode("", true)]);
		};
	}
}), [["__scopeId", "data-v-60f4590a"]]);
//#endregion
//#region node_modules/quasar/src/components/fab/use-fab.js
var labelPositions = [
	"top",
	"right",
	"bottom",
	"left"
];
var useFabProps = {
	type: {
		type: String,
		default: "a"
	},
	outline: Boolean,
	push: Boolean,
	flat: Boolean,
	unelevated: Boolean,
	color: String,
	textColor: String,
	glossy: Boolean,
	square: Boolean,
	padding: String,
	label: {
		type: [String, Number],
		default: ""
	},
	labelPosition: {
		type: String,
		default: "right",
		validator: (v) => labelPositions.includes(v)
	},
	externalLabel: Boolean,
	hideLabel: { type: Boolean },
	labelClass: [
		Array,
		String,
		Object
	],
	labelStyle: [
		Array,
		String,
		Object
	],
	disable: Boolean,
	tabindex: [Number, String]
};
function use_fab_default(props, showing) {
	return {
		formClass: computed(() => `q-fab--form-${props.square === true ? "square" : "rounded"}`),
		stacked: computed(() => props.externalLabel === false && ["top", "bottom"].includes(props.labelPosition)),
		labelProps: computed(() => {
			if (props.externalLabel === true) {
				const hideLabel = props.hideLabel === null ? showing.value === false : props.hideLabel;
				return {
					action: "push",
					data: {
						class: [props.labelClass, `q-fab__label q-tooltip--style q-fab__label--external q-fab__label--external-${props.labelPosition}` + (hideLabel === true ? " q-fab__label--external-hidden" : "")],
						style: props.labelStyle
					}
				};
			}
			return {
				action: ["left", "top"].includes(props.labelPosition) ? "unshift" : "push",
				data: {
					class: [props.labelClass, `q-fab__label q-fab__label--internal q-fab__label--internal-${props.labelPosition}` + (props.hideLabel === true ? " q-fab__label--internal-hidden" : "")],
					style: props.labelStyle
				}
			};
		})
	};
}
//#endregion
//#region node_modules/quasar/src/components/fab/QFabAction.js
var anchorMap = {
	start: "self-end",
	center: "self-center",
	end: "self-start"
};
var anchorValues = Object.keys(anchorMap);
var QFabAction_default = createComponent({
	name: "QFabAction",
	props: {
		...useFabProps,
		icon: {
			type: String,
			default: ""
		},
		anchor: {
			type: String,
			validator: (v) => anchorValues.includes(v)
		},
		to: [String, Object],
		replace: Boolean
	},
	emits: ["click"],
	setup(props, { slots, emit }) {
		const $fab = inject(fabKey, () => ({
			showing: { value: true },
			onChildClick: noop
		}));
		const { formClass, labelProps } = use_fab_default(props, $fab.showing);
		const classes = computed(() => {
			const align = anchorMap[props.anchor];
			return formClass.value + (align !== void 0 ? ` ${align}` : "");
		});
		const isDisabled = computed(() => props.disable === true || $fab.showing.value !== true);
		function click(e) {
			$fab.onChildClick(e);
			emit("click", e);
		}
		function getContent() {
			const child = [];
			if (slots.icon !== void 0) child.push(slots.icon());
			else if (props.icon !== "") child.push(h(QIcon_default, { name: props.icon }));
			if (props.label !== "" || slots.label !== void 0) child[labelProps.value.action](h("div", labelProps.value.data, slots.label !== void 0 ? slots.label() : [props.label]));
			return hMergeSlot(slots.default, child);
		}
		const vm = getCurrentInstance();
		Object.assign(vm.proxy, { click });
		return () => h(QBtn_default, {
			class: classes.value,
			...props,
			noWrap: true,
			stack: props.stacked,
			icon: void 0,
			label: void 0,
			noCaps: true,
			fabMini: true,
			disable: isDisabled.value,
			onClick: click
		}, getContent);
	}
});
//#endregion
//#region node_modules/quasar/src/components/fab/QFab.js
var directions = [
	"up",
	"right",
	"down",
	"left"
];
var alignValues = [
	"left",
	"center",
	"right"
];
var QFab_default = createComponent({
	name: "QFab",
	props: {
		...useFabProps,
		...useModelToggleProps,
		icon: String,
		activeIcon: String,
		hideIcon: Boolean,
		hideLabel: {
			...useFabProps.hideLabel,
			default: null
		},
		direction: {
			type: String,
			default: "right",
			validator: (v) => directions.includes(v)
		},
		persistent: Boolean,
		verticalActionsAlign: {
			type: String,
			default: "center",
			validator: (v) => alignValues.includes(v)
		}
	},
	emits: useModelToggleEmits,
	setup(props, { slots }) {
		const triggerRef = ref(null);
		const showing = ref(props.modelValue === true);
		const targetUid = use_id_default();
		const { proxy: { $q } } = getCurrentInstance();
		const { formClass, labelProps } = use_fab_default(props, showing);
		const { hide, toggle } = use_model_toggle_default({
			showing,
			hideOnRouteChange: computed(() => props.persistent !== true)
		});
		const slotScope = computed(() => ({ opened: showing.value }));
		const classes = computed(() => `q-fab z-fab row inline justify-center q-fab--align-${props.verticalActionsAlign} ${formClass.value}` + (showing.value === true ? " q-fab--opened" : " q-fab--closed"));
		const actionClass = computed(() => `q-fab__actions flex no-wrap inline q-fab__actions--${props.direction} q-fab__actions--${showing.value === true ? "opened" : "closed"}`);
		const actionAttrs = computed(() => {
			const attrs = {
				id: targetUid.value,
				role: "menu"
			};
			if (showing.value !== true) attrs["aria-hidden"] = "true";
			return attrs;
		});
		const iconHolderClass = computed(() => `q-fab__icon-holder  q-fab__icon-holder--${showing.value === true ? "opened" : "closed"}`);
		function getIcon(kebab, camel) {
			const slotFn = slots[kebab];
			const classes = `q-fab__${kebab} absolute-full`;
			return slotFn === void 0 ? h(QIcon_default, {
				class: classes,
				name: props[camel] || $q.iconSet.fab[camel]
			}) : h("div", { class: classes }, slotFn(slotScope.value));
		}
		function getTriggerContent() {
			const child = [];
			props.hideIcon !== true && child.push(h("div", { class: iconHolderClass.value }, [getIcon("icon", "icon"), getIcon("active-icon", "activeIcon")]));
			if (props.label !== "" || slots.label !== void 0) child[labelProps.value.action](h("div", labelProps.value.data, slots.label !== void 0 ? slots.label(slotScope.value) : [props.label]));
			return hMergeSlot(slots.tooltip, child);
		}
		provide(fabKey, {
			showing,
			onChildClick(evt) {
				hide(evt);
				if (evt?.qAvoidFocus !== true) triggerRef.value?.$el.focus();
			}
		});
		return () => h("div", { class: classes.value }, [h(QBtn_default, {
			ref: triggerRef,
			class: formClass.value,
			...props,
			noWrap: true,
			stack: props.stacked,
			align: void 0,
			icon: void 0,
			label: void 0,
			noCaps: true,
			fab: true,
			"aria-expanded": showing.value === true ? "true" : "false",
			"aria-haspopup": "true",
			"aria-controls": targetUid.value,
			onClick: toggle
		}, getTriggerContent), h("div", {
			class: actionClass.value,
			...actionAttrs.value
		}, hSlot(slots.default))]);
	}
});
//#endregion
//#region src/components/translator/TranslatorControls.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = { class: "translator-controls" };
var _hoisted_2$4 = {
	key: 0,
	class: "state-indicator"
};
var _hoisted_3$4 = { class: "controls-row" };
var _hoisted_4$3 = ["disabled"];
var _hoisted_5$3 = ["disabled"];
var _hoisted_6$1 = ["disabled"];
var _hoisted_7$1 = { class: "font-size-fab-wrapper" };
//#endregion
//#region src/components/translator/TranslatorControls.vue
var TranslatorControls_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorControls",
	props: {
		recordingState: {},
		hasApiKey: { type: Boolean },
		microphoneEnabled: { type: Boolean },
		narrationEnabled: { type: Boolean },
		ttsSpeaking: { type: Boolean },
		showSaveTranscript: { type: Boolean },
		translationFontSize: {},
		interpreterModeEnabled: { type: Boolean },
		interpreterModeAvailable: { type: Boolean }
	},
	emits: [
		"start",
		"pause",
		"resume",
		"end",
		"toggle-microphone",
		"open-narration-settings",
		"toggle-interpreter-mode",
		"open-assistant",
		"save-transcript",
		"update-translation-font-size"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const isFontSizeMenuOpen = ref(false);
		const fontSizeOptions = [
			{
				value: "small",
				labelKey: "translator.fontSizeSmall",
				buttonClass: "font-size-action--small"
			},
			{
				value: "medium",
				labelKey: "translator.fontSizeMedium",
				buttonClass: "font-size-action--medium"
			},
			{
				value: "large",
				labelKey: "translator.fontSizeLarge",
				buttonClass: "font-size-action--large"
			}
		];
		const fontSizeLabelByValue = {
			small: "translator.fontSizeSmall",
			medium: "translator.fontSizeMedium",
			large: "translator.fontSizeLarge"
		};
		const isStartState = computed(() => props.recordingState === "idle" || props.recordingState === "stopped" || props.recordingState === "error" || props.recordingState === "canceled");
		const canStart = computed(() => props.hasApiKey && isStartState.value);
		const showStart = computed(() => isStartState.value);
		const isPreparing = computed(() => props.recordingState === "starting" || props.recordingState === "connecting");
		const showPause = computed(() => props.recordingState === "recording" || props.recordingState === "starting" || props.recordingState === "connecting");
		const showResume = computed(() => props.recordingState === "paused");
		const showEnd = computed(() => showPause.value || showResume.value);
		const stateColor = computed(() => {
			if (!props.hasApiKey && isStartState.value) return "warning";
			switch (props.recordingState) {
				case "recording": return "positive";
				case "starting":
				case "connecting": return "warning";
				case "paused": return "warning";
				case "error": return "negative";
				default: return "grey";
			}
		});
		const stateLabel = computed(() => {
			if (!props.hasApiKey && isStartState.value) return "settings.noApiKey";
			switch (props.recordingState) {
				case "recording": return "translator.recording";
				case "starting":
				case "connecting": return "translator.connecting";
				case "paused": return "translator.paused";
				case "error": return "translator.error";
				case "stopped": return "translator.stopped";
				default: return "";
			}
		});
		const currentFontSizeLabelKey = computed(() => fontSizeLabelByValue[props.translationFontSize]);
		function handleTranslationFontSizeSelect(size) {
			emit("update-translation-font-size", size);
			isFontSizeMenuOpen.value = false;
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$4, [stateLabel.value ? (openBlock(), createElementBlock("div", _hoisted_2$4, [createVNode(QBadge_default, {
				color: stateColor.value,
				rounded: "",
				class: "state-dot"
			}, null, 8, ["color"]), createBaseVNode("span", { class: normalizeClass(["state-text", `text-${stateColor.value}`]) }, toDisplayString(_ctx.$t(stateLabel.value)), 3)])) : createCommentVNode("", true), createBaseVNode("div", _hoisted_3$4, [
				showStart.value ? (openBlock(), createElementBlock("button", {
					key: 0,
					class: normalizeClass(["gc-btn gc-btn--pill", { "gc-btn--disabled": !canStart.value }]),
					disabled: !canStart.value,
					onClick: _cache[0] || (_cache[0] = ($event) => emit("start"))
				}, [createVNode(QIcon_default, {
					name: "play_arrow",
					size: "20px"
				})], 10, _hoisted_4$3)) : createCommentVNode("", true),
				showEnd.value ? (openBlock(), createElementBlock("button", {
					key: 1,
					class: "gc-btn gc-btn--end",
					onClick: _cache[1] || (_cache[1] = ($event) => emit("end"))
				}, [createVNode(QIcon_default, {
					name: "call_end",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.end")), 1)]),
					_: 1
				})])) : createCommentVNode("", true),
				showPause.value ? (openBlock(), createElementBlock("button", {
					key: 2,
					class: normalizeClass(["gc-btn", { "gc-btn--disabled": isPreparing.value }]),
					disabled: isPreparing.value,
					onClick: _cache[2] || (_cache[2] = ($event) => emit("pause"))
				}, [createVNode(QIcon_default, {
					name: "pause",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.pause")), 1)]),
					_: 1
				})], 10, _hoisted_5$3)) : showResume.value ? (openBlock(), createElementBlock("button", {
					key: 3,
					class: "gc-btn",
					onClick: _cache[3] || (_cache[3] = ($event) => emit("resume"))
				}, [createVNode(QIcon_default, {
					name: "play_arrow",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.resume")), 1)]),
					_: 1
				})])) : createCommentVNode("", true),
				createBaseVNode("button", {
					class: normalizeClass(["gc-btn", {
						"gc-btn--enabled": __props.microphoneEnabled,
						"gc-btn--alert": !__props.microphoneEnabled
					}]),
					onClick: _cache[4] || (_cache[4] = ($event) => emit("toggle-microphone", !__props.microphoneEnabled))
				}, [createVNode(QIcon_default, {
					name: __props.microphoneEnabled ? "mic" : "mic_off",
					size: "20px"
				}, null, 8, ["name"]), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.microphone")), 1)]),
					_: 1
				})], 2),
				createBaseVNode("button", {
					class: normalizeClass(["gc-btn", {
						"gc-btn--enabled": __props.interpreterModeEnabled,
						"gc-btn--disabled": !__props.interpreterModeAvailable,
						"gc-btn--interpreter-active": __props.interpreterModeEnabled
					}]),
					disabled: !__props.interpreterModeAvailable,
					onClick: _cache[5] || (_cache[5] = ($event) => emit("toggle-interpreter-mode"))
				}, [createVNode(QIcon_default, {
					name: "interpreter_mode",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.interpreterModeEnabled ? _ctx.$t("translator.interpreterModeActive") : _ctx.$t("translator.interpreterMode")), 1)]),
					_: 1
				})], 10, _hoisted_6$1),
				createBaseVNode("button", {
					class: normalizeClass(["gc-btn", {
						"gc-btn--enabled": __props.narrationEnabled,
						"gc-btn--narration-speaking": __props.narrationEnabled && __props.ttsSpeaking
					}]),
					onClick: _cache[6] || (_cache[6] = ($event) => emit("open-narration-settings"))
				}, [createVNode(QIcon_default, {
					name: __props.narrationEnabled ? "record_voice_over" : "voice_over_off",
					size: "20px"
				}, null, 8, ["name"]), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.narrationSettings")), 1)]),
					_: 1
				})], 2),
				createBaseVNode("button", {
					class: "gc-btn",
					onClick: _cache[7] || (_cache[7] = ($event) => emit("open-assistant"))
				}, [createVNode(QIcon_default, {
					name: "smart_toy",
					size: "20px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.assistantOpen")), 1)]),
					_: 1
				})]),
				createBaseVNode("div", _hoisted_7$1, [createVNode(QFab_default, {
					modelValue: isFontSizeMenuOpen.value,
					"onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => isFontSizeMenuOpen.value = $event),
					icon: "format_size",
					"active-icon": "close",
					direction: "up",
					flat: "",
					padding: "0",
					class: "font-size-fab"
				}, {
					default: withCtx(() => [(openBlock(), createElementBlock(Fragment, null, renderList(fontSizeOptions, (option) => {
						return createVNode(QFabAction_default, {
							key: option.value,
							icon: "format_size",
							class: normalizeClass(["font-size-action", option.buttonClass]),
							color: props.translationFontSize === option.value ? "primary" : "grey-8",
							"text-color": "white",
							onClick: ($event) => handleTranslationFontSizeSelect(option.value)
						}, {
							default: withCtx(() => [createVNode(QTooltip_default, null, {
								default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(option.labelKey)), 1)]),
								_: 2
							}, 1024)]),
							_: 2
						}, 1032, [
							"class",
							"color",
							"onClick"
						]);
					}), 64)), createVNode(QTooltip_default, null, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.fontSize")) + ": " + toDisplayString(_ctx.$t(currentFontSizeLabelKey.value)), 1)]),
						_: 1
					})]),
					_: 1
				}, 8, ["modelValue"])]),
				props.showSaveTranscript ? (openBlock(), createElementBlock("button", {
					key: 4,
					class: "gc-btn gc-btn--pill gc-btn--save",
					onClick: _cache[9] || (_cache[9] = ($event) => emit("save-transcript"))
				}, [createVNode(QIcon_default, {
					name: "save_alt",
					size: "20px"
				})])) : createCommentVNode("", true)
			])]);
		};
	}
}), [["__scopeId", "data-v-c9841fe0"]]);
//#endregion
//#region node_modules/quasar/src/components/card/QCardSection.js
var QCardSection_default = createComponent({
	name: "QCardSection",
	props: {
		tag: {
			type: String,
			default: "div"
		},
		horizontal: Boolean
	},
	setup(props, { slots }) {
		const classes = computed(() => `q-card__section q-card__section--${props.horizontal === true ? "horiz row no-wrap" : "vert"}`);
		return () => h(props.tag, { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/card/QCardActions.js
var QCardActions_default = createComponent({
	name: "QCardActions",
	props: {
		...useAlignProps,
		vertical: Boolean
	},
	setup(props, { slots }) {
		const alignClass = use_align_default(props);
		const classes = computed(() => `q-card__actions ${alignClass.value} q-card__actions--${props.vertical === true ? "vert column" : "horiz row"}`);
		return () => h("div", { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/card/QCard.js
var QCard_default = createComponent({
	name: "QCard",
	props: {
		...useDarkProps,
		tag: {
			type: String,
			default: "div"
		},
		square: Boolean,
		flat: Boolean,
		bordered: Boolean
	},
	setup(props, { slots }) {
		const { proxy: { $q } } = getCurrentInstance();
		const isDark = use_dark_default(props, $q);
		const classes = computed(() => "q-card" + (isDark.value === true ? " q-card--dark q-dark" : "") + (props.bordered === true ? " q-card--bordered" : "") + (props.square === true ? " q-card--square no-border-radius" : "") + (props.flat === true ? " q-card--flat no-shadow" : ""));
		return () => h(props.tag, { class: classes.value }, hSlot(slots.default));
	}
});
//#endregion
//#region src/components/translator/SpeakerSettingsDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "panel-card__title" };
var _hoisted_2$3 = { class: "speaker-grid__header" };
var _hoisted_3$3 = { class: "speaker-grid__header speaker-grid__header--right" };
var _hoisted_4$2 = { class: "speaker-grid__label" };
var _hoisted_5$2 = { class: "actions-main" };
//#endregion
//#region src/components/translator/SpeakerSettingsDialog.vue
var SpeakerSettingsDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "SpeakerSettingsDialog",
	props: {
		modelValue: { type: Boolean },
		speakerNames: {}
	},
	emits: ["update:modelValue", "save"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const localSpeakerNames = ref(normalizeSpeakerNames([], 10));
		const speakerRows = computed(() => localSpeakerNames.value.map((name, index) => ({
			index: index + 1,
			name
		})));
		watch(() => props.modelValue, (isOpen) => {
			if (!isOpen) return;
			localSpeakerNames.value = normalizeSpeakerNames(props.speakerNames, 10);
		}, { immediate: true });
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function updateSpeakerName(index, value) {
			const nextNames = [...localSpeakerNames.value];
			nextNames[index] = value;
			localSpeakerNames.value = nextNames;
		}
		function addSpeaker() {
			localSpeakerNames.value = [...localSpeakerNames.value, ""];
		}
		function saveSpeakerSettings() {
			const minSlots = Math.max(10, localSpeakerNames.value.length);
			emit("save", normalizeSpeakerNames(localSpeakerNames.value, minSlots));
			closeDialog();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				class: "panel-dialog panel-dialog--speaker",
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "speaker-settings-dialog panel-card" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, { class: "panel-card__header" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_1$3, [createVNode(QIcon_default, {
								name: "groups",
								size: "18px"
							}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.speakerSettingsTitle")), 1)]), createBaseVNode("button", {
								class: "panel-icon-btn",
								"data-no-panel-drag": "",
								onClick: closeDialog
							}, [createVNode(QIcon_default, {
								name: "close",
								size: "18px"
							})])]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardSection_default, { class: "panel-card__body speaker-settings-body" }, {
							default: withCtx(() => [
								createBaseVNode("div", _hoisted_2$3, toDisplayString(_ctx.$t("translator.speakerColumn")), 1),
								createBaseVNode("div", _hoisted_3$3, toDisplayString(_ctx.$t("translator.speakerNameColumn")), 1),
								(openBlock(true), createElementBlock(Fragment, null, renderList(speakerRows.value, (row) => {
									return openBlock(), createElementBlock(Fragment, { key: row.index }, [createBaseVNode("div", _hoisted_4$2, toDisplayString(_ctx.$t("translator.speaker")) + " " + toDisplayString(row.index), 1), createVNode(QInput_default, {
										"model-value": row.name,
										dense: "",
										outlined: "",
										class: "speaker-name-input",
										placeholder: _ctx.$t("translator.speakerNamePlaceholder"),
										"onUpdate:modelValue": ($event) => updateSpeakerName(row.index - 1, String($event ?? ""))
									}, null, 8, [
										"model-value",
										"placeholder",
										"onUpdate:modelValue"
									])], 64);
								}), 128))
							]),
							_: 1
						}),
						createVNode(QCardActions_default, { class: "panel-card__actions" }, {
							default: withCtx(() => [createBaseVNode("button", {
								class: "speaker-btn speaker-btn--subtle",
								onClick: addSpeaker
							}, [createVNode(QIcon_default, {
								name: "add",
								size: "17px"
							}), createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.addSpeaker")), 1)]), createBaseVNode("div", _hoisted_5$2, [createBaseVNode("button", {
								class: "speaker-btn",
								onClick: closeDialog
							}, [createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.cancel")), 1)]), createBaseVNode("button", {
								class: "speaker-btn speaker-btn--primary",
								onClick: saveSpeakerSettings
							}, [createBaseVNode("span", null, toDisplayString(_ctx.$t("translator.save")), 1)])])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-e8319913"]]);
//#endregion
//#region src/components/translator/DownloadTranscriptDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "text-subtitle1 text-weight-medium" };
var _hoisted_2$2 = { class: "download-option-content" };
var _hoisted_3$2 = { class: "download-option-desc text-caption text-grey-5" };
var _hoisted_4$1 = { class: "download-option-content" };
var _hoisted_5$1 = { class: "download-option-desc text-caption text-grey-5" };
//#endregion
//#region src/components/translator/DownloadTranscriptDialog.vue
var DownloadTranscriptDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "DownloadTranscriptDialog",
	props: { modelValue: { type: Boolean } },
	emits: [
		"update:modelValue",
		"download-txt",
		"download-json"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function handleDownloadTxt() {
			emit("download-txt");
			closeDialog();
		}
		function handleDownloadJson() {
			emit("download-json");
			closeDialog();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "download-transcript-dialog" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, { class: "row items-center justify-between q-pb-sm" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_1$2, toDisplayString(_ctx.$t("translator.downloadTranscript")), 1), createVNode(QBtn_default, {
								flat: "",
								round: "",
								dense: "",
								icon: "close",
								"data-no-panel-drag": "",
								onClick: closeDialog
							})]),
							_: 1
						}),
						createVNode(QSeparator_default),
						createVNode(QCardSection_default, { class: "download-options q-pt-md" }, {
							default: withCtx(() => [createVNode(QBtn_default, {
								unelevated: "",
								"no-caps": "",
								class: "download-option-btn",
								onClick: handleDownloadTxt
							}, {
								default: withCtx(() => [createBaseVNode("div", _hoisted_2$2, [
									createVNode(QIcon_default, {
										name: "description",
										size: "28px",
										color: "blue-4"
									}),
									_cache[1] || (_cache[1] = createBaseVNode("div", { class: "download-option-label text-body1 text-weight-medium" }, ".TXT", -1)),
									createBaseVNode("div", _hoisted_3$2, toDisplayString(_ctx.$t("translator.downloadTxtDesc")), 1)
								])]),
								_: 1
							}), createVNode(QBtn_default, {
								unelevated: "",
								"no-caps": "",
								class: "download-option-btn",
								onClick: handleDownloadJson
							}, {
								default: withCtx(() => [createBaseVNode("div", _hoisted_4$1, [
									createVNode(QIcon_default, {
										name: "data_object",
										size: "28px",
										color: "amber-6"
									}),
									_cache[2] || (_cache[2] = createBaseVNode("div", { class: "download-option-label text-body1 text-weight-medium" }, ".JSON", -1)),
									createBaseVNode("div", _hoisted_5$1, toDisplayString(_ctx.$t("translator.downloadJsonDesc")), 1)
								])]),
								_: 1
							})]),
							_: 1
						}),
						createVNode(QCardActions_default, {
							align: "right",
							class: "q-pa-md q-pt-none"
						}, {
							default: withCtx(() => [createVNode(QBtn_default, {
								flat: "",
								color: "grey-5",
								label: _ctx.$t("translator.cancel"),
								onClick: closeDialog
							}, null, 8, ["label"])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-f84bba15"]]);
//#endregion
//#region node_modules/quasar/src/components/slider/use-slider.js
var markerPrefixClass = "q-slider__marker-labels";
var defaultMarkerConvertFn = (v) => ({ value: v });
var defaultMarkerLabelRenderFn = ({ marker }) => h("div", {
	key: marker.value,
	style: marker.style,
	class: marker.classes
}, marker.label);
var keyCodes = [
	34,
	37,
	40,
	33,
	39,
	38
];
var useSliderProps = {
	...useDarkProps,
	...useFormProps,
	min: {
		type: Number,
		default: 0
	},
	max: {
		type: Number,
		default: 100
	},
	innerMin: Number,
	innerMax: Number,
	step: {
		type: Number,
		default: 1,
		validator: (v) => v >= 0
	},
	snap: Boolean,
	vertical: Boolean,
	reverse: Boolean,
	color: String,
	markerLabelsClass: String,
	label: Boolean,
	labelColor: String,
	labelTextColor: String,
	labelAlways: Boolean,
	switchLabelSide: Boolean,
	markers: [Boolean, Number],
	markerLabels: [
		Boolean,
		Array,
		Object,
		Function
	],
	switchMarkerLabelsSide: Boolean,
	trackImg: String,
	trackColor: String,
	innerTrackImg: String,
	innerTrackColor: String,
	selectionColor: String,
	selectionImg: String,
	thumbSize: {
		type: String,
		default: "20px"
	},
	trackSize: {
		type: String,
		default: "4px"
	},
	disable: Boolean,
	readonly: Boolean,
	dense: Boolean,
	tabindex: [String, Number],
	thumbColor: String,
	thumbPath: {
		type: String,
		default: "M 4, 10 a 6,6 0 1,0 12,0 a 6,6 0 1,0 -12,0"
	}
};
var useSliderEmits = [
	"pan",
	"update:modelValue",
	"change"
];
function use_slider_default({ updateValue, updatePosition, getDragging, formAttrs }) {
	const { props, emit, slots, proxy: { $q } } = getCurrentInstance();
	const isDark = use_dark_default(props, $q);
	const injectFormInput = useFormInject(formAttrs);
	const active = ref(false);
	const preventFocus = ref(false);
	const focus = ref(false);
	const dragging = ref(false);
	const axis = computed(() => props.vertical === true ? "--v" : "--h");
	const labelSide = computed(() => "-" + (props.switchLabelSide === true ? "switched" : "standard"));
	const isReversed = computed(() => props.vertical === true ? props.reverse === true : props.reverse !== ($q.lang.rtl === true));
	const innerMin = computed(() => isNaN(props.innerMin) === true || props.innerMin < props.min ? props.min : props.innerMin);
	const innerMax = computed(() => isNaN(props.innerMax) === true || props.innerMax > props.max ? props.max : props.innerMax);
	const editable = computed(() => props.disable !== true && props.readonly !== true && innerMin.value < innerMax.value);
	const roundValueFn = computed(() => {
		if (props.step === 0) return (v) => v;
		const decimals = (String(props.step).trim().split(".")[1] || "").length;
		return (v) => parseFloat(v.toFixed(decimals));
	});
	const keyStep = computed(() => props.step === 0 ? 1 : props.step);
	const tabindex = computed(() => editable.value === true ? props.tabindex || 0 : -1);
	const trackLen = computed(() => props.max - props.min);
	const innerBarLen = computed(() => innerMax.value - innerMin.value);
	const innerMinRatio = computed(() => convertModelToRatio(innerMin.value));
	const innerMaxRatio = computed(() => convertModelToRatio(innerMax.value));
	const positionProp = computed(() => props.vertical === true ? isReversed.value === true ? "bottom" : "top" : isReversed.value === true ? "right" : "left");
	const sizeProp = computed(() => props.vertical === true ? "height" : "width");
	const thicknessProp = computed(() => props.vertical === true ? "width" : "height");
	const orientation = computed(() => props.vertical === true ? "vertical" : "horizontal");
	const attributes = computed(() => {
		const acc = {
			role: "slider",
			"aria-valuemin": innerMin.value,
			"aria-valuemax": innerMax.value,
			"aria-orientation": orientation.value,
			"data-step": props.step
		};
		if (props.disable === true) acc["aria-disabled"] = "true";
		else if (props.readonly === true) acc["aria-readonly"] = "true";
		return acc;
	});
	const classes = computed(() => `q-slider q-slider${axis.value} q-slider--${active.value === true ? "" : "in"}active inline no-wrap ` + (props.vertical === true ? "row" : "column") + (props.disable === true ? " disabled" : " q-slider--enabled" + (editable.value === true ? " q-slider--editable" : "")) + (focus.value === "both" ? " q-slider--focus" : "") + (props.label || props.labelAlways === true ? " q-slider--label" : "") + (props.labelAlways === true ? " q-slider--label-always" : "") + (isDark.value === true ? " q-slider--dark" : "") + (props.dense === true ? " q-slider--dense q-slider--dense" + axis.value : ""));
	function getPositionClass(name) {
		const cls = "q-slider__" + name;
		return `${cls} ${cls}${axis.value} ${cls}${axis.value}${labelSide.value}`;
	}
	function getAxisClass(name) {
		const cls = "q-slider__" + name;
		return `${cls} ${cls}${axis.value}`;
	}
	const selectionBarClass = computed(() => {
		const color = props.selectionColor || props.color;
		return "q-slider__selection absolute" + (color !== void 0 ? ` text-${color}` : "");
	});
	const markerClass = computed(() => getAxisClass("markers") + " absolute overflow-hidden");
	const trackContainerClass = computed(() => getAxisClass("track-container"));
	const pinClass = computed(() => getPositionClass("pin"));
	const labelClass = computed(() => getPositionClass("label"));
	const textContainerClass = computed(() => getPositionClass("text-container"));
	const markerLabelsContainerClass = computed(() => getPositionClass("marker-labels-container") + (props.markerLabelsClass !== void 0 ? ` ${props.markerLabelsClass}` : ""));
	const trackClass = computed(() => "q-slider__track relative-position no-outline" + (props.trackColor !== void 0 ? ` bg-${props.trackColor}` : ""));
	const trackStyle = computed(() => {
		const acc = { [thicknessProp.value]: props.trackSize };
		if (props.trackImg !== void 0) acc.backgroundImage = `url(${props.trackImg}) !important`;
		return acc;
	});
	const innerBarClass = computed(() => "q-slider__inner absolute" + (props.innerTrackColor !== void 0 ? ` bg-${props.innerTrackColor}` : ""));
	const innerBarStyle = computed(() => {
		const innerDiff = innerMaxRatio.value - innerMinRatio.value;
		const acc = {
			[positionProp.value]: `${100 * innerMinRatio.value}%`,
			[sizeProp.value]: innerDiff === 0 ? "2px" : `${100 * innerDiff}%`
		};
		if (props.innerTrackImg !== void 0) acc.backgroundImage = `url(${props.innerTrackImg}) !important`;
		return acc;
	});
	function convertRatioToModel(ratio) {
		const { min, max, step } = props;
		let model = min + ratio * (max - min);
		if (step > 0) {
			const modulo = (model - innerMin.value) % step;
			model += (Math.abs(modulo) >= step / 2 ? (modulo < 0 ? -1 : 1) * step : 0) - modulo;
		}
		model = roundValueFn.value(model);
		return between(model, innerMin.value, innerMax.value);
	}
	function convertModelToRatio(model) {
		return trackLen.value === 0 ? 0 : (model - props.min) / trackLen.value;
	}
	function getDraggingRatio(evt, dragging) {
		const pos = position(evt), val = props.vertical === true ? between((pos.top - dragging.top) / dragging.height, 0, 1) : between((pos.left - dragging.left) / dragging.width, 0, 1);
		return between(isReversed.value === true ? 1 - val : val, innerMinRatio.value, innerMaxRatio.value);
	}
	const markerStep = computed(() => isNumber(props.markers) === true ? props.markers : keyStep.value);
	const markerTicks = computed(() => {
		const acc = [];
		const step = markerStep.value;
		const max = props.max;
		let value = props.min;
		do {
			acc.push(value);
			value += step;
		} while (value < max);
		acc.push(max);
		return acc;
	});
	const markerLabelClass = computed(() => {
		const prefix = ` ${markerPrefixClass}${axis.value}-`;
		return `q-slider__marker-labels${prefix}${props.switchMarkerLabelsSide === true ? "switched" : "standard"}${prefix}${isReversed.value === true ? "rtl" : "ltr"}`;
	});
	const markerLabelsList = computed(() => {
		if (props.markerLabels === false) return null;
		return getMarkerList(props.markerLabels).map((entry, index) => ({
			index,
			value: entry.value,
			label: entry.label || entry.value,
			classes: markerLabelClass.value + (entry.classes !== void 0 ? " " + entry.classes : ""),
			style: {
				...getMarkerLabelStyle(entry.value),
				...entry.style || {}
			}
		}));
	});
	const markerScope = computed(() => ({
		markerList: markerLabelsList.value,
		markerMap: markerLabelsMap.value,
		classes: markerLabelClass.value,
		getStyle: getMarkerLabelStyle
	}));
	const markerStyle = computed(() => {
		const size = innerBarLen.value === 0 ? "2px" : 100 * markerStep.value / innerBarLen.value;
		return {
			...innerBarStyle.value,
			backgroundSize: props.vertical === true ? `2px ${size}%` : `${size}% 2px`
		};
	});
	function getMarkerList(def) {
		if (def === false) return null;
		if (def === true) return markerTicks.value.map(defaultMarkerConvertFn);
		if (typeof def === "function") return markerTicks.value.map((value) => {
			const item = def(value);
			return isObject(item) === true ? {
				...item,
				value
			} : {
				value,
				label: item
			};
		});
		const filterFn = ({ value }) => value >= props.min && value <= props.max;
		if (Array.isArray(def) === true) return def.map((item) => isObject(item) === true ? item : { value: item }).filter(filterFn);
		return Object.keys(def).map((key) => {
			const item = def[key];
			const value = Number(key);
			return isObject(item) === true ? {
				...item,
				value
			} : {
				value,
				label: item
			};
		}).filter(filterFn);
	}
	function getMarkerLabelStyle(val) {
		return { [positionProp.value]: `${100 * (val - props.min) / trackLen.value}%` };
	}
	const markerLabelsMap = computed(() => {
		if (props.markerLabels === false) return null;
		const acc = {};
		markerLabelsList.value.forEach((entry) => {
			acc[entry.value] = entry;
		});
		return acc;
	});
	function getMarkerLabelsContent() {
		if (slots["marker-label-group"] !== void 0) return slots["marker-label-group"](markerScope.value);
		const fn = slots["marker-label"] || defaultMarkerLabelRenderFn;
		return markerLabelsList.value.map((marker) => fn({
			marker,
			...markerScope.value
		}));
	}
	const panDirective = computed(() => {
		return [[
			TouchPan_default,
			onPan,
			void 0,
			{
				[orientation.value]: true,
				prevent: true,
				stop: true,
				mouse: true,
				mouseAllDir: true
			}
		]];
	});
	function onPan(event) {
		if (event.isFinal === true) {
			if (dragging.value !== void 0) {
				updatePosition(event.evt);
				event.touch === true && updateValue(true);
				dragging.value = void 0;
				emit("pan", "end");
			}
			active.value = false;
			focus.value = false;
		} else if (event.isFirst === true) {
			dragging.value = getDragging(event.evt);
			updatePosition(event.evt);
			updateValue();
			active.value = true;
			emit("pan", "start");
		} else {
			updatePosition(event.evt);
			updateValue();
		}
	}
	function onBlur() {
		focus.value = false;
	}
	function onActivate(evt) {
		updatePosition(evt, getDragging(evt));
		updateValue();
		preventFocus.value = true;
		active.value = true;
		document.addEventListener("mouseup", onDeactivate, true);
	}
	function onDeactivate() {
		preventFocus.value = false;
		active.value = false;
		updateValue(true);
		onBlur();
		document.removeEventListener("mouseup", onDeactivate, true);
	}
	function onMobileClick(evt) {
		updatePosition(evt, getDragging(evt));
		updateValue(true);
	}
	function onKeyup(evt) {
		if (keyCodes.includes(evt.keyCode)) updateValue(true);
	}
	function getTextContainerStyle(ratio) {
		if (props.vertical === true) return null;
		const p = $q.lang.rtl !== props.reverse ? 1 - ratio : ratio;
		return { transform: `translateX(calc(${2 * p - 1} * ${props.thumbSize} / 2 + ${50 - 100 * p}%))` };
	}
	function getThumbRenderFn(thumb) {
		const focusClass = computed(() => preventFocus.value === false && (focus.value === thumb.focusValue || focus.value === "both") ? " q-slider--focus" : "");
		const classes = computed(() => `q-slider__thumb q-slider__thumb${axis.value} q-slider__thumb${axis.value}-${isReversed.value === true ? "rtl" : "ltr"} absolute non-selectable` + focusClass.value + (thumb.thumbColor.value !== void 0 ? ` text-${thumb.thumbColor.value}` : ""));
		const style = computed(() => ({
			width: props.thumbSize,
			height: props.thumbSize,
			[positionProp.value]: `${100 * thumb.ratio.value}%`,
			zIndex: focus.value === thumb.focusValue ? 2 : void 0
		}));
		const pinColor = computed(() => thumb.labelColor.value !== void 0 ? ` text-${thumb.labelColor.value}` : "");
		const textContainerStyle = computed(() => getTextContainerStyle(thumb.ratio.value));
		const textClass = computed(() => "q-slider__text" + (thumb.labelTextColor.value !== void 0 ? ` text-${thumb.labelTextColor.value}` : ""));
		return () => {
			const thumbContent = [h("svg", {
				class: "q-slider__thumb-shape absolute-full",
				viewBox: "0 0 20 20",
				"aria-hidden": "true"
			}, [h("path", { d: props.thumbPath })]), h("div", { class: "q-slider__focus-ring fit" })];
			if (props.label === true || props.labelAlways === true) {
				thumbContent.push(h("div", { class: pinClass.value + " absolute fit no-pointer-events" + pinColor.value }, [h("div", {
					class: labelClass.value,
					style: { minWidth: props.thumbSize }
				}, [h("div", {
					class: textContainerClass.value,
					style: textContainerStyle.value
				}, [h("span", { class: textClass.value }, thumb.label.value)])])]));
				if (props.name !== void 0 && props.disable !== true) injectFormInput(thumbContent, "push");
			}
			return h("div", {
				class: classes.value,
				style: style.value,
				...thumb.getNodeData()
			}, thumbContent);
		};
	}
	function getContent(selectionBarStyle, trackContainerTabindex, trackContainerEvents, injectThumb) {
		const trackContent = [];
		props.innerTrackColor !== "transparent" && trackContent.push(h("div", {
			key: "inner",
			class: innerBarClass.value,
			style: innerBarStyle.value
		}));
		props.selectionColor !== "transparent" && trackContent.push(h("div", {
			key: "selection",
			class: selectionBarClass.value,
			style: selectionBarStyle.value
		}));
		props.markers !== false && trackContent.push(h("div", {
			key: "marker",
			class: markerClass.value,
			style: markerStyle.value
		}));
		injectThumb(trackContent);
		const content = [hDir("div", {
			key: "trackC",
			class: trackContainerClass.value,
			tabindex: trackContainerTabindex.value,
			...trackContainerEvents.value
		}, [h("div", {
			class: trackClass.value,
			style: trackStyle.value
		}, trackContent)], "slide", editable.value, () => panDirective.value)];
		if (props.markerLabels !== false) content[props.switchMarkerLabelsSide === true ? "unshift" : "push"](h("div", {
			key: "markerL",
			class: markerLabelsContainerClass.value
		}, getMarkerLabelsContent()));
		return content;
	}
	onBeforeUnmount(() => {
		document.removeEventListener("mouseup", onDeactivate, true);
	});
	return {
		state: {
			active,
			focus,
			preventFocus,
			dragging,
			editable,
			classes,
			tabindex,
			attributes,
			roundValueFn,
			keyStep,
			trackLen,
			innerMin,
			innerMinRatio,
			innerMax,
			innerMaxRatio,
			positionProp,
			sizeProp,
			isReversed
		},
		methods: {
			onActivate,
			onMobileClick,
			onBlur,
			onKeyup,
			getContent,
			getThumbRenderFn,
			convertRatioToModel,
			convertModelToRatio,
			getDraggingRatio
		}
	};
}
//#endregion
//#region node_modules/quasar/src/components/slider/QSlider.js
var getNodeData = () => ({});
var QSlider_default = createComponent({
	name: "QSlider",
	props: {
		...useSliderProps,
		modelValue: {
			required: true,
			default: null,
			validator: (v) => typeof v === "number" || v === null
		},
		labelValue: [String, Number]
	},
	emits: useSliderEmits,
	setup(props, { emit }) {
		const { proxy: { $q } } = getCurrentInstance();
		const { state, methods } = use_slider_default({
			updateValue,
			updatePosition,
			getDragging,
			formAttrs: useFormAttrs(props)
		});
		const rootRef = ref(null);
		const curRatio = ref(0);
		const model = ref(0);
		function normalizeModel() {
			model.value = props.modelValue === null ? state.innerMin.value : between(props.modelValue, state.innerMin.value, state.innerMax.value);
		}
		watch(() => `${props.modelValue}|${state.innerMin.value}|${state.innerMax.value}`, normalizeModel);
		normalizeModel();
		const modelRatio = computed(() => methods.convertModelToRatio(model.value));
		const ratio = computed(() => state.active.value === true ? curRatio.value : modelRatio.value);
		const selectionBarStyle = computed(() => {
			const acc = {
				[state.positionProp.value]: `${100 * state.innerMinRatio.value}%`,
				[state.sizeProp.value]: `${100 * (ratio.value - state.innerMinRatio.value)}%`
			};
			if (props.selectionImg !== void 0) acc.backgroundImage = `url(${props.selectionImg}) !important`;
			return acc;
		});
		const getThumb = methods.getThumbRenderFn({
			focusValue: true,
			getNodeData,
			ratio,
			label: computed(() => props.labelValue !== void 0 ? props.labelValue : model.value),
			thumbColor: computed(() => props.thumbColor || props.color),
			labelColor: computed(() => props.labelColor),
			labelTextColor: computed(() => props.labelTextColor)
		});
		const trackContainerEvents = computed(() => {
			if (state.editable.value !== true) return {};
			return $q.platform.is.mobile === true ? { onClick: methods.onMobileClick } : {
				onMousedown: methods.onActivate,
				onFocus,
				onBlur: methods.onBlur,
				onKeydown,
				onKeyup: methods.onKeyup
			};
		});
		function updateValue(change) {
			if (model.value !== props.modelValue) emit("update:modelValue", model.value);
			change === true && emit("change", model.value);
		}
		function getDragging() {
			return rootRef.value.getBoundingClientRect();
		}
		function updatePosition(event, dragging = state.dragging.value) {
			const ratio = methods.getDraggingRatio(event, dragging);
			model.value = methods.convertRatioToModel(ratio);
			curRatio.value = props.snap !== true || props.step === 0 ? ratio : methods.convertModelToRatio(model.value);
		}
		function onFocus() {
			state.focus.value = true;
		}
		function onKeydown(evt) {
			if (keyCodes.includes(evt.keyCode) === false) return;
			stopAndPrevent(evt);
			const stepVal = ([34, 33].includes(evt.keyCode) ? 10 : 1) * state.keyStep.value, offset = ([
				34,
				37,
				40
			].includes(evt.keyCode) ? -1 : 1) * (state.isReversed.value === true ? -1 : 1) * (props.vertical === true ? -1 : 1) * stepVal;
			model.value = between(state.roundValueFn.value(model.value + offset), state.innerMin.value, state.innerMax.value);
			updateValue();
		}
		return () => {
			const content = methods.getContent(selectionBarStyle, state.tabindex, trackContainerEvents, (node) => {
				node.push(getThumb());
			});
			return h("div", {
				ref: rootRef,
				class: state.classes.value + (props.modelValue === null ? " q-slider--no-value" : ""),
				...state.attributes.value,
				"aria-valuenow": props.modelValue
			}, content);
		};
	}
});
//#endregion
//#region node_modules/quasar/src/composables/private.use-refocus-target/use-refocus-target.js
function use_refocus_target_default(props, rootRef) {
	const refocusRef = ref(null);
	const refocusTargetEl = computed(() => {
		if (props.disable === true) return null;
		return h("span", {
			ref: refocusRef,
			class: "no-outline",
			tabindex: -1
		});
	});
	function refocusTarget(e) {
		const root = rootRef.value;
		if (e?.qAvoidFocus === true) return;
		if (e?.type.indexOf("key") === 0) {
			if (document.activeElement !== root && root?.contains(document.activeElement) === true) root.focus();
		} else if (refocusRef.value !== null && (e === void 0 || root?.contains(e.target) === true)) refocusRef.value.focus();
	}
	return {
		refocusTargetEl,
		refocusTarget
	};
}
//#endregion
//#region node_modules/quasar/src/utils/private.option-sizes/option-sizes.js
var option_sizes_default = {
	xs: 30,
	sm: 35,
	md: 40,
	lg: 50,
	xl: 60
};
//#endregion
//#region node_modules/quasar/src/components/checkbox/use-checkbox.js
var useCheckboxProps = {
	...useDarkProps,
	...useSizeProps,
	...useFormProps,
	modelValue: {
		required: true,
		default: null
	},
	val: {},
	trueValue: { default: true },
	falseValue: { default: false },
	indeterminateValue: { default: null },
	checkedIcon: String,
	uncheckedIcon: String,
	indeterminateIcon: String,
	toggleOrder: {
		type: String,
		validator: (v) => v === "tf" || v === "ft"
	},
	toggleIndeterminate: Boolean,
	label: String,
	leftLabel: Boolean,
	color: String,
	keepColor: Boolean,
	dense: Boolean,
	disable: Boolean,
	tabindex: [String, Number]
};
var useCheckboxEmits = ["update:modelValue"];
function use_checkbox_default(type, getInner) {
	const { props, slots, emit, proxy } = getCurrentInstance();
	const { $q } = proxy;
	const isDark = use_dark_default(props, $q);
	const rootRef = ref(null);
	const { refocusTargetEl, refocusTarget } = use_refocus_target_default(props, rootRef);
	const sizeStyle = use_size_default(props, option_sizes_default);
	const modelIsArray = computed(() => props.val !== void 0 && Array.isArray(props.modelValue));
	const index = computed(() => {
		const val = toRaw(props.val);
		return modelIsArray.value === true ? props.modelValue.findIndex((opt) => toRaw(opt) === val) : -1;
	});
	const isTrue = computed(() => modelIsArray.value === true ? index.value !== -1 : toRaw(props.modelValue) === toRaw(props.trueValue));
	const isFalse = computed(() => modelIsArray.value === true ? index.value === -1 : toRaw(props.modelValue) === toRaw(props.falseValue));
	const isIndeterminate = computed(() => isTrue.value === false && isFalse.value === false);
	const tabindex = computed(() => props.disable === true ? -1 : props.tabindex || 0);
	const classes = computed(() => `q-${type} cursor-pointer no-outline row inline no-wrap items-center` + (props.disable === true ? " disabled" : "") + (isDark.value === true ? ` q-${type}--dark` : "") + (props.dense === true ? ` q-${type}--dense` : "") + (props.leftLabel === true ? " reverse" : ""));
	const innerClass = computed(() => {
		return `q-${type}__inner relative-position non-selectable q-${type}__inner--${isTrue.value === true ? "truthy" : isFalse.value === true ? "falsy" : "indet"}${props.color !== void 0 && (props.keepColor === true || (type === "toggle" ? isTrue.value === true : isFalse.value !== true)) ? ` text-${props.color}` : ""}`;
	});
	const injectFormInput = useFormInject(computed(() => {
		const prop = { type: "checkbox" };
		props.name !== void 0 && Object.assign(prop, {
			".checked": isTrue.value,
			"^checked": isTrue.value === true ? "checked" : void 0,
			name: props.name,
			value: modelIsArray.value === true ? props.val : props.trueValue
		});
		return prop;
	}));
	const attributes = computed(() => {
		const attrs = {
			tabindex: tabindex.value,
			role: type === "toggle" ? "switch" : "checkbox",
			"aria-label": props.label,
			"aria-checked": isIndeterminate.value === true ? "mixed" : isTrue.value === true ? "true" : "false"
		};
		if (props.disable === true) attrs["aria-disabled"] = "true";
		return attrs;
	});
	function onClick(e) {
		if (e !== void 0) {
			stopAndPrevent(e);
			refocusTarget(e);
		}
		if (props.disable !== true) emit("update:modelValue", getNextValue(), e);
	}
	function getNextValue() {
		if (modelIsArray.value === true) {
			if (isTrue.value === true) {
				const val = props.modelValue.slice();
				val.splice(index.value, 1);
				return val;
			}
			return props.modelValue.concat([props.val]);
		}
		if (isTrue.value === true) {
			if (props.toggleOrder !== "ft" || props.toggleIndeterminate === false) return props.falseValue;
		} else if (isFalse.value === true) {
			if (props.toggleOrder === "ft" || props.toggleIndeterminate === false) return props.trueValue;
		} else return props.toggleOrder !== "ft" ? props.trueValue : props.falseValue;
		return props.indeterminateValue;
	}
	function onKeydown(e) {
		if (e.keyCode === 13 || e.keyCode === 32) stopAndPrevent(e);
	}
	function onKeyup(e) {
		if (e.keyCode === 13 || e.keyCode === 32) onClick(e);
	}
	const getInnerContent = getInner(isTrue, isIndeterminate);
	Object.assign(proxy, { toggle: onClick });
	return () => {
		const inner = getInnerContent();
		props.disable !== true && injectFormInput(inner, "unshift", ` q-${type}__native absolute q-ma-none q-pa-none`);
		const child = [h("div", {
			class: innerClass.value,
			style: sizeStyle.value,
			"aria-hidden": "true"
		}, inner)];
		if (refocusTargetEl.value !== null) child.push(refocusTargetEl.value);
		const label = props.label !== void 0 ? hMergeSlot(slots.default, [props.label]) : hSlot(slots.default);
		label !== void 0 && child.push(h("div", { class: `q-${type}__label q-anchor--skip` }, label));
		return h("div", {
			ref: rootRef,
			class: classes.value,
			...attributes.value,
			onClick,
			onKeydown,
			onKeyup
		}, child);
	};
}
//#endregion
//#region node_modules/quasar/src/components/checkbox/QCheckbox.js
var createBgNode = () => h("div", {
	key: "svg",
	class: "q-checkbox__bg absolute"
}, [h("svg", {
	class: "q-checkbox__svg fit absolute-full",
	viewBox: "0 0 24 24"
}, [h("path", {
	class: "q-checkbox__truthy",
	fill: "none",
	d: "M1.73,12.91 8.1,19.28 22.79,4.59"
}), h("path", {
	class: "q-checkbox__indet",
	d: "M4,14H20V10H4"
})])]);
var QCheckbox_default = createComponent({
	name: "QCheckbox",
	props: useCheckboxProps,
	emits: useCheckboxEmits,
	setup(props) {
		const bgNode = createBgNode();
		function getInner(isTrue, isIndeterminate) {
			const icon = computed(() => (isTrue.value === true ? props.checkedIcon : isIndeterminate.value === true ? props.indeterminateIcon : props.uncheckedIcon) || null);
			return () => icon.value !== null ? [h("div", {
				key: "icon",
				class: "q-checkbox__icon-container absolute-full flex flex-center no-wrap"
			}, [h(QIcon_default, {
				class: "q-checkbox__icon",
				name: icon.value
			})])] : [bgNode];
		}
		return use_checkbox_default("checkbox", getInner);
	}
});
//#endregion
//#region src/components/translator/NarrationSettingsDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "panel-card__title" };
var _hoisted_2$1 = { class: "setting-row" };
var _hoisted_3$1 = { class: "setting-label" };
var _hoisted_4 = { class: "voice-row" };
var _hoisted_5 = ["disabled"];
var _hoisted_6 = { class: "gc-btn__label" };
var _hoisted_7 = {
	key: 0,
	class: "test-voice-error"
};
var _hoisted_8 = { class: "setting-row" };
var _hoisted_9 = { class: "setting-label" };
var _hoisted_10 = { class: "setting-value-group" };
var _hoisted_11 = { class: "setting-value" };
var _hoisted_12 = ["title"];
var _hoisted_13 = { class: "autosync-label" };
var _hoisted_14 = {
	key: 0,
	class: "autosync-badge"
};
var _hoisted_15 = { class: "setting-row" };
var _hoisted_16 = { class: "setting-label" };
var _hoisted_17 = { class: "setting-value" };
var _hoisted_18 = { class: "setting-row" };
var _hoisted_19 = { class: "setting-label" };
var _hoisted_20 = { class: "setting-value" };
var _hoisted_21 = { class: "gc-btn__label" };
var _hoisted_22 = { class: "actions-main" };
var _hoisted_23 = { class: "gc-btn__label" };
var _hoisted_24 = { class: "gc-btn__label" };
var _hoisted_25 = { class: "gc-btn__label" };
//#endregion
//#region src/components/translator/NarrationSettingsDialog.vue
var NarrationSettingsDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "NarrationSettingsDialog",
	props: {
		modelValue: { type: Boolean },
		ttsVoice: {},
		voiceSpeed: {},
		voiceVolume: {},
		originalVolume: {},
		autoSyncSpeed: { type: Boolean },
		narrationEnabled: { type: Boolean },
		ttsQueueLength: {},
		ttsEffectiveSpeed: {},
		isTestingVoice: { type: Boolean },
		testVoiceError: {}
	},
	emits: [
		"update:modelValue",
		"apply",
		"start",
		"test",
		"stop"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const localTTSVoice = ref(props.ttsVoice);
		const localSpeed = ref(props.voiceSpeed);
		const localVoiceVolume = ref(props.voiceVolume);
		const localOriginalVolume = ref(props.originalVolume);
		const localAutoSync = ref(props.autoSyncSpeed);
		watch(() => props.modelValue, (isOpen) => {
			if (!isOpen) return;
			localTTSVoice.value = props.ttsVoice;
			localSpeed.value = props.voiceSpeed;
			localVoiceVolume.value = props.voiceVolume;
			localOriginalVolume.value = props.originalVolume;
			localAutoSync.value = props.autoSyncSpeed;
		}, { immediate: true });
		const voiceOptions = TTS_VOICES.map((voice) => ({
			label: voice.charAt(0).toUpperCase() + voice.slice(1),
			value: voice
		}));
		const speedLabel = computed(() => {
			const v = localSpeed.value;
			if (v === 0) return "1.0×";
			if (v > 0) return `+${v}%`;
			return `${v}%`;
		});
		/** Show effective (boosted) speed when auto-sync is active and boosting */
		const effectiveSpeedLabel = computed(() => {
			if (!props.narrationEnabled || !localAutoSync.value) return null;
			const boosted = props.ttsEffectiveSpeed;
			const base = localSpeed.value >= 0 ? 1 + localSpeed.value / 100 : Math.max(.25, 1 + localSpeed.value / 100 * .75);
			if (Math.abs(boosted - base) < .05) return null;
			return `${boosted.toFixed(1)}×`;
		});
		function closeDialog() {
			emit("update:modelValue", false);
		}
		function getSettings() {
			return {
				ttsVoice: localTTSVoice.value,
				voiceSpeed: localSpeed.value,
				voiceVolume: localVoiceVolume.value,
				originalVolume: localOriginalVolume.value,
				autoSyncSpeed: localAutoSync.value
			};
		}
		function handleApply() {
			emit("apply", getSettings());
			closeDialog();
		}
		function handleStart() {
			emit("start", getSettings());
			closeDialog();
		}
		function handleStop() {
			emit("stop");
			closeDialog();
		}
		function handleTestVoice() {
			emit("test", getSettings());
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QDialog_default, {
				class: "panel-dialog panel-dialog--narration",
				"model-value": __props.modelValue,
				"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => emit("update:modelValue", Boolean($event)))
			}, {
				default: withCtx(() => [createVNode(QCard_default, { class: "narration-dialog panel-card" }, {
					default: withCtx(() => [
						createVNode(QCardSection_default, { class: "panel-card__header" }, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [createVNode(QIcon_default, {
								name: "record_voice_over",
								size: "18px"
							}), createTextVNode(" " + toDisplayString(_ctx.$t("translator.narrationSettings")), 1)]), createBaseVNode("button", {
								class: "gc-btn panel-icon-btn dialog-close-btn",
								"data-no-panel-drag": "",
								onClick: closeDialog
							}, [createVNode(QIcon_default, {
								name: "close",
								size: "18px"
							})])]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardSection_default, { class: "panel-card__body narration-body" }, {
							default: withCtx(() => [
								createBaseVNode("div", _hoisted_2$1, [
									createBaseVNode("div", _hoisted_3$1, toDisplayString(_ctx.$t("translator.ttsVoice")), 1),
									createBaseVNode("div", _hoisted_4, [createVNode(QSelect_default, {
										modelValue: localTTSVoice.value,
										"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => localTTSVoice.value = $event),
										options: unref(voiceOptions),
										dense: "",
										outlined: "",
										"emit-value": "",
										"map-options": "",
										"popup-content-class": "narration-select-menu",
										class: "setting-select"
									}, {
										prepend: withCtx(() => [createVNode(QIcon_default, {
											name: "record_voice_over",
											size: "xs"
										})]),
										_: 1
									}, 8, ["modelValue", "options"]), createBaseVNode("button", {
										class: "gc-btn gc-btn--pill gc-btn--save voice-test-btn",
										disabled: props.isTestingVoice,
										onClick: handleTestVoice
									}, [!props.isTestingVoice ? (openBlock(), createBlock(QIcon_default, {
										key: 0,
										name: "graphic_eq",
										size: "16px"
									})) : (openBlock(), createBlock(QSpinner_default, {
										key: 1,
										size: "16px",
										color: "white"
									})), createBaseVNode("span", _hoisted_6, toDisplayString(props.isTestingVoice ? _ctx.$t("translator.testing") : _ctx.$t("translator.test")), 1)], 8, _hoisted_5)]),
									props.testVoiceError ? (openBlock(), createElementBlock("div", _hoisted_7, toDisplayString(props.testVoiceError), 1)) : createCommentVNode("", true)
								]),
								createBaseVNode("div", _hoisted_8, [
									createBaseVNode("div", _hoisted_9, [createTextVNode(toDisplayString(_ctx.$t("translator.voiceSpeed")) + " ", 1), createBaseVNode("div", _hoisted_10, [createBaseVNode("span", _hoisted_11, toDisplayString(speedLabel.value), 1), effectiveSpeedLabel.value ? (openBlock(), createElementBlock("span", {
										key: 0,
										class: "setting-value setting-value--boosted",
										title: _ctx.$t("translator.autoSyncBoostedHint")
									}, [createTextVNode(" → " + toDisplayString(effectiveSpeedLabel.value) + " ", 1), createVNode(QIcon_default, {
										name: "bolt",
										size: "12px"
									})], 8, _hoisted_12)) : createCommentVNode("", true)])]),
									createVNode(QSlider_default, {
										modelValue: localSpeed.value,
										"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => localSpeed.value = $event),
										min: -100,
										max: 100,
										step: 10,
										color: "primary",
										label: "",
										"label-value": speedLabel.value,
										class: "setting-slider"
									}, null, 8, ["modelValue", "label-value"]),
									createVNode(QCheckbox_default, {
										modelValue: localAutoSync.value,
										"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => localAutoSync.value = $event),
										class: "autosync-checkbox",
										color: "primary",
										size: "sm"
									}, {
										default: withCtx(() => [createBaseVNode("span", _hoisted_13, [createTextVNode(toDisplayString(_ctx.$t("translator.autoSyncSpeed")) + " ", 1), __props.ttsQueueLength > 3 ? (openBlock(), createElementBlock("span", _hoisted_14, toDisplayString(_ctx.$t("translator.autoSyncQueue", { n: __props.ttsQueueLength })), 1)) : createCommentVNode("", true)]), createVNode(QTooltip_default, { "max-width": "220px" }, {
											default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.autoSyncSpeedHint")), 1)]),
											_: 1
										})]),
										_: 1
									}, 8, ["modelValue"])
								]),
								createBaseVNode("div", _hoisted_15, [createBaseVNode("div", _hoisted_16, [createTextVNode(toDisplayString(_ctx.$t("translator.voiceVolume")) + " ", 1), createBaseVNode("span", _hoisted_17, toDisplayString(localVoiceVolume.value) + "%", 1)]), createVNode(QSlider_default, {
									modelValue: localVoiceVolume.value,
									"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => localVoiceVolume.value = $event),
									min: 1,
									max: 100,
									step: 1,
									color: "teal",
									label: "",
									"label-value": `${localVoiceVolume.value}%`,
									class: "setting-slider"
								}, null, 8, ["modelValue", "label-value"])]),
								createBaseVNode("div", _hoisted_18, [createBaseVNode("div", _hoisted_19, [createTextVNode(toDisplayString(_ctx.$t("translator.originalVolume")) + " ", 1), createBaseVNode("span", _hoisted_20, toDisplayString(localOriginalVolume.value) + "%", 1)]), createVNode(QSlider_default, {
									modelValue: localOriginalVolume.value,
									"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => localOriginalVolume.value = $event),
									min: 0,
									max: 100,
									step: 1,
									color: "orange",
									label: "",
									"label-value": `${localOriginalVolume.value}%`,
									class: "setting-slider"
								}, null, 8, ["modelValue", "label-value"])])
							]),
							_: 1
						}),
						createVNode(QSeparator_default, { class: "panel-card__separator" }),
						createVNode(QCardActions_default, { class: "panel-card__actions actions-row" }, {
							default: withCtx(() => [__props.narrationEnabled ? (openBlock(), createElementBlock("button", {
								key: 0,
								class: "gc-btn gc-btn--pill gc-btn--stop",
								onClick: handleStop
							}, [createVNode(QIcon_default, {
								name: "stop",
								size: "18px"
							}), createBaseVNode("span", _hoisted_21, toDisplayString(_ctx.$t("translator.stopNarration")), 1)])) : createCommentVNode("", true), createBaseVNode("div", _hoisted_22, [
								createBaseVNode("button", {
									class: "gc-btn gc-btn--pill",
									onClick: closeDialog
								}, [createBaseVNode("span", _hoisted_23, toDisplayString(_ctx.$t("translator.close")), 1)]),
								createBaseVNode("button", {
									class: "gc-btn gc-btn--pill gc-btn--save",
									onClick: handleApply
								}, [createBaseVNode("span", _hoisted_24, toDisplayString(_ctx.$t("translator.apply")), 1)]),
								!__props.narrationEnabled ? (openBlock(), createElementBlock("button", {
									key: 0,
									class: "gc-btn gc-btn--pill gc-btn--enabled",
									onClick: handleStart
								}, [createVNode(QIcon_default, {
									name: "play_arrow",
									size: "18px"
								}), createBaseVNode("span", _hoisted_25, toDisplayString(_ctx.$t("translator.startNarration")), 1)])) : createCommentVNode("", true)
							])]),
							_: 1
						})
					]),
					_: 1
				})]),
				_: 1
			}, 8, ["model-value"]);
		};
	}
}), [["__scopeId", "data-v-1de5fd5e"]]);
//#endregion
//#region src/services/openai-inline-assistant-client.ts
var OpenAIInlineAssistantClient = class {
	baseUrl = "https://api.openai.com/v1/responses";
	logPrefix = "[InlineAssistant:API]";
	apiKey;
	constructor(apiKey) {
		this.apiKey = apiKey;
	}
	setApiKey(apiKey) {
		this.apiKey = apiKey;
	}
	async run(request, signal) {
		if (!this.apiKey.trim()) throw new Error("OpenAI API key is not configured");
		const userPrompt = buildUserPrompt(request);
		const startedAt = Date.now();
		const body = {
			model: request.model,
			input: [{
				role: "system",
				content: [{
					type: "input_text",
					text: request.systemPrompt
				}]
			}, {
				role: "user",
				content: [{
					type: "input_text",
					text: userPrompt
				}]
			}]
		};
		body.tools = [{ type: "web_search_preview" }];
		console.log(this.logPrefix, "request-start", {
			model: request.model,
			systemPromptLength: request.systemPrompt.length,
			userPromptLength: userPrompt.length
		});
		const response = await fetch(this.baseUrl, {
			method: "POST",
			headers: {
				"Authorization": `Bearer ${this.apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body),
			signal: signal ?? null
		});
		if (!response.ok) {
			const errorText = await response.text().catch(() => "Unknown error");
			console.error(this.logPrefix, "request-error", {
				status: response.status,
				elapsedMs: Date.now() - startedAt,
				bodySnippet: errorText.slice(0, 300)
			});
			throw new InlineAssistantApiError(response.status, errorText);
		}
		const output = extractOutputText(await response.json()).trim();
		if (!output) {
			console.warn(this.logPrefix, "empty-response", { elapsedMs: Date.now() - startedAt });
			throw new Error("OpenAI assistant returned an empty response");
		}
		console.log(this.logPrefix, "request-success", {
			elapsedMs: Date.now() - startedAt,
			outputLength: output.length
		});
		return output;
	}
};
function buildUserPrompt(request) {
	const parts = [];
	if (request.focusOriginal) {
		parts.push("Focus line (original):");
		parts.push(request.focusOriginal);
		parts.push("");
	}
	if (request.focusTranslation) {
		parts.push("Focus line (translated):");
		parts.push(request.focusTranslation);
		parts.push("");
	}
	parts.push("Full transcript context:");
	parts.push(request.transcriptContext || "(empty)");
	parts.push("");
	parts.push("User message:");
	parts.push(request.userMessage || "(empty)");
	return parts.join("\n");
}
function extractOutputText(payload) {
	if (typeof payload.output_text === "string" && payload.output_text.trim()) return payload.output_text;
	const textParts = [];
	for (const item of payload.output ?? []) for (const content of item.content ?? []) {
		if (typeof content.text === "string" && content.text.trim()) {
			textParts.push(content.text);
			continue;
		}
		if (content.text && typeof content.text === "object" && typeof content.text.value === "string" && content.text.value.trim()) textParts.push(content.text.value);
	}
	return textParts.join("\n\n");
}
var InlineAssistantApiError = class extends Error {
	constructor(status, body) {
		super(resolveApiErrorMessage(status, body));
		this.status = status;
		this.body = body;
		this.name = "InlineAssistantApiError";
	}
};
function resolveApiErrorMessage(status, body) {
	if (status === 401) return "Invalid OpenAI API key. Please check your key and try again.";
	if (status === 429) return "OpenAI rate limit reached. Please wait a moment and try again.";
	if (status >= 500) return "OpenAI service error. Please try again later.";
	try {
		return JSON.parse(body).error?.message ?? `OpenAI assistant error (${status})`;
	} catch {
		return `OpenAI assistant error (${status})`;
	}
}
//#endregion
//#region src/pages/TranslatorPage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "title-brand" };
var _hoisted_2 = { class: "title-brand__text" };
var _hoisted_3 = { class: "title-actions" };
var INLINE_ASSISTANT_LOG_PREFIX = "[InlineAssistant:Page]";
var ASSISTANT_CHANNEL_NAME = "live-translator-assistant";
//#endregion
//#region src/pages/TranslatorPage.vue
var TranslatorPage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "TranslatorPage",
	setup(__props) {
		const settingsStore = useSettingsStore();
		const translatorStore = useTranslatorStore();
		const { apiKey, targetLanguage, theirLanguage, microphoneEnabled, speakerNames, translationFontSize, narrationEnabled, openaiApiKey, openaiAssistantModel, openaiAssistantChatPrompt, ttsVoice, voiceSpeed, voiceVolume, originalVolume, autoSyncSpeed } = storeToRefs(settingsStore);
		const { entries, currentSpeakerId, currentOriginal, currentTranslation, recordingState, isActive, error } = storeToRefs(translatorStore);
		const { start, pause, resume, end, setMicEnabled, configureTTS, setNarrationEnabled, applyNarrationSettings, startNarration, testNarrationVoice, stopNarration, ttsState, isInterpreterActive, startInterpreterMode, stopInterpreterMode } = useTranslation();
		const { downloadTxt, downloadJson } = useDownloadTranscript();
		const { t } = useI18n();
		const isSpeakerSettingsOpen = ref(false);
		const isDownloadDialogOpen = ref(false);
		const isNarrationSettingsOpen = ref(false);
		const narrationTestError = ref(null);
		const isTestingVoice = ref(false);
		const isAssistantOpen = ref(false);
		const assistantMessages = ref([]);
		const assistantFocusLine = ref("");
		const assistantInitialInput = ref("");
		const assistantInputPrefillKey = ref(0);
		const isAssistantLoading = ref(false);
		const assistantFocusEntry = ref(null);
		let assistantAbortController = null;
		let inlineAssistantClient = null;
		let assistantMsgCounter = 0;
		let assistantChannel = null;
		const showSaveTranscript = computed(() => recordingState.value === "stopped" && entries.value.length > 0);
		const interpreterModeAvailable = computed(() => isActive.value && theirLanguage.value !== "none" && theirLanguage.value !== targetLanguage.value && microphoneEnabled.value);
		let isDraggingPanel = false;
		function buildNarrationSettings() {
			return {
				apiKey: openaiApiKey.value,
				voice: ttsVoice.value,
				voiceSpeed: voiceSpeed.value,
				voiceVolume: voiceVolume.value,
				originalVolume: originalVolume.value,
				autoSyncSpeed: autoSyncSpeed.value
			};
		}
		function resolveHintPrompt(template) {
			return (template?.trim() || "").trim().replaceAll("{{targetLanguage}}", targetLanguage.value);
		}
		function broadcastAssistantState() {
			try {
				assistantChannel?.postMessage({
					type: "state",
					messages: JSON.parse(JSON.stringify(assistantMessages.value)),
					loading: isAssistantLoading.value,
					focusLine: assistantFocusLine.value,
					initialInput: assistantInitialInput.value,
					inputPrefillKey: assistantInputPrefillKey.value,
					hintExplainPrompt: resolveHintPrompt(DEFAULT_SETTINGS.openaiAssistantExplainPrompt ?? ""),
					hintAnswerPrompt: resolveHintPrompt(DEFAULT_SETTINGS.openaiAssistantQAPrompt ?? "")
				});
			} catch {}
		}
		function setupAssistantChannel() {
			assistantChannel = new BroadcastChannel(ASSISTANT_CHANNEL_NAME);
			assistantChannel.onmessage = (event) => {
				const data = event.data;
				if (!data?.type) return;
				switch (data.type) {
					case "send":
						if (data.payload) handleAssistantSend(data.payload);
						break;
					case "close":
						closeAssistant();
						break;
					case "clear":
						clearAssistantChat();
						broadcastAssistantState();
						break;
					case "request-state":
						broadcastAssistantState();
						break;
				}
			};
		}
		onMounted(async () => {
			await settingsStore.loadSettings();
			syncTTSConfig();
			setupAssistantChannel();
			window.addEventListener("message", handleChatSendResult);
		});
		function syncTTSConfig() {
			if (openaiApiKey.value) configureTTS(buildNarrationSettings());
			setNarrationEnabled(narrationEnabled.value && !!openaiApiKey.value);
		}
		watch([openaiApiKey, ttsVoice], () => {
			syncTTSConfig();
		});
		watch(narrationEnabled, () => {
			syncTTSConfig();
		});
		watch([
			assistantMessages,
			isAssistantLoading,
			assistantFocusLine,
			assistantInitialInput,
			assistantInputPrefillKey,
			targetLanguage
		], () => {
			if (isAssistantOpen.value) broadcastAssistantState();
		}, { deep: true });
		function handleStart() {
			if (!apiKey.value) return;
			start(apiKey.value, targetLanguage.value, microphoneEnabled.value, theirLanguage.value);
		}
		function handlePause() {
			pause();
		}
		function handleResume() {
			resume();
		}
		async function handleEnd() {
			await end();
			clearAssistantChat();
			if (isAssistantOpen.value) broadcastAssistantState();
		}
		function handleMicToggle(enabled) {
			settingsStore.microphoneEnabled = enabled;
			if (isActive.value) setMicEnabled(enabled);
		}
		function handleOpenNarrationSettings() {
			narrationTestError.value = null;
			isNarrationSettingsOpen.value = true;
		}
		function saveDialogSettings(settings) {
			settingsStore.ttsVoice = settings.ttsVoice;
			settingsStore.voiceSpeed = settings.voiceSpeed;
			settingsStore.voiceVolume = settings.voiceVolume;
			settingsStore.originalVolume = settings.originalVolume;
			settingsStore.autoSyncSpeed = settings.autoSyncSpeed;
		}
		function handleNarrationApply(settings) {
			narrationTestError.value = null;
			saveDialogSettings(settings);
			applyNarrationSettings(buildNarrationSettings());
		}
		function handleNarrationStart(settings) {
			narrationTestError.value = null;
			saveDialogSettings(settings);
			settingsStore.narrationEnabled = true;
			startNarration(buildNarrationSettings());
		}
		async function handleNarrationTest(settings) {
			narrationTestError.value = null;
			if (!openaiApiKey.value.trim()) {
				narrationTestError.value = t("errors.openaiApiKeyRequired");
				return;
			}
			isTestingVoice.value = true;
			try {
				await testNarrationVoice({
					apiKey: openaiApiKey.value,
					voice: settings.ttsVoice,
					voiceSpeed: settings.voiceSpeed,
					voiceVolume: settings.voiceVolume,
					originalVolume: settings.originalVolume,
					autoSyncSpeed: settings.autoSyncSpeed
				});
			} catch (err) {
				narrationTestError.value = err instanceof Error ? err.message : "Voice test failed";
			} finally {
				isTestingVoice.value = false;
			}
		}
		function handleNarrationStop() {
			settingsStore.narrationEnabled = false;
			stopNarration();
		}
		function getAssistantClient() {
			if (!inlineAssistantClient) {
				inlineAssistantClient = new OpenAIInlineAssistantClient(openaiApiKey.value);
				console.log(INLINE_ASSISTANT_LOG_PREFIX, "client-created");
				return inlineAssistantClient;
			}
			inlineAssistantClient.setApiKey(openaiApiKey.value);
			return inlineAssistantClient;
		}
		function buildAssistantContext(allEntries, focusedEntryId, includeTranslated = false) {
			return allEntries.map((entry, index) => {
				const speaker = entry.audioSource === "mic" ? t("translator.you") : resolveSpeakerLabel(entry.speakerId, speakerNames.value, t("translator.speaker"), t("translator.speakerUnknown"));
				const marker = entry.id === focusedEntryId ? " <FOCUS>" : "";
				const originalText = entry.originalText || "(empty)";
				const translatedText = entry.translatedText || "(empty)";
				const translatedLine = includeTranslated ? `\n   Translated(${entry.targetLanguage}): ${translatedText}` : "";
				return `${index + 1}. [${speaker}] Original: ${originalText}${translatedLine}${marker}`;
			}).join("\n");
		}
		function buildAssistantSystemPrompt() {
			return (openaiAssistantChatPrompt.value?.trim() || (DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "")).trim().replaceAll("{{targetLanguage}}", targetLanguage.value);
		}
		function genMsgId() {
			assistantMsgCounter++;
			return `msg-${Date.now()}-${assistantMsgCounter}`;
		}
		function handleOpenAssistantFromRow(payload) {
			const entry = payload.entry;
			assistantFocusEntry.value = entry;
			assistantFocusLine.value = entry.translatedText || entry.originalText;
			assistantInitialInput.value = assistantFocusLine.value;
			assistantInputPrefillKey.value += 1;
			isAssistantOpen.value = true;
			sendPanelMessage({ type: "ASSISTANT_OPEN" });
			nextTick(() => broadcastAssistantState());
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "popup-opened-from-row", { entryId: entry.id });
		}
		function handleOpenAssistantFromControls() {
			assistantFocusEntry.value = null;
			assistantFocusLine.value = "";
			assistantInitialInput.value = "";
			assistantInputPrefillKey.value += 1;
			isAssistantOpen.value = true;
			sendPanelMessage({ type: "ASSISTANT_OPEN" });
			nextTick(() => broadcastAssistantState());
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "popup-opened-from-controls");
		}
		async function handleAssistantSend(message) {
			const userMsg = {
				id: genMsgId(),
				role: "user",
				content: message,
				timestamp: Date.now()
			};
			assistantMessages.value.push(userMsg);
			assistantInitialInput.value = "";
			broadcastAssistantState();
			await runAssistantRequest(message);
		}
		async function runAssistantRequest(userMessage) {
			const startedAt = Date.now();
			isAssistantLoading.value = true;
			if (!openaiApiKey.value.trim()) {
				assistantMessages.value.push({
					id: genMsgId(),
					role: "assistant",
					content: t("errors.openaiApiKeyRequiredAssistant"),
					timestamp: Date.now()
				});
				isAssistantLoading.value = false;
				return;
			}
			assistantAbortController?.abort();
			assistantAbortController = new AbortController();
			const model = openaiAssistantModel.value?.trim() || "gpt-4.1-mini";
			const systemPrompt = buildAssistantSystemPrompt();
			const focusEntry = assistantFocusEntry.value;
			const transcriptContext = buildAssistantContext(entries.value, focusEntry?.id ?? "", false);
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "request-prepared", {
				model,
				hasFocusEntry: Boolean(focusEntry),
				transcriptContextLength: transcriptContext.length
			});
			try {
				const result = await getAssistantClient().run({
					model,
					systemPrompt,
					transcriptContext,
					userMessage,
					focusOriginal: focusEntry?.originalText ?? "",
					focusTranslation: focusEntry?.translatedText ?? ""
				}, assistantAbortController.signal);
				assistantMessages.value.push({
					id: genMsgId(),
					role: "assistant",
					content: result,
					timestamp: Date.now()
				});
				console.log(INLINE_ASSISTANT_LOG_PREFIX, "request-success", {
					resultLength: result.length,
					elapsedMs: Date.now() - startedAt
				});
			} catch (err) {
				if (err.name === "AbortError") return;
				const errorMsg = err instanceof Error ? err.message : t("errors.serviceError");
				assistantMessages.value.push({
					id: genMsgId(),
					role: "assistant",
					content: `⚠ ${errorMsg}`,
					timestamp: Date.now()
				});
				console.error(INLINE_ASSISTANT_LOG_PREFIX, "request-failed", {
					elapsedMs: Date.now() - startedAt,
					error: err
				});
			} finally {
				isAssistantLoading.value = false;
				assistantAbortController = null;
			}
		}
		function closeAssistant() {
			console.log(INLINE_ASSISTANT_LOG_PREFIX, "popup-closed", { hadPendingRequest: Boolean(assistantAbortController) });
			assistantAbortController?.abort();
			assistantAbortController = null;
			isAssistantLoading.value = false;
			isAssistantOpen.value = false;
			sendPanelMessage({ type: "ASSISTANT_CLOSE" });
		}
		function clearAssistantChat() {
			assistantMessages.value = [];
			assistantFocusLine.value = "";
			assistantFocusEntry.value = null;
			assistantInitialInput.value = "";
			assistantInputPrefillKey.value += 1;
		}
		async function handleLanguageChange(lang) {
			settingsStore.targetLanguage = lang;
			if (isActive.value) {
				if (isInterpreterActive.value) stopInterpreterMode();
				await end();
				start(apiKey.value, lang, microphoneEnabled.value, theirLanguage.value);
			}
		}
		async function handleTheirLanguageChange(lang) {
			settingsStore.theirLanguage = lang;
			if (isActive.value) {
				if (isInterpreterActive.value) stopInterpreterMode();
				await end();
				start(apiKey.value, targetLanguage.value, microphoneEnabled.value, lang);
			}
		}
		function handleInterpreterTextReady(text) {
			console.info("[Interpreter] sending to chat:", text.substring(0, 80));
			sendPanelMessage({
				type: "SEND_CHAT_MESSAGE",
				text
			});
		}
		function handleToggleInterpreterMode() {
			if (isInterpreterActive.value) stopInterpreterMode();
			else startInterpreterMode(handleInterpreterTextReady);
		}
		function handleChatSendResult(event) {
			const data = event.data;
			if (data?.type !== "CHAT_SEND_RESULT") return;
			if (!data.success && data.error) console.warn("[Interpreter] Chat send failed:", data.error);
		}
		async function handleSpeakerSettingsSave(updatedNames) {
			settingsStore.setSpeakerNames(updatedNames);
			await settingsStore.saveSettings();
		}
		function handleSaveTranscript() {
			isDownloadDialogOpen.value = true;
		}
		function handleTranslationFontSizeChange(size) {
			settingsStore.translationFontSize = size;
		}
		function handleDownloadTxt() {
			downloadTxt(entries.value);
		}
		function handleDownloadJson() {
			downloadJson(entries.value);
		}
		function sendPanelMessage(message) {
			try {
				window.parent.postMessage(message, "*");
			} catch {}
		}
		function stopPanelDrag(shouldNotifyParent = true) {
			if (!isDraggingPanel) return;
			isDraggingPanel = false;
			window.removeEventListener("mousemove", handleWindowMouseMove);
			window.removeEventListener("mouseup", handleWindowMouseUp);
			if (shouldNotifyParent) sendPanelMessage({ type: "PANEL_DRAG_END" });
		}
		function handleWindowMouseMove(event) {
			if (!isDraggingPanel) return;
			sendPanelMessage({
				type: "PANEL_DRAG_MOVE",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
		}
		function handleWindowMouseUp() {
			stopPanelDrag(true);
		}
		function isInteractiveTitleBarTarget(target) {
			if (!(target instanceof HTMLElement)) return false;
			return Boolean(target.closest("button, [role=\"button\"], a, input, textarea, select, [contenteditable=\"true\"], [data-no-panel-drag]"));
		}
		function handleTitleBarMouseDown(event) {
			if (event.button !== 0) return;
			if (isInteractiveTitleBarTarget(event.target)) return;
			event.preventDefault();
			isDraggingPanel = true;
			sendPanelMessage({
				type: "PANEL_DRAG_START",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
			window.addEventListener("mousemove", handleWindowMouseMove);
			window.addEventListener("mouseup", handleWindowMouseUp);
		}
		function openSettingsPage() {
			try {
				chrome.runtime.openOptionsPage();
			} catch {
				window.open(chrome.runtime.getURL("www/index.html#/settings"), "_blank");
			}
		}
		function handleMinimize() {
			stopPanelDrag(false);
			sendPanelMessage({ type: "MINIMIZE_PANEL" });
		}
		async function handleClose() {
			stopPanelDrag(false);
			if (isActive.value) await end();
			sendPanelMessage({ type: "CLOSE_PANEL" });
		}
		onBeforeUnmount(() => {
			stopPanelDrag(true);
			assistantAbortController?.abort();
			assistantAbortController = null;
			assistantChannel?.close();
			assistantChannel = null;
			window.removeEventListener("message", handleChatSendResult);
			if (isInterpreterActive.value) stopInterpreterMode();
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QPage_default, { class: "translator-page" }, {
				default: withCtx(() => [
					createBaseVNode("div", {
						class: "title-bar",
						onMousedown: handleTitleBarMouseDown
					}, [createBaseVNode("div", _hoisted_1, [createVNode(QIcon_default, {
						name: "translate",
						size: "18px",
						class: "title-brand__icon"
					}), createBaseVNode("span", _hoisted_2, toDisplayString(_ctx.$t("translator.title")), 1)]), createBaseVNode("div", _hoisted_3, [
						createBaseVNode("button", {
							class: "title-action-btn",
							"data-no-panel-drag": "",
							onClick: _cache[0] || (_cache[0] = ($event) => isSpeakerSettingsOpen.value = true)
						}, [createVNode(QIcon_default, {
							name: "groups",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.speakerSettings")), 1)]),
							_: 1
						})]),
						createBaseVNode("button", {
							class: "title-action-btn",
							"data-no-panel-drag": "",
							onClick: openSettingsPage
						}, [createVNode(QIcon_default, {
							name: "settings",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("settings.settingsTooltip")), 1)]),
							_: 1
						})]),
						createBaseVNode("button", {
							class: "title-action-btn",
							"data-no-panel-drag": "",
							onClick: handleMinimize
						}, [createVNode(QIcon_default, {
							name: "minimize",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.minimize")), 1)]),
							_: 1
						})]),
						createBaseVNode("button", {
							class: "title-action-btn title-action-btn--danger",
							"data-no-panel-drag": "",
							onClick: handleClose
						}, [createVNode(QIcon_default, {
							name: "close",
							size: "18px"
						}), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("translator.close")), 1)]),
							_: 1
						})])
					])], 32),
					createVNode(TranslatorHeader_default, {
						"target-language": unref(targetLanguage),
						"their-language": unref(theirLanguage),
						disabled: unref(isActive),
						"onUpdate:targetLanguage": handleLanguageChange,
						"onUpdate:theirLanguage": handleTheirLanguageChange
					}, null, 8, [
						"target-language",
						"their-language",
						"disabled"
					]),
					unref(error) ? (openBlock(), createBlock(QBanner_default, {
						key: 0,
						dense: "",
						class: "bg-negative text-white q-mx-sm q-mt-xs",
						rounded: ""
					}, {
						avatar: withCtx(() => [createVNode(QIcon_default, {
							name: "error",
							color: "white"
						})]),
						default: withCtx(() => [createTextVNode(" " + toDisplayString(unref(error)), 1)]),
						_: 1
					})) : createCommentVNode("", true),
					createVNode(TranslatorDisplay_default, {
						entries: unref(entries),
						"current-speaker-id": unref(currentSpeakerId),
						"current-original": unref(currentOriginal),
						"current-translation": unref(currentTranslation),
						"is-active": unref(isActive),
						"translation-font-size": unref(translationFontSize),
						onOpenAssistant: handleOpenAssistantFromRow
					}, null, 8, [
						"entries",
						"current-speaker-id",
						"current-original",
						"current-translation",
						"is-active",
						"translation-font-size"
					]),
					createVNode(TranslatorControls_default, {
						"recording-state": unref(recordingState),
						"has-api-key": unref(apiKey).length > 0,
						"microphone-enabled": unref(microphoneEnabled),
						"narration-enabled": unref(narrationEnabled),
						"tts-speaking": unref(ttsState).isSpeaking.value,
						"show-save-transcript": showSaveTranscript.value,
						"translation-font-size": unref(translationFontSize),
						"interpreter-mode-enabled": unref(isInterpreterActive),
						"interpreter-mode-available": interpreterModeAvailable.value,
						onStart: handleStart,
						onPause: handlePause,
						onResume: handleResume,
						onEnd: handleEnd,
						onToggleMicrophone: handleMicToggle,
						onToggleInterpreterMode: handleToggleInterpreterMode,
						onOpenNarrationSettings: handleOpenNarrationSettings,
						onOpenAssistant: handleOpenAssistantFromControls,
						onSaveTranscript: handleSaveTranscript,
						onUpdateTranslationFontSize: handleTranslationFontSizeChange
					}, null, 8, [
						"recording-state",
						"has-api-key",
						"microphone-enabled",
						"narration-enabled",
						"tts-speaking",
						"show-save-transcript",
						"translation-font-size",
						"interpreter-mode-enabled",
						"interpreter-mode-available"
					]),
					createVNode(SpeakerSettingsDialog_default, {
						modelValue: isSpeakerSettingsOpen.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isSpeakerSettingsOpen.value = $event),
						"speaker-names": unref(speakerNames),
						onSave: handleSpeakerSettingsSave
					}, null, 8, ["modelValue", "speaker-names"]),
					createVNode(DownloadTranscriptDialog_default, {
						modelValue: isDownloadDialogOpen.value,
						"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isDownloadDialogOpen.value = $event),
						onDownloadTxt: handleDownloadTxt,
						onDownloadJson: handleDownloadJson
					}, null, 8, ["modelValue"]),
					createVNode(NarrationSettingsDialog_default, {
						modelValue: isNarrationSettingsOpen.value,
						"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isNarrationSettingsOpen.value = $event),
						"tts-voice": unref(ttsVoice),
						"voice-speed": unref(voiceSpeed),
						"voice-volume": unref(voiceVolume),
						"original-volume": unref(originalVolume),
						"auto-sync-speed": unref(autoSyncSpeed),
						"narration-enabled": unref(narrationEnabled),
						"tts-queue-length": unref(ttsState).queueLength.value,
						"tts-effective-speed": unref(ttsState).effectiveSpeed.value,
						"is-testing-voice": isTestingVoice.value,
						"test-voice-error": narrationTestError.value,
						onApply: handleNarrationApply,
						onStart: handleNarrationStart,
						onTest: handleNarrationTest,
						onStop: handleNarrationStop
					}, null, 8, [
						"modelValue",
						"tts-voice",
						"voice-speed",
						"voice-volume",
						"original-volume",
						"auto-sync-speed",
						"narration-enabled",
						"tts-queue-length",
						"tts-effective-speed",
						"is-testing-voice",
						"test-voice-error"
					])
				]),
				_: 1
			});
		};
	}
}), [["__scopeId", "data-v-d12775cc"]]);
//#endregion
export { TranslatorPage_default as default };
