import { F as watch, G as ref, I as withCtx, L as withDirectives, N as renderList, O as onMounted, Q as normalizeClass, S as nextTick, T as onBeforeUnmount, Z as unref, _ as defineComponent, a as vModelText, d as createBaseVNode, et as toDisplayString, f as createBlock, g as createVNode, h as createTextVNode, j as openBlock, m as createElementBlock, p as createCommentVNode, s as Fragment, u as computed } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import "./dom-ClQ5j7De.js";
import "./Platform-DVLU8Kjq.js";
import { i as QIcon_default } from "./vm-BBDykFtW.js";
import { n as useI18n } from "./vue-i18n.runtime-0_E2riTW.js";
import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import { t as QPage_default } from "./QPage-DRy6HV2c.js";
import "./position-engine-B6rijeNv.js";
import { t as QTooltip_default } from "./QTooltip-D32R4QC4.js";
//#region src/components/translator/AssistantPopup.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "assistant-panel" };
var _hoisted_2 = {
	class: "assistant-header",
	"data-assistant-drag-handle": ""
};
var _hoisted_3 = { class: "assistant-header__title" };
var _hoisted_4 = { class: "assistant-header__actions" };
var _hoisted_5 = {
	key: 0,
	class: "assistant-focus-line"
};
var _hoisted_6 = { class: "assistant-focus-line__text" };
var _hoisted_7 = {
	key: 0,
	class: "assistant-empty"
};
var _hoisted_8 = { class: "assistant-empty__text" };
var _hoisted_9 = { class: "assistant-msg__bubble" };
var _hoisted_10 = { class: "assistant-msg__content" };
var _hoisted_11 = { class: "assistant-msg__time" };
var _hoisted_12 = {
	key: 1,
	class: "assistant-msg assistant-msg--assistant"
};
var _hoisted_13 = { class: "assistant-msg__bubble assistant-msg__bubble--loading" };
var _hoisted_14 = { class: "assistant-typing__label" };
var _hoisted_15 = { class: "assistant-input-area" };
var _hoisted_16 = { class: "assistant-input-row" };
var _hoisted_17 = ["placeholder"];
var _hoisted_18 = ["disabled"];
var _hoisted_19 = { class: "assistant-hints" };
//#endregion
//#region src/components/translator/AssistantPopup.vue
var AssistantPopup_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "AssistantPopup",
	props: {
		messages: {},
		loading: { type: Boolean },
		initialInput: { default: "" },
		inputPrefillKey: { default: 0 },
		focusLine: { default: "" },
		hintExplainPrompt: { default: "" },
		hintAnswerPrompt: { default: "" }
	},
	emits: [
		"send",
		"close",
		"clear"
	],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const { t } = useI18n();
		const inputText = ref("");
		const messagesRef = ref(null);
		const inputRef = ref(null);
		const canSend = computed(() => inputText.value.trim().length > 0 && !props.loading);
		const hasMessages = computed(() => props.messages.length > 0);
		watch(() => props.inputPrefillKey, () => {
			inputText.value = props.initialInput;
			nextTick(() => inputRef.value?.focus());
		}, { immediate: true });
		watch(() => props.messages.length, () => {
			nextTick(() => scrollToBottom());
		});
		function scrollToBottom() {
			if (messagesRef.value) messagesRef.value.scrollTop = messagesRef.value.scrollHeight;
		}
		function handleSend() {
			const text = inputText.value.trim();
			if (!text || props.loading) return;
			inputText.value = "";
			emit("send", text);
		}
		function handleKeyDown(event) {
			if (event.key === "Enter" && !event.shiftKey) {
				event.preventDefault();
				handleSend();
			}
		}
		function handleHintAnswer() {
			inputText.value = props.hintAnswerPrompt || t("translator.assistantHintAnswer");
			nextTick(() => inputRef.value?.focus());
		}
		function handleHintExplain() {
			inputText.value = props.hintExplainPrompt || t("translator.assistantHintExplain");
			nextTick(() => inputRef.value?.focus());
		}
		function formatTime(timestamp) {
			return new Date(timestamp).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			});
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				createBaseVNode("div", _hoisted_2, [createBaseVNode("div", _hoisted_3, [createVNode(QIcon_default, {
					name: "smart_toy",
					size: "20px",
					class: "assistant-header__icon"
				}), createBaseVNode("span", null, toDisplayString(unref(t)("translator.assistantTitle")), 1)]), createBaseVNode("div", _hoisted_4, [createBaseVNode("button", {
					class: "assistant-header__btn",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("clear"))
				}, [createVNode(QIcon_default, {
					name: "delete_sweep",
					size: "18px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createTextVNode("Clear chat", -1)])]),
					_: 1
				})]), createBaseVNode("button", {
					class: "assistant-header__btn",
					onClick: _cache[1] || (_cache[1] = ($event) => emit("close"))
				}, [createVNode(QIcon_default, {
					name: "close",
					size: "18px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [..._cache[4] || (_cache[4] = [createTextVNode("Close", -1)])]),
					_: 1
				})])])]),
				__props.focusLine ? (openBlock(), createElementBlock("div", _hoisted_5, [createVNode(QIcon_default, {
					name: "format_quote",
					size: "14px",
					class: "text-grey-6"
				}), createBaseVNode("span", _hoisted_6, toDisplayString(__props.focusLine), 1)])) : createCommentVNode("", true),
				createBaseVNode("div", {
					ref_key: "messagesRef",
					ref: messagesRef,
					class: "assistant-messages"
				}, [
					!hasMessages.value && !__props.loading ? (openBlock(), createElementBlock("div", _hoisted_7, [createVNode(QIcon_default, {
						name: "forum",
						size: "48px",
						class: "assistant-empty__icon"
					}), createBaseVNode("p", _hoisted_8, toDisplayString(unref(t)("translator.assistantEmpty")), 1)])) : createCommentVNode("", true),
					(openBlock(true), createElementBlock(Fragment, null, renderList(__props.messages, (msg) => {
						return openBlock(), createElementBlock("div", {
							key: msg.id,
							class: normalizeClass(["assistant-msg", `assistant-msg--${msg.role}`])
						}, [createBaseVNode("div", _hoisted_9, [createBaseVNode("div", _hoisted_10, toDisplayString(msg.content), 1), createBaseVNode("div", _hoisted_11, toDisplayString(formatTime(msg.timestamp)), 1)])], 2);
					}), 128)),
					__props.loading ? (openBlock(), createElementBlock("div", _hoisted_12, [createBaseVNode("div", _hoisted_13, [_cache[5] || (_cache[5] = createBaseVNode("span", { class: "assistant-typing" }, [
						createBaseVNode("span", { class: "assistant-typing__dot" }),
						createBaseVNode("span", { class: "assistant-typing__dot" }),
						createBaseVNode("span", { class: "assistant-typing__dot" })
					], -1)), createBaseVNode("span", _hoisted_14, toDisplayString(unref(t)("translator.inlineAssistantLoading")), 1)])])) : createCommentVNode("", true)
				], 512),
				createBaseVNode("div", _hoisted_15, [createBaseVNode("div", _hoisted_16, [withDirectives(createBaseVNode("textarea", {
					ref_key: "inputRef",
					ref: inputRef,
					"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => inputText.value = $event),
					class: "assistant-input",
					placeholder: unref(t)("translator.assistantInputPlaceholder"),
					rows: "3",
					onKeydown: handleKeyDown
				}, null, 40, _hoisted_17), [[vModelText, inputText.value]]), createBaseVNode("button", {
					class: normalizeClass(["assistant-send-btn", { "assistant-send-btn--active": canSend.value }]),
					disabled: !canSend.value,
					onClick: handleSend
				}, [createVNode(QIcon_default, {
					name: "send",
					size: "20px"
				})], 10, _hoisted_18)]), createBaseVNode("div", _hoisted_19, [createBaseVNode("button", {
					class: "assistant-hint-btn",
					onClick: handleHintAnswer
				}, [createVNode(QIcon_default, {
					name: "question_answer",
					size: "16px"
				}), createBaseVNode("span", null, toDisplayString(unref(t)("translator.assistantHintAnswer")), 1)]), createBaseVNode("button", {
					class: "assistant-hint-btn",
					onClick: handleHintExplain
				}, [createVNode(QIcon_default, {
					name: "lightbulb",
					size: "16px"
				}), createBaseVNode("span", null, toDisplayString(unref(t)("translator.assistantHintExplain")), 1)])])])
			]);
		};
	}
}), [["__scopeId", "data-v-9098a413"]]);
//#endregion
//#region src/pages/AssistantPage.vue?vue&type=script&setup=true&lang.ts
var CHANNEL_NAME = "live-translator-assistant";
//#endregion
//#region src/pages/AssistantPage.vue
var AssistantPage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "AssistantPage",
	setup(__props) {
		const messages = ref([]);
		const loading = ref(false);
		const focusLine = ref("");
		const initialInput = ref("");
		const inputPrefillKey = ref(0);
		const hintExplainPrompt = ref("");
		const hintAnswerPrompt = ref("");
		let channel = null;
		let isDragging = false;
		function sendAction(msg) {
			channel?.postMessage(msg);
		}
		function handleSend(message) {
			sendAction({
				type: "send",
				payload: message
			});
		}
		function handleClose() {
			sendAction({ type: "close" });
		}
		function handleClear() {
			sendAction({ type: "clear" });
		}
		function sendPanelMessage(message) {
			try {
				window.parent.postMessage(message, "*");
			} catch {}
		}
		function isInteractiveTarget(target) {
			if (!(target instanceof HTMLElement)) return false;
			return Boolean(target.closest("button, [role=\"button\"], input, textarea, select, a, [contenteditable=\"true\"]"));
		}
		function handleHeaderMouseDown(event) {
			if (!event.target?.closest("[data-assistant-drag-handle]")) return;
			if (isInteractiveTarget(event.target)) return;
			if (event.button !== 0) return;
			event.preventDefault();
			isDragging = true;
			sendPanelMessage({
				type: "ASSISTANT_DRAG_START",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
			window.addEventListener("mousemove", handleMouseMove);
			window.addEventListener("mouseup", handleMouseUp);
		}
		function handleMouseMove(event) {
			if (!isDragging) return;
			sendPanelMessage({
				type: "ASSISTANT_DRAG_MOVE",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
		}
		function handleMouseUp() {
			if (!isDragging) return;
			isDragging = false;
			sendPanelMessage({ type: "ASSISTANT_DRAG_END" });
			window.removeEventListener("mousemove", handleMouseMove);
			window.removeEventListener("mouseup", handleMouseUp);
		}
		onMounted(() => {
			channel = new BroadcastChannel(CHANNEL_NAME);
			channel.onmessage = (event) => {
				const data = event.data;
				if (data?.type === "state") {
					messages.value = data.messages;
					loading.value = data.loading;
					focusLine.value = data.focusLine;
					initialInput.value = data.initialInput;
					inputPrefillKey.value = data.inputPrefillKey;
					hintExplainPrompt.value = data.hintExplainPrompt ?? "";
					hintAnswerPrompt.value = data.hintAnswerPrompt ?? "";
				}
			};
			document.addEventListener("mousedown", handleHeaderMouseDown);
			sendPanelMessage({ type: "ASSISTANT_READY" });
			sendAction({ type: "request-state" });
		});
		onBeforeUnmount(() => {
			channel?.close();
			channel = null;
			document.removeEventListener("mousedown", handleHeaderMouseDown);
			window.removeEventListener("mousemove", handleMouseMove);
			window.removeEventListener("mouseup", handleMouseUp);
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(QPage_default, { class: "assistant-page" }, {
				default: withCtx(() => [createVNode(AssistantPopup_default, {
					messages: messages.value,
					loading: loading.value,
					"initial-input": initialInput.value,
					"input-prefill-key": inputPrefillKey.value,
					"focus-line": focusLine.value,
					"hint-explain-prompt": hintExplainPrompt.value,
					"hint-answer-prompt": hintAnswerPrompt.value,
					onSend: handleSend,
					onClose: handleClose,
					onClear: handleClear
				}, null, 8, [
					"messages",
					"loading",
					"initial-input",
					"input-prefill-key",
					"focus-line",
					"hint-explain-prompt",
					"hint-answer-prompt"
				])]),
				_: 1
			});
		};
	}
}), [["__scopeId", "data-v-488ed8c1"]]);
//#endregion
export { AssistantPage_default as default };
