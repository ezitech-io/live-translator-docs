import { F as watch, G as ref } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { p as defineStore } from "./index-SGausFmx.js";
//#region src/types/index.ts
var SUPPORTED_LANGUAGES = [
	{
		value: "af",
		label: "Afrikaans",
		nativeLabel: "Afrikaans"
	},
	{
		value: "sq",
		label: "Albanian",
		nativeLabel: "Shqip"
	},
	{
		value: "ar",
		label: "Arabic",
		nativeLabel: "العربية"
	},
	{
		value: "az",
		label: "Azerbaijani",
		nativeLabel: "Azərbaycan dili"
	},
	{
		value: "eu",
		label: "Basque",
		nativeLabel: "Euskara"
	},
	{
		value: "be",
		label: "Belarusian",
		nativeLabel: "Беларуская"
	},
	{
		value: "bn",
		label: "Bengali",
		nativeLabel: "বাংলা"
	},
	{
		value: "bs",
		label: "Bosnian",
		nativeLabel: "Bosanski"
	},
	{
		value: "bg",
		label: "Bulgarian",
		nativeLabel: "Български"
	},
	{
		value: "ca",
		label: "Catalan",
		nativeLabel: "Català"
	},
	{
		value: "zh",
		label: "Chinese",
		nativeLabel: "中文"
	},
	{
		value: "hr",
		label: "Croatian",
		nativeLabel: "Hrvatski"
	},
	{
		value: "cs",
		label: "Czech",
		nativeLabel: "Čeština"
	},
	{
		value: "da",
		label: "Danish",
		nativeLabel: "Dansk"
	},
	{
		value: "nl",
		label: "Dutch",
		nativeLabel: "Nederlands"
	},
	{
		value: "en",
		label: "English",
		nativeLabel: "English"
	},
	{
		value: "et",
		label: "Estonian",
		nativeLabel: "Eesti"
	},
	{
		value: "fi",
		label: "Finnish",
		nativeLabel: "Suomi"
	},
	{
		value: "fr",
		label: "French",
		nativeLabel: "Français"
	},
	{
		value: "gl",
		label: "Galician",
		nativeLabel: "Galego"
	},
	{
		value: "de",
		label: "German",
		nativeLabel: "Deutsch"
	},
	{
		value: "el",
		label: "Greek",
		nativeLabel: "Ελληνικά"
	},
	{
		value: "gu",
		label: "Gujarati",
		nativeLabel: "ગુજરાતી"
	},
	{
		value: "he",
		label: "Hebrew",
		nativeLabel: "עברית"
	},
	{
		value: "hi",
		label: "Hindi",
		nativeLabel: "हिन्दी"
	},
	{
		value: "hu",
		label: "Hungarian",
		nativeLabel: "Magyar"
	},
	{
		value: "id",
		label: "Indonesian",
		nativeLabel: "Bahasa Indonesia"
	},
	{
		value: "it",
		label: "Italian",
		nativeLabel: "Italiano"
	},
	{
		value: "ja",
		label: "Japanese",
		nativeLabel: "日本語"
	},
	{
		value: "kn",
		label: "Kannada",
		nativeLabel: "ಕನ್ನಡ"
	},
	{
		value: "kk",
		label: "Kazakh",
		nativeLabel: "Қазақ тілі"
	},
	{
		value: "ko",
		label: "Korean",
		nativeLabel: "한국어"
	},
	{
		value: "lv",
		label: "Latvian",
		nativeLabel: "Latviešu"
	},
	{
		value: "lt",
		label: "Lithuanian",
		nativeLabel: "Lietuvių"
	},
	{
		value: "mk",
		label: "Macedonian",
		nativeLabel: "Македонски"
	},
	{
		value: "ms",
		label: "Malay",
		nativeLabel: "Bahasa Melayu"
	},
	{
		value: "ml",
		label: "Malayalam",
		nativeLabel: "മലയാളം"
	},
	{
		value: "mr",
		label: "Marathi",
		nativeLabel: "मराठी"
	},
	{
		value: "no",
		label: "Norwegian",
		nativeLabel: "Norsk"
	},
	{
		value: "fa",
		label: "Persian",
		nativeLabel: "فارسی"
	},
	{
		value: "pl",
		label: "Polish",
		nativeLabel: "Polski"
	},
	{
		value: "pt",
		label: "Portuguese",
		nativeLabel: "Português"
	},
	{
		value: "pa",
		label: "Punjabi",
		nativeLabel: "ਪੰਜਾਬੀ"
	},
	{
		value: "ro",
		label: "Romanian",
		nativeLabel: "Română"
	},
	{
		value: "ru",
		label: "Russian",
		nativeLabel: "Русский"
	},
	{
		value: "sr",
		label: "Serbian",
		nativeLabel: "Српски"
	},
	{
		value: "sk",
		label: "Slovak",
		nativeLabel: "Slovenčina"
	},
	{
		value: "sl",
		label: "Slovenian",
		nativeLabel: "Slovenščina"
	},
	{
		value: "es",
		label: "Spanish",
		nativeLabel: "Español"
	},
	{
		value: "sw",
		label: "Swahili",
		nativeLabel: "Kiswahili"
	},
	{
		value: "sv",
		label: "Swedish",
		nativeLabel: "Svenska"
	},
	{
		value: "tl",
		label: "Tagalog",
		nativeLabel: "Tagalog"
	},
	{
		value: "ta",
		label: "Tamil",
		nativeLabel: "தமிழ்"
	},
	{
		value: "te",
		label: "Telugu",
		nativeLabel: "తెలుగు"
	},
	{
		value: "th",
		label: "Thai",
		nativeLabel: "ไทย"
	},
	{
		value: "tr",
		label: "Turkish",
		nativeLabel: "Türkçe"
	},
	{
		value: "uk",
		label: "Ukrainian",
		nativeLabel: "Українська"
	},
	{
		value: "ur",
		label: "Urdu",
		nativeLabel: "اردو"
	},
	{
		value: "vi",
		label: "Vietnamese",
		nativeLabel: "Tiếng Việt"
	},
	{
		value: "cy",
		label: "Welsh",
		nativeLabel: "Cymraeg"
	}
];
var TRANSLATION_FONT_SIZES = [
	"small",
	"medium",
	"large"
];
var TTS_VOICES = [
	"alloy",
	"ash",
	"ballad",
	"coral",
	"echo",
	"fable",
	"nova",
	"onyx",
	"sage",
	"shimmer",
	"verse",
	"marin",
	"cedar"
];
var TTS_MODELS = [
	"gpt-4o-mini-tts",
	"tts-1",
	"tts-1-hd"
];
function isTheirLanguage(value) {
	return value === "none" || isSupportedLanguage(value);
}
var SUPPORTED_LANGUAGE_VALUES = new Set(SUPPORTED_LANGUAGES.map((language) => language.value));
var TRANSLATION_FONT_SIZE_VALUES = new Set(TRANSLATION_FONT_SIZES);
var TTS_VOICE_VALUES = new Set(TTS_VOICES);
var TTS_MODEL_VALUES = new Set(TTS_MODELS);
function isSupportedLanguage(value) {
	return typeof value === "string" && SUPPORTED_LANGUAGE_VALUES.has(value);
}
function isTranslationFontSize(value) {
	return typeof value === "string" && TRANSLATION_FONT_SIZE_VALUES.has(value);
}
function isTTSVoice(value) {
	return typeof value === "string" && TTS_VOICE_VALUES.has(value);
}
function isTTSModel(value) {
	return typeof value === "string" && TTS_MODEL_VALUES.has(value);
}
var DEFAULT_SETTINGS = {
	apiKey: "",
	targetLanguage: "vi",
	theirLanguage: "en",
	microphoneEnabled: false,
	speakerNames: [],
	translationFontSize: "medium",
	narrationEnabled: false,
	narrateMyVoice: false,
	sendMyTranslationViaChat: false,
	narrateAllSpeakers: false,
	openaiApiKey: "",
	openaiAssistantModel: "gpt-4.1-mini",
	openaiAssistantExplainPrompt: ["Explain the focus sentence."].join(" "),
	openaiAssistantQAPrompt: ["Give me 3 possible answers to the focus question"].join(" "),
	openaiAssistantChatPrompt: [
		"You are my inline conversation assistant for a live translation session.",
		"Answer the user's question based on the full transcript context provided.",
		"Use web search tool when useful for factual, time-sensitive, or domain-specific details.",
		"Be concise and helpful. Respond in \"{{targetLanguage}}\"."
	].join(" "),
	ttsVoice: "coral",
	ttsModel: "gpt-4o-mini-tts",
	voiceSpeed: 60,
	voiceVolume: 100,
	originalVolume: 20,
	autoSyncSpeed: true,
	ttsProvider: "openai",
	googleVoiceId: "en",
	savedContexts: []
};
var EXTENSION_HOMEPAGE = "https://translate.ezitech.io";
function normalizeSpeakerNames(speakerNames, minimumSlots = 10) {
	const safeMinimum = Number.isFinite(minimumSlots) ? Math.max(0, Math.floor(minimumSlots)) : 10;
	const normalized = Array.isArray(speakerNames) ? speakerNames.map((name) => typeof name === "string" ? name.trim() : "") : [];
	while (normalized.length < safeMinimum) normalized.push("");
	return normalized;
}
function extractSpeakerIndex(speakerId) {
	if (!speakerId) return null;
	const trimmed = speakerId.trim();
	if (!trimmed) return null;
	const match = trimmed.match(/(\d+)/);
	if (!match) return null;
	const parsed = Number.parseInt(match[1] ?? "", 10);
	if (!Number.isFinite(parsed) || parsed <= 0) return null;
	return parsed;
}
function resolveSpeakerLabel(speakerId, speakerNames, speakerPrefixLabel, fallbackLabel) {
	const speakerIndex = extractSpeakerIndex(speakerId);
	if (speakerIndex !== null) {
		const customName = speakerNames[speakerIndex - 1]?.trim();
		if (customName) return customName;
		return `${speakerPrefixLabel} ${speakerIndex}`;
	}
	return fallbackLabel;
}
//#endregion
//#region src/stores/settings-store.ts
var STORAGE_KEY = "translatorSettings";
function normalizeSavedContexts(input) {
	if (!Array.isArray(input)) return [];
	return input.map((item) => {
		if (!item || typeof item !== "object") return null;
		const raw = item;
		if (typeof raw.id !== "string" || typeof raw.name !== "string" || typeof raw.domain !== "string" || typeof raw.topic !== "string" || typeof raw.terms !== "string" || typeof raw.speakers !== "string") return null;
		return {
			id: raw.id,
			name: raw.name,
			domain: raw.domain,
			topic: raw.topic,
			terms: raw.terms,
			speakers: raw.speakers,
			savedAt: typeof raw.savedAt === "number" ? raw.savedAt : Date.now()
		};
	}).filter((ctx) => Boolean(ctx)).sort((a, b) => b.savedAt - a.savedAt);
}
var useSettingsStore = defineStore("settings", () => {
	const apiKey = ref(DEFAULT_SETTINGS.apiKey);
	const targetLanguage = ref(DEFAULT_SETTINGS.targetLanguage);
	const theirLanguage = ref(DEFAULT_SETTINGS.theirLanguage ?? "en");
	const microphoneEnabled = ref(DEFAULT_SETTINGS.microphoneEnabled ?? false);
	const speakerNames = ref(normalizeSpeakerNames(DEFAULT_SETTINGS.speakerNames));
	const translationFontSize = ref(DEFAULT_SETTINGS.translationFontSize ?? "medium");
	const narrationEnabled = ref(DEFAULT_SETTINGS.narrationEnabled ?? false);
	const narrateMyVoice = ref(DEFAULT_SETTINGS.narrateMyVoice ?? false);
	const sendMyTranslationViaChat = ref(DEFAULT_SETTINGS.sendMyTranslationViaChat ?? false);
	const narrateAllSpeakers = ref(DEFAULT_SETTINGS.narrateAllSpeakers ?? false);
	const openaiApiKey = ref(DEFAULT_SETTINGS.openaiApiKey ?? "");
	const openaiAssistantModel = ref(DEFAULT_SETTINGS.openaiAssistantModel ?? "gpt-4.1-mini");
	const openaiAssistantChatPrompt = ref(DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "");
	const ttsVoice = ref(DEFAULT_SETTINGS.ttsVoice ?? "coral");
	const ttsModel = ref(DEFAULT_SETTINGS.ttsModel ?? "gpt-4o-mini-tts");
	const voiceSpeed = ref(DEFAULT_SETTINGS.voiceSpeed ?? 60);
	const voiceVolume = ref(DEFAULT_SETTINGS.voiceVolume ?? 100);
	const originalVolume = ref(DEFAULT_SETTINGS.originalVolume ?? 20);
	const autoSyncSpeed = ref(DEFAULT_SETTINGS.autoSyncSpeed ?? true);
	const ttsProvider = ref(DEFAULT_SETTINGS.ttsProvider ?? "openai");
	const googleVoiceId = ref(DEFAULT_SETTINGS.googleVoiceId ?? "en");
	const subtitleFontSize = ref(DEFAULT_SETTINGS.subtitleFontSize ?? "medium");
	const subtitleOpacity = ref(DEFAULT_SETTINGS.subtitleOpacity ?? 75);
	const savedContexts = ref(normalizeSavedContexts(DEFAULT_SETTINGS.savedContexts));
	const isLoaded = ref(false);
	async function loadSettings() {
		try {
			const result = await chrome.storage.local.get(STORAGE_KEY);
			const legacySavedContexts = normalizeSavedContexts((await chrome.storage.local.get("savedContexts")).savedContexts);
			const stored = result[STORAGE_KEY];
			if (stored) {
				apiKey.value = stored.apiKey ?? DEFAULT_SETTINGS.apiKey;
				targetLanguage.value = isSupportedLanguage(stored.targetLanguage) ? stored.targetLanguage : DEFAULT_SETTINGS.targetLanguage;
				theirLanguage.value = isTheirLanguage(stored.theirLanguage) ? stored.theirLanguage : DEFAULT_SETTINGS.theirLanguage ?? "en";
				microphoneEnabled.value = stored.microphoneEnabled ?? DEFAULT_SETTINGS.microphoneEnabled ?? false;
				speakerNames.value = normalizeSpeakerNames(stored.speakerNames);
				translationFontSize.value = isTranslationFontSize(stored.translationFontSize) ? stored.translationFontSize : DEFAULT_SETTINGS.translationFontSize ?? "medium";
				narrationEnabled.value = stored.narrationEnabled ?? DEFAULT_SETTINGS.narrationEnabled ?? false;
				narrateMyVoice.value = stored.narrateMyVoice ?? DEFAULT_SETTINGS.narrateMyVoice ?? false;
				sendMyTranslationViaChat.value = stored.sendMyTranslationViaChat ?? DEFAULT_SETTINGS.sendMyTranslationViaChat ?? false;
				narrateAllSpeakers.value = stored.narrateAllSpeakers ?? DEFAULT_SETTINGS.narrateAllSpeakers ?? false;
				openaiApiKey.value = stored.openaiApiKey ?? DEFAULT_SETTINGS.openaiApiKey ?? "";
				openaiAssistantModel.value = stored.openaiAssistantModel ?? DEFAULT_SETTINGS.openaiAssistantModel ?? "gpt-4.1-mini";
				openaiAssistantChatPrompt.value = stored.openaiAssistantChatPrompt ?? DEFAULT_SETTINGS.openaiAssistantChatPrompt ?? "";
				ttsVoice.value = isTTSVoice(stored.ttsVoice) ? stored.ttsVoice : DEFAULT_SETTINGS.ttsVoice ?? "coral";
				ttsModel.value = isTTSModel(stored.ttsModel) ? stored.ttsModel : DEFAULT_SETTINGS.ttsModel ?? "gpt-4o-mini-tts";
				voiceSpeed.value = typeof stored.voiceSpeed === "number" ? stored.voiceSpeed : DEFAULT_SETTINGS.voiceSpeed ?? 60;
				voiceVolume.value = typeof stored.voiceVolume === "number" ? stored.voiceVolume : DEFAULT_SETTINGS.voiceVolume ?? 100;
				originalVolume.value = typeof stored.originalVolume === "number" ? stored.originalVolume : DEFAULT_SETTINGS.originalVolume ?? 20;
				autoSyncSpeed.value = stored.autoSyncSpeed ?? DEFAULT_SETTINGS.autoSyncSpeed ?? true;
				ttsProvider.value = stored.ttsProvider === "google" ? "google" : "openai";
				googleVoiceId.value = stored.googleVoiceId ?? DEFAULT_SETTINGS.googleVoiceId ?? "en";
				subtitleFontSize.value = isTranslationFontSize(stored.subtitleFontSize) ? stored.subtitleFontSize : DEFAULT_SETTINGS.subtitleFontSize ?? "small";
				subtitleOpacity.value = typeof stored.subtitleOpacity === "number" ? stored.subtitleOpacity : DEFAULT_SETTINGS.subtitleOpacity ?? 25;
				const normalizedSavedContexts = normalizeSavedContexts(stored.savedContexts);
				savedContexts.value = normalizedSavedContexts.length > 0 ? normalizedSavedContexts : legacySavedContexts;
			} else if (legacySavedContexts.length > 0) savedContexts.value = legacySavedContexts;
		} catch {} finally {
			isLoaded.value = true;
		}
	}
	async function saveSettings() {
		try {
			const settings = {
				apiKey: apiKey.value,
				targetLanguage: targetLanguage.value,
				theirLanguage: theirLanguage.value,
				microphoneEnabled: microphoneEnabled.value,
				speakerNames: [...speakerNames.value],
				translationFontSize: translationFontSize.value,
				narrationEnabled: narrationEnabled.value,
				narrateMyVoice: narrateMyVoice.value,
				sendMyTranslationViaChat: sendMyTranslationViaChat.value,
				narrateAllSpeakers: narrateAllSpeakers.value,
				openaiApiKey: openaiApiKey.value,
				openaiAssistantModel: openaiAssistantModel.value,
				openaiAssistantChatPrompt: openaiAssistantChatPrompt.value,
				ttsVoice: ttsVoice.value,
				ttsModel: ttsModel.value,
				voiceSpeed: voiceSpeed.value,
				voiceVolume: voiceVolume.value,
				originalVolume: originalVolume.value,
				autoSyncSpeed: autoSyncSpeed.value,
				ttsProvider: ttsProvider.value,
				googleVoiceId: googleVoiceId.value,
				subtitleFontSize: subtitleFontSize.value,
				subtitleOpacity: subtitleOpacity.value,
				savedContexts: savedContexts.value.map((ctx) => ({ ...ctx }))
			};
			await chrome.storage.local.set({ [STORAGE_KEY]: settings });
		} catch {}
	}
	let debounceTimer = null;
	function debouncedSave() {
		if (debounceTimer) clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => {
			saveSettings();
		}, 500);
	}
	watch([
		apiKey,
		targetLanguage,
		theirLanguage,
		microphoneEnabled,
		translationFontSize,
		narrationEnabled,
		narrateMyVoice,
		sendMyTranslationViaChat,
		narrateAllSpeakers,
		openaiApiKey,
		openaiAssistantModel,
		openaiAssistantChatPrompt,
		ttsVoice,
		ttsModel,
		voiceSpeed,
		voiceVolume,
		originalVolume,
		autoSyncSpeed,
		ttsProvider,
		googleVoiceId,
		subtitleFontSize,
		subtitleOpacity,
		savedContexts
	], () => {
		if (isLoaded.value) debouncedSave();
	});
	function setSpeakerNames(names) {
		speakerNames.value = normalizeSpeakerNames(names, Math.max(names.length, 10));
	}
	return {
		apiKey,
		targetLanguage,
		theirLanguage,
		microphoneEnabled,
		speakerNames,
		translationFontSize,
		narrationEnabled,
		narrateMyVoice,
		sendMyTranslationViaChat,
		narrateAllSpeakers,
		openaiApiKey,
		openaiAssistantModel,
		openaiAssistantChatPrompt,
		ttsVoice,
		ttsModel,
		voiceSpeed,
		voiceVolume,
		originalVolume,
		autoSyncSpeed,
		ttsProvider,
		googleVoiceId,
		subtitleFontSize,
		subtitleOpacity,
		savedContexts,
		isLoaded,
		setSpeakerNames,
		loadSettings,
		saveSettings
	};
});
//#endregion
export { EXTENSION_HOMEPAGE as a, DEFAULT_SETTINGS as i, normalizeSpeakerNames as n, SUPPORTED_LANGUAGES as o, resolveSpeakerLabel as r, TTS_VOICES as s, useSettingsStore as t };
