"use strict";
(() => {
  // node_modules/@quasar/app-vite/exports/bex/private/bex-bridge.js
  var portNameRE = /^background$|^app$|^content@/;
  var { runtime } = false ? browser : chrome;
  function getRandomId(max) {
    return Math.floor(Math.random() * max);
  }
  var BexBridge = class {
    // Public properties
    /** @type {string} */
    portName = null;
    /** @type {boolean} */
    isConnected = false;
    /** @type {{ type: 'on' | 'once', callback: (message: Message) => void }[]} */
    listeners = {};
    /** @type {{ [portName: string]: chrome.runtime.Port }} */
    portMap = {};
    /** @type {string[]} */
    portList = [];
    /** @type {{ [id: string]: { portName: string, resolve: (payload: any) => void, reject: (err: any) => void } }} */
    messageMap = {};
    /** @type {{ [id: string]: { portName: string, number: number, messageType: string, messageProps: any, payload: any[] } }} */
    chunkMap = {};
    // Private properties
    /** @type {'background' | 'content' | 'app'} */
    #type;
    /** @type {boolean} */
    #debug = false;
    /** @type {string} */
    #banner;
    /**
     * @param {{ type: 'background' | 'content' | 'app', name?: string, debug?: boolean }} options
     */
    constructor({ type, name = "", debug }) {
      this.portName = type;
      this.#type = type;
      if (type === "content") {
        this.portName = `${type}@${name}-${getRandomId(1e4)}`;
      }
      this.#banner = `[QBex|${this.portName}]`;
      this.#debug = debug === true;
      if (type !== "background") {
        this.on("@quasar:ports", ({ payload }) => {
          this.portList = payload.portList;
          if (payload.removed !== void 0) {
            this.#cleanupPort(payload.removed);
          }
        });
        return;
      }
      this.isConnected = true;
      const onPacket = this.#onPacket.bind(this);
      runtime.onConnect.addListener((port) => {
        if (portNameRE.test(port.name) === false) return;
        if (this.portMap[port.name] !== void 0) {
          this.warn(
            `Connection with "${port.name}" already exists. Disconnecting the previous one and connecting the new one.`
          );
          this.portMap[port.name].disconnect();
          this.#cleanupPort(port.name);
        }
        this.portMap[port.name] = port;
        port.onMessage.addListener(onPacket);
        port.onDisconnect.addListener(() => {
          port.onMessage.removeListener(onPacket);
          this.#cleanupPort(port.name);
          this.log(`Closed connection with ${port.name}.`);
          this.#onPortChange({ removed: port.name });
        });
        this.log(`Opened connection with ${port.name}.`);
        this.#onPortChange({ added: port.name });
      });
    }
    /**
     * @returns {Promise<void>}
     */
    connectToBackground() {
      if (this.#type === "background") {
        return Promise.reject("The background script itself does not need to connect");
      }
      if (this.isConnected === true) {
        return Promise.reject("The bridge is already connected");
      }
      const portToBackground = runtime.connect({ name: this.portName });
      return new Promise((resolve, reject) => {
        const onPacket = (packet) => {
          if (this.isConnected === false) {
            this.isConnected = true;
            this.log("Connected to the background script.");
            this.portMap = { background: portToBackground };
            resolve();
          }
          this.#onPacket(packet);
        };
        const onDisconnect = () => {
          if (runtime.lastError?.message?.indexOf("Could not establish connection") !== -1) {
            this.isConnected = false;
            portToBackground.onMessage.removeListener(onPacket);
            portToBackground.onMessage.removeListener(onDisconnect);
            reject("Could not connect to the background script.");
            return;
          }
          this.isConnected = false;
          for (const id in this.messageMap) {
            const item = this.messageMap[id];
            item.reject("Connection was closed");
          }
          this.portMap = {};
          this.portList = [];
          this.messageMap = {};
          this.chunkMap = {};
          this.log("Closed connection with the background script.");
        };
        portToBackground.onMessage.addListener(onPacket);
        portToBackground.onDisconnect.addListener(onDisconnect);
      });
    }
    /**
     * @returns {Promise<void>}
     */
    disconnectFromBackground() {
      if (this.#type === "background") {
        return Promise.reject("Background script does not need to disconnect");
      }
      if (this.isConnected === false) {
        return Promise.reject("Tried to disconnect from the background script but the port was not connected");
      }
      this.portMap.background.disconnect();
      delete this.portMap.background;
      this.isConnected = false;
      return Promise.resolve();
    }
    /**
     * @param {string} event
     * @param {(message: Message) => void} callback
     */
    on(event, callback) {
      if (!event) {
        this.warn("Tried add listener but no event specified.");
        return;
      }
      if (typeof callback !== "function") {
        this.warn("Tried add listener but no valid callback function specified.");
        return;
      }
      const target = this.listeners[event] || (this.listeners[event] = []);
      target.push({ type: "on", callback });
      this.log(`Added a listener for event: "${event}".`);
    }
    /**
     * @param {string} event
     * @param {(message: Message) => void} callback
     */
    once(event, callback) {
      if (!event) {
        this.warn("Tried add listener but no event specified.");
        return;
      }
      if (typeof callback !== "function") {
        this.warn("Tried add listener but no valid callback function specified.");
        return;
      }
      const target = this.listeners[event] || (this.listeners[event] = []);
      target.push({ type: "once", callback });
      this.log(`Added a one-time listener for event: "${event}".`);
    }
    /**
     * @param {string} event
     * @param {(message: Message) => void} callback
     */
    off(event, callback) {
      if (!event) {
        this.warn("Tried to remove listeners but no event specified.");
        return;
      }
      const list = this.listeners[event];
      if (list === void 0) {
        this.warn(`Tried to remove listener for "${event}" event but there is no such listener attached.`);
        return;
      }
      if (callback === void 0) {
        if (event.startsWith("@quasar:")) {
          this.listeners[event] = [list[0]];
        } else {
          delete this.listeners[event];
        }
        this.log(`Stopped listening for "${event}".`);
        return;
      }
      if (typeof callback !== "function") {
        this.warn("Tried to remove listener but the callback specified is not a function.");
        return;
      }
      const liveEvents = list.filter((entry) => entry.callback !== callback);
      if (liveEvents.length !== 0) {
        this.listeners[event] = liveEvents;
        this.log(`Removed a listener for: "${event}".`);
      } else {
        delete this.listeners[event];
        this.log(`Stopped listening for: "${event}".`);
      }
    }
    /**
     * @param {{ event: string, to: string, payload: any } | undefined} param
     * @returns {Promise<any>} response payload
     */
    async send({ event, to, payload } = {}) {
      if (this.isConnected === false) {
        throw new Error("Tried to send message but the bridge is not connected. Please connect it first.");
      }
      if (!event) {
        throw new Error('Tried to send message with no "event" prop specified');
      }
      if (!to) {
        throw new Error('Tried to send message with no "to" prop specified');
      }
      if (this.portList.includes(to) === false) {
        throw new Error(
          this.#type === "background" ? `Tried to send message to "${to}" but there is no such port registered` : `Tried to send message to "${to}" but the port to background is not available to send through`
        );
      }
      const id = getRandomId(1e6);
      await this.#sendMessage({
        id,
        to,
        payload,
        messageType: "event-send",
        messageProps: { event }
      });
      if (this.portList.includes(to) === false) {
        throw new Error(`Connection to "${to}" was closed while waiting for a response`);
      }
      return new Promise((resolve, reject) => {
        this.messageMap[id] = {
          portName: to,
          resolve: (responsePayload) => {
            delete this.messageMap[id];
            resolve(responsePayload);
          },
          reject: (err) => {
            delete this.messageMap[id];
            reject(err);
          }
        };
      });
    }
    /**
     * @param {boolean} value
     */
    setDebug(value) {
      this.#debug = value === true;
    }
    log(...args) {
      if (this.#debug !== true || args.length === 0) return;
      const lastArg = args[args.length - 1];
      if (lastArg !== void 0 && Object(lastArg) === lastArg) {
        const log = `${this.#banner} ${args.slice(0, -1).join(" ")} (click to expand)`;
        console.groupCollapsed(log);
        console.dir(lastArg);
        console.groupEnd(log);
      } else {
        console.log(this.#banner, ...args);
      }
    }
    warn(...args) {
      if (args.length === 0) return;
      const lastArg = args[args.length - 1];
      if (lastArg !== void 0 && Object(lastArg) === lastArg) {
        console.warn(this.#banner, ...args.slice(0, -1));
        const group = "The above warning details (click to expand)";
        console.groupCollapsed(group);
        console.dir(lastArg);
        console.groupEnd(group);
      } else {
        console.warn(this.#banner, ...args);
      }
    }
    /**
     * Should be used only by the background script
     * @param {{ added?: string } | { removed?: string }} reason
     */
    #onPortChange(reason) {
      this.portList = Object.keys(this.portMap);
      const list = ["background", ...this.portList];
      for (const portName of this.portList) {
        this.send({
          event: "@quasar:ports",
          to: portName,
          payload: {
            portList: list.filter((name) => name !== portName),
            ...reason
          }
        }).catch((err) => {
          this.warn(
            `Failed to inform "${portName}" about the port list.`,
            err
          );
        });
      }
    }
    /**
     * @param {Message} message
     */
    async #triggerMessageEvent(message) {
      const list = this.listeners[message.event];
      if (list === void 0) return;
      const plural = list.length > 1 ? "s" : "";
      this.log(
        `Triggering ${list.length} listener${plural} for event: "${message.event}".`,
        { message, listeners: list }
      );
      let responsePayload;
      for (const { type, callback } of list.slice(0)) {
        if (type === "once") {
          this.off(message.event, callback);
        }
        try {
          if (responsePayload === void 0) {
            const value = callback(message);
            responsePayload = value instanceof Promise ? await value : value;
          } else {
            callback(message);
          }
        } catch (err) {
          this.warn(
            `Error while triggering listener${plural} for event: "${message.event}".`,
            { error: err, message, listener: { type, callback } }
          );
          return Promise.reject(err);
        }
      }
      return responsePayload;
    }
    /**
     * @param {string} portName
     */
    #cleanupPort(portName) {
      for (const id in this.chunkMap) {
        const packet = this.chunkMap[id];
        if (packet.portName === portName) {
          delete this.chunkMap[id];
        }
      }
      for (const id in this.messageMap) {
        const packet = this.messageMap[id];
        if (packet.portName === portName) {
          packet.reject("Connection was closed");
        }
      }
      delete this.portMap[portName];
    }
    #onPacket(packet) {
      if (Object(packet) !== packet || packet.id === void 0 || packet.from === void 0 || packet.to === void 0 || packet.type === void 0) {
        this.log(
          "Received a message that does not appear to be emitted by a Quasar bridge or is malformed.",
          packet
        );
        return;
      }
      this.log(
        `Received message of type "${packet.type}" from "${packet.from}".`,
        packet
      );
      if (packet.to !== this.portName) {
        this.#sendPacket(packet).catch((err) => {
          this.warn(
            `Failed to forward message of type "${packet.type}" from "${packet.from}" to "${packet.to}".`,
            err
          );
          this.#sendMessage({
            id: packet.id,
            to: packet.from,
            messageType: "event-response",
            messageProps: {
              error: {
                message: err.message,
                stack: err.stack || "no stack available"
              },
              quiet: true
            }
          });
        });
        return;
      }
      if (packet.type === "full") {
        this.#onMessage({
          id: packet.id,
          from: packet.from,
          to: packet.to,
          payload: packet.payload,
          type: packet.messageType,
          props: packet.messageProps
        });
        return;
      }
      if (packet.type === "chunk") {
        const chunk = this.chunkMap[packet.id];
        if (chunk === void 0) {
          if (packet.chunkIndex !== void 0) {
            this.warn(
              "Received an unregistered chunk.",
              packet
            );
            return;
          }
          this.chunkMap[packet.id] = {
            portName: packet.from,
            number: packet.chunksNumber,
            messageType: packet.messageType,
            messageProps: packet.messageProps,
            payload: []
          };
          return;
        }
        if (packet.chunkIndex !== chunk.payload.length) {
          this.warn(
            "Received an out of order chunk.",
            packet
          );
          delete this.chunkMap[packet.id];
          return;
        }
        chunk.payload.push(packet.payload);
        if (packet.chunkIndex === chunk.number - 1) {
          delete this.chunkMap[packet.id];
          this.#onMessage({
            id: packet.id,
            from: packet.from,
            to: packet.to,
            payload: chunk.payload,
            type: chunk.messageType,
            props: chunk.messageProps
          });
        }
        return;
      }
      if (packet.type === "chunk-abort") {
        delete this.chunkMap[packet.id];
        return;
      }
      this.warn(
        `Received an unknown message type: "${packet.type}".`
      );
    }
    #sendPacket(packet) {
      this.log(
        packet.from === this.portName ? `Sending message of type "${packet.type}" to "${packet.to}".` : `Forwarding message of type "${packet.type}" from "${packet.from}" to "${packet.to}".`,
        packet
      );
      const port = this.#type === "background" ? this.portMap[packet.to] : this.portMap.background;
      if (this.portList.includes(packet.to) === false) {
        return Promise.reject(
          `Tried to send message of type "${packet.type}" to "${packet.to}" but there is no such port registered`
        );
      }
      if (port === void 0) {
        return Promise.reject(
          this.#type === "background" ? `Tried to send message of type "${packet.type}" to "${packet.to}" but the port is not available` : `Tried to send message of type "${packet.type}" to "${packet.to}" but the port to background is not available to forward through`
        );
      }
      try {
        port.postMessage(packet);
      } catch (err) {
        this.warn(
          `Failed to send message to "${packet.to}".`,
          err
        );
        return Promise.reject(err);
      }
      return Promise.resolve();
    }
    /**
     * @param {{ id?: number, to: string, payload: any, messageType: "event-send" | "event-response", messageProps: any }} param
     */
    #sendMessage({
      id = getRandomId(1e6),
      to,
      payload,
      messageType,
      messageProps
    }) {
      if (Array.isArray(payload) === false) {
        return this.#sendPacket({
          id,
          from: this.portName,
          to,
          type: "full",
          payload,
          messageType,
          messageProps
        });
      }
      let promise = this.#sendPacket({
        id,
        from: this.portName,
        to,
        type: "chunk",
        chunksNumber: payload.length,
        messageType,
        messageProps
      });
      for (let i = 0; i < payload.length; i++) {
        promise = promise.then(() => this.#sendPacket({
          id,
          from: this.portName,
          to,
          type: "chunk",
          payload: payload[i],
          chunkIndex: i
        }));
      }
      return promise.catch((err) => {
        this.#sendPacket({
          id,
          from: this.portName,
          to,
          type: "chunk-abort"
        }).catch((err2) => {
          this.warn(
            `Failed to send a chunk-abort message to "${to}".`,
            err2
          );
        });
        return Promise.reject(err);
      });
    }
    #onMessage(message) {
      if (message.type === "event-response") {
        const target = this.messageMap[message.id];
        if (target === void 0) {
          if (message.props.quiet !== true) {
            this.warn(
              `Received a response for an unknown message id: "${message.id}".`,
              message
            );
          }
          return;
        }
        if (message.props.error !== void 0) {
          target.reject(message.props.error);
        } else {
          target.resolve(message.payload);
        }
        return;
      }
      if (message.type === "event-send") {
        this.#triggerMessageEvent({
          from: message.from,
          to: message.to,
          event: message.props.event,
          payload: message.payload
        }).then((returnPayload) => {
          this.#sendMessage({
            id: message.id,
            to: message.from,
            payload: returnPayload,
            messageType: "event-response",
            messageProps: {}
          });
        }).catch((err) => {
          this.#sendMessage({
            id: message.id,
            to: message.from,
            messageType: "event-response",
            messageProps: {
              error: {
                message: err.message,
                stack: err.stack || "no stack available"
              }
            }
          });
        });
        return;
      }
      this.warn(
        `Received a message with unknown type: "${message.type}".`,
        message
      );
    }
  };

  // node_modules/@quasar/app-vite/exports/bex/background.js
  if (false) {
    const devServerPort = process.env.__QUASAR_BEX_SERVER_PORT__;
    const wsToken = process.env.__QUASAR_BEX_WS_TOKEN__;
    interceptRequests(devServerPort);
    connectToDevServer(devServerPort, wsToken);
  }
  var scriptHasBridge = false;
  function createBridge({ debug } = {}) {
    if (scriptHasBridge === true) {
      console.error("Background Quasar Bridge has already been created.");
      return;
    }
    scriptHasBridge = true;
    return new BexBridge({
      type: "background",
      debug
    });
  }

  // src/types/index.ts
  var SUPPORTED_LANGUAGES = [
    { value: "af", label: "Afrikaans", nativeLabel: "Afrikaans" },
    { value: "sq", label: "Albanian", nativeLabel: "Shqip" },
    { value: "ar", label: "Arabic", nativeLabel: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629" },
    { value: "az", label: "Azerbaijani", nativeLabel: "Az\u0259rbaycan dili" },
    { value: "eu", label: "Basque", nativeLabel: "Euskara" },
    { value: "be", label: "Belarusian", nativeLabel: "\u0411\u0435\u043B\u0430\u0440\u0443\u0441\u043A\u0430\u044F" },
    { value: "bn", label: "Bengali", nativeLabel: "\u09AC\u09BE\u0982\u09B2\u09BE" },
    { value: "bs", label: "Bosnian", nativeLabel: "Bosanski" },
    { value: "bg", label: "Bulgarian", nativeLabel: "\u0411\u044A\u043B\u0433\u0430\u0440\u0441\u043A\u0438" },
    { value: "ca", label: "Catalan", nativeLabel: "Catal\xE0" },
    { value: "zh", label: "Chinese", nativeLabel: "\u4E2D\u6587" },
    { value: "hr", label: "Croatian", nativeLabel: "Hrvatski" },
    { value: "cs", label: "Czech", nativeLabel: "\u010Ce\u0161tina" },
    { value: "da", label: "Danish", nativeLabel: "Dansk" },
    { value: "nl", label: "Dutch", nativeLabel: "Nederlands" },
    { value: "en", label: "English", nativeLabel: "English" },
    { value: "et", label: "Estonian", nativeLabel: "Eesti" },
    { value: "fi", label: "Finnish", nativeLabel: "Suomi" },
    { value: "fr", label: "French", nativeLabel: "Fran\xE7ais" },
    { value: "gl", label: "Galician", nativeLabel: "Galego" },
    { value: "de", label: "German", nativeLabel: "Deutsch" },
    { value: "el", label: "Greek", nativeLabel: "\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC" },
    { value: "gu", label: "Gujarati", nativeLabel: "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0" },
    { value: "he", label: "Hebrew", nativeLabel: "\u05E2\u05D1\u05E8\u05D9\u05EA" },
    { value: "hi", label: "Hindi", nativeLabel: "\u0939\u093F\u0928\u094D\u0926\u0940" },
    { value: "hu", label: "Hungarian", nativeLabel: "Magyar" },
    { value: "id", label: "Indonesian", nativeLabel: "Bahasa Indonesia" },
    { value: "it", label: "Italian", nativeLabel: "Italiano" },
    { value: "ja", label: "Japanese", nativeLabel: "\u65E5\u672C\u8A9E" },
    { value: "kn", label: "Kannada", nativeLabel: "\u0C95\u0CA8\u0CCD\u0CA8\u0CA1" },
    { value: "kk", label: "Kazakh", nativeLabel: "\u049A\u0430\u0437\u0430\u049B \u0442\u0456\u043B\u0456" },
    { value: "ko", label: "Korean", nativeLabel: "\uD55C\uAD6D\uC5B4" },
    { value: "lv", label: "Latvian", nativeLabel: "Latvie\u0161u" },
    { value: "lt", label: "Lithuanian", nativeLabel: "Lietuvi\u0173" },
    { value: "mk", label: "Macedonian", nativeLabel: "\u041C\u0430\u043A\u0435\u0434\u043E\u043D\u0441\u043A\u0438" },
    { value: "ms", label: "Malay", nativeLabel: "Bahasa Melayu" },
    { value: "ml", label: "Malayalam", nativeLabel: "\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02" },
    { value: "mr", label: "Marathi", nativeLabel: "\u092E\u0930\u093E\u0920\u0940" },
    { value: "no", label: "Norwegian", nativeLabel: "Norsk" },
    { value: "fa", label: "Persian", nativeLabel: "\u0641\u0627\u0631\u0633\u06CC" },
    { value: "pl", label: "Polish", nativeLabel: "Polski" },
    { value: "pt", label: "Portuguese", nativeLabel: "Portugu\xEAs" },
    { value: "pa", label: "Punjabi", nativeLabel: "\u0A2A\u0A70\u0A1C\u0A3E\u0A2C\u0A40" },
    { value: "ro", label: "Romanian", nativeLabel: "Rom\xE2n\u0103" },
    { value: "ru", label: "Russian", nativeLabel: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439" },
    { value: "sr", label: "Serbian", nativeLabel: "\u0421\u0440\u043F\u0441\u043A\u0438" },
    { value: "sk", label: "Slovak", nativeLabel: "Sloven\u010Dina" },
    { value: "sl", label: "Slovenian", nativeLabel: "Sloven\u0161\u010Dina" },
    { value: "es", label: "Spanish", nativeLabel: "Espa\xF1ol" },
    { value: "sw", label: "Swahili", nativeLabel: "Kiswahili" },
    { value: "sv", label: "Swedish", nativeLabel: "Svenska" },
    { value: "tl", label: "Tagalog", nativeLabel: "Tagalog" },
    { value: "ta", label: "Tamil", nativeLabel: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD" },
    { value: "te", label: "Telugu", nativeLabel: "\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41" },
    { value: "th", label: "Thai", nativeLabel: "\u0E44\u0E17\u0E22" },
    { value: "tr", label: "Turkish", nativeLabel: "T\xFCrk\xE7e" },
    { value: "uk", label: "Ukrainian", nativeLabel: "\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430" },
    { value: "ur", label: "Urdu", nativeLabel: "\u0627\u0631\u062F\u0648" },
    { value: "vi", label: "Vietnamese", nativeLabel: "Ti\u1EBFng Vi\u1EC7t" },
    { value: "cy", label: "Welsh", nativeLabel: "Cymraeg" }
  ];
  var TRANSLATION_FONT_SIZES = ["small", "medium", "large"];
  var TTS_VOICES = [
    "alloy",
    "ash",
    "ballad",
    "coral",
    "echo",
    "fable",
    "nova",
    "onyx",
    "sage",
    "shimmer",
    "verse",
    "marin",
    "cedar"
  ];
  var TTS_MODELS = ["gpt-4o-mini-tts", "tts-1", "tts-1-hd"];
  var TTS_BROWSER_DEFAULT_VOICE_ID = "default";
  var SUPPORTED_LANGUAGE_VALUES = new Set(SUPPORTED_LANGUAGES.map((language) => language.value));
  var TRANSLATION_FONT_SIZE_VALUES = new Set(TRANSLATION_FONT_SIZES);
  var TTS_VOICE_VALUES = new Set(TTS_VOICES);
  var TTS_MODEL_VALUES = new Set(TTS_MODELS);
  var DEFAULT_SETTINGS = {
    apiKey: "",
    targetLanguage: "vi",
    theirLanguage: "en",
    microphoneEnabled: false,
    speakerNames: [],
    translationFontSize: "medium",
    narrationEnabled: false,
    narrateMyVoice: false,
    sendMyTranslationViaChat: false,
    narrateAllSpeakers: false,
    openaiApiKey: "",
    openaiAssistantModel: "gpt-4.1-mini",
    openaiAssistantExplainPrompt: [
      "Explain the focus sentence."
    ].join(" "),
    openaiAssistantQAPrompt: [
      "Give me 3 possible answers to the focus question"
    ].join(" "),
    openaiAssistantChatPrompt: [
      "You are my inline conversation assistant for a live translation session.",
      "Answer the user's question based on the full transcript context provided.",
      "Use web search tool when useful for factual, time-sensitive, or domain-specific details.",
      'Be concise and helpful. Respond in "{{targetLanguage}}".'
    ].join(" "),
    ttsVoice: "coral",
    ttsModel: "gpt-4o-mini-tts",
    voiceSpeed: 60,
    voiceVolume: 100,
    originalVolume: 20,
    autoSyncSpeed: true,
    ttsProvider: "google",
    googleVoiceId: "vi",
    browserVoiceId: TTS_BROWSER_DEFAULT_VOICE_ID,
    narrateMyVoiceTtsVoice: "coral",
    narrateMyVoiceTtsProvider: "google",
    narrateMyVoiceGoogleVoiceId: "en",
    savedContexts: []
  };
  var PRO_FEATURES = [
    "speaker-names",
    "narration",
    "interpreter-mode",
    "inline-assistant",
    "narrate-my-voice",
    "download-srt"
  ];
  var PRO_FEATURE_SET = new Set(PRO_FEATURES);

  // src-bex/background.ts
  var bridge = createBridge({ debug: false });
  var OFFSCREEN_DOCUMENT_PATH = "www/offscreen-audio.html";
  var OFFSCREEN_DOCUMENT_URL = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  var AUTO_INJECT_PATTERNS = [
    /^https?:\/\/www\.youtube\.com\//,
    /^https?:\/\/meet\.google\.com\//,
    /^https?:\/\/(.*\.)?zoom\.us\//,
    /^https?:\/\/teams\.microsoft\.com\//,
    /^https?:\/\/teams\.live\.com\//,
    /^https?:\/\/(.*\.)?facebook\.com\//,
    /^https?:\/\/(.*\.)?douyin\.com\//,
    /^https?:\/\/(.*\.)?tiktok\.com\//,
    /^https?:\/\/(.*\.)?dailymotion\.com\//,
    /^https?:\/\/(.*\.)?vimeo\.com\//,
    /^https?:\/\/(.*\.)?udemy\.com\//,
    /^https?:\/\/(.*\.)?domestika\.org\//,
    /^https?:\/\/web\.whatsapp\.com\//
  ];
  function isAutoInjectedPage(url) {
    return AUTO_INJECT_PATTERNS.some((p) => p.test(url));
  }
  function getOffscreenApi() {
    const chromeAny = chrome;
    return chromeAny.offscreen ?? null;
  }
  async function hasOffscreenDocument() {
    const runtimeAny = chrome.runtime;
    if (!runtimeAny.getContexts) return false;
    const contexts = await runtimeAny.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [OFFSCREEN_DOCUMENT_URL]
    });
    return contexts.length > 0;
  }
  var ensureOffscreenInFlight = null;
  async function ensureOffscreenDocument() {
    const offscreenApi = getOffscreenApi();
    if (!offscreenApi?.createDocument) {
      console.warn("[TTS:Background] chrome.offscreen is not available in this browser");
      return false;
    }
    if (await hasOffscreenDocument()) return true;
    if (!ensureOffscreenInFlight) {
      ensureOffscreenInFlight = offscreenApi.createDocument({
        url: OFFSCREEN_DOCUMENT_PATH,
        reasons: ["AUDIO_PLAYBACK"],
        justification: "Play OpenAI TTS audio outside captured tab to avoid STT feedback loops"
      }).catch((err) => {
        const message = err instanceof Error ? err.message : String(err);
        console.error("[TTS:Background] Failed creating offscreen document:", message);
        throw err;
      }).finally(() => {
        ensureOffscreenInFlight = null;
      });
    }
    await ensureOffscreenInFlight;
    return hasOffscreenDocument();
  }
  async function sendMessageToOffscreen(message) {
    const ready = await ensureOffscreenDocument();
    if (!ready) return null;
    return await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeErr = chrome.runtime.lastError;
        if (runtimeErr) {
          reject(new Error(runtimeErr.message));
          return;
        }
        resolve(response ?? null);
      });
    });
  }
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.storage.local.get("translatorSettings").then((result) => {
      if (!result.translatorSettings) {
        const defaults = { ...DEFAULT_SETTINGS };
        void chrome.storage.local.set({ translatorSettings: defaults });
      }
    });
  });
  chrome.action.onClicked.addListener((tab) => {
    if (!tab.id || !tab.url) return;
    const tabId = tab.id;
    if (isAutoInjectedPage(tab.url)) {
      const contentPort = bridge.portList.find((name) => name.startsWith("content@"));
      if (contentPort) {
        void bridge.send({ event: "panel.toggle", to: contentPort });
      }
    } else {
      void chrome.scripting.insertCSS({ target: { tabId }, files: ["assets/content.css"] }).then(
        () => chrome.scripting.executeScript({
          target: { tabId },
          files: ["content-script.js"]
        })
      ).then(() => {
        setTimeout(() => {
          const contentPort = bridge.portList.find(
            (name) => name.startsWith("content@")
          );
          if (contentPort) {
            void bridge.send({ event: "panel.toggle", to: contentPort });
          }
        }, 300);
      });
    }
  });
  bridge.on("storage.get", ({ payload: key }) => {
    return new Promise((resolve) => {
      if (key === void 0) {
        chrome.storage.local.get(null, (items) => {
          resolve(Object.values(items));
        });
      } else {
        chrome.storage.local.get([key], (items) => {
          resolve(items[key]);
        });
      }
    });
  });
  bridge.on("storage.set", ({ payload: { key, value } }) => {
    void chrome.storage.local.set({ [key]: value });
  });
  bridge.on("storage.remove", ({ payload: key }) => {
    void chrome.storage.local.remove(key);
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const msg = message;
    if (!msg?.type) return;
    if (msg.type === "tts.play") {
      void (async () => {
        try {
          const response = await sendMessageToOffscreen({
            type: "offscreen.tts.play",
            payload: msg.payload
          });
          if (!response?.ok) {
            sendResponse({ ok: false, error: response?.error ?? "Offscreen playback failed" });
            return;
          }
          sendResponse({ ok: true });
        } catch (err) {
          const messageText = err instanceof Error ? err.message : "Unknown offscreen playback error";
          console.error("[TTS:Background] Failed to play in offscreen document:", messageText);
          sendResponse({ ok: false, error: messageText });
        }
      })();
      return true;
    }
    if (msg.type === "tts.stop") {
      void (async () => {
        try {
          await sendMessageToOffscreen({ type: "offscreen.tts.stop" });
          sendResponse({ ok: true });
        } catch (err) {
          const messageText = err instanceof Error ? err.message : "Unknown offscreen stop error";
          console.error("[TTS:Background] Failed to stop offscreen playback:", messageText);
          sendResponse({ ok: false, error: messageText });
        }
      })();
      return true;
    }
    if (msg.type === "tts.setVolume") {
      void (async () => {
        try {
          await sendMessageToOffscreen({ type: "offscreen.tts.setVolume", volume: msg.volume });
          sendResponse({ ok: true });
        } catch {
          sendResponse({ ok: false });
        }
      })();
      return true;
    }
    if (msg.type === "tts.setPlaybackRate") {
      void (async () => {
        try {
          await sendMessageToOffscreen({
            type: "offscreen.tts.setPlaybackRate",
            playbackRate: msg.playbackRate
          });
          sendResponse({ ok: true });
        } catch {
          sendResponse({ ok: false });
        }
      })();
      return true;
    }
  });
})();
