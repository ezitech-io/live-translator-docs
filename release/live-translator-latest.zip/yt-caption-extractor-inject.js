"use strict";
(() => {
  // src-bex/yt-caption-extractor-inject.ts
  var SOURCE = "live-translator-yt-caption";
  var RELAY_SOURCE = "live-translator-panel-relay";
  var LOG = "[YT-Caption:Inject]";
  var cachedTracks = null;
  var cachedVideoId = null;
  var videoTimeInterval = null;
  var timedTextObserver = null;
  var timedTextUrlByVideo = /* @__PURE__ */ new Map();
  function send(data) {
    window.postMessage({ ...data, source: SOURCE }, "*");
  }
  function getVideoId() {
    return new URLSearchParams(window.location.search).get("v");
  }
  function parseUrl(rawUrl) {
    try {
      return new URL(rawUrl, window.location.origin);
    } catch {
      return null;
    }
  }
  function isTimedTextUrl(rawUrl) {
    const url = parseUrl(rawUrl);
    if (!url) return false;
    return url.pathname === "/api/timedtext";
  }
  function scoreTimedTextUrl(url) {
    const importantParams = [
      "pot",
      "potc",
      "xorb",
      "xobt",
      "xovt",
      "c",
      "cver",
      "cplayer",
      "cplatform",
      "cbr",
      "cbrver",
      "cos",
      "signature",
      "sparams"
    ];
    let score = 0;
    for (const key of importantParams) {
      if (url.searchParams.has(key)) score += 1;
    }
    if (url.searchParams.get("fmt") === "json3") score += 1;
    if (url.searchParams.has("tlang")) score += 1;
    return score;
  }
  function captureTimedTextUrl(rawUrl, source) {
    if (!isTimedTextUrl(rawUrl)) return;
    const parsed = parseUrl(rawUrl);
    if (!parsed) return;
    const videoId = parsed.searchParams.get("v") ?? getVideoId();
    if (!videoId) return;
    const score = scoreTimedTextUrl(parsed);
    const existing = timedTextUrlByVideo.get(videoId);
    if (existing && existing.score > score) return;
    timedTextUrlByVideo.set(videoId, { url: parsed.toString(), score });
    console.debug(LOG, "captured timedtext URL template", {
      source,
      videoId,
      score,
      hasPot: parsed.searchParams.has("pot"),
      hasPotc: parsed.searchParams.has("potc"),
      hasXorb: parsed.searchParams.has("xorb"),
      hasClientContext: parsed.searchParams.has("c") && parsed.searchParams.has("cver"),
      preview: parsed.toString().slice(0, 220)
    });
  }
  function startTimedTextCapture() {
    const existingResources = performance.getEntriesByType("resource");
    for (const entry of existingResources) {
      captureTimedTextUrl(entry.name, "performance-buffered");
    }
    if (!("PerformanceObserver" in window)) {
      console.warn(LOG, "PerformanceObserver unavailable; cannot capture native timedtext URLs");
      return;
    }
    try {
      timedTextObserver?.disconnect();
      timedTextObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        for (const entry of entries) {
          captureTimedTextUrl(entry.name, "performance-observer");
        }
      });
      timedTextObserver.observe({ type: "resource", buffered: true });
      console.debug(LOG, "timedtext URL capture started");
    } catch {
      try {
        timedTextObserver?.disconnect();
        timedTextObserver = new PerformanceObserver((list) => {
          const entries = list.getEntries();
          for (const entry of entries) {
            captureTimedTextUrl(entry.name, "performance-observer-legacy");
          }
        });
        timedTextObserver.observe({ entryTypes: ["resource"] });
        console.debug(LOG, "timedtext URL capture started (legacy mode)");
      } catch (error) {
        console.warn(LOG, "failed to start timedtext URL capture", {
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
  }
  function upsertQueryParam(url, key, value) {
    const encodedValue = encodeURIComponent(value);
    const regex = new RegExp(`([?&])${key}=([^&]*)`);
    if (regex.test(url)) {
      return url.replace(regex, `$1${key}=${encodedValue}`);
    }
    return `${url}${url.includes("?") ? "&" : "?"}${key}=${encodedValue}`;
  }
  function buildTrackBaseUrl(baseUrl, sourceLang, targetLang) {
    let url = baseUrl;
    if (sourceLang) url = upsertQueryParam(url, "lang", sourceLang);
    if (targetLang) url = upsertQueryParam(url, "tlang", targetLang);
    url = upsertQueryParam(url, "fmt", "json3");
    return url;
  }
  function buildTimedTextTemplateUrl(sourceLang, targetLang) {
    const videoId = getVideoId();
    if (!videoId) return null;
    const captured = timedTextUrlByVideo.get(videoId);
    if (!captured?.url) return null;
    let url = captured.url;
    if (sourceLang) url = upsertQueryParam(url, "lang", sourceLang);
    if (targetLang) url = upsertQueryParam(url, "tlang", targetLang);
    url = upsertQueryParam(url, "fmt", "json3");
    return url;
  }
  function getPlayerResponse() {
    const w = window;
    const initial = w.ytInitialPlayerResponse;
    if (initial?.captions) {
      console.debug(LOG, "playerResponse found via ytInitialPlayerResponse");
      return initial;
    }
    try {
      const player = document.getElementById("movie_player");
      if (player?.getPlayerResponse) {
        const resp = player.getPlayerResponse();
        if (resp?.captions) {
          console.debug(LOG, "playerResponse found via movie_player.getPlayerResponse()");
          return resp;
        }
      }
    } catch {
    }
    try {
      const flexy = document.querySelector("ytd-watch-flexy");
      if (flexy?.__data?.playerResponse?.captions) {
        console.debug(LOG, "playerResponse found via ytd-watch-flexy.__data");
        return flexy.__data.playerResponse;
      }
    } catch {
    }
    console.debug(LOG, "playerResponse not found via any strategy");
    return null;
  }
  function extractCaptionTracks(playerResponse) {
    const captions = playerResponse.captions;
    const renderer = captions?.playerCaptionsTracklistRenderer;
    if (!renderer) return { tracks: [], translationLanguages: [] };
    const rawTracks = renderer.captionTracks;
    const tracks = (rawTracks ?? []).map((t) => {
      const nameObj = t.name;
      const langCode = typeof t.languageCode === "string" ? t.languageCode : "";
      const baseUrlStr = typeof t.baseUrl === "string" ? t.baseUrl : "";
      const name = nameObj?.simpleText ?? nameObj?.runs?.[0]?.text ?? langCode;
      return {
        languageCode: langCode,
        languageName: name,
        kind: t.kind === "asr" ? "asr" : "manual",
        isTranslatable: Boolean(t.isTranslatable),
        baseUrl: baseUrlStr
      };
    });
    const rawLangs = renderer.translationLanguages;
    const translationLanguages = (rawLangs ?? []).map((l) => l.languageCode);
    return { tracks, translationLanguages };
  }
  var HTML_ENTITY_MAP = {
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">",
    "&quot;": '"',
    "&#39;": "'",
    "&apos;": "'",
    "&#x27;": "'",
    "&#x2F;": "/"
  };
  function decodeHtmlEntities(text) {
    return text.replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code))).replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => String.fromCharCode(parseInt(hex, 16))).replace(/&\w+;/g, (entity) => HTML_ENTITY_MAP[entity] ?? entity);
  }
  function parseJson3(payload) {
    if (!payload || typeof payload !== "object") return [];
    const json = payload;
    const events = json.events;
    if (!Array.isArray(events)) return [];
    const segments = [];
    for (const event of events) {
      const segs = event.segs;
      if (!segs?.length) continue;
      const text = segs.map((s) => s.utf8 ?? "").join("").trim();
      if (!text) continue;
      segments.push({
        text: decodeHtmlEntities(text),
        startMs: typeof event.tStartMs === "number" ? event.tStartMs : 0,
        durationMs: typeof event.dDurationMs === "number" ? event.dDurationMs : 4e3
      });
    }
    return segments;
  }
  function parseXmlCaptions(xmlText) {
    const segments = [];
    const textNodeRegex = /<text\b([^>]*)>([\s\S]*?)<\/text>/g;
    let match = textNodeRegex.exec(xmlText);
    while (match) {
      const attrs = match[1] ?? "";
      const body = match[2] ?? "";
      const startMatch = attrs.match(/\bstart="([^"]+)"/);
      const durMatch = attrs.match(/\bdur="([^"]+)"/);
      const startSec = Number.parseFloat(startMatch?.[1] ?? "0");
      const durSec = Number.parseFloat(durMatch?.[1] ?? "0");
      const cleanText = decodeHtmlEntities(body).replace(/<[^>]+>/g, "").trim();
      if (cleanText) {
        segments.push({
          text: cleanText,
          startMs: Number.isFinite(startSec) ? Math.round(startSec * 1e3) : 0,
          durationMs: Number.isFinite(durSec) && durSec > 0 ? Math.round(durSec * 1e3) : 4e3
        });
      }
      match = textNodeRegex.exec(xmlText);
    }
    return segments;
  }
  async function fetchCaptions(baseUrl, targetLang, sourceLang) {
    const templateUrl = buildTimedTextTemplateUrl(sourceLang, targetLang);
    const baseTrackUrl = buildTrackBaseUrl(baseUrl, sourceLang, targetLang);
    const attempts = [];
    if (templateUrl) attempts.push({ label: "captured-template", url: templateUrl });
    attempts.push({ label: "track-base", url: baseTrackUrl });
    const uniqueAttempts = attempts.filter(
      (attempt, index, arr) => arr.findIndex((item) => item.url === attempt.url) === index
    );
    console.debug(LOG, "fetchCaptions: prepared request attempts", {
      sourceLang,
      targetLang,
      attemptCount: uniqueAttempts.length,
      attempts: uniqueAttempts.map((a) => ({
        label: a.label,
        hasPot: a.url.includes("pot="),
        hasPotc: a.url.includes("potc="),
        hasXorb: a.url.includes("xorb="),
        hasClientContext: a.url.includes("c=") && a.url.includes("cver="),
        preview: a.url.slice(0, 220)
      }))
    });
    for (const attempt of uniqueAttempts) {
      console.debug(LOG, "fetchCaptions: request start", {
        attempt: attempt.label,
        urlPreview: attempt.url.slice(0, 220),
        urlLength: attempt.url.length
      });
      const resp = await fetch(attempt.url, { credentials: "include" });
      console.debug(LOG, "fetchCaptions: response meta", {
        attempt: attempt.label,
        ok: resp.ok,
        status: resp.status,
        statusText: resp.statusText,
        contentType: resp.headers.get("content-type"),
        responseUrlPreview: resp.url.slice(0, 220)
      });
      if (!resp.ok) {
        console.warn(LOG, "fetchCaptions HTTP error", {
          attempt: attempt.label,
          status: resp.status,
          statusText: resp.statusText
        });
        continue;
      }
      const raw = await resp.text();
      console.debug(LOG, "fetchCaptions: raw response received", {
        attempt: attempt.label,
        bytes: raw.length,
        startsWith: raw.slice(0, 20),
        preview: raw.slice(0, 220)
      });
      let json = null;
      try {
        json = JSON.parse(raw);
        const jsonKeys = json && typeof json === "object" ? Object.keys(json) : [];
        const eventCount = json && typeof json === "object" && Array.isArray(json.events) ? json.events.length : null;
        console.debug(LOG, "fetchCaptions: JSON parse success", {
          attempt: attempt.label,
          jsonType: typeof json,
          jsonKeys: jsonKeys.slice(0, 10),
          hasEventsArray: eventCount !== null,
          eventCount
        });
      } catch {
        console.debug(LOG, "fetchCaptions: JSON parse failed, trying XML fallback", { attempt: attempt.label });
      }
      const jsonSegments = parseJson3(json);
      if (jsonSegments.length > 0) {
        console.info(LOG, "fetchCaptions: parsed JSON3 segments", {
          attempt: attempt.label,
          count: jsonSegments.length,
          sample: jsonSegments.slice(0, 2).map((s) => ({ startMs: s.startMs, text: s.text.slice(0, 80) }))
        });
        return jsonSegments;
      }
      const xmlSegments = parseXmlCaptions(raw);
      if (xmlSegments.length > 0) {
        console.info(LOG, "fetchCaptions: parsed XML segments (reference-style fallback)", {
          attempt: attempt.label,
          count: xmlSegments.length,
          sample: xmlSegments.slice(0, 2).map((s) => ({ startMs: s.startMs, text: s.text.slice(0, 80) }))
        });
        return xmlSegments;
      }
      console.warn(LOG, "fetchCaptions: parsed 0 segments in this attempt", {
        attempt: attempt.label,
        targetLang,
        rawPreview: raw.slice(0, 220)
      });
    }
    console.warn(LOG, "fetchCaptions: all attempts failed to parse segments", { sourceLang, targetLang });
    return [];
  }
  function startVideoTimeMonitor() {
    stopVideoTimeMonitor();
    videoTimeInterval = setInterval(() => {
      const video = document.querySelector("video.html5-main-video, video");
      if (!video) return;
      send({
        type: "VIDEO_TIME_UPDATE",
        currentTimeMs: Math.round(video.currentTime * 1e3),
        state: video.paused ? "paused" : "playing"
      });
    }, 250);
  }
  function stopVideoTimeMonitor() {
    if (videoTimeInterval) {
      clearInterval(videoTimeInterval);
      videoTimeInterval = null;
    }
  }
  function preloadTracks() {
    const vid = getVideoId();
    if (!vid) {
      console.debug(LOG, "preloadTracks: no video ID in URL, skipping");
      return;
    }
    console.debug(LOG, "preloadTracks: starting for video", vid);
    let attemptNum = 0;
    const attempt = () => {
      attemptNum++;
      const pr = getPlayerResponse();
      if (!pr) {
        console.debug(LOG, `preloadTracks: attempt ${attemptNum} \u2014 playerResponse not available yet`);
        return false;
      }
      const { tracks, translationLanguages } = extractCaptionTracks(pr);
      cachedTracks = tracks;
      cachedVideoId = vid;
      console.info(LOG, `preloadTracks: success on attempt ${attemptNum}`, {
        videoId: vid,
        trackCount: tracks.length,
        tracks: tracks.map((t) => `${t.languageCode} (${t.kind}, translatable=${t.isTranslatable})`),
        translationLanguageCount: translationLanguages.length
      });
      send({ type: "CAPTION_TRACKS_PRELOADED", tracks, videoId: vid, translationLanguages });
      return true;
    };
    if (!attempt()) {
      setTimeout(() => {
        if (!cachedTracks) attempt();
      }, 1500);
      setTimeout(() => {
        if (!cachedTracks) {
          const ok = attempt();
          if (!ok) console.warn(LOG, "preloadTracks: all 3 attempts failed for video", vid);
        }
      }, 4e3);
    }
  }
  function handleNavigate() {
    console.debug(LOG, "yt-navigate-start: clearing cached tracks");
    cachedTracks = null;
    cachedVideoId = null;
    stopVideoTimeMonitor();
  }
  document.addEventListener("yt-navigate-start", handleNavigate);
  document.addEventListener("yt-navigate-finish", () => {
    console.debug(LOG, "yt-navigate-finish: scheduling preload");
    setTimeout(preloadTracks, 600);
  });
  console.info(LOG, "inject script loaded");
  startTimedTextCapture();
  preloadTracks();
  window.addEventListener("message", (event) => {
    const data = event.data;
    if (!data || data.source !== RELAY_SOURCE) return;
    switch (data.type) {
      case "REQUEST_CAPTION_TRACKS": {
        const vid = getVideoId();
        console.debug(LOG, "REQUEST_CAPTION_TRACKS received", { videoId: vid });
        if (!vid) {
          console.warn(LOG, "REQUEST_CAPTION_TRACKS: no video ID \u2014 sending CAPTION_ERROR");
          send({ type: "CAPTION_ERROR", error: "No video element found", code: "NO_VIDEO" });
          return;
        }
        if (cachedTracks && cachedVideoId === vid) {
          console.debug(LOG, "REQUEST_CAPTION_TRACKS: serving from cache", { trackCount: cachedTracks.length });
          send({ type: "CAPTION_TRACKS_RESULT", tracks: cachedTracks, videoId: vid });
          return;
        }
        const pr = getPlayerResponse();
        if (!pr) {
          console.warn(LOG, "REQUEST_CAPTION_TRACKS: playerResponse unavailable \u2014 returning empty tracks");
          send({ type: "CAPTION_TRACKS_RESULT", tracks: [], videoId: vid });
          return;
        }
        const { tracks } = extractCaptionTracks(pr);
        cachedTracks = tracks;
        cachedVideoId = vid;
        console.info(LOG, "REQUEST_CAPTION_TRACKS: extracted tracks", {
          trackCount: tracks.length,
          tracks: tracks.map((t) => `${t.languageCode} (${t.kind})`)
        });
        send({ type: "CAPTION_TRACKS_RESULT", tracks, videoId: vid });
        break;
      }
      case "REQUEST_TRANSLATED_CAPTIONS": {
        const targetLang = typeof data.targetLanguage === "string" ? data.targetLanguage : "";
        console.debug(LOG, "REQUEST_TRANSLATED_CAPTIONS received", { targetLang });
        if (!cachedTracks?.length) {
          console.warn(LOG, "REQUEST_TRANSLATED_CAPTIONS: no tracks loaded \u2014 sending CAPTION_ERROR");
          send({ type: "CAPTION_ERROR", error: "No tracks loaded", code: "NO_TRACKS" });
          return;
        }
        const track = cachedTracks.find((t) => t.isTranslatable) ?? cachedTracks[0];
        if (!track) {
          console.warn(LOG, "REQUEST_TRANSLATED_CAPTIONS: no usable track");
          send({ type: "CAPTION_ERROR", error: "No usable track", code: "NO_TRACKS" });
          return;
        }
        console.debug(LOG, "REQUEST_TRANSLATED_CAPTIONS: fetching from track", {
          trackLang: track.languageCode,
          trackKind: track.kind,
          targetLang
        });
        void fetchCaptions(track.baseUrl, targetLang, track.languageCode).then((segments) => {
          console.info(LOG, "TRANSLATED_CAPTIONS_RESULT", { language: targetLang, segmentCount: segments.length });
          send({ type: "TRANSLATED_CAPTIONS_RESULT", segments, language: targetLang });
        }).catch((err) => {
          const msg = err instanceof Error ? err.message : String(err);
          console.error(LOG, "fetchCaptions failed", { targetLang, error: msg });
          send({ type: "CAPTION_ERROR", error: `Failed to fetch captions: ${msg}`, code: "FETCH_ERROR" });
        });
        break;
      }
      case "START_VIDEO_TIME_MONITOR":
        console.debug(LOG, "START_VIDEO_TIME_MONITOR");
        startVideoTimeMonitor();
        break;
      case "STOP_VIDEO_TIME_MONITOR":
        console.debug(LOG, "STOP_VIDEO_TIME_MONITOR");
        stopVideoTimeMonitor();
        break;
    }
  });
})();
